# P21 English manuscript — final freeze

**Artifact ID:** `P21-MANUSCRIPT-EN-FINAL-20260908-v1`  
**Date:** 8 September 2026  
**Japanese source freeze:** `P21-MANUSCRIPT-JA-FINAL-20260908-v1`

## Status

### Mathematics

\[
\boxed{\textbf{P21 CLOSED}}
\]

under the canonical hypothesis stated in the manuscript.

### English manuscript

\[
\boxed{\textbf{DUAL-INDEPENDENT-AUDIT REVIEWED}}
\]

### Final English status

\[
\boxed{\textbf{ENGLISH MANUSCRIPT FINAL FREEZE}}
\]

The two blind English audits agree that the mathematics and translation force are intact. The only accepted post-audit changes are the zero-mathematics EN-01–EN-08 English/presentation/packaging repairs documented in `DUAL_ENGLISH_AUDIT_RECONCILIATION.md` and `ENGLISH_FINAL_EDITORIAL_CHANGELOG.md`.

## Principal files

- `P21_MANUSCRIPT_EN_FINAL.md` — final English reading copy.
- `P21_MANUSCRIPT_EN_FINAL.tex` — final neutral preprint LaTeX source.
- `P21_MANUSCRIPT_EN_FINAL.pdf` — final built manuscript (98 pages).
- `source/` — authoritative final English Markdown source by section/appendix.
- `appendices/`, `sections/` — build-facing mirrors and generated TeX.
- `supplement/APPENDICES/` — frozen static coefficient tables and unchanged proof verifiers.
- `bibliography/references.bib` — bibliography used by the final build.
- `DUAL_ENGLISH_AUDIT_RECONCILIATION.md` — reconciliation of the two blind audits.
- `ENGLISH_FINAL_EDITORIAL_CHANGELOG.md` — authorized zero-math edits.
- `ENGLISH_FINAL_FREEZE_DIFF_REPORT.md` — authorized diff classification.
- `ENGLISH_FINAL_REGRESSION_REPORT.md` — full final regression.
- `SHA256SUMS.txt` — canonical distribution manifest.
- `provenance/` — **non-normative provenance/build evidence**, including the two blind audits, the audited draft-stage reports, input hashes, authorized patch, and final build logs.

## Final regression headline

```text
Mathematical changes: 0
Translation-force changes: 0
Display math: 791/791
Equation tags: 229/229
Dependency nodes: 42/42
CENTRAL EXHAUSTION: COMPLETE
CHAIN → CENTRAL scope: PASS
D-linear: PASS — 28/28, 715, c0=35
Euclidean: PASS — 35/35, 3234, c0=63
Build errors: 0
Undefined refs/cites: 0/0
Broken links: 0
Duplicate anchors: 0
Missing glyphs: 0
Overfull boxes: 0
MATH-RESIZE: 0
Unauthorized mathematical diff: 0
```

## Non-mutating proof-data verification

The documented distribution check does **not** rewrite files covered by the canonical manifest. It copies the unchanged symbolic verifier directories into a temporary directory and runs them there:

```bash
python3 supplement/verify_distribution.py
```

Expected headline:

```text
[D-linear] ... PASS ... 28 ... 715 ... 35
[Euclidean] ... PASS ... 35 ... 3234 ... 63
[distribution] PASS — canonical package not modified
```

## Rebuild policy

The final ZIP is a read-only distribution master. If rebuilding the manuscript, work on a copy so the canonical manifest remains meaningful. For example:

```bash
cp -a P21_MANUSCRIPT_EN_FINAL_20260908 /tmp/P21_MANUSCRIPT_EN_FINAL_20260908-work
cd /tmp/P21_MANUSCRIPT_EN_FINAL_20260908-work
python3 supplement/typeset_english.py
xelatex -interaction=nonstopmode -halt-on-error P21_MANUSCRIPT_EN_FINAL.tex
bibtexu P21_MANUSCRIPT_EN_FINAL
xelatex -interaction=nonstopmode -halt-on-error P21_MANUSCRIPT_EN_FINAL.tex
xelatex -interaction=nonstopmode -halt-on-error P21_MANUSCRIPT_EN_FINAL.tex
```

## Authority order

1. frozen mathematics in `supplement/frozen_source/`;
2. frozen Japanese final snapshot in `supplement/ja_source_snapshot/`;
3. final English source in `source/`;
4. audit editorial recommendations only insofar as incorporated by the authorized EN-01–EN-08 freeze.

No audit recommendation is allowed to change mathematics.

## Not yet claimed

- journal peer review;
- acceptance;
- proof-assistant formalization;
- final priority/novelty verification;
- journal-template production.

The next phase is **final literature / priority sweep → journal selection → submission package**. It is intentionally outside this freeze.
