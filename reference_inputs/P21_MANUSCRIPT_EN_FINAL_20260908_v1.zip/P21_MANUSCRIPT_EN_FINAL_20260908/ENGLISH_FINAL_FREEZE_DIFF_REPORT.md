# English final-freeze authorized diff report

**Baseline:** audited `P21_MANUSCRIPT_EN_20260908` English draft  
**Final:** `P21-MANUSCRIPT-EN-FINAL-20260908-v1`

The complete authoritative-source patch is preserved at:

`provenance/AUTHORIZED_FINAL_FREEZE.patch`

## Changed authoritative source files

| File | Authorized classes |
|---|---|
| `source/sections/02.md` | EN-05, EN-07 |
| `source/sections/03.md` | EN-06 |
| `source/sections/04.md` | EN-04, EN-05 |
| `source/sections/05.md` | EN-01, EN-06 |
| `source/sections/08.md` | EN-03, EN-06 |
| `source/sections/09.md` | EN-02 |
| `source/sections/10.md` | EN-06 |
| `supplement/typeset_english.py` | freeze metadata / output naming only |

The build-facing root mirrors were synchronized with the authoritative `source/` files and regenerated TeX. The final mirror regression found **0 source/mirror differences**.

## EN-06 layout-only display changes

The raw text of ten display instances differs from the draft because of the seven authorized layout wrappers, the EN-02 source-brace repair, the EN-03 defensive typography, and G4.9 punctuation/packaging. After normalization that removes only authorized layout wrappers and language inside `\text{}`, the comparison gives:

```text
semantic display differences, final vs audited English draft: 0
semantic display differences, final vs frozen Japanese final: 0
```

The exact equation-tag sequence is unchanged: **229/229**.

## Classification of non-source changes

- **EN-08:** `provenance/` segregation and `supplement/verify_distribution.py` non-mutating wrapper.
- **freeze metadata:** final-freeze ID, title metadata, and principal output filenames.
- **generated build artifacts:** final Markdown, TeX, PDF, generated section/appendix TeX, reproducibility logs.
- **final-freeze documentation:** reconciliation, changelog, diff report, regression report, README, input hashes, final manifest.

## Forbidden-change audit

```text
changed signs:                 0
changed inequalities:          0
changed quantifiers:           0
changed mathematical ranges:   0
changed equation tags:         0
changed hypotheses:            0
changed conclusions:           0
changed proof dependencies:    0
changed actual/signed status:  0
changed criticality scope:     0
```

\[
\boxed{\textbf{UNAUTHORIZED MATHEMATICAL CHANGES}=0.}
\]
