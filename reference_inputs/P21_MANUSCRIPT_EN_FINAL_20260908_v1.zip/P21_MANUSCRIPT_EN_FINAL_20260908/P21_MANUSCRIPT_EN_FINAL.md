# The type of four-generated numerical semigroups with canonical reduction

English manuscript final freeze — 8 September 2026

Draft ID: `P21-MANUSCRIPT-EN-FINAL-20260908-v1`

Author name and affiliation: [to be inserted]

## Abstract

Let $\Gamma=\langle m,n_1,n_2,n_3\rangle$ be a numerical semigroup with four minimal generators, where $m$ is its least positive element and $F$ its Frobenius number. Under the canonical-reduction condition $F+m-\varphi\in\Gamma$ for every pseudo-Frobenius number $\varphi$, we prove that the type of $\Gamma$ is at most $4$. The proof combines a two-layer decomposition of the Apéry set, factorization geometry in the three-generated tail, and a Euclidean descent on two packet relations. We prove that the coefficients required for the final exchanges occur within factorizations of the same element, and we provide static full-coefficient certificates for the positivity arguments.


<a id="sec-01"></a>

# 1　Introduction

The type of a numerical semigroup is the number of its pseudo-Frobenius numbers, and it agrees with the Cohen--Macaulay type of the corresponding semigroup ring [[MS21](#ref-MS21)]. In this paper we control this number through the minimal generators and their nonnegative representations. Standard structure theorems are available for three-generated semigroups in both the symmetric and nonsymmetric cases, whereas in embedding dimension four one must relate the three-generated subsemigroup obtained by removing the smallest generator to the gap conditions in the original semigroup.

The condition studied here is canonical reduction. Let $m$ denote the least positive generator and $F$ the Frobenius number. We require $F+m-\varphi\in\Gamma$ for every pseudo-Frobenius number $\varphi$. This semigroup-theoretic formulation appears in §4 of Moscariello--Strazzanti [[MS21](#ref-MS21)]. The corresponding condition for all nonnegative gaps has also been studied under the name positioned [[Branco2021](#ref-Branco2021)]. We use canonical reduction as our primary terminology and prove directly in Section 2 the passage from pseudo-Frobenius numbers to all gaps. For the ring-theoretic background, see Rahimi [[Rahimi2020](#ref-Rahimi2020)].

Our main result is the following.

<a id="fr-T1"></a>

## Type bound for canonical four-generated numerical semigroups

A numerical semigroup is a cofinite subset of the nonnegative integers that contains $0$ and is closed under addition. Let
$$
\Gamma=\langle m,n_1,n_2,n_3\rangle,\qquad
\operatorname{edim}(\Gamma)=4,\qquad m=\min(\Gamma\setminus\{0\})
$$
with all four generators minimal; in particular, $0<m<n_r$. Let
$F=F(\Gamma)=\max(\mathbb Z\setminus\Gamma)$ be the Frobenius number, and define
$$
PF(\Gamma)=\{q\in\mathbb Z\setminus\Gamma:
q+s\in\Gamma\text{ for every }s\in\Gamma\setminus\{0\}\},
\qquad t(\Gamma)=|PF(\Gamma)|
$$
Under the canonical condition
$$
\boxed{F+m-\varphi\in\Gamma\quad(\forall\varphi\in PF(\Gamma))}
\tag{CANONICAL}
$$
one has
$$
\boxed{t(\Gamma)\le4}
$$
The proof is assembled in [I9](#fr-I9).


This statement has the same hypotheses and conclusion as Question 4.4 of Moscariello--Strazzanti and Problem 21 of Moscariello--Sammartano [[MS21](#ref-MS21); [MoscarielloSammartano](#ref-MoscarielloSammartano)]. Throughout the paper, the canonical condition displayed above is used at every stage of the proof.

The proof begins with a two-layer decomposition of the Apéry set. Set $Q(\Gamma)=PF(\Gamma)\setminus\{F\}$, and associate to each $q\in Q(\Gamma)$ the elements $q+m$ and $c_q=F+m-q$. Their nonnegative representations imply that $H=\langle n_1,n_2,n_3\rangle$ is a genuine minimally three-generated numerical semigroup. When $H$ is symmetric, we use a stable ideal and the correspondence between its minimal generators and the Apéry set to obtain the bound.

When $H$ is nonsymmetric, its two pseudo-Frobenius numbers give rise to six arms. The two colors of arms in the same direction have synchronized return levels, while three arms of the same color are excluded using an empty relative-lattice tetrahedron and a finite path inside a box. Combining these constraints with incomparability of the complements reduces four elements selected from a putative counterexample to one of three configurations: a path configuration, a configuration with one singleton, or a chain configuration.

The first two configurations are eliminated by comparing two returns. In the chain configuration, we maximize one coordinate over the finite factorization set of the same element $q_A+m$, thereby constructing a unit-root relation. After treating the boundary and the range in which the relevant packets are available, two exchange relations between nonnegative representations remain. We then perform a Euclidean descent that preserves the same semigroup and the same $W=F+m$ while decreasing the positive integer $E+\chi$. At termination, all coefficients required for the exchange are shown to occur in representations of that same $W$, and removing one copy of $m$ yields the contradiction $F\in\Gamma$.

Sections 2--4 establish the structural reductions and the classification into the three terminal configurations. Sections 5--6 eliminate the configurations involving singletons. Sections 7--10 treat the chain configuration, and Section 11 assembles the main theorem. Appendix A contains the complete case analysis for the symmetric tail, Appendix B gives the relative-lattice and box-path arguments, Appendix C records the positivity expansions, and Appendix D specifies the static full-coefficient certificates. The complete coefficient tables for the two large identities are required supplementary proof data, and their coefficient checks are computer-assisted. The argument does not rely on a finite-range scan of numerical semigroups or on a complete formalization in a proof assistant.


<a id="sec-02"></a>

# 2　Preliminaries and canonical reduction

We fix the hypotheses of the main theorem. In this section, the canonical condition is converted into an involution on the Apéry set and into nonnegative representations in the supported directions. Under the assumption of a counterexample, we also prove coprimality and minimality for the three-generated tail. The objects passed to the later classification are the same semigroup, the same $F,m,W$, and actual pseudo-Frobenius numbers.

## Common notation and scope of the contradiction argument

$$
Q(\Gamma)=PF(\Gamma)\setminus\{F\},\qquad W=F+m,
\qquad H=\langle n_1,n_2,n_3\rangle,
$$
$$
\mathcal A=\operatorname{Ap}(\Gamma,m)
=\{w\in\Gamma:w-m\notin\Gamma\}.
$$
Since $F\in PF(\Gamma)$, we have $t=|Q(\Gamma)|+1$. From now on the contradiction hypothesis is $|Q(\Gamma)|\ge4$. Selecting four rows does not mean that the total number of elements of $Q$ is fixed to be four. We write $x\le_\Gamma y$ when $y-x\in\Gamma$. For each $q\in Q(\Gamma)$, define its complement by $c_q=W-q$.

In the nonsymmetric part we use
$$
SH(q)=\{r:q+n_r\in H\},\qquad D(c)=\{r:c-n_r\in H\}.
$$
The set $Q(\Gamma)$ and a local integer denoted by $Q$ are distinguished by type and by the point at which they are defined. Likewise, the two-generated semigroup $T$ in the symmetric case and the matrix $C$ in an appendix are local notation and should not be confused with the canonical CHAIN coefficient $T=b_k+\alpha$ or the root coefficient $C$.

## Standard external results used in the proof

The proof uses the following three standard results as external input, in exactly the forms stated here.

These results are not proved in this paper. We retain the bibliographic information for the original sources, and we have checked the precise locations in the supporting references used here. We do not assert unverified theorem numbers in the historical originals.

<a id="ext-STD_SYM_GLUE"></a>

### Representation of symmetric three-generated semigroups

After permuting the generators, every minimally three-generated symmetric numerical semigroup can be written as
$H=\langle du,dv,w\rangle$, with $d,u,v\ge2$,
$\gcd(u,v)=\gcd(d,w)=1$, and $w\in\langle u,v\rangle$.
This is the form corresponding to the three-generated complete-intersection theory of Herzog and Delorme; the direction used here is stated explicitly in García-Sánchez--Martín Cruz, §3.2, Theorem 6 [[Herzog1970](#ref-Herzog1970); [Delorme1976](#ref-Delorme1976); [GarciaMartin2020](#ref-GarciaMartin2020)].

<a id="ext-STD_HERZOG"></a>

### Standard form for nonsymmetric three-generated semigroups

For every minimally three-generated nonsymmetric numerical semigroup there exist positive integers $a_r,b_r$, with $\rho_r=a_r+b_r$, such that the critical relations, the two pseudo-Frobenius numbers, and the formulas for the primitive tail generators given below hold. The precise forms used here follow Nari--Numata--Watanabe, §1, equation (1.1), and §2, equation (2.1.1) and Propositions 2.1--2.2 [[Herzog1970](#ref-Herzog1970); [Nari2011](#ref-Nari2011)]. Pairwise coprimality of the three generators is not assumed.

<a id="ext-STD_WHITE"></a>

### Empty lattice tetrahedra

A lattice tetrahedron containing no lattice points other than its vertices has lattice width one. Equivalently, there is a nonconstant primitive integer-valued affine functional that places all four vertices on two consecutive integer levels. We use White's theorem in this form [[White1964](#ref-White1964)]. Khan--Rogers, §1, Theorems 3--4, gives the normal form required here [[Khan2016](#ref-Khan2016)]. The application to the relative lattice, the partition of the vertices into two pairs, and the subsequent coefficient comparisons are all proved in this paper.

We fix the convention for STD_HERZOG in a cyclic order $(i,j,k)$:
$$
\rho_i n_i=b_jn_j+a_kn_k,\quad
\rho_jn_j=a_in_i+b_kn_k,\quad
\rho_kn_k=b_in_i+a_jn_j.
\tag{HCR}
$$
Each $\rho_r$ is the least positive multiple of $n_r$ admitting a nonnegative representation by the other two generators.
$$
f_A=(\rho_i-1)n_i+(a_j-1)n_j-n_k,
\quad f_B=(\rho_i-1)n_i-n_j+(b_k-1)n_k,
\quad PF(H)=\{f_A,f_B\}.
$$
We also use the cyclic versions of these formulas. For a primitive tail,
$$
n_1=a_2a_3+a_3b_2+b_2b_3,\quad
n_2=a_1a_3+a_1b_3+b_1b_3,\quad
n_3=a_1a_2+a_2b_1+b_1b_2.
$$
The later cross-product comparisons retain any positive common scale.

## Symmetry operations

A cyclic permutation acts simultaneously on all indices. Color reversal is the combination of an odd permutation and the interchange of all $a$- and $b$-parameters. The operation reversing the pivot in PATH and the operation interchanging $j$ and $k$ in CHAIN are given with their full parameter transformations in P5, [R7](#fr-R7), and [E8](#fr-E8), respectively. These operations leave $\Gamma,F,m,W$ and the set of actual pseudo-Frobenius elements unchanged.

## Discipline for representations and proof steps

An actual factorization is a representation by the generators with all coefficients nonnegative integers. A signed equality or a completed zero identity is not, by itself, an actual factorization. Whenever the final contradiction uses a coefficient vector, its nonnegativity is stated explicitly. Herzog criticality is applied only after the coefficient of $m$ has been completely eliminated, so that the relation lies entirely in $H$. A support replacement is performed only when the source occurs coefficientwise within an explicitly identified factorization of the same actual element. Every extremal choice used below is accompanied by the underlying finite set or well-ordering argument.

<a id="notation-scope"></a>

## Scope of notation

For traceability to the source notation, we do not globally rename the principal symbols. The following symbols have local scopes and should not be identified across the different rows of the table.

| Symbol | Principal scope and meaning |
|---|---|
| $Q$ | In Section 2, $Q(\Gamma)=PF(\Gamma)\setminus\{F\}$ is a set. In Section 8, $Q=U_j+1$; in the latter part of D in Section 9, $Q=\tau_0$ is a local integer. |
| $H$ | Throughout, the three-generated tail $H=\langle n_1,n_2,n_3\rangle$. In Section 10, $H_p=T+w$ is a local packet coefficient. |
| $C$ | In Sections 7--9, the $n_k$-coefficient of the CORE-ROOT. In Appendix B, a $3\times3$ matrix $C$. |
| $T$ | In CHAIN/CENTRAL, $T=b_k+\alpha$. In Section 3 and Appendix A, $T=\langle u,v\rangle$ is the two-generated semigroup in the symmetric tail. |
| $A,B$ | In Sections 4--7, labels for the two colors and arm families. In Sections 9--10, capital $A,B$ are local Euclidean-source coefficients. |
| $E$ | A packet coefficient in Sections 9--10: in the initial embedding $E=R+\upsilon$, and in the abstract theorem $E=R+u$. It is distinct from the return labels $EA,EB$. |
| $L,M$ | In Sections 4 and 8, local return levels. In Section 10, the row sums $L=p+q,\ M=s+t$ of the source matrix. |
| $\Delta$ | Not a single global variable. Examples are $\Delta_j,\Delta_k$ in G4 and $\Delta_0$ in CENTRAL; each indexed local difference is read from its point of definition. |
| $\theta$ | Appears in the initial packet of Section 9 as $\theta=Q-fE$ and is then carried unchanged into the Euclidean package in Section 10. |
| $\chi$ | A coefficient from the strict-packet/D analysis in Sections 8--9, embedded as a packet coefficient in Section 10. After a nonterminal transformation, $\chi'=\theta$. |

Reuse of local notation is delimited by the definitions and anchors in the relevant sections. Equation tags, verifier keys, and JSON keys are retained unchanged for traceability.

<a id="fr-C2"></a>

## The two Apéry layers and supported returns

**C2.** Under the canonical condition of Sections 1--2, the following statements hold.

## Common setting

Let $\Gamma=\langle m,n_1,n_2,n_3\rangle$ be a numerical semigroup, with $m$ its multiplicity, $F$ its Frobenius number, $H=\langle n_1,n_2,n_3\rangle$, $W=F+m$, and $\mathcal A=\operatorname{Ap}(\Gamma,m)$. Let $Q(\Gamma)=\operatorname{PF}(\Gamma)\setminus\{F\}$.

The canonical condition is

$$
W-\varphi\in\Gamma\quad(\varphi\in PF(\Gamma)).
$$

Every factorization of an element of $\mathcal A$ contains no copy of $m$, so $\mathcal A\subseteq H$. Moreover $W\in\mathcal A$, and for every $w\in\mathcal A$ one has $w-m\le F$, hence $w\le W$.

<a id="fr-C2.1"></a>

## From the PF condition to the condition for every gap

Let x be a nonnegative gap. Choose the largest integer $\varphi$ in the finite set $(x+\Gamma)\setminus\Gamma$. For every positive $s\in\Gamma$, maximality gives $\varphi+s\in\Gamma$. Thus $\varphi\in PF(\Gamma)$, and $\varphi-x\in\Gamma$.

$$
W-x=(W-\varphi)+(\varphi-x)\in\Gamma.
$$

This direction is therefore obtained directly, without invoking an external positioned-semigroup criterion.

<a id="fr-C2.2"></a>

## Exact two-layer decomposition

For $w\in\mathcal A$, set $b=W-w\ge0$. If $w=0$, then $b=W\in\mathcal A$. If $w>0$, then $x=w-m$ is a nonnegative gap, so the preceding subsection gives $b+m=W-x\in\Gamma$.

- If $b\in\Gamma$, then $b-m\in\Gamma$ would imply $w+(b-m)=F\in\Gamma$, so $b\in\mathcal A$. In this case $b+m\notin\mathcal A$.
- If $b\notin\Gamma$, then $b+m\in\Gamma$ and $(b+m)-m=b\notin\Gamma$, so $b+m\in\mathcal A$.

Thus exactly one of the following holds: $W-w\in\mathcal A$ or $W+m-w\in\mathcal A$.

$$
\mathcal A_0=\{w\in \mathcal A:W-w\in \mathcal A\},\qquad \mathcal A_1=\mathcal A\setminus \mathcal A_0.
$$

If $x\le_\Gamma y$ and $y\in\mathcal A_0$, then $W-x=(W-y)+(y-x)\in\Gamma$. Since its sum with the Apéry element $x$ is $W$, one has $W-x\in\mathcal A$. Hence $\mathcal A_0$ is a lower ideal and $\mathcal A_1$ an upper filter.

On $\mathcal A_1$, the map $\iota(w)=W+m-w$ again takes values in $\mathcal A_1$; moreover $\iota^2=\mathrm{id}$ and $\iota(x)-\iota(y)=y-x$. Thus $\iota$ is an order-reversing involution.

The maximal elements of the Apéry set are $PF+m$. Indeed, if $q\in PF$, then $q+m\in\mathcal A$; if a larger Apéry element differed from it by $s>0$ in $\Gamma$, then $q+s\in\Gamma$, a contradiction. Conversely, if $w\in\mathcal A$ is maximal, then $q=w-m$ is a gap, and if $q+s$ were a gap for some positive $s\in\Gamma$, then $w+s\in\mathcal A$, contrary to maximality.

If $q\in Q$, then $q<F$. The inclusion $q+m\in\mathcal A_0$ would give $W-(q+m)=F-q\in\Gamma\setminus\{0\}$, contradicting maximality. Together with the fact that $\mathcal A_1$ is an upper filter, this yields

$$
\operatorname{Max}\mathcal A_1=(PF\setminus\{F\})+m,
$$
$$
\operatorname{Min}\mathcal A_1=\{W-q:q\in Q\},\qquad
|\operatorname{Min}\mathcal A_1|=|Q|=t-1.
$$

Moreover, $\mathcal A_0=\{h\in H:W-h\in H\}$. For an element $h$ on the right, if $h-m\in\Gamma$ then $F=(h-m)+(W-h)\in\Gamma$, so $h\in\mathcal A$.

<a id="fr-C2.3"></a>

## KEY: direct proof of the support-zero return

Let $q\in Q$ and $c=W-q\in\Gamma$, and choose a direction $i$ for which $c-n_i\in H$. The pseudo-Frobenius property gives $q+n_i\in\Gamma$.

If $q+n_i-m\in\Gamma$, then

$$
F=(c-n_i)+(q+n_i-m)\in\Gamma,
$$

a contradiction. Therefore

$$
q+n_i\in \mathcal A\subset H.
$$

If a genuine $H$-factorization of this element had positive $n_i$-coefficient, removing one copy of $n_i$ from that same factorization would put $q$ in $\Gamma$. Hence

$$
\boxed{c-n_i\in H\ \Longrightarrow\ q+n_i\in\langle n_j,n_k\rangle.}
$$

Since $c=W-q>0$ lies in $H$, the set $D(c)$ is nonempty. Thus, with the conventions $D(c)=\{i:c-n_i\in H\}$ and $SH(q)=\{i:q+n_i\in H\}$, one has $\varnothing\ne D(c)\subseteq SH(q)$. **Equality is not asserted.** No Hall-type existence theorem, factorization uniqueness, or generic connectivity is needed.

Furthermore, $c-m=F-q$ is positive and does not lie in $\Gamma$, so $c\in\mathcal A$. Also $x=c-n_i\in\mathcal A$, since $x-m\in\Gamma$ would imply $c-m\in\Gamma$. With $y=q+n_i$ and $h=q+m$,

$$
h,c,x,y\in H\cap \mathcal A,\quad h+c=W+m,\quad x+y=W.
$$

This conclusion is obtained separately for each supported direction. The classification of rows is carried out in G4.

<a id="fr-C2.4"></a>

## Tail gcd firewall

Assume $Q\ne\varnothing$, and choose $q\in Q$. Then $q+m,W,c=W-q$ all lie in $\mathcal A\subseteq H$. Hence

$$
m=(q+m)+(W-q)-W\in\mathbb ZH.
$$

Let $d=\gcd(n_1,n_2,n_3)$. Then $d$ also divides $m$. Since $\Gamma$ is a numerical semigroup, $\gcd(m,n_1,n_2,n_3)=1$, and therefore $d=1$.

The signed equality above is used only in the group $\mathbb ZH$; it is not called a nonnegative factorization.

<a id="fr-C2.5"></a>

## Selection of four rows and minimality of the tail

Under the contradiction hypothesis, we may choose four distinct elements $q_1,q_2,q_3,q_4\in Q(\Gamma)$. The Apéry and KEY statements above hold for all of $Q$, hence simultaneously for these four selected rows. If one tail generator were a nonnegative combination of the other two, that generator would also be redundant in $\Gamma$, contradicting $\operatorname{edim}\Gamma=4$. Thus the tail is minimally generated. By [C2.4](#fr-C2.4), its gcd is one. Hence $H$ is a genuine minimally three-generated numerical semigroup, and it is either symmetric or nonsymmetric.


<a id="sec-03"></a>

# 3　The symmetric three-generated tail

We treat the case in which the minimally three-generated tail obtained in the previous section is symmetric. The main text establishes the correspondence between a stable ideal and the Apéry set, and Appendix A excludes the possibility that all four candidates survive by a complete case analysis. The two-generated semigroup $T=\langle u,v\rangle$ and the coefficient notation in this section are local to this section and Appendix A.

<a id="fr-S3"></a>

## Exclusion of the symmetric tail

Let $\Gamma=\langle m,x,y,z\rangle$ be a minimally four-generated numerical semigroup, with multiplicity $m$. Assume that $H=\langle x,y,z\rangle$ is symmetric and that
$$
m+F(\Gamma)-q\in\Gamma\qquad(q\in PF(\Gamma))
\tag{CAN}
$$
Then $t(\Gamma)\le4$.

From now on write $F=F(\Gamma)$, $f=F(H)$, and $Q=PF(\Gamma)\setminus\{F\}$. A minimal generator of an ideal of a semigroup means an element from which no positive semigroup element can be subtracted while remaining in the ideal.

<a id="fr-S3.2"></a>

## Stable core and the exact bridge

$$
K=\{a\in H:a+nm\in H\ (n\ge0)\},\qquad h=\min K.
$$
By symmetry and $\Gamma=H+\mathbb N m$, for every integer $t$,
$$
t\notin\Gamma\iff f-t\in K.
\tag{GAP-K}
$$
Hence $F=f-h$. Since $0\notin K$ (because $m\notin H$), we have $h\ge\min(H\setminus\{0\})>m$. Put
$$
r=h-m=f-F-m>0,\qquad r+nm\in H\quad(n\ge1).
\tag{FS}
$$
The set $K$ is a $\Gamma$-ideal, and GAP-K shows that $q\mapsto f-q$ is a bijection from $PF(\Gamma)$ onto $\operatorname{Min}_\Gamma K$. Applying CAN to these minimal generators gives
$$
J:=K-r\subseteq\Gamma,\qquad \min J=m,\qquad m\in J.
$$
Set
$$
I_r=\{c\in H:c+r\in H\}
$$
By FS, $c\in I_r\Rightarrow c+r\in K$, and therefore $J\cap H=I_r$.

We now prove directly that
$$
\operatorname{Min}_\Gamma J
=\{m\}\sqcup(\operatorname{Min}_H I_r\cap\operatorname{Ap}(\Gamma,m)).
\tag{BRIDGE}
$$
Let $j\in\operatorname{Min}_\Gamma J\setminus\{m\}$. If $j-m\in\Gamma$, then $j=m+(j-m)$, contrary to $m\in J$ and the minimality of $j$. Hence $j$ lies in the Apéry set, and its factorizations contain no $m$, so $j\in H$. Minimality in $H$ follows from minimality in $\Gamma$.

Conversely, let $c\in\operatorname{Min}_H I_r\cap\operatorname{Ap}$. Since $J\subseteq\Gamma$, one has $c-m\notin J$. If $c-n\in J$ for some $n\in\{x,y,z\}$, then $c-n\in\Gamma$ and $c-n-m\notin\Gamma$, so $c-n\in H$, hence $c-n\in J\cap H=I_r$. This contradicts minimality in $H$, proving the reverse inclusion.

Thus
$$
t(\Gamma)=1+|\operatorname{Min}_H I_r\cap\operatorname{Ap}|.
\tag{TYPE-BRIDGE}
$$
We now assume $t\ge5$ and derive a contradiction.

<a id="fr-S3.3"></a>

## Exact classification of RAW4

By the standard complete-intersection classification, after permuting the generators we may write
$$
x=du,\quad y=dv,\quad z=w,\quad H=\langle du,dv,w\rangle,
\quad \gcd(u,v)=\gcd(d,w)=1,\quad w\in T.
$$
Since $H$ is minimally three-generated, $d,u,v\ge2$. Every integer has a unique expression $jw+dt$, with $0\le j<d$, and membership in $H$ is equivalent to $t\in T$. Consequently
$$
f=(d-1)w+dF_T.
$$
Write $r=sw+d\rho$, with $0\le s<d$. If $s=0$, the raw minima of $I_r$ occur only in the layer $j=0$, and the two-generated lemma below gives at most two of them. Henceforth assume $1\le s\le d-1$. The only layers containing raw minima of $I_r$ are $j=0$ and $j=d-s$, coming respectively from the $T$-minima of
$$
J_0=\{t\in T:t+\rho\in T\},\quad J_1=\{t\in T:t+\rho+w\in T\}
$$
Every other layer allows one copy of $w$ to be subtracted.

For every $\eta=pu+qv$, $0\le q<u$, the set $\{t\in T:t+\eta\in T\}$ has at most two generators. Indeed, writing $t=au+bv$, $0\le b<u$, the required threshold for $a$ takes only the two values
$$
\max(0,-p)\quad(b<u-q),\qquad \max(0,-p-v)\quad(b\ge u-q)
$$
The two minima are distinct and incomparable exactly when $0<q<u,-v<p<0$. In that case, putting
$$
A=-p, C=q, B=u-q, D=v+p,\quad A+D=v, B+C=u,
$$
the minima are $Au$ and $Bv$, and their images are $Cv$ and $Du$.

Hence $|\operatorname{Min}_H I_r|\le4$. Since $t\ge5$, TYPE-BRIDGE implies that all four minima exist and all four remain in the Apéry set. With positive integers $A,B,C,D$ and their primed versions, the four pairs are
$$
(c_x,a_x)=(Ax,sw+Cy),\quad(c_y,a_y)=(By,sw+Dx),
$$
$$
(c'_x,a'_x)=((d-s)w+A'x,C'y),\quad
(c'_y,a'_y)=((d-s)w+B'y,D'x),
\tag{RAW4}
$$
where in every case $a=c+r$, $A+D=A'+D'=v$, and $B+C=B'+C'=u$. Moreover
$$
\rho=uv-Au-Bv=-Au+Cv=-Bv+Du.
$$

<a id="fr-S3.4"></a>

## Cross-layer rigidity and actual pseudo-Frobenius input

If $A'\ge A$, then $c'_x-c_x=(d-s)w+(A'-A)x\in H$, contradicting raw incomparability. Hence $\alpha:=A-A'>0$. Similarly $\beta:=B-B'>0$. Subtracting the threshold formulas for the two layers gives
$$
\begin{aligned}
w&=\alpha u+\beta v,\quad A'=A-\alpha>0,\quad B'=B-\beta>0,\\
C'&=C+\beta,\quad D'=D+\alpha.
\end{aligned}
\tag{CROSS-LAYER}
$$

By BRIDGE, the four raw rows correspond to actual pseudo-Frobenius rows $q=f-a$. In particular,
$$
c_x-m,c_y-m,c'_x-m,c'_y-m\notin\Gamma.
\tag{ALL-AP}
$$
If $a_x-m\in H$, then $a_x\in K$ implies $a_x-m\in K$; applying CAN would then give $c_x-m\in\Gamma$, impossible. The same argument applies on the $y$-side. By symmetry of $H$,
$$
q_x+m,q_y+m\in H.
\tag{QM}
$$

<a id="fr-S3.5"></a>

## Complete division into Branch I and Branch II

Write $m=ew+d\mu$, with $0\le e<d$. Since $m\notin H$, $\mu\notin T$. Put $\ell=d-1-s$ and
$$
k_0=\left\lfloor\frac{\ell+e}{d}\right\rfloor\in\{0,1\},
\qquad\theta=\mu+k_0w
$$
From the representation of $f$,
$q_x=\ell w+d((B-1)v-u)$ and $q_y=\ell w+d((A-1)u-v)$. Thus QM becomes
$$
\theta+(B-1)v-u\in T,\qquad\theta+(A-1)u-v\in T.
$$
Applying 2GI to $X=\theta+(A-1)u+(B-1)v$ gives
$$
\theta-u-v\in T\qquad\text{or}\qquad\theta-\rho-u-v\in T.
\tag{SPLIT}
$$
We call the left condition Branch I and the right condition Branch II. Their possible overlap causes no difficulty. We first exclude Branch I.

<a id="sym-branches"></a>

### Two-generated calculations and completion of the case analysis

The normal form and intersection formula for the two-generated semigroup used here are proved in [S3.1](#fr-S3.1) of Appendix A. It remains to exclude the assumption that all four raw minima survive in the Apéry set. The two conditions in SPLIT cover the entire range. Allowing overlap, contradictions are obtained in the following order.

| Condition | Constraint obtained from the same element | Location of the contradiction |
|---|---|---|
| Branch I | The same stable walk hits all four sets $U_x,U_y,Z_x,Z_y$ | [S3.6](#fr-S3.6)--[S3.7](#fr-S3.7) |
| Branch II, $k_0=1$ | Backward points of the two D-rows and the two-generated intersection formula | [S3.8](#fr-S3.8): reduction to Branch I |
| Branch II, $k_0=0,e=0$ | The first stable coordinate is negative | [S3.9](#fr-S3.9) |
| Branch II, $k_0=0,e>0$ | The cross-core complement identity and the actual predecessor | [S3.10](#fr-S3.10): contradiction to the pseudo-Frobenius property |

In Branch I, we first separate the case in which the return index is one. If both rectangle hits were later returns, the first stable point would be a gap, so at least one of them must be the first return. Classifying that point as X-only, Y-only, or XY, the first two possibilities lack the required $U_x$ or $U_y$ hit, respectively, while in the XY case the second stable point is a gap. The key point in this branch is not to apply to the first return a predecessor constraint that is valid only for later returns.

For Branch II with $k_0=1$, we first establish positivity of the auxiliary quantity and then move backward along the two D-rows. Since both backward points are gaps, symmetry of the two-generated semigroup and the intersection formula imply the Branch I condition. When $k_0=0$, the case $e=0$ is excluded directly. For $e>0$, we distinguish whether a carry occurs. Either the complement representation lies in the semigroup or the actual immediately preceding stable point is a gap; in the final step this contradicts the pseudo-Frobenius property of the same $q_x$.

All of these calculations are given in Appendix A. Therefore the four raw minima cannot all remain in the Apéry set, and the assertion for the symmetric tail follows from BRIDGE.


<a id="sec-04"></a>

# 4　Nonsymmetric factorization geometry and classification into three terminal configurations

Assume that the three-generated tail is nonsymmetric. We first classify the supported directions of a pseudo-Frobenius element into six arms, then establish coexistence restrictions for pairs of rows and exclude three arms of the same color. Finally, we exhaust the possibilities for four distinct rows selected from a putative counterexample and obtain three terminal configurations with their exact coefficient ranges.

<a id="fr-G4.1"></a>

## Common setting

Let $\Gamma=\langle m,n_i,n_j,n_k\rangle$, let $m$ be the multiplicity, let $F=F(\Gamma)$, $W=F+m$, and $H=\langle n_i,n_j,n_k\rangle$. Canonical reduction gives

$$
q\in Q:=PF(Γ)\setminus\{F\}\Longrightarrow c_q=W-q\in Γ
$$

For every actual $q$, we have $q+m,c_q\in H$, $c_q-m\notin\Gamma$, and $q\notin\Gamma$, by the elementary canonical lemmas.

$$
SH(q)=\{r:q+n_r\in H\},\qquad D(c)=\{r:c-n_r\in H\}.
$$

KEY says $\varnothing\ne D(c_q)\subseteq SH(q)$; equality is not assumed. The KEY implication itself follows directly: if $q+n_r-m\in\Gamma$, then $F=(c_q-n_r)+(q+n_r-m)\in\Gamma$, a contradiction.

For a cyclic order (i,j,k), we use the Herzog convention

$$
ρ_i=a_i+b_i,\quad ρ_in_i=b_jn_j+a_kn_k,
$$
$$
ρ_jn_j=a_in_i+b_kn_k,\qquad ρ_kn_k=b_in_i+a_jn_j,
\tag{H}
$$

where all $a_r,b_r$ are positive integers and $ρ_r$ is the critical multiplier of $n_r$ in $H$.

By KEY, $SH(q)$ is nonempty. A row with $SH(q)=\{r\}$ is called a singleton $S_r$; a row with $|SH(q)|=2$ is called a doubleton; and a row with $SH(q)=\{i,j,k\}$ is called a corner. For a doubleton, the missing direction $r$ is defined by $r\notin SH(q)$. The six-arm atlas for doubletons is given in [G4.1.1](#fr-G4.1.1):

$$
A_r(λ)=f_A-λn_r\quad(1≤λ≤a_r-1),
$$
$$
B_r(μ)=f_B-μn_r\quad(1≤μ≤b_r-1).
$$

The exact formulas for the pseudo-Frobenius corners, including all three cyclic representations, are

$$
f_A=(ρ_i-1)n_i+(a_j-1)n_j-n_k
      =-n_i+(ρ_j-1)n_j+(a_k-1)n_k,
$$
$$
f_B=(ρ_i-1)n_i-n_j+(b_k-1)n_k,
\qquad f_A-f_B=a_jn_j-b_kn_k.
\tag{PF}
$$

Two rows on the same arm, and a corner together with an arm of the same color, contradict the pseudo-Frobenius antichain property. There is at most one lower corner with triple support. A higher corner would give $F(H)\ge F(Γ)$ while its corresponding $q$ must satisfy $q<F(Γ)$, a contradiction.

<a id="fr-G4.1.1"></a>

### Short proof of the six-arm atlas

Assume $q\notin H$, $q+n_j,q+n_k\in H$, and $q+n_i\notin H$. Choose the largest integer $\ell\ge0$ such that $q+\ell n_i\notin H$. It exists because $H$ is a numerical semigroup, and $\ell\ge1$ because $q+n_i\notin H$. Then $f=q+\ell n_i$ satisfies $f+n_i\in H$; moreover, adding $\ell n_i$ to $q+n_j,q+n_k\in H$ gives $f+n_j,f+n_k\in H$. Hence $f\in PF(H)=\{f_A,f_B\}$.

Suppose first that $f=f_A$ and $\ell\ge a_i$. The canonical formula is
$$
q+n_j=(a_i-ℓ-1)n_i+(ρ_k-1)n_k.
$$
Comparing this with a genuine H-factorization $Xn_i+Yn_j+Zn_k$ gives
$$
(ρ_k-1-Z)n_k=(ℓ-a_i+1+X)n_i+Yn_j.
$$
The right-hand side is positive, so the coefficient on the left is positive and is strictly less than $ρ_k$, contradicting criticality. Thus $1\le\ell\le a_i-1$.

If $f=f_B$, the same argument, using $q+n_k=(b_i-\ell-1)n_i+(ρ_j-1)n_j$, gives $\ell\le b_i-1$.

Conversely, for $A_i(λ)$, $1\le λ\le a_i-1$,
$$
q+n_j=(a_i-λ-1)n_i+(ρ_k-1)n_k\in H,
$$
$$
q+n_k=(ρ_i-λ-1)n_i+(a_j-1)n_j\in H.
$$
If either $q$ or $q+n_i$ belonged to $H$, adding the missing nonnegative multiple of $n_i$ would put $f_A$ in $H$, impossible. Thus both are gaps. The B-case follows from the corresponding two canonical formulas. The color and the depth are uniquely determined by the maximal $\ell$ above.

This proves the six-arm atlas from STD_HERZOG.

<a id="fr-G4.2"></a>

## Basic actual antichain and coefficient constraints

For distinct pseudo-Frobenius rows $q,q'$, neither $q-q'$ nor $q'-q$ lies in $\Gamma$. Hence distinct complements $c,c'$ also form a $\Gamma$-antichain.

For a singleton $S_r$, KEY implies $c_S=κ_r n_r$. If some H-factorization of $c_S$ used another direction, then $D(c_S)\subseteq\{r\}$ would fail. If $κ_r\geρ_r$, relation (H) would provide such a factorization in the other directions. Therefore

$$
1≤κ_r≤ρ_r-1.
\tag{SR}
$$

There cannot be two singletons in the same direction, by comparability along the pure ray. If $S_r$ exists, then in every H-factorization of every other complement the $r$-coordinate is at most $κ_r-1$. Otherwise $c-κ_rn_r\in H$, contradicting the complement antichain; if the difference were zero, the two rows would coincide.

Likewise, every H-factorization of $W$ has $r$-coordinate at most $κ_r-1$: if it contained $κ_r$ copies, removing them would put $q_S$ in $H$. Since $q_S+n_r\in H$, the maximum $κ_r-1$ is attained.

The complement of an arm missing direction $i$ uses no copy of $n_i$ and has the form

$$
c=y n_j+z n_k,\qquad 0≤y<ρ_j,\quad0≤z<ρ_k.
\tag{CB}
$$

Indeed, if $y\geρ_j$ or $z\geρ_k$, relation (H) produces a representation involving $n_i$, contradicting KEY. This two-coefficient representation is unique: the difference of two such representations would be a pure relation between $n_j$ and $n_k$, and any nonzero such relation would place a critical multiplier below $ρ_j$ or $ρ_k$ on one side.

<a id="fr-G4.3"></a>

## Critical-box uniqueness and an integer kernel basis

**Critical-box uniqueness.** There do not exist two distinct nonnegative factorizations for which every coordinate satisfies $X_r<ρ_r$. Their difference would be a nonzero kernel vector. With three coordinates, one sign class consists of a single coordinate, and its absolute value is strictly below the corresponding $ρ_r$, contradicting criticality.

**Integer basis.**

$$
r_j=(a_i,-ρ_j,b_k),\qquad r_k=(b_i,a_j,-ρ_k)
$$

form a basis of the integer kernel. They are linearly independent and span the real kernel. Given any integer kernel vector, subtract the floor multiples of its real coefficients to obtain

$$
v=xr_j+yr_k\in\mathbb Z^3,\qquad0≤x,y<1.
$$

If $x+y>0$, then $0<v_i<ρ_i$, $-ρ_j<v_j<a_j$, and $-ρ_k<v_k<b_k$. If $v_j,v_k\le0$, criticality in direction $i$ gives a contradiction. If $v_j\ge0$, the negative $k$-coordinate has absolute value below $ρ_k$, contradicting $k$-criticality. If $v_k\ge0$, the same argument uses $j$-criticality. A nonzero all-nonnegative kernel vector is impossible because all $n_r$ are positive. Therefore $x=y=0$, and the original real coefficients were integers.

This lemma uses no hidden connectivity or global factorization uniqueness. Whenever uniqueness is invoked below, it is only the critical-box uniqueness stated explicitly above.

<a id="fr-G4.4"></a>

## Corners and singletons cannot coexist

Assume that the corner $f_A$ and the singleton $S_j$ coexist. Let $c_0=W-f_A\in H$ and $c_S=κn_j$, with $κ\leρ_j-1$. For the same actual $q_{S_j}$,

$$
q_S+n_i=f_A+c_0-κn_j+n_i
=(ρ_j-1-κ)n_j+(a_k-1)n_k+c_0\in H.
$$

Direction $i$ is missing for $S_j$, a contradiction. Cyclic permutation treats every singleton direction, and the case $f_B$ follows by color reversal.

This is a stronger local coexistence exclusion than merely excluding corners among four selected rows. A corner with three arms of the opposite color and no singleton still requires the separate COLOR-CAP argument below.

<a id="fr-G4.5"></a>

## Synchronization of a matched $A_i/B_i$ pair

Take actual rows $A_i(λ),B_i(μ)$ with complements

$$
c_A=y n_j+z n_k,\qquad c_B=y'n_j+z'n_k
$$

They satisfy the bounds in (CB). Let $Δ_j=y'-y$ and $Δ_k=z'-z$. Then

$$
v=(μ-λ,a_j-Δ_j,-b_k-Δ_k)\in\ker_{\mathbb{Z}}(n).
$$

By [G4.3](#fr-G4.3), write $v=u r_j+v_0 r_k$, with $u,v_0\in\mathbb Z$. The coordinate bounds are

$$
2-a_i≤v_i≤b_i-2,
$$
$$
1-b_j≤v_j≤ρ_j+a_j-1,\qquad v_k≤a_k-1.
$$

If $u\ge1,v_0\le0$, then the $j$-coordinate is at most $-ρ_j$, impossible. If $u\le-1,v_0\ge1$, then the $j$-coordinate is at least $ρ_j+a_j$, impossible. If $u\ge0,v_0\ge1$, then the $i$-coordinate is at least $b_i$, impossible. If $u\le-1,v_0\le0$, then the $i$-coordinate is at most $-a_i$, impossible. The remaining case $u=0,v_0\le-1$ gives $k\geρ_k$, also impossible. Thus $u=v_0=0$.

Therefore

$$
λ=μ,\qquad y'=y+a_j,\qquad z'=z-b_k.
$$

Putting $g=y\ge0$ and $α=z'\ge0$, we obtain

$$
P=ρ_i-λ,\quad R=a_j+g<ρ_j,\quad T=b_k+α<ρ_k,
$$
$$
c_A=g n_j+Tn_k,\qquad c_B=Rn_j+αn_k,
$$
$$
W=(P-1)n_i+(R-1)n_j+(T-1)n_k.
\tag{MATCH}
$$

Moreover $P>a_i,b_i$, $g\le b_j-1$, and $α\le a_k-1$. We do not assume strict positivity of $g$ or $α$; the boundary cases $g=0$ and $α=0$ are included.

<a id="fr-G4.5.1"></a>

### Matched pair and singleton

If $S_j$ exists, then $κ_j<ρ_j$. The complement antichain and $c_B=Rn_j+αn_k$ imply $κ_j>R$ (if equality holds and $α=0$, the complements coincide; otherwise they are comparable). For the same $q_{S_j}$,

$$
q_{S_j}+n_k=(P-1)n_i+(R-κ_j-1)n_j+Tn_k
$$

Using $a_in_i+b_kn_k=ρ_jn_j$ once gives

$$
q_{S_j}+n_k=(P-a_i-1)n_i+(R-κ_j-1+ρ_j)n_j+αn_k\in H.
$$

Since $P-a_i-1=b_i-λ-1\ge0$ and $κ_j\leρ_j-1$, all coefficients are nonnegative, contradicting the missing direction $k$.

The case $S_k$ is dual: $κ_k>T$, and replacing $b_in_i+a_jn_j$ by $ρ_kn_k$ in $q_{S_k}+n_j$ again gives a nonnegative H-representation. Thus the only singleton that could coexist with a matched pair at this stage is $S_i$.

<a id="fr-M4"></a>

## Root-free matched-pair level rigidity

Fix the same actual matched pair of [G4.5](#fr-G4.5), with $q_A=A_i(\lambda),q_B=B_i(\lambda)$, $\delta=a_i-\lambda\ge1,\beta=b_i-\lambda\ge1$, and $g,\alpha\ge0$. Let $P=\rho_i-\lambda,R=a_j+g,T=b_k+\alpha$. Then there exist a positive integer $L$ and nonnegative integers $t,u$ such that
$$
q_A+n_i=Lm+(a_j+t)n_j+un_k,\qquad
q_B+n_i=Lm+tn_j+(u+b_k)n_k,
$$
$$
Pn_i=Lm+(t+1)n_j+(u+1)n_k.
$$
The proof retains the cases $g=0$ and $α=0$. Below, we refer to the complement representations in [G4.5](#fr-G4.5) as COMP.

<a id="fr-M4.2"></a>

## Actual positive-m returns can be chosen independently

By the pseudo-Frobenius property, $E_A=q_A+n_i$ and $E_B=q_B+n_i$ belong to $\Gamma$. No $\Gamma$-factorization of either element can contain $n_i$, since removing one copy of $n_i$ from that same nonnegative coefficient vector would put $q_A$ or $q_B$ in $\Gamma$.

Moreover, neither $E_A$ nor $E_B$ lies in $H$. We give the short pure-H proofs separately.

### $E_A\notin H$

Suppose $E_A=Xn_j+Yn_k$, with $X,Y\ge0$. The canonical formula gives

$$
Pn_i=(X-a_j+1)n_j+(Y+1)n_k.
$$

If $X\ge a_j-1$, this contradicts criticality because $0<P<ρ_i$.

If $X\le a_j-2$, then

$$
(Y+1)n_k=Pn_i+(a_j-1-X)n_j.
$$

Criticality gives $Y+1\geρ_k$. Subtracting $R_k$ once yields

$$
δn_i=(X+1)n_j+(Y+1-ρ_k)n_k.
$$

This contradicts $0<δ<ρ_i$. The coefficient of $m$ has been zero throughout; hence the applications of criticality are legitimate.

### $E_B\notin H$

Similarly, if $E_B=Xn_j+Yn_k$, then

$$
Pn_i=(X+1)n_j+(Y-b_k+1)n_k.
$$

If $Y\ge b_k-1$, then $P<ρ_i$ contradicts criticality. If $Y\le b_k-2$, then

$$
(X+1)n_j=Pn_i+(b_k-1-Y)n_k,
$$

so $X+1\geρ_j$. Subtracting $R_j$ gives

$$
βn_i=(X+1-ρ_j)n_j+(Y+1)n_k,
$$

contradicting $0<β<ρ_i$.

Thus both actual elements admit positive-m returns. For each element independently, choose the least positive coefficient of $m$ occurring in a factorization and fix one factorization that realizes it:

$$
E_A=L_A m+U_jn_j+U_kn_k,\qquad
E_B=L_B m+V_jn_j+V_kn_k,
\tag{RET}
$$

$$
L_A,L_B\ge1,\qquad U_j,U_k,V_j,V_k\ge0.
$$

These are explicit minima of nonempty subsets of the positive integers. The semigroup, $F,W,q_A,q_B$, and the canonical coefficients remain fixed; only the two nonnegative coefficient vectors in RET are chosen.

<a id="fr-M4.3"></a>

## Four coordinate caps

Adding RET and COMP and removing one copy of $m$ gives two genuine representations of the same element $F+n_i$:

$$
F+n_i=(L_A-1)m+(U_j+g)n_j+(U_k+T)n_k,
$$
$$
F+n_i=(L_B-1)m+(V_j+R)n_j+(V_k+α)n_k
\tag{FI}
$$

For example, if $U_j+g\geρ_j$, replace the contained block $ρ_jn_j$ by $a_in_i+b_kn_k$. Removing the resulting copy of $n_i$ from the same final representation would give $F\in\Gamma$; the condition $a_i\ge1$ supplies that copy. The other three cases are analogous, using $R_j$ or $R_k$. Hence

$$
U_j+g\leρ_j-1,\quad U_k+T\leρ_k-1,
$$
$$
V_j+R\leρ_j-1,\quad V_k+α\leρ_k-1.
\tag{CAP}
$$

<a id="fr-M4.4"></a>

## Uniform exclusion of unequal levels

Set

$$
t=U_j-a_j,\quad K=U_k+b_k,\quad
x=V_j-t,
\quad y=K-V_k.
$$

Using the canonical difference $E_B=E_A-a_jn_j+b_kn_k$ and RET gives

$$
(L_A-L_B)m=xn_j-yn_k.
\tag{DIFF}
$$

CAP implies in particular

$$
-ρ_j<x<ρ_j,\qquad -ρ_k<y<ρ_k.
\tag{BOX}
$$

More precisely,

$$
R+1-ρ_j\le x\leρ_j-g-1,
\quad T+1-ρ_k\le y\leρ_k-α-1.
$$

<a id="fr-M4.4.1"></a>

### $L_A>L_B$ is impossible

Let $σ=L_A-L_B\ge1$. If $V_k\ge b_k$, then

$$
E_A=L_Bm+(V_j+a_j)n_j+(V_k-b_k)n_k
$$

is an actual positive-m return for $E_A$ at a strictly smaller level, contradicting the minimality of $L_A$. Thus $V_k\le b_k-1$.

Consequently $C:=y=U_k+b_k-V_k\ge1$, and DIFF becomes

$$
σm+C n_k=Δ n_j,
\qquad Δ:=x>0.
$$

By BOX, $Δ<ρ_j$.

Adding $R_j$ as a completed zero identity yields the exact representation

$$
W=(β-1)n_i+(ρ_j+R-1)n_j+(α-1)n_k
\tag{WJ}
$$

of the same number $W$. **If $α=0$, the $k$-coefficient is $-1$, so this is only a signed intermediate equality.** Add the completed identity $σm+C n_k-Δn_j=0$, and use $F=W-m$. Then

$$
\boxed{F=(σ-1)m+(β-1)n_i+(ρ_j+R-1-Δ)n_j+(α+C-1)n_k\inΓ.}
\tag{ABS+}
$$

Every coefficient in this final expression is nonnegative, a contradiction. In particular, when $α=0$, the inequality $C\ge1$ gives $α+C-1\ge0$. No stronger bound such as $σ\ge3$ or $σ\ge5$ is needed.

<a id="fr-M4.4.2"></a>

### $L_B>L_A$ is impossible

Let $σ=L_B-L_A\ge1$. If $t\ge0$, then

$$
E_B=L_A m+t n_j+K n_k
$$

is an actual positive-m return for $E_B$ at a lower level, contradicting the minimality of $L_B$. Hence $t<0$.

Thus $Δ:=x=V_j-t\ge1$, and DIFF becomes

$$
σm+Δn_j=Cn_k,\qquad C:=y>0.
$$

By BOX, $C<ρ_k$.

Adding $R_k$ as a completed zero identity yields the exact representation

$$
W=(δ-1)n_i+(g-1)n_j+(ρ_k+T-1)n_k
\tag{WK}
$$

of the same number $W$. **If $g=0$, the $j$-coefficient is $-1$, so this is only a signed intermediate equality.** Adding $σm+Δn_j-Cn_k=0$ and using $F=W-m$ gives

$$
\boxed{F=(σ-1)m+(δ-1)n_i+(g+Δ-1)n_j+(ρ_k+T-C-1)n_k\inΓ.}
\tag{ABS-}
$$

Again all coefficients are nonnegative. In particular, when $g=0$, $Δ\ge1$ gives $g+Δ-1\ge0$. This is a contradiction.

<a id="fr-M4.5"></a>

## Equal-level matching and exclusion of PRE

It follows that $L_A=L_B=:L$. Then DIFF gives $xn_j=yn_k$.

By BOX and tail criticality, $x=y=0$. Indeed, if one is zero then both are zero, while if they are nonzero they have the same sign and $|x|n_j=|y|n_k$ contradicts $0<|x|<ρ_j$.

Hence

$$
V_j=t\ge0,\qquad V_k=U_k+b_k.
$$

Putting $u:=U_k$, we obtain

$$
\boxed{E_A=Lm+(a_j+t)n_j+u n_k,\quad
E_B=Lm+t n_j+(u+b_k)n_k,\quad t,u\ge0.}
\tag{EA/EB}
$$

Comparison with the canonical formula for $E_A$ gives

$$
\boxed{Pn_i=Lm+(t+1)n_j+(u+1)n_k.}
\tag{P-FIBER}
$$

The right-hand side is genuine. Thus the PRE region $t<0$ has been excluded completely.

<a id="fr-G4.5.2"></a>

### Matched pair and extra arms

The root-free level theorem [M4](#fr-M4), using only (MATCH) and the two actual pseudo-Frobenius rows, gives

$$
q_A+n_i=Lm+(a_j+t)n_j+u n_k,
$$
$$
q_B+n_i=Lm+t n_j+(u+b_k)n_k,
\qquad L≥1,\ t,u≥0
\tag{EA/EB}
$$

No unit-root hypothesis is used in this synchronization.

Therefore the genuine factorization $f_A=(q_A+n_i)+(λ-1)n_i$ has $j$-coordinate at least $a_j$. If an actual $A_j(μ)$, with $μ\le a_j-1$, were present, then removing $μn_j$ from this same factorization would put $A_j$ in $\Gamma$, a contradiction. Similarly, the $k$-coordinate of $f_B$ is at least $b_k$, so $B_k$ cannot coexist.

Thus the only additional arms compatible with a matched pair in direction $i$ are $B_j$ and $A_k$. We use this coexistence restriction in the classification below.

<a id="fr-G4.5.3"></a>

### A matched pair cannot coexist with $S_i$ either

From (EA/EB),
$$
Pn_i=Lm+(t+1)n_j+(u+1)n_k
$$
so $Pn_i-m\in\Gamma$. If the complement of the singleton $S_i$ is $κn_i$, then the genuine representation (MATCH) of $W$ shows that $κ\le P-1$ would imply $q_{S_i}\in H$. Hence $κ\ge P$. It follows that
$$
c_{S_i}-m=(κ-P)n_i+(Pn_i-m)\in Γ,
$$
contradicting the Apéry property of the actual complement. Thus a matched pair cannot coexist with any singleton. This eliminates all configurations containing both a matched pair and a singleton.

<a id="fr-G4.6"></a>

## Exact complement geometry for two arms of the same color

Take actual rows $A_i(λ),A_k(ν)$. Write $c_i=y n_j+z n_k$ and $c_k=x n_i+y'n_j$. Then

$$
(λ+x,y'-y,-ν-z)=u r_j+v r_k.
$$

From $i>0,k<0$, and $|j|<ρ_j$, we get $u\ge0,v\ge1$. The combination $u\le-1,v\ge1$ contradicts $j\geρ_j+a_j$; $u\le-1,v\le0$ contradicts $i>0$; and $u\ge0,v\le0$ contradicts $k<0$.

Since $i\leρ_i+a_i-2$, we have $u\le1$. Since $-k\leρ_k+a_k-2$, we have $v\le1$. Thus the only possibilities are $(u,v)=(0,1)$ or $(1,1)$.

**Case A:**
$$
c_i=y n_j+(ρ_k-ν)n_k,
\qquad c_k=(b_i-λ)n_i+(y+a_j)n_j.
\tag{AA-A}
$$

**Case B:**
$$
c_i=(y'+b_j)n_j+(a_k-ν)n_k,
\qquad c_k=(ρ_i-λ)n_i+y'n_j.
\tag{AA-B}
$$

The displayed coefficients come from the original genuine complement factorizations and are therefore nonnegative. In particular, Case A implies $b_i-λ\ge0$.

<a id="fr-G4.6.1"></a>

### The singleton in the remaining direction $S_j$ is impossible

In Case A,
$$
W=(ρ_i-λ-1)n_i+(a_j+y-1)n_j+(ρ_k-ν-1)n_k.
$$
Use $a_i n_i+b_k n_k=ρ_j n_j$ once in $q_{S_j}+n_i$:
$$
q_{S_j}+n_i=(b_i-λ)n_i+(a_j+y-κ_j-1+ρ_j)n_j+(a_k-ν-1)n_k\in H.
$$
All coefficients are nonnegative, contradicting the missing direction $i$.

In Case B,
$$
W=(ρ_i-λ-1)n_i+(ρ_j+y'-1)n_j+(a_k-ν-1)n_k.
$$
Since $κ_j\leρ_j-1$, the element $q_{S_j}=W-κ_jn_j$ itself belongs to $H$, a contradiction.

<a id="fr-G4.6.2"></a>

### Two simultaneous singletons $S_i,S_k$ are also impossible

Case A: if $y=0$, then $c_i$ lies on the pure $k$-ray and is comparable with $c_{S_k}$. Thus $y\ge1$. By antichain incomparability, $κ_k>ρ_k-ν$. In the above expression for $W$, replace $b_i n_i+a_j n_j$ by $ρ_k n_k$ in $q_{S_k}+n_i$. This gives
$$
q_{S_k}+n_i=(a_i-λ)n_i+(y-1)n_j+(ρ_k-ν-κ_k-1+ρ_k)n_k\in H.
$$
The last coefficient is at least $ρ_k-ν\ge1$, since $κ_k\leρ_k-1$. This contradicts the missing direction $i$.

Case B: if $y'=0$, then $c_k$ lies on the pure $i$-ray and is comparable with $c_{S_i}$, so $y'\ge1$. Replacing $ρ_j n_j$ by $a_i n_i+b_k n_k$ in $q_{S_i}+n_k$ yields
$$
q_{S_i}+n_k=(ρ_i-λ+a_i-κ_i-1)n_i+(y'-1)n_j+(ρ_k-ν)n_k\in H.
$$
The first coefficient is at least $a_i-λ\ge1$, contradicting the missing direction $k$.

Thus two same-color arms cannot coexist with two singletons. Color reversal gives the corresponding statement for two B-arms.

<a id="fr-G4.7"></a>

## Two arms of different colors and different directions: the two orientations

<a id="fr-G4.7.1"></a>

### The orientation $B_i(λ),A_k(ν)$

Write $c_{B_i}=y n_j+z n_k$ and $c_{A_k}=x n_i+y'n_j$. Then
$$
(λ+x,a_j-y+y',-b_k-ν-z)=u r_j+v r_k.
$$

The bounds $i>0$, $-b_j<j<ρ_j+a_j$, $-k<2ρ_k$, and $i<ρ_i+b_i$ force $(u,v)=(0,1)$: mixed signs contradict either the $j$-bound or $i>0$; $u\ge1,v=1$ gives $j\le-b_j$; $u\ge1,v\ge2$ gives $i\geρ_i+b_i$; and $u=0,v\ge2$ gives $-k\ge2ρ_k$.

Hence, with positive integers $β=b_i-λ$, $α=a_k-ν$, and $R=y=y'\ge0$,
$$
c_{B_i}=R n_j+αn_k,\qquad c_{A_k}=βn_i+R n_j.
\tag{BA}
$$

An exact expression for $W$ is
$$
W=(a_i+β-1)n_i+(R-1)n_j+(b_k+α-1)n_k
$$
If $R=0$, however, this expression is signed. We call only the following completed expression actual:
$$
W=(β-1)n_i+(R+ρ_j-1)n_j+(α-1)n_k.
\tag{BA-W}
$$
It is obtained from $a_i n_i+b_k n_k=ρ_j n_j$ and has all coefficients nonnegative.

If $S_j$ existed, then $κ_j\leρ_j-1$, and (BA-W) would imply $q_{S_j}\in H$, a contradiction. Hence any singleton must be in direction $i$ or $k$.

<a id="fr-G4.7.2"></a>

### The opposite orientation $A_i(λ),B_k(ν)$

Similarly, the kernel vector is
$$
(λ+x,-a_j-y+y',b_k-ν-z)=u r_j+v r_k.
$$

The bounds $i>0$, $-ρ_j-a_j<j<b_j$, $-ρ_k<k<b_k$, and $i<ρ_i+a_i$ force $(u,v)=(1,1)$. Mixed signs violate the $j$- or $k$-bound; $u=0$ or $v=0$ violates the $k$-bound; $u\ge2$ violates the $i$-bound; and $v\ge2$ violates the $k$-bound.

Thus, with $P=ρ_i-λ$, $T=ρ_k-ν$, $y\ge0$, and $y'=y+a_j-b_j\ge0$,
$$
c_{A_i}=y n_j+Tn_k,\qquad c_{B_k}=Pn_i+y'n_j,
$$
$$
W=(P-1)n_i+(a_j+y-1)n_j+(T-1)n_k.
\tag{AB-reverse}
$$

Assume $S_i$ exists. If $y'=0$, then there is pure-ray comparability, so $y'\ge1$. Since $a_j+y-1=b_j+y'-1\ge b_j$ and $T-1\ge a_k$, we may replace $b_jn_j+a_kn_k$ by $ρ_in_i$:
$$
W=(P+ρ_i-1)n_i+(y'-1)n_j+(b_k-ν-1)n_k.
$$
Since $κ_i\leρ_i-1$, this gives $q_{S_i}\in H$, a contradiction.

Assume $S_k$ exists. If $y=0$, there is pure-ray comparability, so $y\ge1$. Since $P-1\ge b_i$ and $a_j+y-1\ge a_j$, replace $b_i n_i+a_j n_j$ by $ρ_k n_k$:
$$
W=(a_i-λ-1)n_i+(y-1)n_j+(T+ρ_k-1)n_k.
$$
Since $κ_k\leρ_k-1$, this gives $q_{S_k}\in H$, again a contradiction.

Thus the only singleton compatible with this opposite orientation is $S_j$.

<a id="fr-G4.8"></a>

## If three singletons exist, then $|Q|=3$

Assume $S_i,S_j,S_k$ exist. By [G4.2](#fr-G4.2), every factorization of $W$ has all coordinates at most $κ_r-1<ρ_r$. By critical-box uniqueness [G4.3](#fr-G4.3), $W$ has a unique factorization. Since each maximal coordinate $κ_r-1$ is attained,
$$
W=(κ_i-1)n_i+(κ_j-1)n_j+(κ_k-1)n_k.
$$

For any other row $q$, antichain incomparability forces every coordinate of its complement $c$ to be at most $κ_r-1$. Thus any genuine factorization of $c$ is contained coefficientwise in this same factorization of $W$, and hence $q=W-c\in H$, a contradiction.

No global factorization uniqueness is assumed here. The singleton caps first confine all factorizations to the critical box, and uniqueness then follows from [G4.3](#fr-G4.3).

<a id="three-arm-bridge"></a>

## Excluding three same-color arms and connecting to the classification

To exclude three arms of the same color, we follow the same tail pseudo-Frobenius element in the same semigroup. Let the color be $\varepsilon$, and write the actual arms in the three directions as
$$
q_i=f_\varepsilon-\lambda_i n_i\in PF(\Gamma),\qquad
1\le\lambda_i\le\alpha_i-1
$$
Here $\alpha_i$ is $a_i$ for color A and $b_i$ for color B. Choose, among nonnegative representations of $f_\varepsilon$, one with the least positive coefficient of $m$. Then
$$
f_\varepsilon=km+\sum_i(p_i-1)n_i,\qquad
1\le p_i\le\lambda_i\le\alpha_i-1
$$
The choice set is nonempty and the minimum exists by well-ordering of the positive integers.

In [A1.1](#fr-A1.1)--[A1.4](#fr-A1.4) of Appendix B, the three rows $U_i$ representing the socle and the point $p$ determine a tetrahedron in the relative lattice $p+L_m$. A lattice point at an intermediate level would give a positive $m$-coefficient smaller than $k$, while a nonvertex lattice point on the top face would imply $f_\varepsilon\in H$. Hence the tetrahedron is empty and has relative volume $k$. If $k\ge2$, White's width-one theorem leaves only a partition of the four vertices into two pairs. For a class in the quotient lattice and its companion, minimality forbids simultaneous positivity of every coordinate. Writing these failure conditions for both colors produces a nonnegative weighted row vector $v$ and a positive integer $D$ with
$$
v\cdot n=kDm,\qquad |v|_1\ge kD
$$
contradicting $n_i>m$. All six inequalities, weights, and coordinate sums for the two colors are recorded in [A1.5](#fr-A1.5)--[A1.8](#fr-A1.8). Therefore $k=1$.

Orient the argument to color A. By [A1.9](#fr-A1.9), $x=p$, $y=a-p$, and $z=y+b$ are positive and satisfy
$$
C=\begin{pmatrix}-x_1&z_2&y_3\\y_1&-x_2&z_3\\z_1&y_2&-x_3\end{pmatrix},
\qquad Cn=m\mathbf1
$$
Consider the operation of subtracting a row $c_i$ inside the box $\mathcal B=\prod_i[1,a_i-1]\cap\mathbb Z^3$. The three allowed source regions inside the box are pairwise disjoint, and each operation decreases $u\cdot n$ by $m$. Therefore every path is finite.

The possibility that a path terminates without an operation that exits the box while remaining positive is excluded by the exhaustive division below. In the two-color calculations, the integer-fraction separator is applied only to the initial prefix of crossings that actually succeeds. In the reciprocal-rank calculation, the dual count is first shown to correspond to points traversed by the original path, and only then are coordinate ranks counted. The relevant ranges and proofs are in [A2.3](#fr-A2.3)--[A2.4](#fr-A2.4).

| Rows used by the path | Proof excluding termination |
|---|---|
| One row only | Weighted certificate for every sink in [A2.6](#fr-A2.6) |
| Rows 1 and 2 | Last-row, pre-cross, and sink-by-sink analysis in [A2.7](#fr-A2.7) |
| Rows 1 and 3 | Last-row and sink-by-sink analysis in [A2.8](#fr-A2.8) |
| All three rows | Two directions for the first occurrence of the third color in [A2.9](#fr-A2.9) |

The weighted-certificate principle is that $v=\lambda C\ge0$ and $|v|_1\ge|\lambda|_1>0$ imply
$$
|\lambda|_1m=v\cdot n>|v|_1m\ge|\lambda|_1m
$$
a contradiction. Appendix B retains the margins for every sink. Hence a maximal path inside the box has a positive exit.

After a total of $t$ operations, let $u=p-rC$, with $|r|_1=t$. The same element being tracked has the representation
$$
f_A=(t+1)m+\sum_i(u_i-1)n_i
$$
At a positive exit all coefficients are still nonnegative, and $u_i\ge a_i$ for some $i$. Hence $u_i-1\ge a_i-1\ge\lambda_i$, and removing $\lambda_i n_i$ from this single representation gives $q_i\in\Gamma$, a contradiction. For color B, simultaneously exchange the indices, all $a/b$-parameters, the arm elements, and their ranges; the same argument applies.

Thus three arms of the same color cannot exist. Two depths on the same arm, and a corner together with an arm of the same color, are also incompatible by pseudo-Frobenius incomparability. Therefore, for each color, there are at most two corner/arm rows. This conclusion, including the cases involving a corner, is used in the four-row classification below.

<a id="fr-G4.9"></a>

## Exhaustive classification of four rows

Choose four distinct actual $Q$-rows. Let $s$ be the number of singletons, $c$ the number of corners, and $a$ the number of arms.

**Case with a corner.** By [G4.4](#fr-G4.4), no singleton is present. A corner cannot coexist with an arm of the same color by antichain incomparability. Hence if $c=1,a=3$, the three arms all have the opposite color. Duplicates of an arm are impossible, so all three directions occur. At this point we apply [Proposition B.1 (THREE-ARM / COLOR-CAP)](#prop-B1) from Appendix B.

Henceforth $c=0$. By [G4.8](#fr-G4.8), $s\le2$.

**$s=2,a=2$.** By [G4.5.1](#fr-G4.5.1), a matched pair allows a singleton in at most one direction. By [G4.6](#fr-G4.6), two same-color arms cannot coexist with two singletons. The opposite orientation in [G4.7.2](#fr-G4.7.2) likewise allows a singleton in only one direction. Therefore the orientation is that of [G4.7.1](#fr-G4.7.1), with singletons in directions $i,k$. The configuration is exactly
$$
S_i,\quad B_i(λ),\quad A_k(ν),\quad S_k
$$
which we call PATH.

**$s=1,a=3$.** If the three arms have the same color, they occupy all three directions. Applying [G4.6.1](#fr-G4.6.1) to the two arms outside the singleton direction gives a contradiction. Thus the color distribution is $2+1$.

If a matched pair were present, [G4.5.3](#fr-G4.5.3) would exclude coexistence with the singleton. Hence no matched pair occurs in this case.

Up to cyclic permutation and full color reversal, the remaining candidate
$$
S_i,\quad A_i(λ),\quad B_i(λ),\quad A_k(ν)
$$
contains a matched pair in direction $i$ together with the singleton $S_i$, and is therefore already excluded by [G4.5.3](#fr-G4.5.3). It need not be treated as an independent terminal branch.

If there is no matched pair, the three missing directions are all distinct. Write the two same-color arms as $A_i,A_k$ and the opposite-color arm as $B_j$. Applying the opposite-orientation pair [G4.7.2](#fr-G4.7.2) to $A_k,B_j$ shows that the only possible singleton is $S_i$. Thus the configuration is exactly
$$
S_i,\quad A_i(λ),\quad B_j(μ),\quad A_k(ν)
$$
which we call TYPE II.

**$s=0,a=4$.** There are three directions, and each color contributes at most one copy of any given arm, so in some direction $i$ both $A_i$ and $B_i$ occur. By [G4.5.2](#fr-G4.5.2), the only additional arms are $B_j$ and $A_k$. Hence the configuration is
$$
B_j(μ),\quad A_i(λ),\quad B_i(λ),\quad A_k(ν)
$$
which we call CHAIN.

Thus every actual four-row nonsymmetric counterexample reduces exhaustively to PATH, TYPE II, or CHAIN. The two coexistence restrictions for a matched pair were proved in [G4.5.2](#fr-G4.5.2)--[G4.5.3](#fr-G4.5.3).

<a id="fr-G4.11"></a>

## Extraction of the scalar input needed for the terminal proofs

<a id="fr-G4.11.1"></a>

### General singleton saturation lemma

Suppose the same actual $W$ has the representation
$$
W=(P-1)n_i+(R-1)n_j+(T-1)n_k,
\quad1≤P≤ρ_i,\quad1≤R≤ρ_j,\quad1≤T≤ρ_k
\tag{BOX-W}
$$
and the complement of a singleton $S_i$ is $κ n_i$. By [G4.2](#fr-G4.2), every factorization of $W$ has $i$-coordinate at most $κ-1<ρ_i$, and the maximum $κ-1$ is attained.

Let the difference between an arbitrary factorization of $W$ and (BOX-W) be $u r_j+v r_k$. If $u\ge1,v\le0$, then the $j$-coordinate is at most $R-1-ρ_j<0$. If $u\le0,v\ge1$, then the $k$-coordinate is at most $T-1-ρ_k<0$. If $u,v\ge1$, then the $i$-coordinate is at least $P-1+ρ_i\geρ_i$, contradicting the singleton cap. In the remaining case $u,v\le0$, the $i$-coordinate is at most $P-1$.

Hence the maximum is $P-1$, so
$$
\boxed{κ=P.}
$$

The cyclic versions are identical. No global uniqueness of the factorization fiber is needed.

<a id="fr-G4.11.2"></a>

### The full canonical positive box for CHAIN

Take the CHAIN rows of [G4.9](#fr-G4.9). The matched pair in direction $i$ gives (MATCH). Apply [G4.7.1](#fr-G4.7.1), in cyclic order $(j,k,i)$, to the right-oriented pair $B_j(μ),A_i(λ)$. Then
$$
c_{A_i}=(b_j-μ)n_j+Tn_k,\qquad c_{B_j}=(a_i-λ)n_i+Tn_k.
$$
Comparison with the unique $j/k$-representation of the matched complement gives
$$
g=b_j-μ≥1,\quad R=ρ_j-μ.
$$
Similarly, from $B_i(λ),A_k(ν)$,
$$
α=a_k-ν≥1,\quad T=ρ_k-ν,
$$
$$
c_{A_k}=(b_i-λ)n_i+Rn_j.
$$
Thus, with $δ=a_i-λ≥1$ and $β=b_i-λ≥1$,
$$
P=λ+δ+β,\quad R=a_j+g,\quad T=b_k+α
$$
and the four complements are
$$
c_{B_j}=δn_i+Tn_k,\quad c_{A_i}=g n_j+Tn_k,
$$
$$
c_{B_i}=Rn_j+αn_k,\quad c_{A_k}=βn_i+Rn_j.
$$
These positive coefficient ranges are the input for the root construction and the subsequent packet analysis in CHAIN.

<a id="fr-G4.11.3"></a>

### Full input for TYPE II

Take $S_i,A_i(λ),B_j(μ),A_k(ν)$. Compare Case A/B of [G4.6](#fr-G4.6) for $A_i,A_k$ with [G4.7.1](#fr-G4.7.1) for $B_j,A_i$. In Case B, the $j$-coordinate of $c_{A_i}$ would be simultaneously $b_j+y'$ and $b_j-μ$, forcing $y'=-μ<0$, impossible. Hence Case A holds.

Consequently
$$
λ≤b_i,\quad P=ρ_i-λ,\quad R=ρ_j-μ,\quad T=ρ_k-ν,
$$
$$
c_{A_i}=(b_j-μ)n_j+Tn_k,
$$
$$
c_{A_k}=(b_i-λ)n_i+Rn_j,\qquad
c_{B_j}=(a_i-λ)n_i+Tn_k.
$$
Thus the same $W$ has the form (BOX-W), and singleton saturation gives $c_{S_i}=Pn_i$. Therefore
$$
q_{S_i}=-n_i+(R-1)n_j+(T-1)n_k.
$$
The arm-domain restrictions $1\leλ\le a_i-1$, $1\leμ\le b_j-1$, and $1\leν\le a_k-1$, together with $λ\le b_i$, are precisely the full input to [T6.1](#fr-T6.1).

<a id="fr-G4.11.4"></a>

### Canonical endpoint rays for PATH

From the PATH pair $B_i(λ),A_k(ν)$, [G4.7.1](#fr-G4.7.1) gives $α=a_k-ν>0$, $β=b_i-λ>0$, and $R\ge0$. If $R=0$, then $c_{A_k}=βn_i$ is comparable on the pure ray with $c_{S_i}$, or is the same row, which is impossible. Hence $R\ge1$.

The missing-$i$ critical box for $c_{B_i}$ gives $R<ρ_j$. Thus
$$
P=a_i+β=ρ_i-λ,\quad T=b_k+α=ρ_k-ν,
$$
$$
W=(P-1)n_i+(R-1)n_j+(T-1)n_k
$$
has the form (BOX-W). Applying singleton saturation in directions $i$ and $k$ gives
$$
c_{S_i}=Pn_i,\qquad c_{S_k}=Tn_k.
$$
If we set $q_L=q_{S_i},q_A=q_{A_k},q_B=q_{B_i},q_R=q_{S_k}$, then
$$
q_L+a_in_i=q_A+Rn_j,
\quad q_A+βn_i=q_B+αn_k,
\quad q_R+b_kn_k=q_B+Rn_j.
$$
This actual PATH ladder is passed to P5. Here $q_A/q_B$ are only ladder labels and do not refer to the Herzog colors.

<a id="terminal-input-table"></a>

## How to read the input to the three terminal configurations

| Configuration | Four pseudo-Frobenius elements | Additional conditions used later | Eliminated in |
|---|---|---|---|
| Path | $S_i,B_i(\lambda)$, $A_k(\nu),S_k$ | The two endpoint complements are $Pn_i,Tn_k$, and $1\le R<\rho_j$ | Section 5 |
| Type II | $S_i,A_i(\lambda)$, $B_j(\mu),A_k(\nu)$ | $\lambda\le b_i$, $c_{S_i}=Pn_i$, and the full arm ranges in [G4.11.3](#fr-G4.11.3) | Section 6 |
| Chain | $B_j(\mu),A_i(\lambda)$, $B_i(\lambda),A_k(\nu)$ | $\lambda,\delta,\beta,g,\alpha\ge1$, and the four complements in [G4.11.2](#fr-G4.11.2) | Sections 7--10 |

All three configurations live in the same $\Gamma,F,m,W$. The table is only a reference to the coefficient ranges proved immediately above; the complete inputs are stated explicitly in the corresponding extraction propositions.


<a id="sec-05"></a>

# 5　Exclusion of the path configuration

We fix the same $W$ and the four elements of the path configuration from the preceding section. We divide according to whether the returns of the two central elements match. In the nonmatching case, we first determine the signs and then compare the returns at the two endpoints. In this section, $q_A,q_B$ label $A_k,B_i$, respectively.

<a id="fr-P5.0"></a>

## Exact input and labels

Take the PATH configuration of [G4.11.4](#fr-G4.11.4), with $1\le\lambda<b_i,1\le\nu<a_k$,
$\beta=b_i-\lambda\ge1,\alpha=a_k-\nu\ge1$,
$P=a_i+\beta,T=b_k+\alpha,1\le R<\rho_j$. The four rows for the same W are
$$
q_L=-n_i+(R-1)n_j+(T-1)n_k,\quad c_L=Pn_i,
$$
$$
q_A=(a_i-1)n_i-n_j+(T-1)n_k=A_k(\nu),\quad c_A=\beta n_i+Rn_j,
$$
$$
q_B=(P-1)n_i-n_j+(b_k-1)n_k=B_i(\lambda),\quad c_B=Rn_j+\alpha n_k,
$$
$$
q_R=(P-1)n_i+(R-1)n_j-n_k,\quad c_R=Tn_k.
$$
All four are actual pseudo-Frobenius rows, and $SH(q_L)=\{i\},SH(q_R)=\{k\}$. The ladder is
$$
q_L+a_in_i=q_A+Rn_j,\quad q_A+\beta n_i=q_B+\alpha n_k,
\quad q_R+b_kn_k=q_B+Rn_j.
$$
In this section the labels $q_A,q_B$ refer to the ladder; their missing directions are $k,i$, respectively.

<a id="fr-P5.1"></a>

## The required part of the central match-or-seam argument

By [C2](#fr-C2), both elements $q_A+m,q_B+m$ lie in $H$. We call a pair satisfying
$$
\begin{aligned}
q_A+m&=Xn_i+H_0n_j+(Z+\alpha)n_k,\\
q_B+m&=(X+\beta)n_i+H_0n_j+Zn_k,\qquad X,H_0,Z\ge0
\end{aligned}
\tag{P5-PAIR}
$$
a PAIR. If no PAIR exists, then every factorization of the first element has $k$-coefficient below $\alpha$, and every factorization of the second has $i$-coefficient below $\beta$. Otherwise, the central ladder equality produces a PAIR.

Within the same actual element, replace HCR packets until the two factorizations are normalized as
$$
q_A+m=Xn_i+H_0n_j+Kn_k,\quad
0\le X<\rho_i,\ 0\le H_0<\rho_j,\ 0\le K<\alpha,
$$
$$
q_B+m=Yn_i+J_0n_j+Ln_k,\quad
0\le Y<\beta,\ 0\le J_0<\rho_j,\ 0\le L<\rho_k
$$
For the first element, every removal of a $j$-packet decreases $H_0$ by $\rho_j$. If $i\ge\rho_i$, an $R_i$-replacement gives $k\ge a_k>\alpha$ and hence a PAIR. For the second element, remove $j$-packets; if $k\ge\rho_k$, an $R_k$-replacement gives $i\ge b_i>\beta$ and hence a PAIR. Thus, in the no-PAIR case, the process terminates within the displayed ranges.

Comparison gives
$$
A_c n_i+(H_0-J_0)n_j=B_c n_k,
\quad A_c=X+\beta-Y>0,\quad B_c=\alpha+L-K>0.
$$
If $H_0<J_0$, let $e=J_0-H_0\in[1,\rho_j-1]$; then $A_c\ge\rho_i$. Put $a=A_c-\rho_i\in[0,\beta-1]$. Comparison after using $R_i$ gives
$$
a n_i=(e-b_j)n_j+(B_c-a_k)n_k.
$$
Here $B_c-a_k\le T-1<\rho_k$. Split according to the four possible sign patterns of the two coefficients on the right. If both are nonnegative, $i$-criticality forces all terms to vanish. If exactly one is negative, a positive subcritical multiple of $n_j$ or $n_k$ is represented by the other two generators, a contradiction. Both negative is impossible. Hence
$$
A_c=\rho_i,\quad J_0-H_0=b_j,\quad B_c=a_k.
$$
This gives the following actual central kernel:
$$
\boxed{q_A+m=(Y+a_i+\lambda)n_i+H_0n_j+K_0n_k,}
$$
$$
\boxed{q_B+m=Yn_i+(H_0+b_j)n_j+(K_0+\nu)n_k,}
\tag{P5-PFREE-i}
$$
$$
0\le Y<\beta,\quad0\le K_0<\alpha,\quad0\le H_0<a_j.
$$
The case $H_0>J_0$ is sent to the same kernel by the full left-right reversal below. If $H_0=J_0$, then $A_c n_i=B_c n_k$. Criticality gives $A_c\ge\rho_i,B_c\ge\rho_k$, and after comparison with $R_i$,
$(B_c-a_k)n_k=(A_c-\rho_i)n_i+b_jn_j$ contradicts $0<B_c-a_k\le T-1<\rho_k$.
Thus PAIR, PFREE_i, and the full dual of PFREE_i exhaust the possibilities. No endpoint reconstruction with unchecked signs is treated as actual here.

<a id="fr-P5-dual"></a>

## Full parameter transformation under left-right reversal

$$
i^\vee=k,\ j^\vee=j,\ k^\vee=i,\qquad
(n_i^\vee,n_j^\vee,n_k^\vee)=(n_k,n_j,n_i),
$$
$$
(a_i^\vee,b_i^\vee)=(b_k,a_k),\quad
(a_j^\vee,b_j^\vee)=(b_j,a_j),\quad
(a_k^\vee,b_k^\vee)=(b_i,a_i),
$$
$$
(\lambda^\vee,\nu^\vee)=(\nu,\lambda),\quad
(\alpha^\vee,\beta^\vee)=(\beta,\alpha),\quad
(P^\vee,R^\vee,T^\vee)=(T,R,P),
$$
$$
(q_L^\vee,q_A^\vee,q_B^\vee,q_R^\vee)=(q_R,q_B,q_A,q_L).
$$
The quantities Γ,F,m,W are unchanged. This transformation preserves HCR, the arm bounds, singleton status, and the ladder. On the no-PAIR side with $H_0>J_0$, the new $q_A$ is the old $q_B$, and its new $j$-coefficient is $J_0<H_0$; thus the case reduces exactly to the already proved case $H_0<J_0$.

<a id="fr-P5.2"></a>

## From PAIR to a strong port

Comparing PAIR with the canonical rows gives
$$
m=(X-a_i+1)n_i+(H_0+1)n_j+(Z-b_k+1)n_k.
$$
Let $t_0=\rho_j-H_0-1$. Using HCR,
$$
t_0n_j+m=(X+1)n_i+(Z+1)n_k.
$$
The right-hand side is greater than $m$, so $1\le t_0<\rho_j$. For the same $q_A,q_B$,
$$
q_A=m+(a_i-X-2)n_i+(t_0-1)n_j+(T-Z-2)n_k,
$$
$$
q_B=m+(P-X-2)n_i+(t_0-1)n_j+(b_k-Z-2)n_k.
$$
If all final coefficients were nonnegative, the relevant gap would lie in $\Gamma$. Hence
$$
X\ge a_i-1\ \vee\ Z\ge T-1,\qquad
X\ge P-1\ \vee\ Z\ge b_k-1.
$$
On the other hand, if $X\ge a_i-1$ and $Z\ge b_k-1$, the root would be a nonnegative representation and would put $m$ in $H$, impossible. Therefore
$$
X\le a_i-2,\ Z\ge T-1
\quad\text{or}\quad
X\ge P-1,\ Z\le b_k-2.
$$
By left-right reversal we may assume the first case. Then, with $d=a_i-1-X,S=H_0+1,e=Z-b_k+1$,
$$
m=-dn_i+Sn_j+en_k,\quad1\le d\le a_i-1,\ S\ge1,\ e\ge\alpha
$$
We call this identity WEAK-ROOT and pass it to the next proposition.

<a id="fr-P5.3"></a>

## Normalization of a weak root and exclusion of PAIR

The input is the same $q_L,q_A,W$ from [P5.0](#fr-P5.0), together with a weak root from [P5.2](#fr-P5.2).

<a id="fr-P5.3.2"></a>

### Actual missing-direction returns

By the pseudo-Frobenius property, $q_L+n_j,q_L+n_k∈Γ$. If a genuine factorization of $q_L+n_j$ contained $n_j$, removing one copy from that same coefficient vector would give $q_L∈Γ$. Thus its $j$-coefficient is zero. Similarly, every genuine factorization of $q_L+n_k$ has $k$-coefficient zero.

Moreover, by the SINGLETON condition neither successor lies in $H$, so the coefficient of m is positive. Hence any genuine returns have the form
$$
q_L+n_j=\ell m+A n_i+C n_k,
\quad \ell\ge1,\ A,C\ge0,
\tag{LJ}
$$
$$
q_L+n_k=L_km+A_kn_i+B_kn_j,
\quad L_k\ge1,\ A_k,B_k\ge0.
\tag{LK}
$$
No uniqueness, return-level minimality, or change of selected support is used here.

<a id="fr-P5.3.3"></a>

### A weak ROOT forces $S<R$ and $e≥T$

Substitute WEAK-ROOT once into LK and use the exact identity for QA:
$$
q_A=(L_k-1)m+(A_k-d+a_i)n_i
 +(B_k+S-R)n_j+(e-1)n_k.
\tag{QA-ROOT}
$$
Here
$$
L_k-1\ge0,\quad A_k-d+a_i\ge1,\quad e-1\ge0.
$$
If $S≥R$, the remaining coefficient is also nonnegative, giving $q_A∈Γ$. Therefore
$$
1\le S\le R-1.
\tag{S-WALL}
$$

Next, subtract the copy of $m$ represented by ROOT from the same $W$. The exact identity is
$$
F=(P+d-1)n_i+(R-S-1)n_j+(T-e-1)n_k.
\tag{F-ROOT}
$$
The first two coefficients are nonnegative. If $e≤T-1$, the third is also nonnegative and $F∈Γ$. Hence
$$
e\ge T=b_k+\alpha.
\tag{E-WALL}
$$
Thus, with $K:=e-α$, we have $K≥b_k$.

The conclusion of this subsection applies to **every ROOT** satisfying only the WEAK-ROOT hypotheses. Its original derivation from the paired-port coefficients $X,H,Z$ is no longer needed.

<a id="fr-P5.3.4"></a>

### Finite ROOT normalization: $b_k≤K<ρ_k$

By the preceding subsection, $K=e-α≥b_k$. If $K≥ρ_k$, use the HCR relation $ρ_k n_k=b_i n_i+a_j n_j$ to rewrite the same equality as
$$
m=-d'n_i+S'n_j+e'n_k,
\quad d'=d-b_i,\ S'=S+a_j,\ e'=e-\rho_k
\tag{ROOT-STEP}
$$
We have $e'=K-ρ_k+α≥α$ and $S'≥1$.

If $d'≤0$, the right-hand side is coefficientwise nonnegative, with $S'≥1$, so $m≥n_j$, contradicting multiplicity.

Hence, in every surviving case, $d'>0$ and
$$
1\le d'\le a_i-1,\quad S'\ge1,\quad e'\ge\alpha.
$$
Thus **all** WEAK-ROOT hypotheses are preserved. The original $Γ,F,m,W,q_L,q_A$ are unchanged, and LK/LJ remain the same actual returns. Applying [P5.3.3](#fr-P5.3.3) to the new ROOT gives
$$
S'<R,\qquad e'\ge T,\qquad K':=e'-\alpha\ge b_k
$$
But
$$
K'=K-\rho_k<K.
$$
Since the positive integer $K$ strictly decreases, the process terminates. If no contradiction arises earlier, at termination we have
$$
\boxed{\begin{aligned}
m&=-dn_i+Sn_j+(K+\alpha)n_k,\\
1&\le d\le a_i-1,\qquad 1\le S<R,\qquad b_k\le K<\rho_k
\end{aligned}}
\tag{NORMALIZED-ROOT}
$$
We use $d,S,K$ for the normalized variables from this point onward.

This does **not** assert that the original ROOT already had subcritical $K$. It is a finite normalization to another ROOT preserving the same actual data, all hypotheses, and an explicit positive-integer measure. In particular, no assumption $b_i>a_i$ is made.

<a id="fr-P5.3.5"></a>

### The endpoint missing-$j$ level is at least two

Fix any LJ. From $q_L+Pn_i=W$,
$$
F=(\ell-1)m+(P+A)n_i-n_j+Cn_k.
$$
Adding one copy of the HCR zero identity gives
$$
F=(\ell-1)m+(\beta+A)n_i
 +(\rho_j-1)n_j+(C-b_k)n_k.
\tag{C-CERT}
$$
Thus $C≥b_k$ would put $F$ in $Γ$, impossible. Hence
$$
0\le C\le b_k-1.
\tag{C-CAP}
$$

Now suppose $ℓ=1$. Substituting the normalized ROOT into LJ gives the exact identity
$$
q_L=(A-d)n_i+(S-1)n_j+(C+K+\alpha)n_k.
\tag{QL-CERT}
$$
If $A≥d$, all coefficients are nonnegative and $q_L∈Γ$. Thus
$$
0\le A\le d-1.
\tag{A-CAP}
$$

On the other hand, comparing LJ with the canonical QL formula eliminates m completely and gives the pure-H identity
$$
(C+K-b_k+1)n_k
 =(d-A-1)n_i+(R-S)n_j
\tag{PURE-K}
$$
The coefficients on the right satisfy
$$
d-A-1\ge0,\qquad R-S\ge1.
$$
The positive integer $V:=C+K-b_k+1$ on the left satisfies
$$
1\le K-b_k+1\le V\le K<\rho_k.
$$
Thus $V n_k∈⟨n_i,n_j⟩$ with $0<V<ρ_k$, contradicting Herzog criticality of $ρ_k$.

Therefore, for every genuine missing-$j$ return of the same actual $q_L$,
$$
\boxed{\ell\ge2.}
\tag{ENDPOINT-LEVEL-2}
$$

Criticality was used only in PURE-K, after the m-coordinate had been completely eliminated.

<a id="fr-P5.3.6"></a>

### One-step Frobenius absorption

Insert the normalized ROOT once into LJ and use $q_L+Pn_i=W$:
$$
\boxed{
F=(\ell-2)m+(P+A-d)n_i
 +(S-1)n_j+(C+K+\alpha)n_k.
}
\tag{LEFT-FABS}
$$
The coefficients satisfy
$$
\ell-2\ge0,\quad
P+A-d\ge\beta+1>0,\quad
S-1\ge0,\quad
C+K+\alpha>0.
$$
Thus LEFT-FABS is a genuine factorization of $F$ itself, so $F∈Γ$, a contradiction.

Hence the strong-left weak-root configuration cannot occur.

<a id="fr-P5.4"></a>

## Determining the sign in PFREE first

Starting from the central kernel PFREE_i, put $\eta=\nu-b_k$,
$$
A_0=Y+\lambda+1,\ B_0=H_0+1,\ C_0=T-K_0-1,
$$
$$
D_0=P-Y-1>0,\ E_0=H_0+b_j+1,\ F_0=K_0+\eta+1
$$
The same element $m$ has the two exact identities
$$
m=A_0n_i+B_0n_j-C_0n_k=-D_0n_i+E_0n_j+F_0n_k.
\tag{P5-M}
$$
They satisfy $A_0+D_0=\rho_i,E_0-B_0=b_j,C_0+F_0=a_k$. Call the left representation M+ and the right representation M−. We first exclude $F_0\le0$. In that case $C_0\ge a_k$, $T=C_0+K_0+1\ge a_k+1$, and $T\ge b_k+1$.

<a id="fr-P5.4.2"></a>

### Two genuine returns of the same right singleton

By the pseudo-Frobenius property and the missing directions,

$$
q_R+n_i=s m+U n_j+V n_k,
\qquad s\ge1,\ U,V\ge0,
\tag{RIGHT-I}
$$

$$
q_R+n_j=r m+X n_i+Z n_k,
\qquad r\ge1,\ X,Z\ge0.
\tag{RIGHT-J}
$$

If the relevant missing coordinate were positive, removing one copy from that same factorization would put $q_R$ in $\Gamma$. If the m-level were zero, the definition of the missing direction would be violated. Thus both actuality and positivity of the levels are explicit.

<a id="fr-P5.4.3"></a>

### $r≥2$ or $s≥2$ gives a one-step absorption of F

Insert one copy of M+ into RIGHT-J and return to $q_R+Tn_k=W$:

$$
F=(r-2)m+(X+A_0)n_i+H_0n_j+(T+Z-C_0)n_k.
\tag{J-FABS}
$$

If $r\ge2$, every coefficient is nonnegative. In particular, $T+Z-C_0=K_0+1+Z\ge1$.

Similarly, RIGHT-I gives

$$
F=(s-2)m+(A_0-1)n_i+(U+H_0+1)n_j+(T+V-C_0)n_k.
\tag{I-FABS}
$$

If $s\ge2$, then $A_0-1\ge0$, $T+V-C_0=K_0+1+V\ge1$, and the remaining coefficients are also nonnegative.

Thus any surviving counterexample must satisfy

$$
r=s=1.
\tag{UNIT}
$$

<a id="fr-P5.4.4"></a>

### Two endpoint caps

From RIGHT-I and $c_R=Tn_k$,

$$
F=(s-1)m-n_i+Un_j+(T+V)n_k.
$$

Add the zero identity $ρ_i n_i-b_j n_j-a_k n_k=0$ once:

$$
F=(s-1)m+(\rho_i-1)n_i+(U-b_j)n_j+(T+V-a_k)n_k.
\tag{U-CERT}
$$

Since $T\ge a_k$, the inequality $U\ge b_j$ would make all coefficients nonnegative. Hence

$$
0\le U\le b_j-1.
\tag{U-CAP}
$$

For RIGHT-J, use $R_j$ as a completed repair:

$$
F=(r-1)m+(X-a_i)n_i+(\rho_j-1)n_j+(T+Z-b_k)n_k.
\tag{X-CERT}
$$

Since $T\ge b_k$,

$$
0\le X\le a_i-1.
\tag{X-CAP}
$$

Only the non-strict part of the stronger T-CAPS is needed here.

<a id="fr-P5.4.5"></a>

### Equal unit levels contradict pure-H criticality

With $r=s=1$, eliminate m completely from the two returns:

$$
(X+1)n_i=(U+1)n_j+(V-Z)n_k.
\tag{UNIT-DIFF}
$$

- If $V\ge Z$, the right-hand side is nonnegative and positive, whereas $0<X+1\le a_i<ρ_i$, contradicting $i$-criticality.
- If $V<Z$, rewrite the equation as $(U+1)n_j=(X+1)n_i+(Z−V)n_k$. Since $0<U+1\le b_j<ρ_j$, this contradicts $j$-criticality.

All cases are eliminated. Therefore

$$
\boxed{\mathrm{PFREE}_i\cap\{F_0\le0\}=\varnothing.}
$$

<a id="fr-P5.5"></a>

## Two-return absorption in PFREE and the level-one normal form

From now on $F_0\ge1$ has been proved. Take a return of the same left singleton,
$$
q_L+n_j=\ell m+A n_i+C n_k,\quad\ell\ge1,\ A,C\ge0
$$
Adding $c_L=Pn_i$ and comparing once with HCR gives
$$
F=(\ell-1)m+(\beta+A)n_i+(\rho_j-1)n_j+(C-b_k)n_k
$$
so $C\le b_k-1$. A single substitution of M− gives
$$
q_L=(\ell-1)m+(A-D_0)n_i+(E_0-1)n_j+(C+F_0)n_k
$$
so $A\le D_0-1$. Furthermore,
$$
F=(\ell-2)m+(P+A-D_0)n_i+(E_0-1)n_j+(C+F_0)n_k.
\tag{P5-PFREE-FABS}
$$
Here $P+A-D_0=A+Y+1\ge1,E_0-1\ge0,C+F_0\ge1$. Hence $\ell\ge2$ is impossible.

For $\ell=1$, comparison with M+ gives
$$
P_c n_i=Q_c n_j+K_c n_k,
\quad P_c=A+A_0+1\in[1,\rho_i],
$$
$$
Q_c=R-H_0-1,\quad K_c=2T-K_0-C-2\ge T.
$$
If $Q_c<0$, put $r_c=-Q_c\in[1,a_j-1]$. After applying $k$-criticality and then subtracting $R_k$,
$$
(P_c-b_i)n_i=(a_j-r_c)n_j+(K_c-\rho_k)n_k.
$$
If $P_c\le b_i$, positivity is impossible; if $P_c>b_i$, then $0<P_c-b_i\le a_i<ρ_i$, contradicting criticality.
If $Q_c\ge0$, $i$-criticality gives $P_c=ρ_i$. Subtracting $R_i$ gives
$$
(Q_c-b_j)n_j+(K_c-a_k)n_k=0.
$$
If $Q_c<b_j$, then $0<b_j-Q_c\le b_j<ρ_j$, contradicting $j$-criticality. If $Q_c>b_j$, then $0<a_k-K_c<a_k<ρ_k$, contradicting $k$-criticality. Hence $Q_c=b_j,K_c=a_k$, and moreover
$$
H_0=R-b_j-1,\quad A=D_0-1,\quad C=T-K_0-\eta-2.
\tag{P5-FIX-J}
$$
No uniform upper bound on $K_c-a_k$ is needed in this comparison.

Take the other actual return $q_L+n_k=Lm+D n_i+B n_j$. Then
$$
F=(L-2)m+(P+D-D_0)n_i+(B+E_0)n_j+(F_0-1)n_k.
$$
If $L\ge2$, all coefficients are nonnegative, a contradiction. Thus the only remaining case is the double-unit configuration
$$
\begin{aligned}
q_L+n_j&=m+A n_i+C n_k,\\
q_L+n_k&=m+D n_i+B n_j,\\
&A,B,C,D\ge0
\end{aligned}
\tag{P5-DOUBLE-UNIT}
$$
together with P5-FIX-J.

<a id="fr-P5.6"></a>

## Exclusion of the double-unit case

The input consists of [P5.0](#fr-P5.0), P5-M, P5-FIX-J, and P5-DOUBLE-UNIT. Below, FIX-J and UNIT-K refer to the two returns above.

<a id="fr-P5.6.2"></a>

### The C-cap and the upper bound for A

We have already proved in [P5.5](#fr-P5.5) that $0\le C\le b_k-1$. Also $A=P-Y-2<P<ρ_i$.

<a id="fr-P5.6.3"></a>

### The two unit returns are pinned to one point

Eliminating m between (FIX-J) and (UNIT-K) gives
$$
(D-A)n_i+(B+1)n_j=(C+1)n_k.
\tag{EQ}
$$

If $D\ge A$, the right-hand $k$-coefficient satisfies $1\le C+1\le b_k<ρ_k$, while the left-hand side is nonnegative and positive, contradicting $k$-criticality.

Therefore $D<A$, and
$$
(B+1)n_j=(A-D)n_i+(C+1)n_k,
$$
Thus $B+1\geρ_j$. Subtract $R_j$ once:
$$
(B+1-ρ_j)n_j=(A-D-a_i)n_i+(C+1-b_k)n_k.
\tag{EQ-RJ}
$$

Put $x=A-D-a_i$. If $x>0$, then
$$
x n_i=(B+1-ρ_j)n_j+(b_k-C-1)n_k,
$$
whose right-hand side is nonnegative. Since $x<A<ρ_i$, this contradicts $i$-criticality; if the right side were zero, the equality $x n_i=0$ would itself be impossible. If $x\le0$, then in (EQ-RJ) the left side is nonnegative and the right side nonpositive, so equality is possible only if all coefficients vanish.

Thus the unique possibility is
$$
\boxed{D=A-a_i,\qquad B=ρ_j-1,\qquad C=b_k-1.}
\tag{PIN}
$$

Up to this point, criticality has been applied only to pure-H relations after m has been completely eliminated.

<a id="fr-P5.6.4"></a>

### Two new exact roots

Comparing the value of $C$ in (FIX-J) with (PIN) gives
$$
T-K_0-η-2=b_k-1
\Longrightarrow
\boxed{α=K_0+η+1=F_0.}
$$

Since $η=ν-b_k$,
$$
\boxed{T-ν=α-η=K_0+1≥1,}
\tag{SURPLUS}
$$
and
$$
C_0=T-K_0-1=ν.
$$
Therefore (M+) becomes
$$
\boxed{m=A_0n_i+(H_0+1)n_j-νn_k,\qquad A_0>0.}
\tag{ROOT+}
$$

Comparing $B=ρ_j-1$ in (UNIT-K) with the canonical expression for $q_L+n_k$, and writing $μ=ρ_j-R\ge1$, gives
$$
\boxed{m=-(D+1)n_i-μn_j+Tn_k.}
\tag{ROOT-T}
$$

These are exact identities for the same $m$ and the same generators. The signed rows are not called actual factorizations.

<a id="fr-P5.6.5"></a>

### A missing-j return of the opposite singleton

Since $q_R\in PF(Γ)$ and $j\notin SH(q_R)$, take a genuine return
$$
q_R+n_j=r m+Xn_i+Zn_k,
\quad r≥1,\quad X,Z≥0
\tag{RIGHT-J}
$$
If the $n_j$-coordinate were positive, removing one copy would give $q_R\inΓ$, so it is zero. If $r=0$, then $q_R+n_j\in H$, contrary to the missing direction.

<a id="fr-P5.6.5.1"></a>

### $r≥2$ gives a direct factorization of F

Insert one copy of $m$ from (ROOT+) into (RIGHT-J), remove one copy of $n_j$, add $c_R=Tn_k$, and remove one copy of $m$ from $W=F+m$. This gives
$$
\boxed{
F=(r-2)m+(X+A_0)n_i+H_0n_j+(T+Z-ν)n_k.
}
\tag{RIGHT-FABS}
$$
For $r\ge2$, the coefficients satisfy $r-2\ge0$, $X+A_0>0$, $H_0\ge0$, and $T+Z-ν\ge K_0+1\ge1$. Thus all are nonnegative and $F\inΓ$, a contradiction.

<a id="fr-P5.6.5.2"></a>

### $r=1$ gives a subcritical pure k/i relation

Using (ROOT+),
$$
q_R=(X+A_0)n_i+H_0n_j+(Z-ν)n_k.
$$
If $Z\geν$, then $q_R\inΓ$. Hence
$$
0≤Z≤ν-1.
\tag{RIGHT-Z}
$$

Now insert (ROOT-T) into (RIGHT-J) with $r=1$ and compare with the canonical identity
$$
q_R+n_j=(P-1)n_i+Rn_j-n_k
$$
Then
$$
(P+D-X)n_i+(R+μ)n_j=(T+Z+1)n_k.
$$
Since $R+μ=ρ_j$ and $ρ_jn_j=a_in_i+b_kn_k$,
$$
\boxed{(P+D+a_i-X)n_i=(α+Z+1)n_k.}
\tag{LAST}
$$

The right coefficient satisfies
$$
1≤α+Z+1≤α+ν=a_k<ρ_k.
$$
The right-hand side is positive, so the left coefficient is a positive integer. Thus (LAST) represents a positive multiple of $n_k$ strictly below $ρ_k$ as a nonnegative multiple of $n_i$, contradicting $k$-criticality.

Both $r\ge2$ and $r=1$ are impossible. Hence
$$
\boxed{\mathfrak D_i=\varnothing.}
$$
Applying [P5-dual](#fr-P5-dual) gives
$$
\boxed{\mathfrak D_k=\varnothing.}
$$

<a id="fr-P5.7"></a>

## Closure of PATH

Section [P5.1](#fr-P5.1) exhausts all actual central returns by PAIR or one of the two orientations of PFREE. PAIR is excluded in [P5.2](#fr-P5.2)--[P5.3](#fr-P5.3). After the sign determination in [P5.4](#fr-P5.4), PFREE is excluded in [P5.5](#fr-P5.5)--[P5.6](#fr-P5.6). The right-oriented case is covered by exactly the same proof under the full parameter transformation [P5-dual](#fr-P5-dual). Therefore the PATH configuration supplied by G4 does not exist.


<a id="sec-06"></a>

# 6　Exclusion of the one-singleton configuration (Type II)

Independently of the preceding section, we now treat the configuration with one singleton from Section 4. The input range includes $\lambda\le b_i$. The two missing-direction returns of the singleton give common coefficient caps, after which we exhaust the three possible orderings of their levels.

<a id="fr-T6"></a>

## Proposition excluding the one-singleton configuration

**T6.** The complete parameter range of [G4.11.3](#fr-G4.11.3) is excluded by the following single two-return argument.

<a id="fr-T6.1"></a>

## Exact input theorem

Let $\Gamma=\langle m,n_i,n_j,n_k\rangle$ be a numerical semigroup, let $F$ be its Frobenius number, and let $H=\langle n_i,n_j,n_k\rangle$. For positive integers $a_r,b_r$, with $\rho_r=a_r+b_r$, assume

$$
\rho_i n_i=b_jn_j+a_kn_k,\qquad
\rho_j n_j=a_in_i+b_kn_k,\qquad
\rho_k n_k=b_in_i+a_jn_j
\tag{H}
$$

and assume that each $\rho_r$ is the least positive critical multiplier of $n_r$ with respect to the other two generators.

Let the integers $\lambda,\mu,\nu$ satisfy

$$
1\le\lambda\le a_i-1,\qquad \lambda\le b_i,\qquad
1\le\mu\le b_j-1,\qquad
1\le\nu\le a_k-1
\tag{RANGES}
$$

Set

$$
P=\rho_i-\lambda,\quad R=\rho_j-\mu,\quad T=\rho_k-\nu,
\quad g=b_j-\mu\ge1.
$$

For the same actual $F,m$, assume

$$
W=F+m=(P-1)n_i+(R-1)n_j+(T-1)n_k
\tag{W}
$$

The following singleton is an actual pseudo-Frobenius element with missing directions $j,k$:

$$
q_S=-n_i+(R-1)n_j+(T-1)n_k\in PF(\Gamma),
\quad q_S+n_j\notin H,\quad q_S+n_k\notin H.
\tag{S}
$$

Moreover,

$$
f_A=(\rho_i-1)n_i+(a_j-1)n_j-n_k
=(a_i-1)n_i-n_j+(\rho_k-1)n_k,
$$

$$
q_{A_i}=f_A-\lambda n_i\notin\Gamma,
\qquad q_{A_k}=f_A-\nu n_k\notin\Gamma.
\tag{A-GAPS}
$$

**Theorem.** No configuration satisfying this input exists.

The TYPE II configuration of [G4.11.3](#fr-G4.11.3) satisfies these hypotheses. The proof does not require an actual return of $B_j$, although that arm supplies the parameter $\mu$ and the canonical representation of $W$ above.

<a id="fr-T6.2"></a>

## Two actual singleton returns

Since $q_S\in PF(\Gamma)$, $q_S+n_j,q_S+n_k\in\Gamma$. In every factorization of either successor, the generator that was added has coefficient zero. For example, for the generator $n_j$, if a factorization of $q_S+n_j$ contained a positive copy of it, removing one copy of $n_j$ from that same factorization would give $q_S\in\Gamma$.

Therefore we may write

$$
q_S+n_j=\ell m+A n_i+C n_k,
\qquad
q_S+n_k=h m+D n_i+B n_j
\tag{SJ/SK}
$$

with $A,B,C,D\ge0$ and $\ell,h\ge1$. Positivity of the two $m$-levels follows from the missing-direction assumptions: if one m-coefficient were zero, the corresponding successor would lie in $H$.

Comparison with the canonical singleton gives

$$
\ell m=-(A+1)n_i+Rn_j+(T-1-C)n_k,
\tag{JR}
$$

$$
hm=-(D+1)n_i+(R-1-B)n_j+Tn_k.
\tag{KR}
$$

<a id="fr-T6.3"></a>

## Endpoint caps

Since $q_S+Pn_i=W$, SJ gives

$$
F=(\ell-1)m+(P+A)n_i-n_j+C n_k.
$$

Adding $-a_in_i+\rho_jn_j-b_kn_k=0$ gives

$$
F=(\ell-1)m+(b_i-\lambda+A)n_i+(\rho_j-1)n_j+(C-b_k)n_k.
$$

Because $\lambda\le b_i$, if $C\ge b_k$ all coefficients would be nonnegative and $F\in\Gamma$. Hence

$$
0\le C\le b_k-1.
\tag{C-CAP}
$$

Similarly, SK gives

$$
F=(h-1)m+(P+D)n_i+B n_j-n_k
$$

Adding $-b_in_i-a_jn_j+\rho_kn_k=0$, we obtain

$$
F=(h-1)m+(a_i-\lambda+D)n_i+(B-a_j)n_j+(\rho_k-1)n_k.
$$

Since $a_i-\lambda\ge1$,

$$
0\le B\le a_j-1.
\tag{B-CAP}
$$

Up to this point, the repairs have been made only as signed identities; whenever a contradiction is inferred, nonnegativity of every coefficient in the final expression is checked explicitly.

<a id="fr-T6.4"></a>

## Uniform cap: $A,D\le b_i-1$

Set

$$
\eta=\nu-b_k,\qquad \theta=\mu-a_j.
$$

The canonical relations give

$$
f_A-q_S=\mu n_j+\eta n_k.
\tag{ANCH-A}
$$

Also,

$$
f_B=(\rho_i-1)n_i-n_j+(b_k-1)n_k,
\qquad f_B-q_S=\theta n_j+\nu n_k.
\tag{ANCH-B}
$$

No gap status for $f_B$ is assumed or used; ANCH-B is used only as an identity of values.

<a id="fr-T6.4.1"></a>

### $\eta\ge1$

Lifting SJ and SK to the same $f_A$ gives

$$
f_A=\ell m+A n_i+(\mu-1)n_j+(C+\eta)n_k,
$$

$$
f_A=hm+D n_i+(B+\mu)n_j+(\eta-1)n_k.
$$

Both are genuine factorizations. If $A\ge\lambda$ or $D\ge\lambda$, removing $\lambda n_i$ from that same factorization would give $q_{A_i}\in\Gamma$. Therefore

$$
A,D\le\lambda-1\le b_i-1.
$$

<a id="fr-T6.4.2"></a>

### $\theta\ge1$

Combine $q_{A_k}=f_A-\nu n_k=q_S+\mu n_j-b_kn_k$ with SJ, and add $\mathcal R_k$ as a completed identity. This gives

$$
\boxed{
q_{A_k}=\ell m+(A-b_i)n_i+(\mu-a_j-1)n_j+(C+a_k)n_k.
}
\tag{AK-J}
$$

Hence $A\ge b_i$ would make all coefficients nonnegative, so $q_{A_k}\in\Gamma$. Thus $A\le b_i-1$.

From SK the same operation gives

$$
\boxed{
q_{A_k}=hm+(D-b_i)n_i+(B+\mu-a_j)n_j+(a_k-1)n_k.
}
\tag{AK-K}
$$

If $D\ge b_i$, this is again a genuine factorization of the gap. Thus $D\le b_i-1$.

Neither use of AK-J/AK-K assumes any sign for $\eta$.

<a id="fr-T6.4.3"></a>

### $\eta=\theta=0$

From SJ,

$$
f_A=\ell m+A n_i+(\mu-1)n_j+C n_k
$$

is genuine, so $A\le\lambda-1\le b_i-1$.

In AK-K, $B+\mu-a_j=B\ge0$, so $D\le b_i-1$ follows as well.

<a id="fr-T6.4.4"></a>

### The remaining sign regions contradict singleton status

- If $\eta=0,\theta\le-1$, then $\mu\le a_j-1$, and
  $$
  q_S+n_k=(\rho_i-1)n_i+(a_j-\mu-1)n_j\in H,
  $$
  contradicting the missing direction $k$.
- If $\theta=0,\eta\le-1$, then $\nu\le b_k-1$, and
  $$
  q_S+n_j=(\rho_i-1)n_i+(b_k-\nu-1)n_k\in H,
  $$
  contradicting the missing direction $j$.
- If $\eta,\theta\le-1$, then
  $$
  q_S=(\rho_i-1)n_i+(-\theta-1)n_j+(-\eta-1)n_k\in H\subseteq\Gamma,
  $$
  contradicting the gap status of $q_S$.

These integer sign cases are exhaustive. Therefore

$$
\boxed{0\le A,D\le b_i-1.}
\tag{UNIFORM-I-CAP}
$$

<a id="fr-T6.5"></a>

## Exhaustion of the return levels

<a id="fr-T6.5.1"></a>

### $\ell=h$

Subtracting KR from JR gives

$$
(D-A)n_i+(B+1)n_j=(C+1)n_k.
$$

If $D\ge A$, then $1\le C+1\le b_k<\rho_k$ contradicts criticality of $n_k$. If $D<A$, then

$$
(B+1)n_j=(A-D)n_i+(C+1)n_k
$$

and $1\le B+1\le a_j<\rho_j$ contradicts criticality of $n_j$.

The coefficient of $m$ has been completely eliminated in this argument.

<a id="fr-T6.5.2"></a>

### $\ell>h$

Substitute KR exactly once into the expression for $F$ obtained from SJ:

$$
\boxed{
F=(\ell-h-1)m+(P+A-D-1)n_i+(R-2-B)n_j+(C+T)n_k.
}
\tag{ABS-L}
$$

The coefficients satisfy

$$
\ell-h-1\ge0,
\quad P+A-D-1\ge P-b_i=a_i-\lambda\ge1,
$$

$$
R-2-B\ge R-a_j-1=g-1\ge0,
\quad C+T\ge0.
$$

Thus every coefficient is nonnegative and $F\in\Gamma$, a contradiction.

<a id="fr-T6.5.3"></a>

### $h>\ell$

Conversely, substitute JR once into the expression for $F$ obtained from SK:

$$
\boxed{
F=(h-\ell-1)m+(P+D-A-1)n_i+(B+R)n_j+(T-2-C)n_k.
}
\tag{ABS-R}
$$

Again,

$$
h-\ell-1\ge0,
\quad P+D-A-1\ge P-b_i=a_i-\lambda\ge1,
$$

$$
B+R\ge0,
\quad T-2-C\ge T-b_k-1=a_k-\nu-1\ge0.
$$

Hence $F\in\Gamma$, a contradiction.

The three possible orderings have now been exhausted, so the input configuration does not exist.

$$
\boxed{\textbf{TYPE II CLOSED}}
$$


<a id="sec-07"></a>

# 7　A unit root for the chain configuration

For the remaining chain configuration, we maximize the $n_i$-coordinate over the finite set of factorizations of the same element $h_A=q_A+m$. This yields a unit-root relation, after which we derive the returns, caps, and slope inequalities needed for the boundary analysis. In this section $q_A,q_B$ denote $A_i,B_i$, respectively.

<a id="fr-R7"></a>

## Existence of a unit root

For the strict CHAIN configuration of [G4.11.2](#fr-G4.11.2), keeping the same $\Gamma,F,m,W$ and the same four actual pseudo-Frobenius rows, and after a full color reversal if necessary, we obtain
$$
\boxed{m+dn_i=Sn_j+Cn_k,\quad1\le d\le\lambda,\ S\ge g+1,\ C\ge\alpha}
$$
We call this conclusion CORE-ROOT.

<a id="fr-R7.1"></a>

## Exact hypotheses

Let Γ=⟨m,n_i,n_j,n_k⟩, with $m<\min(n_i,n_j,n_k)$, let $F$ be the Frobenius number, and put $W=F+m$.

The positive canonical Herzog data satisfy

$$
ρ_i n_i=b_j n_j+a_k n_k,\quad
ρ_j n_j=a_i n_i+b_k n_k,\quad
ρ_k n_k=b_i n_i+a_j n_j,
\quad ρ_r=a_r+b_r.
\tag{HCR}
$$

Let $λ,δ,β,g,α\ge1$ and set

$$
a_i=λ+δ,\quad b_i=λ+β,\quad
P=ρ_i-λ=a_i+β=b_i+δ,
\quad R=a_j+g,\quad T=b_k+α.
$$

Assume the same actual $W$ has the representation

$$
W=(P-1)n_i+(R-1)n_j+(T-1)n_k
\tag{W}
$$

and that the following four elements are actual pseudo-Frobenius gaps:

$$
q_A=(P-1)n_i+(a_j-1)n_j-n_k,
$$
$$
q_B=(P-1)n_i-n_j+(b_k-1)n_k,
$$
$$
q_J=(b_i-1)n_i+(R-1)n_j-n_k,
$$
$$
q_K=(a_i-1)n_i-n_j+(T-1)n_k.
\tag{CHAIN-PF}
$$

By [M4](#fr-M4), the genuine factorization

$$
P n_i=Lm+(t+1)n_j+(u+1)n_k,
\quad L\ge1,\quad t,u\ge0.
\tag{PFIBER}
$$

holds.

The proof of root existence itself uses only $q_A$ and PFIBER. The other three gaps are retained to preserve the scope of the color-reversal argument and the downstream theorems.

<a id="fr-R7.2"></a>

## An extremal choice on the same named actual element $h_A$

Set

$$
h_A=q_A+m.
$$

By the pseudo-Frobenius property, $h_A\in\Gamma$. Every $\Gamma$-factorization of $h_A$ has m-coordinate zero: if it were positive, removing one copy of $m$ from that same factorization would put $q_A$ in $\Gamma$. Hence $h_A\in H=\langle n_i,n_j,n_k\rangle$.

Among all H-factorizations of this same $h_A$, choose one with maximal $i$-coordinate:

$$
h_A=Xn_i+Yn_j+Zn_k,
\quad X,Y,Z\ge0.
\tag{MAX-I}
$$

Because all generators are positive, this factorization set is finite and nonempty, so the maximum exists explicitly.

<a id="fr-R7.2.1"></a>

### $X\le P-1$

By PFIBER,

$$
P n_i-m=(L-1)m+(t+1)n_j+(u+1)n_k\inΓ.
$$

If $X\ge P$, the same actual factorization of $h_A$ contains $Pn_i$ coefficientwise. Replacing that block by the displayed representation gives

$$
q_A=h_A-m=(h_A-Pn_i)+(Pn_i-m)\inΓ,
$$

a contradiction. Hence $X\le P-1$.

<a id="fr-R7.2.2"></a>

### $Y\leρ_j-1$, $Z\leρ_k-1$

If $Y\geρ_j$, replace the contained block $ρ_jn_j$ by $a_in_i+b_kn_k$. This produces another factorization of the same $h_A$ with $i$-coordinate $X+a_i>X$, contradicting MAX-I.

If $Z\geρ_k$, the relation $R_k$ similarly produces a same-$h_A$ factorization with $i$-coordinate $X+b_i>X$. Therefore

$$
0\le X\le P-1,\quad 0\le Y\leρ_j-1,\quad0\le Z\leρ_k-1.
\tag{BOX}
$$

No generic connectivity or uniqueness is used; only these two explicit legal replacements inside a factorization of the same element are needed.

<a id="fr-R7.3"></a>

## The initial root and its bounds

Comparing the canonical expression for $q_A$ with MAX-I, define

$$
d=P-1-X,\quad S=Y-a_j+1,\quad C=Z+1
$$

Then exactly

$$
m=-d n_i+S n_j+C n_k.
\tag{ROOT0}
$$

From BOX,

$$
0\le d\le P-1,\quad 1-a_j\le S\le b_j,
\quad1\le C\leρ_k.
\tag{INITIAL}
$$

At this point no nonnegativity assumption is made on $S$.

<a id="fr-R7.3.1"></a>

### $S\ge g$

Rewrite $W$ using $R_k$, and use $F=W-m$ together with ROOT0. This gives

$$
F=(δ+d-1)n_i+(g-S-1)n_j+(ρ_k+T-C-1)n_k.
\tag{F-S}
$$

If $S\le g-1$, then all coefficients are nonnegative: $δ+d-1\ge0$, $g-S-1\ge0$, and $ρ_k+T-C-1\ge T-1\ge0$. Hence $F\in\Gamma$, a contradiction.

Thus $S\ge g\ge1$.

<a id="fr-R7.3.2"></a>

### $C\geα$

Similarly, rewriting $W$ with $R_j$ gives

$$
F=(β+d-1)n_i+(ρ_j+R-S-1)n_j+(α-C-1)n_k.
\tag{F-C}
$$

If $C\leα-1$, then $β+d-1\ge0$,

$$
ρ_j+R-S-1\geρ_j+R-b_j-1=a_j+R-1\ge0,
$$

and $α-C-1\ge0$. Hence $F\in\Gamma$, a contradiction.

Therefore $C\geα\ge1$.

<a id="fr-R7.3.3"></a>

### $d\ge1$

If $d=0$, then $m=S n_j+C n_k$, with $S,C\ge1$, so $m\ge n_j+n_k$. This contradicts the multiplicity inequality $m<\min(n_j,n_k)$.

<a id="fr-R7.3.4"></a>

### $d\leλ$

From $F=W-m$ and ROOT0,

$$
F=(P+d-1)n_i+(R-S-1)n_j+(T-C-1)n_k.
$$

Add one copy of $R_i$ as a completed zero identity:

$$
\boxed{
F=(d-λ-1)n_i+(R+b_j-S-1)n_j+(T+a_k-C-1)n_k.
}
\tag{F-D}
$$

If $d\geλ+1$, every coefficient is nonnegative. Indeed,

$$
R+b_j-S-1\ge R-1\ge0,
$$

and

$$
T+a_k-C-1\ge T+a_k-ρ_k-1
=T-b_k-1=α-1\ge0.
$$

Thus $F\in\Gamma$, a contradiction.

We have proved

$$
\boxed{1\le d\leλ,\qquad g\le S\le b_j,\qquad α\le C\leρ_k.}
\tag{ROOT-BOX}
$$

Signed intermediate identities are not called actual; every contradiction above uses a final representation of $F$ whose coefficients have been checked to be nonnegative.

<a id="fr-R7.4"></a>

## At least one inequality is strict

If $S=g$ and $C=α$, substituting ROOT0 into $F=W-m$ gives

$$
F=(P+d-1)n_i+(a_j-1)n_j+(b_k-1)n_k\inΓ,
$$

a contradiction. Therefore

$$
S\ge g+1\quad\text{or}\quad C\geα+1.
\tag{STRICT}
$$

If $S\ge g+1$, we are already in the desired orientation of CORE-ROOT. It remains to treat $S=g,C\geα+1$, where we apply the full color reversal below.

<a id="fr-R7.5"></a>

## Full preservation under color reversal

Define new notation by

$$
i'=i,\quad j'=k,\quad k'=j,
$$
$$
a_i'=b_i,\ b_i'=a_i,\quad
a_j'=b_k,\ b_j'=a_k,\quad
a_k'=b_j,\ b_k'=a_j
$$

The scalar parameters transform as

$$
λ'=λ,\quadδ'=β,\quadβ'=δ,
\quad g'=α,\quadα'=g,
$$
$$
P'=P,\quad R'=T,\quad T'=R,
\quad d'=d,\quad S'=C,\quad C'=S.
$$

Under these replacements, every HCR equation is merely renamed. The same element $W$ is still

$$
(P'-1)n_{i'}+(R'-1)n_{j'}+(T'-1)n_{k'}
$$

The semigroup $\Gamma$, $F$, and $m$ are unchanged.

The actual pseudo-Frobenius gaps are exchanged by

$$
q_A'=q_B,\qquad q_B'=q_A,\qquad
q_J'=q_K,\qquad q_K'=q_J
$$

Hence all four actuality and gap statuses are preserved. PFIBER is the same nonnegative factorization of the same element $Pn_i$, with $t'=u,u'=t$.

ROOT0 becomes

$$
m+d'n_{i'}=S'n_{j'}+C'n_{k'},
$$

In the case under consideration,

$$
1\le d'\leλ',\qquad
S'=C\geα+1=g'+1,\qquad
C'=S=g=α'.
$$

Thus all hypotheses of UNITROOT hold for the same configuration after relabeling.

<a id="fr-C8.1"></a>

## Input from CORE to the late-stage closure

<a id="fr-C8.1.0"></a>

## Minimal sufficient CORE input

Assume the following.

1. A numerical semigroup $\Gamma=\langle m,n_i,n_j,n_k\rangle$, with $0<m<\min(n_i,n_j,n_k)$, and Frobenius number $F\notin\Gamma$.
2. Positive integers $\lambda,\delta,\beta,g,\alpha,a_j,b_j,a_k,b_k$, with
   $$
   a_i=\lambda+\delta,\quad b_i=\lambda+\beta,\quad
   \rho_r=a_r+b_r,\quad P=\lambda+\delta+\beta,\quad
   R=a_j+g,\quad T=b_k+\alpha.
   $$
   The genuine critical relations in the pure tail $H=\langle n_i,n_j,n_k\rangle$ are
   $$
   \rho_i n_i=b_jn_j+a_kn_k,\qquad
   \rho_j n_j=a_in_i+b_kn_k,\qquad
   \rho_k n_k=b_in_i+a_jn_j.
   $$
   Here “critical” means that $\rho_r$ is the least positive multiple of $n_r$ admitting a nonnegative representation by the other two generators. No minimality is assumed for arbitrary signed relations.
3. One and the same actual element
   $$
   W=F+m=(P-1)n_i+(R-1)n_j+(T-1)n_k.
   $$
4. Four pseudo-Frobenius gaps in the same configuration:
   $$
   \begin{aligned}
   q_{A_i}&=(P-1)n_i+(a_j-1)n_j-n_k,\\
   q_{B_i}&=(P-1)n_i-n_j+(b_k-1)n_k,\\
   q_{B_j}&=(b_i-1)n_i+(R-1)n_j-n_k,\\
   q_{A_k}&=(a_i-1)n_i-n_j+(T-1)n_k.
   \end{aligned}
   $$
   What is used below is that each $q\notin\Gamma$ and that the successor in the displayed missing direction belongs to $\Gamma$. The latter follows from the pseudo-Frobenius property.
5. A ROOT on the same generators,
   $$
   m+d n_i=S n_j+C n_k,\qquad
   1\le d\le\lambda,\quad S\ge g+1,\quad C\ge\alpha.
   \tag{CORE-ROOT}
   $$

Here $C$ is the coefficient in ROOT and is distinct from $T=b_k+\alpha$. We do not assume minimality or equality of any return levels.

**Input lemma.** The configuration of [R7](#fr-R7) satisfies this CORE input. We now derive the consequences required in [C8.2](#fr-C8.2)--[E8](#fr-E8).

<a id="fr-C8.1.1"></a>

## Missing-coordinate returns and positive m-levels follow from CORE

By the pseudo-Frobenius property, every relevant successor lies in $\Gamma$. If a genuine factorization of such a successor contained one copy of its missing generator, removing that copy coefficientwise would put the original gap in $\Gamma$. Thus every missing coordinate is zero in every such factorization.

First write
$$
EA=q_{A_i}+n_i=L_i m+U_jn_j+U_kn_k
$$
Suppose $L_i=0$. Comparing with the canonical row gives
$$
P n_i=(U_j-a_j+1)n_j+(U_k+1)n_k.
$$
Since $P<\rho_i$, if the $j$-coefficient is nonnegative this is an immediate subcritical $i$-contradiction. If it is negative, then
$$
(U_k+1)n_k=P n_i+(a_j-1-U_j)n_j
$$
so $U_k+1\ge\rho_k$. Comparing one copy of $\mathcal R_k$ gives
$$
\delta n_i=(U_j+1)n_j+(U_k+1-\rho_k)n_k,
$$
again a positive subcritical $i$-contradiction. Hence $L_i\ge1$.

Similarly, if $EB=q_{B_i}+n_i=L_bm+V_jn_j+V_kn_k$ had $L_b=0$, then
$$
P n_i=(V_j+1)n_j+(V_k-b_k+1)n_k
$$
When necessary, comparing one copy of $\mathcal R_j$ produces
$$
\beta n_i=(V_j+1-\rho_j)n_j+(V_k+1)n_k
$$
which is impossible. Thus $L_b\ge1$. Every use of criticality here occurs in a relation with m-coordinate zero.

From the CORE representation of $W$ and the four rows, the complements are exactly
$$
c_{A_i}=g n_j+Tn_k,\quad c_{B_i}=R n_j+\alpha n_k,
\quad c_{B_j}=\delta n_i+Tn_k,\quad c_{A_k}=\beta n_i+Rn_j.
$$
Add the corresponding complement to EA or EB and remove one actually present copy of $m$. This gives
$$
F+n_i=(L_i-1)m+(U_j+g)n_j+(U_k+T)n_k,
$$
$$
F+n_i=(L_b-1)m+(V_j+R)n_j+(V_k+\alpha)n_k.
$$
If the $j$- or $k$-coefficient reached the corresponding $\rho$, replace one canonical packet to create a positive copy of $n_i$; removing that copy would give $F\in\Gamma$. Hence
$$
U_j+g<\rho_j,\quad U_k+T<\rho_k,\quad
V_j+R<\rho_j,\quad V_k+\alpha<\rho_k.
\tag{FI-CAPS}
$$
In particular, $R<\rho_j$, $T<\rho_k$, $g<b_j$, and $\alpha<a_k$.

Next consider $Q_j=q_{B_j}+n_j=L_jm+A_jn_i+C_jn_k$. If $L_j=0$, then
$$
(b_i-1-A_j)n_i+R n_j=(C_j+1)n_k.
$$
If the $i$-coefficient is nonpositive, this contradicts $R<\rho_j$. If it is positive, $k$-criticality forces $C_j+1\ge\rho_k$. Comparing one copy of $\mathcal R_k$ then gives
$$
g n_j=(A_j+1)n_i+(C_j+1-\rho_k)n_k,
$$
a subcritical $j$-contradiction. Thus $L_j\ge1$. Dually, assuming $L_k=0$ in $Q_k=q_{A_k}+n_k=L_km+A_kn_i+B_kn_j$ reduces to
$$
\alpha n_k=(A_k+1)n_i+(B_k+1-\rho_j)n_j
$$
which is impossible. Hence $L_k\ge1$.

We refer to these four positive-level actual representations as RET. They all follow from CORE.

<a id="fr-C8.1.2"></a>

## Additional caps and slopes

Adding the complement to the actual row $Q_j$ and removing one copy of $m$ gives
$$
F+n_j=(L_j-1)m+(A_j+\delta)n_i+(C_j+T)n_k.
\tag{FJ}
$$
If $C_j+T\ge\rho_k$, replacing one $\mathcal R_k$-packet creates $a_j\ge1$ copies of $n_j$, and removing one gives $F\in\Gamma$. Therefore
$$
C_j+T<\rho_k.
\tag{FJ-KCAP}
$$
In particular, $C_j<\rho_k$.

Make one completed ROOT substitution into Qj:
$$
Q_j=(L_j-1)m+(A_j-d)n_i+S n_j+(C_j+C)n_k.
$$
If $A_j\ge d$, every coefficient is nonnegative and the representation contains a positive $j$-coefficient, contradicting the gap property. Thus $A_j\le d-1$. The same argument gives $A_k\le d-1$. Inserting ROOT and one copy of $\mathcal R_j$ or $\mathcal R_k$ into EA/EB also yields
$$
U_j+S<\rho_j,\quad U_k+C<\rho_k,
\quad V_j+S<\rho_j,\quad V_k+C<\rho_k
$$
For example, in each of the following four representations, nonnegativity of the indicated problematic coefficient would put the original gap in $\Gamma$:
$$
q_{A_i}=(L_i-1)m+(a_i-d-1)n_i+(U_j+S-\rho_j)n_j+(U_k+C+b_k)n_k,
$$
$$
q_{A_i}=(L_i-1)m+(b_i-d-1)n_i+(U_j+S+a_j)n_j+(U_k+C-\rho_k)n_k,
$$
$$
q_{B_i}=(L_b-1)m+(a_i-d-1)n_i+(V_j+S-\rho_j)n_j+(V_k+C+b_k)n_k,
$$
$$
q_{B_i}=(L_b-1)m+(b_i-d-1)n_i+(V_j+S+a_j)n_j+(V_k+C-\rho_k)n_k.
$$

Before removing one copy of $n_i$, the relevant coefficient is $a_i-d>0$ or $b_i-d>0$.

Comparison of ROOT with $\mathcal R_j$ gives
$$
\rho_jm=(Sa_i-d\rho_j)n_i+(Sb_k+C\rho_j)n_k.
$$
If $d\rho_j-Sa_i\le0$, then $m>n_k$, contradicting multiplicity. Similarly,
$$
\rho_km=(Cb_i-d\rho_k)n_i+(S\rho_k+Ca_j)n_j
$$
gives the second slope inequality. Hence
$$
d\rho_j-Sa_i>0,\qquad d\rho_k-Cb_i>0.
\tag{SLOPES}
$$
In particular, $S<\rho_j,C<\rho_k$. This argument uses multiplicity, not criticality.

<a id="fr-C8.1.3"></a>

## Two intrinsic candidates and safe color reversal

Set
$$
h=\lfloor\lambda/d\rfloor,\quad q_0=h+1,\quad
r=\lambda-hd,\quad e_0=q_0d-\lambda=d-r.
$$
Using ROOT and $-\mathcal R_i$, the completed F-row for arbitrary integers $x,y$ is
$$
v(x,y)=(x-1,\ P-1+xd-y\rho_i,\ R-1-xS+yb_j,\ T-1-xC+ya_k).
$$
If the final row is nonnegative, then $x\ge1$. A successful point with $y\le0$ requires the $j,k$-coordinates to succeed already at $(x,y)=(1,0)$, in which case that point itself gives a nonnegative representation of $F$. For $y\ge1$, the $i$-fit condition is
$$
xd\ge\lambda+1+(y-1)\rho_i.
$$
The identity
$$
\rho_i-q_0d-q_0=(q_0-2)(d-1)+2r+\delta+\beta-2\ge0
\tag{RHO-GAP}
$$
then gives $x\ge yq_0$. Thus for the second candidate
$$
v(q_0,1)=(q_0-1,e_0-1,J_0,K_0),
$$
$$
J_0=\rho_j+g-1-q_0S,\quad K_0=\rho_k+\alpha-1-q_0C
$$
if either the $j$- or $k$-coordinate is negative, then no point in the region $y\ge1$ succeeds. Conversely, if both are nonnegative, the second candidate succeeds. This gives the complete integer test by two candidates.

Since $F$ is a gap, the second candidate fails. Moreover,
$$
q_0m=(\rho_i-q_0d)n_i+(q_0S-b_j)n_j+(q_0C-a_k)n_k
\tag{QM}
$$
together with RHO-GAP shows that the $j$- and $k$-coordinates cannot both be deficient. More strongly,
$$
J_0<0\Longrightarrow q_0C\le a_k-1,
\quad K_0<0\Longrightarrow q_0S\le b_j-1.
$$
For example, in the first implication, if $q_0C\ge a_k$, then in QM the $i$-coefficient is $\ge q_0$ and the $j$-coefficient is $\ge R>0$, forcing $m>n_i$.

If only $K_0$ is negative, interchange $j,k$ and simultaneously apply
$$
(a_i,b_i)\mapsto(b_i,a_i),\quad
(a_j,b_j)\mapsto(b_k,a_k),\quad
(a_k,b_k)\mapsto(b_j,a_j).
$$
Thus
$$
(\delta,\beta,g,\alpha,R,T,S,C)
\mapsto(\beta,\delta,\alpha,g,T,R,C,S).
$$
The four pseudo-Frobenius rows are exchanged by $q_{A_i}\leftrightarrow q_{B_i}$ and $q_{B_j}\leftrightarrow q_{A_k}$, while $\Gamma,F,m,W,\lambda,d$ remain unchanged.

Before reversal, $hC<\rho_k$ and $K_0<0$ imply
$$
1\le-K_0\le C-\alpha,
$$
so $C\ge\alpha+1$. After reversal, $S'\ge g'+1$ still holds and $C'=S\ge\alpha'$. Hence the whole CORE package is preserved.

We may therefore orient the situation so that $J_0<0$. Put
$$
\Delta_0=q_0S-\rho_j-g+1\ge1,\quad
A_0=e_0-\delta-1\ge0,\quad C_0=a_k-q_0C-1\ge0.
$$
The sign of $A_0$ follows because $q_0S>\rho_j$, together with SLOPES, implies $q_0d>a_i$.
$$
\tau_0=\rho_j-hS\ge1,\quad
\Delta_0+\tau_0=S-g+1,
\quad 1\le\Delta_0\le S-g.
$$
The second candidate gives the genuine actual relation
$$
\Omega_0=F+\Delta_0n_j=(q_0-1)m+(e_0-1)n_i+(C_0+T)n_k
\tag{COMPACT}
$$
The source $c_{B_j}=\delta n_i+Tn_k$ is actually contained in this one factorization. Removing it and adding $m$ yields
$$
q_{B_j}+\Delta_0n_j=q_0m+A_0n_i+C_0n_k.
$$

<a id="fr-C8.1.4"></a>

## Making the required lower bounds on return levels explicit

### Ai/Bi

Comparing the canonical and actual expressions for EA and eliminating m completely gives
$$
(P+L_id)n_i=(L_iS+U_j-a_j+1)n_j+(L_iC+U_k+1)n_k.
$$
If $L_id<\lambda$, the coefficient on the left is below $\rho_i$. If the $j$-coefficient on the right is nonnegative, this is immediately a subcritical $i$-contradiction. If it is negative, then the $k$-coefficient must be $\ge\rho_k$; after comparing one copy of $\mathcal R_k$,
$$
(\delta+L_id)n_i=(L_iS+U_j+1)n_j+(L_iC+U_k+1-\rho_k)n_k
$$
which is again a subcritical $i$-contradiction. The dual argument for EB is identical. Hence
$$
L_id\ge\lambda,\quad L_bd\ge\lambda,
\quad L_i,L_b\ge\lceil\lambda/d\rceil\ge h.
\tag{I-LEVEL}
$$

### Bj

Suppose $L_j\le h$. Then
$$
(b_i-1-A_j+L_jd)n_i+(R-L_jS)n_j=(C_j+L_jC+1)n_k.
$$
The $i$-coefficient is positive because $A_j\le d-1$, and it is below $\rho_i$ because $L_jd\le\lambda$. If the $j$-coefficient is nonpositive, this is a subcritical $i$-contradiction. If it is positive, applying $k$-criticality and then comparing $\mathcal R_k$ gives
$$
(L_jd-A_j-1)n_i+(g-L_jS)n_j=(C_j+L_jC+1-\rho_k)n_k
$$
The $j$-coefficient is negative. If the $i$-coefficient is nonpositive, positivity fails; if it is positive, we again obtain a subcritical $i$-contradiction. Thus $L_j\ge q_0$.

If $L_j=q_0$, compare the same actual element $q_{B_j}+\Delta_0n_j$ and eliminate m:
$$
0=(A_j-A_0)n_i+(\Delta_0-1)n_j+(C_j-C_0)n_k.
$$
The absolute value of each of the three coefficients is below the corresponding $\rho$. If the relation were nonzero, one sign class would consist of a subcritical multiple of a single generator, impossible. Hence
$$
L_j=q_0\Longrightarrow(\Delta_0,A_j,C_j)=(1,A_0,C_0).
$$
The subcritical bound on $C_j$ used here is exactly FJ-KCAP from [C8.1.2](#fr-C8.1.2).

### Ak in the strict region $C>\alpha$

Assume $L_k\le h$. Eliminating m gives
$$
(a_i-1-A_k+L_kd)n_i+(T-L_kC)n_k=(B_k+L_kS+1)n_j.
$$
The first $i$-coefficient is positive and below $\rho_i$. If the $k$-coefficient is nonpositive, we get a subcritical $i$-contradiction. If it is positive, apply $j$-criticality and then compare $\mathcal R_j$:
$$
(L_kd-A_k-1)n_i=(B_k+L_kS+1-\rho_j)n_j+(L_kC-\alpha)n_k.
\tag{K-PURE}
$$
Since $C>\alpha$, the $k$-coefficient on the right is positive, so both signs of the $i$-coefficient are impossible. Therefore $L_k\ge q_0$. In this range, the $j$-coefficient on the right of K-PURE is also positive because $q_0S>\rho_j$, and hence
$$
L_kd-A_k-1\ge\rho_i\ge q_0d+q_0.
$$
Thus in fact $L_k\ge q_0+1$.

Insert $q_0$ copies of ROOT and one $R_j$ into the actual FK representation, and finally remove one copy of $n_k$. The completed F-row is
$$
\begin{aligned}
F={}&(L_k-q_0-1)m+(A_k+\beta+\delta-e_0)n_i\\
 &+(B_k+R+q_0S-\rho_j)n_j+(q_0C+b_k-1)n_k.
\end{aligned}
$$
All coefficients except possibly the $i$-coefficient are nonnegative, so
$$
A_k+\beta+\delta\le e_0-1,
\qquad e_0\ge\beta+\delta+1.
\tag{SUM-NOTCH}
$$
This strict-region conclusion is not used when $C=\alpha$.

<a id="fr-C8.1.5"></a>

## The intrinsic packet and the cap from FK

Comparing $h$ copies of ROOT with one $R_j$ gives the exact equality
$$
h m+\tau_0n_j=(a_i-hd)n_i+(b_k+hC)n_k.
\tag{SHIFT-NEW}
$$
All coefficients are nonnegative, and $a_i-hd=r+\delta>0$. By I-LEVEL, the m-source in EA and EB always contains at least $h$ copies. Therefore the replacement can be made within those same actual factorizations, giving
$$
U_j,V_j\le\tau_0-1.
$$

In the strict region $C>\alpha$, the actual FK representation has m-coefficient $L_k-1\ge h+1$, so it also contains the required $h$ copies. If $B_k+R\ge\tau_0$, then
$$
\begin{aligned}
F={}&(L_k-h-1)m+(A_k+\beta+a_i-hd)n_i\\
 &+(B_k+R-\tau_0)n_j+(b_k+hC-1)n_k\in\Gamma.
\end{aligned}
$$
Hence
$$
0\le B_k\le\tau_0-R-1,\qquad \tau_0\ge R+1.
\tag{FK-STRONG}
$$
This $\tau_0$-cap from FK is used in [C8.4](#fr-C8.4).


<a id="sec-08"></a>

# 8　Boundary elimination and the packet window

We take as input the root and the actual returns obtained in the preceding section. We first specify the selection set and prove existence in order to define the first fitting point, and then determine the range in which its packet can be contained within the same element. We separate the boundary case $C=\alpha$ from the strict case and show that the final residual range is exhausted by $\mathcal U$ and $\mathcal D$. For ease of reference, the positivity expansions are also collected in Appendix C.

<a id="fr-C8.2"></a>

## First point, boundary, and strict packet window

We use CORE, RET, the caps, and the slopes from [C8.1](#fr-C8.1). In what follows, the local symbols $L,M$ denote $L_i,L_j$, respectively; $x,z$ are pure-$H$ kernel coefficients, $Q=U_j+1$, and $a=A_j+1$.

<a id="fr-C8.2.2"></a>

## The first ROOT / $R_j$ fitting point intrinsic to CENTRAL

The $R_k$-face of $W$ is genuinely

$$
\boxed{W=(\delta-1)n_i+(g-1)n_j+(\rho_k+T-1)n_k.}\tag{W-K}
$$

From ROOT and $R_j$,

$$
\begin{aligned}
F={}&(n-1)m+(\delta-1+nd-\zeta a_i)n_i\\
&+(g-1+\zeta\rho_j-nS)n_j\\
&+(\rho_k+T-1-nC-\zeta b_k)n_k.
\end{aligned}
\tag{HRJ}
$$

This is a completed family. We do not claim a new exhaustive classification of the entire integral family below; instead, we select one first point with the required properties.

For $\zeta\ge1$, set

$$
n_\zeta=\left\lceil\frac{\zeta a_i-\delta+1}{d}\right\rceil,
$$
$$
I_\zeta=\delta-1+n_\zeta d-\zeta a_i,
\qquad J_\zeta=g-1+\zeta\rho_j-n_\zeta S.
$$

Since $a_i>d$, the sequence $n_\zeta$ is strictly increasing and $0\le I_\zeta\le d-1$. Moreover, $n_1=\lceil(\lambda+1)/d\rceil\ge2$.

Because $V=d\rho_j-Sa_i>0$,

$$
J_d=V+S\left\lfloor\frac{\delta-1}{d}\right\rfloor+g-1>0.
$$

Hence

$$
\widehat\zeta=\min\{\zeta\ge1:J_\zeta\ge0\}\le d
$$

exists. For brevity, write

$$
N=n_{\widehat\zeta},\quad I=I_{\widehat\zeta},\quad J=J_{\widehat\zeta}
$$

If $\widehat\zeta>1$, the preceding value of $J$ is negative and $n$ increases by at least one, so

$$
J\le\rho_j-S-1.
$$

A uniform safe cap, including $\widehat\zeta=1$, is therefore

$$
\boxed{N\ge2,\quad 0\le I\le d-1,\quad
0\le J\le\rho_j-S+g-1.}\tag{FIRST-CAPS}
$$

Define

$$
\boxed{\Xi=NC+\widehat\zeta b_k-(\rho_k+T-1).}
$$

If $\Xi\le0$, then HRJ itself is a nonnegative $F$-row, and the case is closed. Thus every survivor has $\Xi\ge1$.

$$
\widehat\Omega=F+\Xi n_k=(N-1)m+In_i+Jn_j
$$

is a genuine ZERO-$k$ face of the named actual upper element.

---

<a id="fr-C8.2.3"></a>

## SAME-element packet and the FI/FJ level wall

<a id="fr-C8.2.3.1"></a>

### Re-deriving CENTRAL FK

From $W$, ROOT, and $R_j$, exactly

$$
\boxed{F+n_k=(d+\beta-1)n_i+(R+\rho_j-S-1)n_j+(\alpha-C)n_k.}\tag{C-FK}
$$

When $C>\alpha$, this expression cannot itself be called actual. However,

$$
F+(C-\alpha+1)n_k
=(d+\beta-1)n_i+(R+\rho_j-S-1)n_j
$$

is genuine.

Define

$$
D_F=d+\beta-1-I\ge\beta>0,
$$
$$
E_F=R+\rho_j-S-1-J\ge a_j>0,
$$
$$
\boxed{\chi=C-\alpha+1-\Xi.}
$$

Raise the two actual upper elements to the same element using only additional copies of $n_k$, and then remove their common $In_i+Jn_j$ coefficientwise. This gives

$$
\boxed{(N-1)m+\max(\chi,0)n_k
=D_Fn_i+E_Fn_j+\max(-\chi,0)n_k.}\tag{PACKET}
$$

**Both sides of this displayed relation have nonnegative coefficients.** In particular, we are not misrepresenting the signed FK relation as an actual factorization.

<a id="fr-C8.2.3.2"></a>

### The strong wall at $C=\alpha$

At this boundary, $\chi=1-\Xi\le0$. Hence

$$
(N-1)m=D_Fn_i+E_Fn_j+(\Xi-1)n_k.
$$

If $N-1\le L_i$, we insert this packet into the $m$-part of the SAME EA representation, producing a positive $i$-coefficient and hence $q_{A_i}\in\Gamma$. The same applies to EB. If $N-1\le L_j$, we insert it into the SAME $Q_j$ representation and produce a positive $j$-coefficient.

Therefore

$$
\boxed{C=\alpha\Longrightarrow N\ge\max(L_i,L_b,L_j)+2.}\tag{BOUNDARY-WALL}
$$

<a id="fr-C8.2.3.3"></a>

### The wall for general $\chi\le T$

Assume $\chi\le T$. If $N\le L_i$, apply PACKET inside the SAME FI-A representation and finally remove one copy of $n_i$:

$$
\boxed{
F=(L_i-N)m+(D_F-1)n_i
 +(U_j+g+E_F)n_j+(U_k+T-\chi)n_k\in\Gamma.
}\tag{FI-CERT}
$$

If $N\le L_j$, apply it inside the SAME FJ representation:

$$
\boxed{
F=(L_j-N)m+(A_j+\delta+D_F)n_i
 +(E_F-1)n_j+(C_j+T-\chi)n_k\in\Gamma.
}\tag{FJ-CERT}
$$

When $\chi>0$, the $T$ copies of $n_k$ in FI/FJ supply the required source. When $\chi\le0$, no $n_k$ is consumed and copies are instead produced. Every coefficient in the final displayed representations is nonnegative.

Consequently,

$$
\boxed{\chi\le T\Longrightarrow N\ge\max(L_i,L_j)+1.}\tag{WINDOW-WALL}
$$

**We do not apply this $T$-window unconditionally to a general EB representation.** The canonical $k$-supply in FI-B is $\alpha$, not $T$.

---

<a id="fr-C8.2.4"></a>

## The pure-$H$ integer basis and two coefficients equal to one

<a id="fr-C8.2.4.1"></a>

### Kernel basis

Use the integer kernel basis $\mathbf r_j=(a_i,-\rho_j,b_k),\mathbf r_k=(b_i,a_j,-\rho_k)$ from [G4.3](#fr-G4.3). In all coefficient comparisons below, the $m$-coordinate is eliminated completely before the comparison is made.

<a id="fr-C8.2.4.2"></a>

### EA

We work under WINDOW-WALL. Put $L=L_i$, $M=L_j$, $a=A_j+1\ge1$, and $Q=U_j+1\ge1$.

Compare the canonical and actual EA rows and eliminate $m$ completely using ROOT:

$$
(P+Ld,\ a_j-1-LS-U_j,\ -LC-U_k-1)
=x\mathbf r_j+y\mathbf r_k.
$$

The quantities $x,y$ are integers. The first coordinate is positive, the third is negative, and the second is less than $a_j$. If $y\le0$, the sign of the third coordinate forces $x\le0$, contradicting the first coordinate. If $x\le0$, the second coordinate is at least $a_j$. Thus $x,y\ge1$.

Comparing coefficients gives

$$
Ld=xa_i+(y-1)b_i-\delta,
\quad LS=x\rho_j-(y-1)a_j-Q.
$$

If $y\ge2$, then at the HRJ point $(\zeta,n)=(x,L)$,

$$
I=(y-1)b_i-1\ge0,\quad J=Q+g-1+(y-1)a_j\ge0.
$$

For the same $\zeta=x$, minimizing $n$ only increases $J$, and $n_x\le L$. Hence the first point also has $N\le L$, contradicting WINDOW-WALL.

Therefore $y=1$:

$$
\boxed{Ld=xa_i-\delta,\quad LS=x\rho_j-Q,\quad
\varepsilon:=\rho_k-U_k-1=LC+xb_k.}\tag{EA-ONE}
$$

<a id="fr-C8.2.4.3"></a>

### SAME Qj

After eliminating $m$ completely using ROOT,

$$
(Md+b_i-1-A_j,\ R-MS,\ -MC-C_j-1)
=z\mathbf r_j+v\mathbf r_k.
$$

The first coordinate is positive because $A_j\le d-1$, the third is negative, and the second is less than $a_j$ because $S\ge g+1$. The same sign argument gives $z,v\ge1$.

If $v\ge2$, then at the point $(z,M)$,

$$
I=A_j+\delta+(v-1)b_i\ge0,
\quad J=(v-1)a_j-1\ge0.
$$

Thus $N\le M$, contradicting WINDOW-WALL. Hence

$$
\boxed{Md=za_i+a,\quad MS=z\rho_j+g,\quad
\rho_k=MC+C_j+1+zb_k.}\tag{QJ-ONE}
$$

---

<a id="fr-C8.2.5"></a>

## An empty integer triangle, determinant one, and the level exception

Consider the triangle in the $(\zeta,n)$-plane with vertices

$$
O=(0,0),\quad U=(x,L),\quad V_0=(z,M)
$$

The values of the affine functions $I,J$ at its vertices are

| Vertex | I | J |
|---|---:|---:|
| O | $\delta-1$ | $g-1$ |
| U | $-1$ | $Q+g-1$ |
| V0 | $A_j+\delta$ | $-1$ |

At every nonvertex integer point, $I$ and $J$ are integers strictly greater than $-1$, hence nonnegative. Moreover, $0<n\le\max(L,M)$. Such a point would yield a first fit with $N\le\max(L,M)$, contradicting WINDOW-WALL.

On the other hand,

$$
(xM-zL)d=xa+z\delta>0.
$$

If the positive integer determinant were at least two, the fundamental parallelogram would contain a nonzero integer point, and either that point or its reflection across $U+V_0$ would give a nonvertex integer point of the triangle. Hence

$$
\boxed{xM-zL=1.}\tag{DET1}
$$

It follows that

$$
\boxed{
\begin{aligned}
d&=xa+z\delta,&S&=xg+zQ,\\
a_i&=La+M\delta,&\rho_j&=Lg+MQ,\\
b_i&=La+(M-1)\delta+\beta,&V&=aQ-\delta g>0.
\end{aligned}}\tag{PARAM}
$$

From $a_i>d$ and DET1, the level is exactly

$$
\boxed{
[L\ge x+1\ge2,\ M>z\ge1]
\quad\vee\quad
[L=x=1,\ M=z+1].
}\tag{LEVEL-SPLIT}
$$

Indeed, if $x\ge2,L\le x$, then $xM=zL+1\le zx+1$, so $M\le z$, and hence $a_i\le d$. If $x=1,L=1$, DET1 gives $M=z+1$. All other cases fall in the first alternative.

The second alternative is the level-one exception $\mathcal U$, which is passed to [C8.3](#fr-C8.3).

---

<a id="fr-C8.2.6"></a>

## The exact $k$-ceiling from FJ absorption

EA-ONE is

$$
\delta n_i+\varepsilon n_k=Lm+Qn_j,
\quad \varepsilon=LC+xb_k.
$$

If $\varepsilon\le C_j+T$, the left packet lies inside the SAME FJ representation, creating a positive $j$-coefficient and making $F$ actual. Therefore

$$
\boxed{H_0:=LC+(x-1)b_k-\alpha-C_j-1\ge0.}\tag{H0}
$$

Together with QJ-ONE, this yields

$$
\boxed{\rho_k=(M+L)C+(z+x-1)b_k-\alpha-H_0.}\tag{K-CEILING}
$$

Only on the boundary $C=\alpha$,

$$
H_0=(L-1)\alpha+(x-1)b_k-C_j-1,
$$
$$
\rho_k=(M+L-1)\alpha+(z+x-1)b_k-H_0.
$$

In the general formula, $LC-\alpha$ must not be replaced by $(L-1)C$.

---

<a id="fr-C8.2.7"></a>

## $C=\alpha$: synchronization of actual EA/EB representations

Only here do we use BOUNDARY-WALL. After eliminating $m$, the pure EB row is

$$
(P+L_bd,\ -1-L_bS-V_j,\ b_k-1-L_bC-V_k)
=x_b\mathbf r_j+y_b\mathbf r_k.
$$

The first coordinate is positive, the second is negative, and the third is less than $b_k$, so $x_b,y_b\ge1$. If $y_b\ge2$, then $(x_b,L_b)$ has both $I,J\ge0$, hence $N\le L_b$, contradicting BOUNDARY-WALL.

Thus

$$
L_bd=x_ba_i-\delta,
\quad L_bS=x_b\rho_j-(V_j+a_j+1).
$$

The same triangle argument applied to EB and SAME Qj gives

$$
x_bM-zL_b=1.
$$

Subtracting the EA determinant identity and combining the difference with the $i$-equations gives

$$
(Md-za_i)(x_b-x)=a(x_b-x)=0.
$$

Since $a\ge1$,

$$
\boxed{L_b=L_i=L,\quad x_b=x,\quad
U_j=V_j+a_j,\quad V_k=U_k+b_k.}\tag{SYNC}
$$

In particular,

$$
\boxed{Q=U_j+1\ge a_j+1\ge2.}
$$

This synchronization follows from nonnegative representations of the same original elements together with the level bound above.

Moreover, the alternative $L=x=1$ in LEVEL-SPLIT is impossible on the boundary, because then $H_0=-C_j-1<0$. Hence

$$
L\ge x+1\ge2,\qquad M>z\ge1.
$$

---

<a id="fr-C8.2.8"></a>

## Multiplicity contradiction throughout $C=\alpha$

Set the canonical cross products

$$
\mathcal I=\rho_j\rho_k-a_jb_k,
\quad\mathcal J=a_i\rho_k+b_ib_k,
\quad\mathcal K=b_i\rho_j+a_ia_j
$$

For some $\sigma>0$,

$$
(n_i,n_j,n_k)=\sigma(\mathcal I,\mathcal J,\mathcal K),
\quad m=\sigma\widehat m,
\quad\widehat m=-d\mathcal I+S\mathcal J+C\mathcal K.
$$

We do not assume $\sigma=1$.

$$
D_j=da_j+Sb_i,\quad P_0=V+a_i>0,
$$
$$
C_A=\mathcal K-(M+L-1)P_0,
\quad C_B=D_j-b_i-(z+x-1)P_0.
$$

The boundary form of K-CEILING gives exactly

$$
\boxed{\widehat m-\mathcal J=H_0P_0+\alpha C_A+b_kC_B.}\tag{BOUND-MULT}
$$

The positivity decomposition is

$$
C_A=aA_a+\delta A_\delta+\beta\rho_j,
\quad C_B=aB_a+\delta B_\delta+\beta(S-1),
$$

$$
\begin{aligned}
A_a={}&(L-1)(M-1)(Q-2)+L^2(g-1)+L(a_j-1)\\
&+(L-2)M+2,\\
A_\delta={}&M(M-1)(Q-2)+(LM+M-1)(g-1)\\
&+M(a_j-1)+M^2+M-1,\\
B_a={}&\bigl[z(L-1)-x+1\bigr]\,(Q-2)+Lx(g-1)+x(a_j-1)\\
&+z(L-x-1)+(z-1)(x-1)+1,\\
B_\delta={}&(xM+z-1)(g-1)+z(M-1)(Q-2)\\
&+z(a_j-1)+zM.
\end{aligned}\tag{POS-COEFF}
$$

Under $Q\ge2$, $g,a_j\ge1$, $L\ge x+1$, and $M>z$, every displayed summand is nonnegative and each coefficient is positive.

In particular, $z(L-1)-x+1=x(z-1)+1+z(L-x-1)\ge1$. Hence $C_A,C_B>0$. By BOUND-MULT, $m>n_j$, contradicting multiplicity.

$$
\boxed{C=\alpha\ \textbf{CLOSED}.}
$$

This covers both $\Delta_0=1$ and $\Delta_0\ge2$, and all minimal and strict return levels.

---

<a id="fr-C8.2.9"></a>

## Strict packet-window theorem

### Claim

$$
\boxed{C>\alpha,\quad \chi\le T,\quad L_i\ge2\Longrightarrow\bot.}\tag{STRICT-WINDOW}
$$

By WINDOW-WALL, the arguments of [C8.2.4](#fr-C8.2.4)–[C8.2.6](#fr-C8.2.6) apply unchanged. Since $L=L_i\ge2$, the exceptional alternative in LEVEL-SPLIT does not occur. Hence $L\ge x+1$ and $M>z$. We do not use SYNC here; only $Q\ge1$ is needed.

Put $\gamma=C-\alpha\ge1$. From the general K-CEILING identity,

$$
\boxed{
\widehat m-\mathcal J
=H_0P_0+\alpha C_A+\gamma(C_A-P_0)+b_kC_B.
}\tag{STRICT-J}
$$

<a id="fr-C8.2.9.1"></a>

### The regular range $Q\ge2$

The inequalities $C_A,C_B>0$ from [C8.2.8](#fr-C8.2.8) remain valid.

The coefficient of $a$ in $C_A-P_0$ is

$$
\begin{aligned}
E_a={}&\bigl[(L-1)(M-1)-1\bigr]\,(Q-2)+L^2(g-1)\\
&+L(a_j-1)+(L-2)M-L.
\end{aligned}
$$

The coefficient of $\delta$ is

$$
E_\delta=M(M-1)(Q-2)+(LM+M)(g-1)+M(a_j-1)+M^2>0,
$$

and the coefficient of $\beta$ is $\rho_j>0$.

The coefficient $E_a$ can be negative only in exactly the following three cases.

1. $L=2,x=1,M=2z+1,Q=2,g=a_j=1$, $z\ge1$.
2. $L=2,x=1,z=1,M=3,Q=3,g=a_j=1$.
3. $L=3,x=2,z=1,M=2,Q=2,g=a_j=1$.

For completeness: if $L\ge4$, then $(L-2)M-L\ge L-4\ge0$. If $L=3,M\ge3$, this term is again nonnegative. If $L=3,M=2$, the determinant and level conditions force $x=2,z=1$, and $E_a=Q-3+9(g-1)+3(a_j-1)$. If $L=2$, then $x=1,M=2z+1$, so $E_a=(2z-1)(Q-2)+4(g-1)+2(a_j-1)-2$. Exhausting the integral possibilities gives exactly the three cases above.

Outside these cases, $C_A-P_0>0$, and STRICT-J gives $m>n_j$.

<a id="fr-C8.2.9.2"></a>

### $Q=1$ and the three exceptions

We use a different positivity decomposition. Define

$$
A'=\mathcal K-(M+L)V,
\quad B'=D_j-(z+x-1)V.
$$

$$
\begin{aligned}
A'={}&a\{L^2g+[(L-1)M-L]Q+La_j\}\\
&+\delta\{(M-1)\rho_j+Ma_j+(M+L)g\}+\beta\rho_j,\\
B'={}&a\{xa_j+Lxg+[z(L-1)-x+1]Q\}\\
&+\delta\{za_j+(M-1)S+(z+x-1)g\}+\beta S.
\end{aligned}
$$

For $Q\ge1,L\ge x+1,M>z$, we have $A',B'>0$.

$$
D_{\rm base}=2A'+B'+V-\mathcal K.
$$

Exactly,

$$
\boxed{
\widehat m-\mathcal K
=H_0V+(\alpha-1)(V+A')+(\gamma-1)A'
 +(b_k-1)B'+D_{\rm base}.
}\tag{STRICT-K}
$$

The coefficient decomposition of $D_{\rm base}$ is

$$
\begin{aligned}
D_{\rm base}={}&a\{(L+x)a_j+L(L+x)g+E Q\}\\
&+\delta\{(M-1)\rho_j+(M+z)a_j+(M-1)S\\
&\hspace{4em}+[2(M+L)+z+x-2]g\}
 +\beta(\rho_j+S),
\end{aligned}
$$

$$
E=(L-2)M+(L-1)z-2L-x+2.
$$

For $Q=1$,

$$
E-(L-x-3)=(L-2)(M-2)+(L-1)(z-1)\ge0,
$$

so the coefficient of $a$ is at least $(L+x)(L+1)-2$, and is therefore positive. The other coefficients are also positive.

In the three exceptional cases above, the coefficients of $a$ are respectively

$$
2z+3,\qquad3,\qquad16
$$

all positive. Thus $D_{\rm base}>0$ in those cases as well, and STRICT-K gives $m>n_k$.

This exhausts the entire range $Q\ge1$ and proves STRICT-WINDOW.

**The only finite branching used here is the set of three boundary cases derived from the sign calculation; no arbitrary numerical cutoff is used.**

---

<a id="fr-C8.2.10"></a>

## The closed strict infinite region and the exact source shortage

Every survivor has $\Xi\ge1$, so

$$
\chi=C-\alpha+1-\Xi\le C-\alpha.
$$

Thus, if $C\le b_k+2\alpha$, then $\chi\le b_k+\alpha=T$. If in addition $\lambda>d$, the intrinsic bound gives $L_i\ge2$. Therefore

$$
\boxed{\lambda>d,\quad\alpha<C\le b_k+2\alpha\ \textbf{CLOSED}.}
$$

In general, a survivor with $L_i\ge2$ cannot lie in the window itself, so

$$
\chi\ge T+1
\Longleftrightarrow
\boxed{1\le\Xi\le C-b_k-2\alpha.}\tag{DEEP}
$$

In particular, $C\ge b_k+2\alpha+1$. This is precisely the shortage of $k$-source for the displayed packet.

---

<a id="fr-C8.2.11"></a>

## The remaining level-one boundary inside the window

If a survivor satisfies $\chi\le T$, STRICT-WINDOW forces $L_i=1$. The intrinsic bound together with $d\le\lambda$ then gives $\lambda=d$ and $q_0=2$. The wall, basis, and triangle arguments of [C8.2.4](#fr-C8.2.4)–[C8.2.6](#fr-C8.2.6) remain valid, so LEVEL-SPLIT necessarily takes the form

$$
L=x=1,\qquad M=z+1.
$$

Put $\eta=C_j+1$. Then PARAM becomes

$$
\boxed{
\begin{aligned}
d=\lambda&=a+z\delta,&S&=g+zQ,\\
a_i&=d+\delta,&b_i&=d+\beta,\\
\rho_j&=g+(z+1)Q,&L_j&=z+1,\\
A_j&=a-1,&\rho_k&=(z+1)C+\eta+zb_k,\\
U_j&=Q-1,&U_k&=a_k-C-1.
\end{aligned}}
\tag{UNIT-PARAM}
$$

Also $H_0$ equals $C-\alpha-\eta\ge0$.

<a id="fr-C8.2.11.1"></a>

### The first point can be computed exactly

For $1\le\zeta\le z+1$,

$$
n_\zeta=\zeta+
\left\lceil\frac{(\zeta-1)\delta+1}{d}\right\rceil
=\zeta+1,
$$

$$
J_\zeta=(\zeta-z)Q-1.
$$

Hence

$$
\boxed{\widehat\zeta=z+1,\ N=z+2,\ I=a-1,\ J=Q-1,}
$$
$$
\boxed{\Xi=C-\alpha-\eta+1,\qquad \chi=\eta.}
$$

Thus

$$
\boxed{1\le\eta\le\min(C-\alpha,T).}\tag{UNIT-ETA}
$$

The compact data are

$$
\Delta_0=(z-1)Q+1,\qquad \tau_0=Q.
$$

The case $z=1$ has $\Delta_0=1$, while $z\ge2$ has $\Delta_0\ge2$. Both are treated in [C8.3](#fr-C8.3).

Notice that the first point of the window does not depend on the choice of EA representation. Hence, if a survivor actually exists, **the presence of any other EA factorization of level at least two would itself close the case by STRICT-WINDOW**. Thus, in this exceptional situation, every missing-$i$ EA factorization must have level one. This is not an assumption of uniqueness; it is a necessary condition deduced by applying the preceding theorem.

<a id="fr-C8.2.11.2"></a>

### Excluding the unit boundary by multiplicity

$$
\boxed{D_u:=Q\eta-R(C+b_k).}
$$

Substitute the unit parameters into the cross products. Set

$$
M_a=R(C+b_k)-Q\eta=-D_u,
$$
$$
\begin{aligned}
M_\delta={}&C[Qz(z+1)+a_j(z+1)+g(2z+1)]\\
&+b_k[Qz^2+a_jz+2gz]+\eta g>0,\\
M_\beta={}&C[Q(z+1)+g]+b_k[Qz+g]>0.
\end{aligned}
$$

Exactly,

$$
\widehat m=aM_a+\delta M_\delta+\beta M_\beta,
$$

$$
\boxed{\widehat m-\mathcal I=(a+z+1)M_a
 +(\delta-1)M_\delta+(\beta-1)M_\beta.}\tag{UNIT-MULT}
$$

If $D_u\le0$, the right-hand side is nonnegative, giving $m\ge n_i$, contrary to strict multiplicity. Therefore

$$
\boxed{D_u>0.}\tag{UNIT-REMAIN}
$$

Since $\eta\le C-\alpha<C+b_k$, in particular

$$
\boxed{Q>R=a_j+g.}
$$

Thus the entire unit-boundary range $Q\le R$ is excluded as well.

Moreover, $U_j=Q-1\ge a_j$, so actual transport through the canonical EA/EB difference constructs, in the same configuration, a level-one EB representation

$$
EB=m+(Q-a_j-1)n_j+(U_k+b_k)n_k
$$

This does not assert uniqueness of the level of an arbitrarily chosen EB representation.

---

<a id="fr-C8.2.12"></a>

## Exhaustive handoff

The boundary $C=\alpha$ has been eliminated. In the strict case $C>\alpha$, the conjunction $\chi\le T$ and $L_i\ge2$ is impossible. If $\chi\le T$, we are in the $\mathcal U$-parameter region of [C8.2.11](#fr-C8.2.11). On the other hand, if $\chi>T$, then

$$
\mathcal D:\quad T<\chi\le C-\alpha,\quad
1\le\Xi\le C-b_k-2\alpha,\quad C\ge b_k+2\alpha+1.
$$

Thus the remaining cases are exhausted by $\mathcal U$ and $\mathcal D$.

<a id="boundary-table"></a>

## Complete branching for the boundary and the window

| Entry | Required branch | Conclusion |
|---|---|---|
| $C=\alpha$ | Synchronization of the same EA/EB representations, $Q\ge2$, boundary-specific wall | Excluded by [C8.2.7](#fr-C8.2.7)–[C8.2.8](#fr-C8.2.8) |
| $C>\alpha,\chi\le T,L_i\ge2$ | Regular $Q\ge2$ range, three exceptions, $Q=1$ | Excluded by [C8.2.9](#fr-C8.2.9) |
| $C>\alpha,\chi\le T,L_i=1$ | First exclude $D_u\le0$ | Unit case $\mathcal U$ with $D_u>0$ |
| $C>\alpha,\chi>T$ | $T<\chi\le C-\alpha$, $\Xi\ge1$ | Source-shortage region $\mathcal D$ |

The strong caps on $e_0$ and FK obtained in the strict case are not applied at the boundary $C=\alpha$.


<a id="sec-09"></a>

# 9　From the residual cases to two packet relations

We treat in turn the two regions passed from the preceding section. The region $\mathcal U$ is eliminated by repeated exchanges within the same upper element. In $\mathcal D$, we reduce the first point to the linear case and use a 715-term identity to secure the required $i$-source. The remaining shortage of $j$-source yields two genuine packets, which are embedded into the abstract input of the next section.

<a id="fr-C8.3"></a>

## Elimination of the entire region $\mathcal U$

<a id="fr-C8.3.1"></a>

## Exact parameterization of $\mathcal U$

$$
a:=A_j+1\ge1,\qquad z\ge1,\qquad Q:=U_j+1\ge1.
$$

$$
\begin{aligned}
\lambda=d&=a+z\delta,& S&=g+zQ,\\
a_i&=d+\delta,& b_i&=d+\beta,\\
\rho_j&=g+(z+1)Q,&
\rho_k&=(z+1)C+\eta+zb_k.
\end{aligned}
\tag{U-PARAM}
$$

$$
1\le\eta\le\min(C-\alpha,T),\qquad
D_u:=Q\eta-R(C+b_k)>0.
\tag{U-SIGNS}
$$

Here $\eta=C_j+1$ and $L_j=z+1$. By [C8.2.11](#fr-C8.2.11),

$$
\widehat\zeta=z+1,\quad N=z+2,\quad
I=a-1,\quad J=Q-1,
$$
$$
\Xi=C-\alpha-\eta+1,\qquad\chi=\eta
$$

This proof does not require $\Xi=1$. The condition $D_u>0$ is the residual condition left by the multiplicity exclusion in [C8.2.11.2](#fr-C8.2.11.2), not an additional assumption.

---

<a id="fr-C8.3.2"></a>

## The required number of packets and the $j$-capacity

Set

$$
H_u:=C-\alpha-\eta\ge0,
\qquad
b_0:=z\delta+\beta>0.
$$

Let $t$ be the number of repetitions:

$$
t:=\left\lfloor\frac{H_u}{\eta}\right\rfloor+1\ge1,
\qquad H_u=(t-1)\eta+r,\qquad0\le r\le\eta-1.
\tag{COUNT}
$$

Thus

$$
C=\alpha+t\eta+r.
$$

Since $\eta\le T=b_k+\alpha$,

$$
C+b_k=T+t\eta+r\ge(t+1)\eta.
$$

From $D_u>0$ and integrality,

$$
\boxed{Q\ge(t+1)R+1.}
\tag{J-FIT}
$$

This estimate is uniform over all parameters and imposes no a priori bound on the number of repetitions.

---

<a id="fr-C8.3.3"></a>

## Multiplicity forces the required $i$-capacity

### Claim

Every survivor in $\mathcal U$ satisfies

$$
\boxed{a\ge t(z\delta+\beta)+\beta+1}
\tag{I-FIT}
$$

<a id="fr-C8.3.3.1"></a>

### Scope of the cross-product argument

Define

$$
\mathcal I=\rho_j\rho_k-a_jb_k,
\quad\mathcal J=a_i\rho_k+b_ib_k,
\quad\mathcal K=b_i\rho_j+a_ia_j.
$$

The canonical relations imply that, for a common $\sigma>0$,

$$
(n_i,n_j,n_k)=\sigma(\mathcal I,\mathcal J,\mathcal K).
$$

We make no additional assumption that $\sigma=1$, nor any additional gcd assumption. From ROOT,

$$
m=\sigma\widehat m,
\qquad
\widehat m=-d\mathcal I+S\mathcal J+C\mathcal K.
$$

Set

$$
\Phi(a):=\widehat m-\mathcal J
$$

Under U-PARAM, $\Phi$ is linear in $a$, and exactly

$$
\boxed{\frac{\partial\Phi}{\partial a}=-D_u-\rho_k-b_k<0.}
\tag{MONO-A}
$$

<a id="fr-C8.3.3.2"></a>

### Positivity at the threshold

$$
a_*:=t(z\delta+\beta)+\beta.
$$

$$
w:=T-\eta\ge0,
\qquad q':=Q-(t+1)(a_j+g)-1\ge0.
$$

After substituting $C=\alpha+t\eta+r$ and $b_k=\eta-\alpha+w$, exactly

$$
\begin{aligned}
\Phi(a_*)={}&\delta\{P_\delta+(a_j-1)X_\delta+(g-1)Y_\delta+q'Z_\delta\}\\
&+\beta\{P_\beta+(a_j-1)X_\beta+(g-1)Y_\beta+q'Z_\beta\}.
\end{aligned}
\tag{POS-DECOMP}
$$

The polynomials $X,Y,Z$ are nonnegative and are displayed explicitly in Appendix C. The two leading terms are

$$
\begin{aligned}
P_\delta={}&\alpha(2tz+3z+1)\\
&+\eta(t^2z^2+t^2z+3tz^2+tz+t+2z^2)\\
&+r(tz^2+3tz+2z^2+4z+1)\\
&+wz(tz+t+2z+1)>0,
\end{aligned}
$$

$$
\begin{aligned}
P_\beta={}&2\alpha(t+2)\\
&+\eta(t^2z+t^2+3tz+2z-3)\\
&+r(tz+3t+2z+5)\\
&+w(tz+t+2z+1)>0.
\end{aligned}
$$

The only bracket that appears to contain a negative contribution is nevertheless positive, since $t,z\ge1$:

$$
t^2z+t^2+3tz+2z-3\ge4.
$$

Hence $\Phi(a_*)>0$. If $a\le a_*$, MONO-A gives

$$
\Phi(a)\ge\Phi(a_*)>0,
$$

so $m>n_j$, contradicting multiplicity. Integrality therefore yields I-FIT.

This comparison does not invoke criticality for a signed relation; it is a contradiction between an explicit positive polynomial and strict multiplicity.

---

<a id="fr-C8.3.4"></a>

## Replacing $t$ packets inside the SAME actual upper element and actualizing the PF gap

From U-PARAM,

$$
\boxed{b_0n_i+Rn_j=(z+1)m+\eta n_k.}
\tag{U-PACKET}
$$

Both sides have nonnegative coefficients.

For the same $q_{A_k}$, the following identity holds:

$$
\boxed{
q_{A_k}+(H_u+1)n_k
=(z+2)m+(a-\beta-1)n_i+(Q-R-1)n_j.
}
\tag{U-UPPER}
$$

The left side is a named actual upper element because $q_{A_k}+n_k\in\Gamma$ and $H_u\ge0$.

By I-FIT and J-FIT,

$$
a-\beta-1\ge t b_0,
\qquad Q-R-1\ge tR.
$$

Thus the right side of U-UPPER is also genuine and contains coefficientwise $t$ copies of the left side of U-PACKET. Replace all of them by the right side of U-PACKET. The resulting $k$-coefficient in the same upper element is $t\eta$.

$$
t\eta-(H_u+1)=\eta-r-1\ge0.
$$

We can therefore remove **the entire same added term $(H_u+1)n_k$**, leaving

$$
\boxed{\begin{aligned}
q_{A_k}={}&[z+2+t(z+1)]m\\
&+[a-\beta-1-t(z\delta+\beta)]n_i\\
&+[Q-(t+1)R-1]n_j\\
&+(\eta-r-1)n_k\in\Gamma.
\end{aligned}}
\tag{U-FINAL}
$$

All four coefficients are nonnegative. This contradicts $q_{A_k}\in PF(\Gamma)$.

$$
\boxed{\boxed{\mathcal U=\varnothing.}}
$$

No intermediate signed row has been treated as actual, and no second factorization of $Q_k$ has been assumed. The required number $t$ is determined by the exact floor above.

<a id="fr-C8.4"></a>

## The high-$q$, nonlinear-first, and linear-first cases in $\mathcal D$

Having eliminated $\mathcal U$, we consider only $\mathcal D$. In this proposition, $Q$ will later be an abbreviation for $\tau_0$, not for $Q(\Gamma)$. We write $\tau=\tau_0$. From [C8.1](#fr-C8.1), we receive $e_0\ge\beta+\delta+1$ and $\tau_0\ge R+1$; from [C8.2](#fr-C8.2), we receive the first point and a genuine packet.

<a id="fr-C8.4.0.1"></a>

### Input notation for $\mathcal D$

All canonical coefficients below are positive integers:

$$
a_i=\lambda+\delta,\quad b_i=\lambda+\beta,\quad
\rho_i=a_i+b_i,\quad\rho_j=a_j+b_j,\quad\rho_k=a_k+b_k,
$$
$$
P=\lambda+\delta+\beta,\quad R=a_j+g,\quad T=b_k+\alpha.
$$

The CENTRAL root and the expression for $W$ are

$$
m+d n_i=S n_j+C n_k,\qquad 1\le d\le\lambda,
$$
$$
W=F+m=(P-1)n_i+(R-1)n_j+(T-1)n_k.
$$

Here $C$ is the root coefficient and is distinct from $T=b_k+\alpha$.

$$
0<m<\min(n_i,n_j,n_k),\qquad F\notin\Gamma.
$$

The pure-$H$ relations are

$$
\rho_jn_j=a_i n_i+b_k n_k,\qquad
\rho_kn_k=b_i n_i+a_jn_j,\qquad
\rho_in_i=b_jn_j+a_kn_k.
$$

The integer kernel is used below only after the $m$-coordinate has been eliminated completely.

Set

$$
h=\lfloor\lambda/d\rfloor,\quad q_0=h+1,\quad
r=\lambda-hd,\quad e_0=d-r,
$$
$$
b=r+\delta,\qquad c=r+\beta,\qquad
\tau=\rho_j-hS.
$$

Then

$$
a_i=hd+b,\quad b_i=hd+c,\quad \rho_j=hS+\tau.
$$

The $\mathcal D$-input satisfies

$$
e_0\ge\beta+\delta+1,\quad
1\le\tau\le S-g,\quad \tau\ge R+1,
$$
$$
V:=d\rho_j-Sa_i=d\tau-bS>0,
\qquad C\ge b_k+2\alpha+1.
$$

In particular, $1\le b\le d-\beta-1<d$.

<a id="fr-C8.4.0.2"></a>

### The first point and its packet

For $z\ge1$, define

$$
n_z=\left\lceil\frac{z a_i-\delta+1}{d}\right\rceil,
$$
$$
I_z=\delta-1+n_zd-z a_i,\qquad
J_z=g-1+z\rho_j-n_zS.
$$

Take the first index $z=\widehat\zeta$ for which $J_z\ge0$, and put

$$
N=n_z,\quad I=I_z,\quad J=J_z.
$$

Define

$$
\Xi=NC+z b_k-(\rho_k+T-1),\qquad
\chi=C-\alpha+1-\Xi,
$$

The region $\mathcal D$ satisfies

$$
\Xi\ge1,\qquad T<\chi\le C-\alpha.
$$

The genuine representation on both sides is

$$
D_Fn_i+E_Fn_j=(N-1)m+\chi n_k,
$$
$$
D_F=d+\beta-1-I,\qquad
E_F=R+\rho_j-S-1-J.
$$

The same actual upper element is

$$
\Omega_D=F+(C-\alpha+1)n_k
=(d+\beta-1)n_i+(R+\rho_j-S-1)n_j.
$$

The least number of repetitions required for this packet is

$$
b_D=\left\lfloor\frac{C-\alpha}{\chi}\right\rfloor+1\ge2.
$$

That number fits inside the source if and only if

$$
b_DD_F\le d+\beta-1,\qquad
b_DE_F\le R+\rho_j-S-1.
$$

We handle these fitting conditions symbolically below.

---

<a id="fr-C8.4.1"></a>

## The last crossing is an $h$-step

Since $a_i=hd+b$ with $0<b<d$, successive increments of $n$ are either $h$ or $h+1$. At $z=1$, $n_1=h+1=q_0$, and

$$
J_1=\rho_j+g-1-q_0S=-\Delta_0<0.
$$

Hence $z\ge2$. If the final increment were $h+1$, then

$$
J_z-J_{z-1}=\rho_j-(h+1)S=\tau-S\le-g<0,
$$

so the sequence could not cross from negative to nonnegative. Therefore

$$
\boxed{n_z-n_{z-1}=h.}
$$

Consequently,

$$
\boxed{0\le J\le\tau-1,\qquad
0\le I\le d-b-1=e_0-\delta-1.}
\tag{FIRST-CAPS}
$$

The upper bound for $I$ follows from $I_{z-1}=I+b\le d-1$.

We use the following two exact identities:

$$
NV=\rho_j(I-\delta+1)+a_i(J-g+1),
$$
$$
zV=S(I-\delta+1)+d(J-g+1).
\tag{NV-ZV}
$$

FIRST-CAPS gives

$$
NV\le hV+(d-\delta)\rho_j-a_i g,
$$
$$
(z-1)V\le S(d-\delta)-dg.
\tag{FIRST-BOUNDS}
$$

If $h\ge2$, then

$$
E_F\ge R+(h-1)S>\tau-1\ge J.
$$

Since $R+\rho_j-S-1=E_F+J$, two or more packets cannot fit into the $j$-source of $\Omega_D$. For this high-$h$ range, we instead use the multiplicity comparison below.

---

<a id="fr-C8.4.2"></a>

## A common multiplicity certificate

Define

$$
\mathcal I=\rho_j\rho_k-a_jb_k,\quad
\mathcal J=a_i\rho_k+b_i b_k,\quad
\mathcal K=b_i\rho_j+a_i a_j.
$$

There is a common positive scale $\sigma>0$ such that

$$
(n_i,n_j,n_k)=\sigma(\mathcal I,\mathcal J,\mathcal K),\qquad
m=\sigma\widehat m,
$$
$$
\widehat m=-d\mathcal I+S\mathcal J+C\mathcal K.
$$

We do not assume $\sigma=1$.

Define

$$
D_j=da_j+Sb_i,\quad
A=\mathcal K-NV,\quad B=D_j-(z-1)V.
$$

From

$$
\rho_k=NC+(z-1)b_k-\alpha+1-\Xi,
$$

we obtain the exact identity

$$
\widehat m=C A+b_kB+(\alpha-1+\Xi)V.
$$

In particular,

$$
\begin{aligned}
\widehat m-\mathcal K={}&
(C-b_k-2\alpha-1)A\\
&+(b_k-1)(A+B)+(\alpha-1)(2A+V)\\
&+(\Xi-1)V+[4A+B+V-\mathcal K].
\end{aligned}
\tag{M-MASTER}
$$

All coefficients preceding the final bracket are nonnegative throughout $\mathcal D$. It therefore suffices to give positive lower bounds for $A$, $B$, and the final bracket.

---

<a id="fr-C8.4.3"></a>

## Excluding $\mathcal D$ when $q_0\ge3$

Assume $h\ge2$. FIRST-BOUNDS gives

$$
A\ge A_0:=\mathcal K-hV-(d-\delta)\rho_j+a_i g,
$$
$$
B\ge B_0:=dR+S(P-d)>0.
$$

Write

$$
A_0=S A_S+\tau A_\tau+a_iR,
$$

where

$$
A_S=h[(h-1)d+\beta+2\delta+2r],\quad
A_\tau=\beta-d+\delta+r.
$$

Moreover,

$$
A_S+A_\tau=[h(h-1)-1]d+(h+1)\beta+(2h+1)(\delta+r)>0.
$$

Since $S>\tau>0$, it follows that $A_0>0$.

A direct expansion gives

$$
4A_0+B_0+V-\mathcal K=S H_S+\tau H_\tau+H_c,
$$

where

$$
H_S=(3h^2-3h-1)d+(3h+1)\beta+8h\delta+7hr>0,
$$
$$
H_\tau=3\beta-(h+3)d+4\delta+3r,
$$
$$
H_c=a_j[(3h+1)d+3(\delta+r)]
+g[(4h+1)d+4(\delta+r)]>0.
$$

The sum of the first two coefficients is

$$
H_S+H_\tau=(h-2)(3h+2)d
+(3h+4)\beta+(8h+4)\delta+(7h+3)r>0.
$$

Thus

$$
S H_S+\tau H_\tau
=(S-\tau)H_S+\tau(H_S+H_\tau)>0.
$$

M-MASTER then yields $\widehat m>\mathcal K$, i.e. $m>n_k$, a contradiction.

$$
\boxed{\mathcal D\cap\{q_0\ge3\}=\varnothing.}
\tag{HIGH-Q-CLOSED}
$$

Hence the only possible cases in $\mathcal D$ have $h=1$, equivalently $d\le\lambda<2d$.

---

<a id="fr-C8.4.4"></a>

## When $q_0=2$, the first point satisfies $N=z+1$

Write $\lambda=d+r$, $a_i=d+b$, and $b=r+\delta$. Then

$$
n_z=z+\ell_z,\qquad
\ell_z=\left\lceil\frac{zb-\delta+1}{d}\right\rceil\ge1.
$$

We show that no first point in $\mathcal D$ can have $\ell_z\ge2$.

Suppose otherwise and set

$$
\kappa=\left\lfloor\frac{d+\delta-1}{b}\right\rfloor\ge1.
$$

For $1\le v\le\kappa$, the candidate points have $\ell_v=1$. None is the first successful point, so

$$
\boxed{S\ge\kappa\tau+g.}
$$

Put $r'=d-\kappa b$. The slope identity

$$
V=d\tau-bS\le r'\tau-bg>0
$$

implies $r'>0$. From the definition of the floor,

$$
\boxed{1\le r'\le b-\delta.}
\tag{SMALL-R}
$$

If the first point had $I\ge r'$, then the preceding integer point

$$
(z-\kappa,\ \ell_z-1)
$$

would have $i$-coefficient $I-r'\ge0$ and $j$-coefficient $J+S-\kappa\tau\ge g>0$. Its $z$-index is positive and smaller than the original $z$. Replacing $n$ by the least allowed value only increases the $j$-coefficient, contradicting the definition of the first point. Therefore

$$
\boxed{0\le I\le r'-1.}
$$

Combining this with $J\le\tau-1$ and NV-ZV yields

$$
A\ge A_1:=((\kappa+1)b+\beta)S+(\beta-r')\tau+a_iR>0,
$$
$$
B\ge B_1:=(\kappa b+\beta)S+dR>0.
$$

The coefficient of $S$ in $A_1$ is positive, and the sum of its $S$- and $\tau$-coefficients is

$$
(\kappa+1)b+2\beta-r'\ge\kappa b+\delta+2\beta>0.
$$

Since $S>\tau$, this gives $A_1>0$.

For the final bracket,

$$
4A_1+B_1+V-\mathcal K=S E_S+\tau E_\tau+E_c,
$$
$$
E_S=(4\kappa+2)b+4\beta+\delta-r'>0,
$$
$$
E_\tau=-b+3\beta+\delta-4r',
$$
$$
E_c=a_j[(4\kappa+3)b+4r']
+g[(5\kappa+4)b+5r']>0.
$$

Using $b\ge r'+\delta$,

$$
\begin{aligned}
\kappa E_S+E_\tau
&=(4\kappa^2+2\kappa-1)b+(4\kappa+3)\beta
 +(\kappa+1)\delta-(\kappa+4)r'\\
&\ge(\kappa-1)(4\kappa+5)r'
 +\kappa(4\kappa+3)\delta+(4\kappa+3)\beta>0.
\end{aligned}
$$

Since $S\ge\kappa\tau+g$,

$$
S E_S+\tau E_\tau=(S-\kappa\tau)E_S+
\tau(\kappa E_S+E_\tau)>0.
$$

M-MASTER again gives $m>n_k$.

$$
\boxed{q_0=2,\quad N\ge z+2\Longrightarrow\bot.}
\tag{NONLINEAR-FIRST-CLOSED}
$$

Therefore every remaining case in $\mathcal D$ satisfies

$$
\boxed{q_0=2,\qquad N=z+1.}
$$

This is a symbolic proof over the full range of $z$.

---

<a id="fr-C8.4.5"></a>

## Exact parameterization of the remaining first point

Set

$$
k=z-1\ge1,\quad Q=\tau,\quad
\upsilon=Q-1-J\ge0,\quad G=g+\upsilon,\quad E=R+\upsilon,
$$
$$
b=r+\delta,\quad c=r+\beta,\quad
B=kb+c=D_F,\quad a=d-kb.
$$

From this point onward, $Q$ abbreviates $\tau$, and $\upsilon$ is the new residual parameter attached to this first point. In the static coefficient table and verification code, $\upsilon$ is denoted by `u`.

The exact formulas are

$$
S=kQ+G,\quad\rho_j=(k+1)Q+G,
$$
$$
\rho_k=(k+1)C+kb_k+\chi,
$$
$$
a_i=d+b,\quad b_i=d+c,\quad d=a+kb,
$$
$$
I=d+\delta-1-(k+1)b,\quad J=Q-\upsilon-1.
$$

In particular, $a\ge r+1\ge1$.

The two genuine packets are

$$
\boxed{Bn_i+En_j=(k+1)m+\chi n_k,}
\tag{D-LINEAR}
$$
$$
\boxed{m+Qn_j=bn_i+(C+b_k)n_k.}
\tag{INTRINSIC-LINEAR}
$$

<a id="fr-C8.4.5.1"></a>

### Positivity of the packet determinant

Define

$$
\mathscr D:=Q\chi-E(C+b_k).
$$

We prove its positivity directly in this parameter region.

Set

$$
\begin{aligned}
M_b={}&C[Qk(k+1)+a_j(k+1)+G(2k+1)]\\
&+b_k[Qk^2+a_jk+2Gk]+\chi G>0,\\
M_c={}&C[Q(k+1)+G]+b_k[Qk+G]>0.
\end{aligned}
$$

A direct expansion gives

$$
\boxed{\widehat m-\mathcal I
=-(a+k+1)\mathscr D+(b-1)M_b+(c-1)M_c.}
$$

If $\mathscr D\le0$, the right side is nonnegative, contradicting $m<n_i$. Therefore

$$
\boxed{\mathscr D>0.}
\tag{DSCR}
$$

---

<a id="fr-C8.4.6"></a>

## The $i$-source always contains the least required number of packets

Write the least repetition count as $b_D=f+1$:

$$
f=\left\lfloor\frac{C-\alpha}{\chi}\right\rfloor\ge1,
\qquad C=\alpha+f\chi+w,\quad 0\le w<\chi.
$$

By DSCR,

$$
Q\chi>E(f\chi+T+w),\qquad
\boxed{\theta:=Q-fE\ge1.}
$$

Equivalently,

$$
\boxed{\theta\chi>E(T+w).}
\tag{REMAINDER-SLOPE}
$$

### $i$-source fitting claim

$$
\boxed{d\ge(f+1)B-\beta+1.}
\tag{I-FIT}
$$

Since $c=r+\beta$, this is equivalent to $a\ge fB+r+1$.

### Proof

In the parameterization of [C8.4.5](#fr-C8.4.5), hold the remaining parameters fixed and set $\Phi(a)=\widehat m-\mathcal J$. Direct differentiation gives

$$
\boxed{\Phi'(a)=-\mathscr D-\rho_k-b_k<0.}
$$

Consider the threshold $a_*=fB+r$. Substitute

$$
Q=f(a_j+g+\upsilon)+\theta,\quad
C=\alpha+f\chi+w,\quad
\chi=b_k+\alpha+1+\epsilon,\quad\epsilon\ge0,
$$
$$
b=r+\delta,\quad c=r+\beta,\quad G=g+\upsilon.
$$

The value $\Phi(a_*)$ admits a nonnegative-coefficient certificate in the nonnegative variables

$$
\mathbf y=(f-1,r,\delta-1,\beta-1,g-1,\upsilon,
\alpha-1,w,\theta-1,\epsilon,k-1,a_j-1,b_k-1).
$$

Precisely,

$$
\boxed{\Phi(a_*)=35+\sum_{\gamma\ne0}c_\gamma\mathbf y^\gamma,
\qquad c_\gamma\in\mathbb Z_{\ge0}.}
\tag{I-POS-CERT}
$$

There are 715 monomials including the constant term. The static table recording every coefficient and exponent is `supplement/APPENDICES/LINEAR/I_FIT_POSITIVE_COEFFICIENTS.json`. Appendix D gives the defining identity, variable correspondence, and reconstruction procedure. Nonnegativity of all coefficients together with the positive constant term proves positivity for the full parameter range.

Hence $\Phi(a_*)>0$. If $a\le a_*$, monotonicity yields $\Phi(a)\ge\Phi(a_*)>0$, so $m>n_j$, a contradiction. By integrality, $a\ge a_*+1$, which is I-FIT.

The threshold $a_*$ is an evaluation point of the polynomial. It is not assumed that this point itself satisfies the actual-semigroup or first-point conditions.

---

<a id="fr-C8.4.7"></a>

## The remaining $j$-shortage after the least-packet test

Replace $b_D=f+1$ packets in the same representation of $\Omega_D$. Then

$$
\boxed{
\begin{aligned}
F={}&(f+1)(k+1)m\\
&+[d+\beta-1-(f+1)B]n_i\\
&+(\theta-\upsilon-1)n_j+(\chi-w-1)n_k.
\end{aligned}}
\tag{J-ONLY}
$$

The coefficient of $m$ is positive; the coefficient of $n_i$ is nonnegative by I-FIT; and the coefficient of $n_k$ is nonnegative because $0\le w<\chi$. Consequently,

$$
\boxed{\theta\ge\upsilon+1\Longrightarrow\bot.}
$$

The remaining case is

$$
\boxed{1\le\theta\le\upsilon,\qquad
\Delta_1:=\upsilon+1-\theta\ge1.}
\tag{J-FAIL}
$$

The same actual upper element then has the genuine zero-$j$ representation

$$
\boxed{
F+\Delta_1n_j=(f+1)(k+1)m+
[d+\beta-1-(f+1)B]n_i+(\chi-w-1)n_k
}
$$

The $i$-shortage for this packet family has been eliminated. We pass the remaining $j$-shortage to the two-packet theorem below.

---

<a id="fr-C8.4.8"></a>

## A complementary genuine packet

Adding $f$ copies of D-LINEAR and one copy of INTRINSIC-LINEAR gives the exact identity

$$
\boxed{
L_\diamond m+\theta n_j=B_\diamond n_i+(T+w)n_k,
}
\tag{COMPLEMENTARY}
$$

where

$$
L_\diamond=1+f(k+1),\qquad B_\diamond=b+fB.
$$

Every coefficient on both sides is nonnegative, so this is a genuine packet equality.

We pass D-LINEAR from [C8.4.5](#fr-C8.4.5) and COMPLEMENTARY from the present subsection to [E8](#fr-E8) as two genuine packets in the same $\Gamma,F,m,W$.

<a id="fr-E8.2.3"></a>

## Embedding the initial residual configuration

For the two packets of [C8.4](#fr-C8.4), take

$$
\mathsf M_0=\begin{pmatrix}fk+1&f\\k&1\end{pmatrix}
$$

Its determinant is $1$, and

$$
L=1+f(k+1)>M=k+1,
$$

Moreover,

$$
A=(fk+1)b+fc=b+fB,
\quad B=kb+c.
$$

Also,

$$
LE+M\theta-a_j=(k+1)Q+g+\upsilon=\rho_j,
$$
$$
L\chi+M(T+w)-b_k=(k+1)C+kb_k+\chi=\rho_k.
$$

Thus the initial residual configuration is fully contained in this package. No cases are lost according to whether $w=0$ or $w\ge1$, or whether $\Delta_0=1$ or $\Delta_0\ge2$.

---

<a id="initial-embedding-table"></a>

## Correspondence between the initial packets and the abstract notation

| Quantity in Section 9 | Input in Section 10 |
|---|---|
| $\upsilon$ | $u=\upsilon\ge1$ |
| $R+\upsilon$ | $E=R+u$ |
| $T+w$ | $H_p=T+w$ |
| $Q-fE$ | $\theta$, $1\le\theta\le u$ |
| $kb+c$ | $B=s(r+\delta)+t(r+\beta)$ |
| $b+fB$ | $A=p(r+\delta)+q(r+\beta)$ |
| $k+1,1+f(k+1)$ | $M=s+t,L=p+q$ |

Here $b=r+\delta,c=r+\beta$, and the matrix is the $\mathsf M_0$ displayed above. Since $f,k\ge1$, all matrix entries are positive and $L>M$; REMAINDER-SLOPE gives $\theta\chi-EH_p>0$. The common $P,R,T$, HCR, the $W$-face, $a_i=P-\beta>0,b_i=P-\delta>0$, and the multiplicity condition are inherited from the same configuration. These are exactly the inputs required in the next section. The choice of the first point is used only up to this initial embedding.

<a id="chain-core-central-euclidean-handoff"></a>

## CHAIN → CORE → CENTRAL → Euclidean handoff table

This table only records where already-proved inputs enter the argument; it adds no new assumption. In particular, the first-point data and $q_0$-specific conditions used in $\mathcal D$ are not inherited after entry into the abstract Euclidean theorem.

| Quantity / assumption | Output from CHAIN / R7 | Use in CORE / CENTRAL | Initial Euclidean embedding | After a nonterminal descent step |
|---|---|---|---|---|
| $\Gamma,F,m,W$ | Same semigroup, $F\notin\Gamma$, $m$ is the multiplicity, and the same actual $W=F+m$ | Basis for CORE 1,3 and every SAME-element comparison | [E8.2.3](#fr-E8.2.3) passes the same $m,n_i,n_j,n_k,F,W$ | Color exchange only interchanges generator names; the same semigroup and the same $F,m,W$-face are retained |
| canonical parameters / HCR | Positive $\lambda,\delta,\beta,g,\alpha$, $P,R,T$, and the three critical relations | Used in CORE 2 and in slopes / caps / cross products | $a_i=P-\beta>0$, $b_i=P-\delta>0$, $R=a_j+g$, $T=b_k+\alpha$; HCR is part of the E8 package | Preserved in the same form under the full $j\leftrightarrow k$ and $a/b$ exchange |
| ROOT | $m+d n_i=S n_j+C n_k$, $1\le d\le\lambda,\ S\ge g+1,\ C\ge\alpha$ | CORE 5; used to derive returns, the boundary/window, and the $\mathcal U/\mathcal D$ packets | Upstream input until the two genuine packets are constructed; ROOT itself is not an abstract E8 hypothesis | **Not required.** Neither ROOT nor its coefficient bounds are used after descent |
| four actual PF gaps / missing successor | Obtained from the four-row CHAIN configuration | CORE 4; used to derive missing-coordinate returns and their caps | Used until the initial packets and their common $W$-face are established | **Not required.** After transformation the abstract theorem does not require the original first point, minimal return levels, or the four PF rows |
| determinant-one matrix | Not a direct output of R7 | Introduced after the two $\mathcal D$-packets have been obtained | $\mathsf M_0=\begin{pmatrix}fk+1&f\\k&1\end{pmatrix}$, $\det\mathsf M_0=1$, $L>M$ | The matrix $\mathsf M'$ of [E8.6.1](#fr-E8.6.1) preserves determinant $1$ and $L'>M'$ |
| genuine packets | CENTRAL/$\mathcal D$ yields D-LINEAR and COMPLEMENTARY as actual equalities | Verified as two packets with all coefficients nonnegative, not as signed relations | Identified directly with (DP) and (PP) in E8 | The new DP is the old PP; the new PP is NEW-PACKET. Both remain genuine |
| packet determinant | REMAINDER-SLOPE gives $\theta\chi-E(T+w)>0$ | Slope condition for the initial residual case | $\mathcal D_p=\theta\chi-EH_p>0$ | $\mathcal D_p'=\mathcal D_p>0$ |
| $\mathcal D$-specific conditions such as first point, $q_0=2$, and $N=\widehat\zeta+1$ | Not themselves CHAIN outputs | Used only in C8.4 to construct the initial two packets | Their role ends at [E8.2.3](#fr-E8.2.3) | **Not inherited.** As stated at the beginning of Section 10 and in the preservation table, they are no longer domain conditions |
| descent measure | None | None | Start with the positive integer $\mathcal M=E+\chi$ | Strictly decreases at every step by [E8.6.4](#fr-E8.6.4), so a terminal state is reached after finitely many steps |

Thus no CHAIN-derived information is carried past a descent step without justification; the Euclidean part closes using only the abstract package listed in [E8](#fr-E8).


<a id="sec-10"></a>

# 10　Euclidean descent and source containment

This section uses only the abstract inputs listed below. The minimality of the first point constructed in the preceding section is not required in the descent that follows. At a terminal state we show that the required source is contained in the same $W$; at a nonterminal state we construct a transformation preserving every input condition and strictly decreasing a positive integer measure.

<a id="fr-E8"></a>

## Euclidean two-packet closure theorem

We introduce new local packet notation here. The indices $N,I,J$ attached to the first point in [C8.4](#fr-C8.4) are not carried into this theorem. The common parameters $\delta,\beta,g,\alpha,a_j,b_k$ are positive integers, $P$ is a positive integer, $a_i=P-\beta>0,b_i=P-\delta>0$, and $R=a_j+g,T=b_k+\alpha$. We retain the original HCR and
$W=(P-1)n_i+(R-1)n_j+(T-1)n_k=F+m$. We denote the packet coefficient by $H_p$, its determinant by $\mathcal D_p$, and the descent measure by $\mathcal M$. The variables $u,\theta,w,\chi$ are integers with $u\ge1$, $w\ge0$, and $\chi\ge1$.

<a id="fr-E8.2.1"></a>

## Definition

For the same $m,n_i,n_j,n_k,F,W$, assume the following.

$$
\mathsf M=\begin{pmatrix}p&q\\s&t\end{pmatrix},\qquad
p,q,s,t\in\mathbb Z_{\ge1},\qquad pt-qs=1,
$$
$$
L=p+q>M=s+t.
\tag{MATRIX}
$$

$$
r\in\mathbb Z_{\ge0},\qquad
A=p(r+\delta)+q(r+\beta),\quad
B=s(r+\delta)+t(r+\beta).
\tag{SOURCES}
$$

$$
E=R+u,\quad H_p=T+w,\qquad
1\le\theta\le u,\quad w\ge0,\quad \chi\ge1,
$$
$$
\boxed{\mathcal D_p:=\theta\chi-EH_p>0.}
\tag{DET-POS}
$$

The two genuine equalities are

$$
\boxed{Bn_i+En_j=Mm+\chi n_k,}
\tag{DP}
$$
$$
\boxed{An_i+H_p n_k=Lm+\theta n_j.}
\tag{PP}
$$

For the canonical multipliers we require

$$
\boxed{\rho_j=LE+M\theta-a_j,\qquad
\rho_k=L\chi+MH_p-b_k.}
\tag{RHO}
$$

The package also includes $a_i=P-\beta>0$, $b_i=P-\delta>0$, the relations (HCR), and the original representation of $W$.

<a id="fr-E8.2.2"></a>

## Theorem

**Euclidean two-packet closure theorem.**  
If this package holds together with $m<\min(n_i,n_j,n_k)$, then

$$
\boxed{F\in\Gamma.}
$$

Consequently, no package of this form can occur when $F$ is a gap.

We prove the theorem by strong induction on the positive integer

$$
\boxed{\mathcal M:=E+\chi}
$$

The quantity $\mathcal M$ is the descent measure used only in the present argument; it is not a depth parameter inherited from an earlier branch.

<a id="fr-E8.3"></a>

## Terminal candidate: the packet to be removed within the SAME $W$

Set

$$
\nu=\left\lfloor\frac u\theta\right\rfloor+1\ge2
$$

The completed sum of (DP) and $\nu$ copies of (PP) is

$$
\boxed{
Zn_i+j_*n_j+k_*n_k=Nm,
}
\tag{TERMINAL-PACKET}
$$

where

$$
Z=B+\nu A,\quad N=M+\nu L,
\quad j_*=E-\nu\theta,\quad k_*=\nu H_p-\chi.
$$

Always,

$$
j_*\le R-1.
$$

The terminal condition is

$$
\boxed{k_*\le T-1.}
\tag{TERMINAL}
$$

If it holds, then the inequality $P\ge Z+1$, proved in the next subsection, gives

$$
\boxed{
F=(N-1)m+(P-1-Z)n_i+(R-1-j_*)n_j+(T-1-k_*)n_k
\in\Gamma.
}
\tag{FINAL-F}
$$

### Actual replacement within the same $W$

The quantities $j_*$ and $k_*$ may be negative. In that event, rewrite (TERMINAL-PACKET) as

$$
Zn_i+(j_*)_+n_j+(k_*)_+n_k
=Nm+(-j_*)_+n_j+(-k_*)_+n_k
$$

Every coefficient on both sides is nonnegative.

The existing face of the SAME $W$ contains the left source coefficientwise. Replacing that source by the right side produces a new genuine factorization of $W$. Since $N\ge1$, we then remove **one copy of $m$** from the final vector to obtain (FINAL-F). No external packet has been added, and no shift remains to be removed.

---

<a id="fr-E8.4"></a>

## Terminal $i$-source fit: a multiplicity proof over the full domain

<a id="fr-E8.4.1"></a>

## Positivity order of the matrix

From (MATRIX),

$$
\boxed{p\ge s+1,\qquad q\ge t.}
\tag{ORDER}
$$

Indeed, if $p\le s$, positivity of the determinant forces $q<t$, hence $L<M$. Thus $p>s$. If next $q<t$, write $p=s+a$, $t=q+b$ with $a,b\ge1$. Then

$$
pt-qs=sb+aq+ab\ge s+q+1>1,
$$

which is impossible.

<a id="fr-E8.4.2"></a>

## Cross products and the correct scale

$$
\mathcal I=\rho_j\rho_k-a_jb_k,
\quad \mathcal J=a_i\rho_k+b_ib_k,
\quad \mathcal K=b_i\rho_j+a_ia_j.
$$

The two relevant rows of (HCR) are independent, so for a common $\sigma>0$,

$$
(n_i,n_j,n_k)=\sigma(\mathcal I,\mathcal J,\mathcal K).
$$

We impose neither $\sigma=1$ nor any gcd assumption.

Define

$$
I_0=EA+\theta B,\quad J_0=\chi A+H_pB,
$$
$$
M_0=LE+M\theta=\rho_j+a_j,
\quad K_0=L\chi+MH_p=\rho_k+b_k.
$$

The two packets imply

$$
I_0n_i=M_0m+\mathcal D_p n_k.
$$

Also,

$$
AM-BL=(pt-qs)(\delta-\beta)=\delta-\beta,
$$
$$
I_0K_0-M_0J_0=-\mathcal D_p(\delta-\beta).
$$

It follows that, writing $m=\sigma\widehat m$,

$$
\boxed{
\widehat m=I_0\rho_k-a_jJ_0-\mathcal D_p(P-\delta).
}
\tag{M-HAT}
$$

Set

$$
\Phi(P):=\widehat m-\mathcal K
$$

This is linear in $P$, and with all other packet parameters fixed,

$$
\boxed{\Phi'(P)=-(\mathcal D_p+M_0)<0.}
\tag{MONOTONE}
$$

<a id="fr-E8.4.3"></a>

## Fully specified static positivity polynomial

Under the terminal condition, write

$$
u=(\nu-1)\theta+z,\quad0\le z<\theta,
\quad h=\theta-z\ge1,
$$
$$
x=\chi-\nu H_p+T-1\ge0
$$

Equivalently,

$$
\begin{aligned}
\theta&=h+z,\qquad E=\nu(h+z)+R-h,\\
H_p&=T+w,\qquad \chi=\nu(T+w)-T+1+x.
\end{aligned}
\tag{TERMINAL-SUB}
$$

Define the polynomial

$$
\mathcal P:=\Phi(B+\nu A),
\tag{POS-POLY}
$$

where $\Phi$ is the fully explicit expression obtained from (M-HAT) and

$$
\mathcal K=(P-\delta)\rho_j+(P-\beta)a_j
$$

with (TERMINAL-SUB) substituted for $E,H_p,\theta,\chi$.

Following (ORDER), introduce independent nonnegative variables by

$$
s=s_0+1,\ t=t_0+1,\
p=s_0+2+p_0,\ q=t_0+1+q_0,
$$
$$
r=r_0,\ \delta=\delta_0+1,\ \beta=\beta_0+1,
\quad a_j=a_{j0}+1,\quad g=g_0+1,
$$
$$
\alpha=\alpha_0+1,\ b_k=b_{k0}+1,
\quad\nu=\nu_0+2,\ h=h_0+1,
\quad z=z_0,\ x=x_0,\ w=w_0.
$$

Then the following exact polynomial identity holds:

$$
\boxed{
\mathcal P=63+\sum_{\gamma\ne0}c_\gamma\mathbf y^\gamma,
\qquad c_\gamma\in\mathbb Z_{\ge0}.
}
\tag{STATIC-POS}
$$

The complete coefficient/exponent table is stored at `supplement/APPENDICES/EUCLIDEAN/TERMINAL_POSITIVITY_COEFFICIENTS.json`. The variable order is

```text
p0, q0, s0, t0, r0, delta0, beta0, aj0, g0, alpha0, bk0, nu0, h0, z0, x0, w0
```

The table contains **3,234 monomials including the constant term, total degree 7, and constant term 63**. The standard verifier reads this static table and checks that **every coefficient agrees** with the polynomial independently expanded from the defining expression above. Since all coefficients are nonnegative and the constant term is positive, $\mathcal P>0$ is a symbolic proof over the full parameter domain.

This positivity statement holds on the independent-variable domain specified only by (ORDER); the determinant-one condition need not be imposed as an additional constraint on the polynomial expansion. The determinant-one identity is, however, used exactly where required to identify the actual $\widehat m$ with (M-HAT).

This is not a finite scan over bounded numerical-semigroup parameters. Nor do we assume that the threshold $P=B+\nu A$ itself determines an actual semigroup. Only polynomial evaluation and (MONOTONE) are used.

<a id="fr-E8.4.4"></a>

## Consequence for the $i$-fit

If $P\le B+\nu A$, then

$$
\Phi(P)\ge\Phi(B+\nu A)=\mathcal P>0.
$$

Thus $m>n_k$, contradicting multiplicity. By integrality,

$$
\boxed{P\ge B+\nu A+1.}
\tag{I-FIT}
$$

All four coefficients in (FINAL-F) are now nonnegative. In particular, the final terminal representation is

$$
\boxed{
F=(M+\nu L-1)m+(P-1-B-\nu A)n_i+(h-1)n_j+x n_k.
}
\tag{FINAL-EXACT}
$$

---

<a id="fr-E8.5"></a>

## The exact Euclidean transformation outside the terminal case

The negation of the terminal condition is, by integrality,

$$
\nu H_p-\chi\ge T.
\tag{FAIL}
$$

Set

$$
e=\left\lfloor\frac E\theta\right\rfloor\ge1,
\quad\rho=E-e\theta,
\quad\kappa=\chi-eH_p
$$

Then $0\le\rho<\theta$, and

$$
\mathcal D_p=\theta\kappa-\rho H_p>0
$$

implies $\kappa\ge1$.

We have $\nu\le e+1$. If $\nu\le e$, then $\nu H_p-\chi\le-\kappa<0$, contradicting (FAIL). Hence

$$
\nu=e+1.
$$

Since $\lfloor u/\theta\rfloor=e$ and $u=E-R$, we have $\rho\ge R$. Equation (FAIL) gives $H_p-\kappa\ge T$, equivalently $\kappa\le w$. Thus

$$
\boxed{R\le\rho<\theta,\qquad1\le\kappa\le w.}
\tag{REMAINDERS}
$$

In particular, failure implies $w\ge1$. Therefore, if $w=0$, the terminal condition necessarily holds.

Combining (DP) with $e$ copies of (PP) gives

$$
\boxed{(B+eA)n_i+\rho n_j=(M+eL)m+\kappa n_k.}
\tag{NEW-PACKET}
$$

Every coefficient on both sides is nonnegative.

We now exchange the names $j,k$ and perform the following full transformation:

$$
n_i'=n_i,\quad n_j'=n_k,\quad n_k'=n_j,
\quad m'=m,\ F'=F,\ W'=W,
$$
$$
a_i'=b_i,\ b_i'=a_i,
\quad a_j'=b_k,\ b_j'=a_k,
\quad a_k'=b_j,\ b_k'=a_j,
$$
$$
\delta'=\beta,\ \beta'=\delta,
\quad g'=\alpha,\ \alpha'=g,
\quad R'=T,\ T'=R,\ P'=P,\ r'=r.
\tag{COLOR}
$$

The packet parameters become

$$
\boxed{
E'=H_p,\quad\theta'=\kappa,\quad
\chi'=\theta,\quad H_p'=\rho,
\quad u'=w,\quad w'=\rho-R.
}
\tag{EUCLID}
$$

The source matrix becomes

$$
\boxed{
\mathsf M'=\begin{pmatrix}t+eq&s+ep\\q&p\end{pmatrix}.
}
\tag{M-UPDATE}
$$

---

<a id="fr-E8.6"></a>

## Preservation of all hypotheses and well-foundedness

<a id="fr-E8.6.1"></a>

## Matrix, source, and level

All entries of the new matrix are positive, and

$$
(t+eq)p-(s+ep)q=pt-qs=1.
$$

$$
L'=M+eL>M'=L.
$$

Since the color exchange interchanges $r+\delta$ and $r+\beta$,

$$
A'=B+eA,\qquad B'=A.
$$

Thus (SOURCES) is preserved.

<a id="fr-E8.6.2"></a>

## The two genuine packets

The new (DP) is exactly the old (PP) after color exchange:

$$
B'n_i'+E'n_j'=An_i+H_p n_k=Lm+\theta n_j=M'm'+\chi'n_k'.
$$

The new (PP) is (NEW-PACKET) after color exchange:

$$
A'n_i'+H_p'n_k'=(B+eA)n_i+\rho n_j
=(M+eL)m+\kappa n_k=L'm'+\theta'n_j'.
$$

Thus no assumption is made that a signed intermediate relation is actual.

<a id="fr-E8.6.3"></a>

## Positivity, multipliers, and canonical relations

By (REMAINDERS),

$$
E'=R'+u',\quad H_p'=T'+w',\quad
1\le\theta'\le u',\quad w'\ge0,
$$
$$
\mathcal D_p'=\theta'\chi'-E'H_p'=\kappa\theta-H_p\rho=\mathcal D_p>0.
$$

Moreover,

$$
L'E'+M'\theta'-a_j'=\rho_k=\rho_j',
$$
$$
L'\chi'+M'H_p'-b_k'=\rho_j=\rho_k'.
$$

The relations (HCR) are simply interchanged. The identities $a_i'=P'-\beta'$ and $b_i'=P'-\delta'$ are also preserved.

The element $W$ retains not only the same value but the same canonical face after renaming:

$$
W=(P-1)n_i+(R-1)n_j+(T-1)n_k
=(P'-1)n_i'+(R'-1)n_j'+(T'-1)n_k'.
$$

The underlying semigroup, the Frobenius number, and the multiplicity condition are unchanged.

<a id="fr-E8.6.4"></a>

## Strict descent

The new measure is

$$
\mathcal M'=E'+\chi'=H_p+\theta.
$$

Using $E=e\theta+\rho$ and $\chi=eH_p+\kappa$,

$$
\boxed{
\mathcal M-\mathcal M'
=(e-1)(H_p+\theta)+\rho+\kappa>0.
}
\tag{DESCENT}
$$

The positive integer measure therefore decreases by at least one at every step, so failure cannot continue indefinitely. Strong induction shows that every abstract state reaches a terminal state after finitely many failure transformations. In that terminal state, (FINAL-EXACT) is obtained within the SAME $W$. Since color exchange only renames generators, this is the assertion $F\in\Gamma$ in the original $\Gamma$.

This proves the theorem [E8](#fr-E8).

---

<a id="preservation-table"></a>

## Conditions preserved by one transformation

| Input condition | Verification after a nonterminal transformation |
|---|---|
| Positive-integer matrix; determinant one | Entry formulas and determinant calculation in [E8.6.1](#fr-E8.6.1) |
| $L>M$; two linear source combinations | $L'=M+eL>M'=L$, $A'=B+eA,B'=A$ |
| Genuine DP and PP | New DP is old PP; new PP is NEW-PACKET |
| $E=R+u,H_p=T+w,1\le\theta\le u,w\ge0,\chi\ge1$ | $R\le\rho<\theta$, $1\le\kappa\le w$, and EUCLID |
| Positive packet determinant | $\mathcal D_p'=\mathcal D_p>0$ |
| Two RHO identities | [E8.6.3](#fr-E8.6.3) interchanges $\rho_j,\rho_k$ |
| Herzog coefficients, HCR, and $a_i=P-\beta,b_i=P-\delta$ | COLOR simultaneously exchanges the indices and all $a/b$-data |
| Positive common coefficients; $r\ge0$ | $\delta,\beta$ and $g,\alpha$ are exchanged; $r'=r$ |
| Same semigroup, Frobenius number, multiplicity, and $W$-face | Renaming generators preserves the original values and nonnegative representation |
| Positive-integer stopping measure | [E8.6.4](#fr-E8.6.4) proves strict decrease of $E+\chi$ |

This table summarizes the itemized proof immediately above. No row assumes preservation of the original first-point condition.


<a id="sec-11"></a>

# 11　Proof of the main theorem

We now combine the conclusion for the symmetric tail, the classification of the nonsymmetric tail into three terminal configurations, and the elimination of each configuration. Starting from the contradiction hypothesis obtained by selecting four rows, we return to the cardinality bound for the full set $Q(\Gamma)$.

<a id="fr-C8.5"></a>

## Completion of the CHAIN closure

[R7](#fr-R7) supplies the CORE of [C8.1](#fr-C8.1) from every actual CHAIN configuration. In [C8.2](#fr-C8.2), the boundary $C=\alpha$ is eliminated and the strict case is divided into $\mathcal U\vee\mathcal D$. The region $\mathcal U$ is eliminated in [C8.3](#fr-C8.3). In [C8.4](#fr-C8.4), $\mathcal D$ is reduced to $q_0=2$ and $N=\widehat\zeta+1$; if $\theta\ge\upsilon+1$, a nonnegative representation of the same $F$ gives a contradiction. In the remaining range $1\le\theta\le\upsilon$, the determinant-one matrix of [E8.2.3](#fr-E8.2.3) satisfies every hypothesis of [E8](#fr-E8). The termination and terminal source-fit in [E8](#fr-E8) then produce a nonnegative representation of $F$ in the original $\Gamma$. Hence CHAIN cannot occur.

<a id="fr-I9"></a>

## Proof of the main theorem [T1](#fr-T1)

Let $\Gamma$ be a minimally four-generated numerical semigroup satisfying the canonical condition of Sections 1–2, and suppose that
$|Q(\Gamma)|\ge4$.

By [C2](#fr-C2), for every $q\in Q(\Gamma)$ we have $q+m,c_q,W\in\operatorname{Ap}(\Gamma,m)\subseteq H$, $c_q-m\notin\Gamma$, and KEY holds. If four distinct rows are selected, the same $\Gamma,F,m,W$, together with their actuality, pseudo-Frobenius, and complement conditions, are preserved.

We first exclude the third possibility for the tail gcd. Choose any $q\in Q(\Gamma)$. Then

$$
m=(q+m)+(W-q)-W\in\mathbb ZH.
$$

Hence $\gcd(n_1,n_2,n_3)$ also divides $m$. Since $\gcd(m,n_1,n_2,n_3)=1$, the tail gcd is one. Moreover, minimality of $\Gamma$ implies that the three generators of the tail are themselves minimal. Thus $H$ is a genuine minimally three-generated numerical semigroup, and is either symmetric or nonsymmetric. The signed identity above need not be called a nonnegative factorization.

If $H$ is symmetric, [S3](#fr-S3) eliminates the contradiction hypothesis. If $H$ is nonsymmetric, then G4, [M4](#fr-M4), and Appendix B show that the surviving configuration of the four selected rows is one of PATH, TYPE II, or CHAIN. The case of three singletons, in which the full set $Q$ consists of only three rows, is proved separately in [G4.8](#fr-G4.8). Four-row configurations containing a corner are excluded by COLOR-CAP, and a matched pair together with a singleton is excluded in [G4.5.3](#fr-G4.5.3). This classification does not assume that the full set $Q$ has exactly four elements.

PATH is impossible by [P5.7](#fr-P5.7), and TYPE II by [T6](#fr-T6). A CHAIN configuration has, by [R7](#fr-R7), the CORE-ROOT structure of the same configuration and passes through [C8.1](#fr-C8.1)–[C8.4](#fr-C8.4) into [E8](#fr-E8). The full color exchange of [E8](#fr-E8) preserves the original $\Gamma,F,m,W$, and every nonterminal step strictly decreases the positive integer $\mathcal M=E+\chi$. After finitely many steps a terminal state is reached, and replacing the packet coefficientwise inside the source of that same $W$ yields a factorization of the original $F$ with all coefficients nonnegative. This contradicts $F\notin\Gamma$.

Thus every case arising from the contradiction hypothesis is impossible, and therefore

$$
\boxed{|Q(\Gamma)|\le3.}
$$

Since $F\in PF(\Gamma)$,

$$
\boxed{t(\Gamma)=|Q(\Gamma)|+1\le4.}
$$

This proves Theorem [T1](#fr-T1) from Sections 1–2.


<a id="app-A"></a>

# Appendix A　Auxiliary calculations and complete branching for the symmetric tail

<a id="fr-S3.1"></a>

## Elementary two-generator facts

Let $T=\langle u,v\rangle$, with $\gcd(u,v)=1$ and $u,v\ge2$. Every integer has a unique representation

$$
a u+b v,\qquad a\in\mathbb Z,\quad0\le b<u
$$

and membership in $T$ is equivalent to $a\ge0$. The difference between any two integral coefficient representations is $(kv,-ku)$. The following consequences will be used.

* $F_T=uv-u-v$, and for every integer $t$, $t\notin T\iff F_T-t\in T$. Indeed, the complementary representation to the normal form above is $(-a-1)u+(u-b-1)v$.
* If $P<v,Q<u$ and $Pu+Qv\in T$, then $P,Q\ge0$. A primitive shift that repairs either negative coordinate makes the other coordinate negative.
* If $P,Q>0$, then $uv-Pu-Qv\notin T$. Otherwise one would obtain a representation of $uv$ with both the $u$- and $v$-coefficients positive, whereas the integral solutions of $Xu+Yv=uv$ are exactly $X=v(1-k),Y=uk$.
* If $0\le P<v,0\le Q<u$, then $Pu+Qv-uv\notin T$. In $v$-normal form, the $u$-coefficient is $P-v<0$.

Moreover, if $0<A<v,0<B<u$, then

$$
(Au+T)\cap(Bv+T)=(Au+Bv+T)\cup(uv+T).
\tag{2GI}
$$

Indeed, write $X=(A+p)u+qv=ru+(B+s)v$ with $p,q,r,s\ge0$. If the primitive shift between the two representations is zero, both coefficients contain $A$ and $B$. If it is positive, the first $u$-coefficient is at least $v$; if it is negative, the $v$-coefficient in the second representation is at least $u$. Thus $X\in uv+T$. The reverse inclusion is immediate from $A<v,B<u$.

<a id="fr-S3.6"></a>

## Branch I: the walk and the necessity of four hits

Let $\theta=L=u+v+t_0$, where $t_0=p_0u+q_0v\in T$. If $k_0=0$, then $\mu=L\in T$, so $k_0=1$. Hence

$$
\kappa=d-e,\quad 1\le\kappa\le d-1-s,\quad
m=dL-\kappa w,\quad E=w-L>0.
$$

The final positivity follows from $m<w$ and $\kappa+1\le d-s<d$. Define

$$
c_n=\left\lceil\frac{n\kappa-s}{d}\right\rceil,\quad
j_n=s-n\kappa+dc_n,\quad
\tau_n=\rho+nL-c_nw.
$$

FS is equivalent to $\tau_n\in T\ (n\ge1)$. Each adjacent step is either $L$ or $L-w$. A return is an index with $j_n=0$, equivalently $n\kappa\equiv s\pmod d$.

The $T$-coordinate of $a_x-y+nm$ is $\tau_n+Au-v$. For $\tau$ in $T$,

$$
\tau+Au-v\notin T\iff\tau\in U_x:=\{ju:0\le j<D\}.
$$

This follows directly from the normal form in [S3.1](#fr-S3.1). Although $a_x-y\in H$, actual pseudo-Frobenius behavior gives $q_x+y\in\Gamma$, while GAP-K yields $a_x-y\notin K$. Hence a hit of $U_x$ is required for some $n\ge1$. Dually, a hit is required in

$$
U_y=\{jv:0\le j<C\}
$$

Likewise, for $a_x-w+nm$, every nonreturn index automatically gives an element of $H$. At a return, the $T$-coordinate becomes $\tau_n+A'u-\beta v$. This is a gap of $T$ precisely when the same $\tau_n$ lies in

$$
Z_x=\{pu+qv:0\le p<D',\ 0\le q<\beta\}
$$

Since $a_x-w\in H$ and $q_x+w\in\Gamma$, such a return hit is necessary. Dually, at a return one also needs a hit in

$$
Z_y=\{pu+qv:0\le p<\alpha,\ 0\le q<C'\}
$$

All four hits arise from the same actual pseudo-Frobenius pair and the same walk.

<a id="fr-S3.7"></a>

## Branch I: the four hits are incompatible

Write $a=A'>0,b=B'>0$. Let $\rho=uv-w-au-bv$. At a return index $N$, one has $c_{N-1}=c_N$ and $c_{N+1}=c_N+1$. Thus, if $N>1$,

$$
\tau_{N-1}=\tau_N-L\in T.
$$

If $\tau_N=pu+qv\in Z_x$ or $Z_y$, then $p<v,q<u$. Hence [S3.1](#fr-S3.1) gives

$$
p\ge p_0+1,\qquad q\ge q_0+1.
\tag{LOWER}
$$

We do not impose this restriction when $N=1$.

If both the $Z_x$- and $Z_y$-hits occur at indices $N>1$, then $R=\alpha-p_0-1>0$ and $Q=\beta-q_0-1>0$. But $c_1\in\{0,1\}$, and

$$
\tau_1=uv-(a+R)u-(b+Q)v-c_1w\notin T
$$

(after substituting the positive coefficient representation of $w$ and applying [S3.1](#fr-S3.1)). Hence one of the return hits must occur at $N=1$, and in particular $\kappa=s$. The base point $\tau_1$ splits into the three cases X-only, Y-only, and XY.

In general, a later hit $\tau_N=ju$, $j<D$, in $U_x$ must occur through a carry. Without a carry,
$\tau_{N-1}=(j-p_0-1)u-(q_0+1)v\notin T$. The dual statement holds for $U_y$.

**X-only.** The $Z_y$-hit is later, so LOWER gives $p_0\le\alpha-2,q_0\le u-b-2$. Put $R=\alpha-p_0-1>0$ and $S=q_0+1-\beta$. Then

$$
w-L=Ru-Sv,\qquad\tau_1=(v-a-R)u+(S-b)v.
$$

Both coefficients lie below the upper edge of the fundamental strip, so FS implies $S\ge b$. Also $1\le R\le\alpha-1,1\le S<u$. For the base point to lie in $U_x$, one would need $S=b$, but then its $u$-coefficient $v-a-R\ge D+1$ is too large. If there were a later $U_x$-hit, its carry predecessor would be $(j+R)u-Sv$; however, $j+R\le v-a-2<v$ and $0<S<u$, so this is a $T$-gap. Hence there is no $U_x$-hit.

**Y-only.** The same argument, with $u\leftrightarrow v$, $A\leftrightarrow B$, $\alpha\leftrightarrow\beta$, and $a\leftrightarrow b$, shows that there is no $U_y$-hit.

**XY.** The coordinate representation in both rectangles is unique in the range $p<v,q<u$, so

$$
\tau_1=pu+qv,\quad 0\le p<\alpha,\quad 0\le q<\beta.
$$

$$
E=uv-(a+p)u-(b+q)v,\qquad
\tau_2=(2p+a)u+(2q+b)v-uv.
$$

If the $U_x$-hit occurs at the base point, then also $p\le D-1$, and hence $2p+a\le(\alpha-1)+(D-1)+a=v-2$. If a later hit is $ju$ with $j<D$, then its carry predecessor is

$$
ju+E=uv-(a+p-j)u-(b+q)v.
$$

The interior-gap criterion from [S3.1](#fr-S3.1) gives $j\ge a+p$. Together with $p\le\alpha-1$, this again yields $2p+a<v$. Dually, the $U_y$-hit forces $2q+b<u$. Therefore the final gap criterion in [S3.1](#fr-S3.1) gives $\tau_2\notin T$, contradicting FS.

Thus the four hits are incompatible in all three cases, and Branch I is eliminated.

<a id="fr-S3.8"></a>

## Branch II, $k_0=1$: D-row drop or Branch I

Let $\theta=\rho+u+v+t_0$, with $t_0\in T$. If $k_0=1$, then $e\ge s+1$, $\kappa=d-e>0$, and

$$
\mu=\theta-w,\qquad m=d\theta-\kappa w,\qquad
\kappa w<d\theta<(\kappa+1)w.
$$

Set $g=w-u-v-t_0=w-\theta+\rho$. We record explicitly that $g>0$: from $r>0$, $\rho>-sw/d$, and from $m<w$, $\theta<(\kappa+1)w/d$. Hence

$$
\theta-\rho<\frac{\kappa+s+1}{d}w\le w.
\tag{K1-g}
$$

The backward points of the two D-rows are

$$
a'_x-m=\kappa w+d(A'u+g),\qquad
a'_y-m=\kappa w+d(B'v+g).
$$

If either lies in $H$, then it lies in $K$, and CAN gives the corresponding $c'-m\in\Gamma$, contradicting ALL-AP. Thus both are gaps of $H$, so $A'u+g,B'v+g\notin T$. By symmetry of $T$,

$$
F_T-g\in(A'u+T)\cap(B'v+T).
$$

Apply 2GI. Since $g>0$, one has $F_T-g<uv$, so the $uv+T$ component is impossible. Therefore

$$
F_T-g-A'u-B'v=\rho+t_0=\theta-u-v\in T.
$$

This is precisely Branch I, already eliminated. Hence the case $k_0=1$ is also impossible.

<a id="fr-S3.9"></a>

## Branch II, $k_0=0,e=0$

Here $\theta=\mu\notin T$ and $m=d\theta$. By multiplicity,
$0<\theta<\min(u,v)$. Since $c_1=\lfloor(s+e)/d\rfloor=0$, the first stable coordinate is

$$
\tau_1=\rho+\theta=2\theta-u-v-t_0<0.
$$

This contradicts FS.

<a id="fr-S3.10"></a>

## Branch II, $k_0=0,e>0$: cross-core exclusion

Write $t_0=pu+qv$. Since $\theta=\rho+u+v+t_0\notin T$, one has $p\le A-2,q\le B-2$. Hence

$$
P=A-1-p>0,\quad R=B-1-q>0,\quad Q=u-R,\quad S=v-P,
$$
$$
\theta=-Pu+Qv=Su-Rv<0.
\tag{K0}
$$

The final inequality follows from $m=ew+d\theta<w$ and $e\ge1$. We have $P\le A-1,R\le B-1$ and $0<Q<u,0<S<v$.

Let $k=d-s$, $c_n=\lfloor(s+ne)/d\rfloor$, and $\tau_n=\rho+n\theta+c_nw\in T$. If $c_1=0$, then $\rho+\theta<0$, so $e\ge k$. Put $L_0=u+v+t_0$. Then $\tau_1=2\theta+w-L_0\ge0$. With $h_0=-\theta>0$, this gives $2h_0\le w-L_0<w$. Together with $m<w$,

$$
(e-1)w<dh_0<dw/2,\qquad 2e\le d+1.
\tag{PHASE}
$$

Let $\lambda_n=\lceil ne/d\rceil$ and $\varepsilon_n=\lambda_n-c_n\in\{0,1\}$. If $Y_n$ denotes the $T$-coordinate in the $H$-normal form of $c_y-nm$, direct calculation gives

$$
Y_n+\tau_n=Du-\varepsilon_n w.
\tag{COMP}
$$

By ALL-AP, $c_y-nm\notin H$ for every $n\ge1$, hence $Y_n\notin T$.

On the other hand, the $T$-coordinate of $a_x-y+nm$ is $\tau_n+Au-v$. If this were a $T$-gap, the translation criterion from [S3.6](#fr-S3.6) would force $\tau_n=ju$, with $0\le j<D$.

* If $\varepsilon_n=0$, then COMP gives $Y_n=(D-j)u\in T$, a contradiction.
* Suppose $\varepsilon_n=1$. Write $ne=qd+r$, $0\le r<d$. Then $1\le r<k$. Since $e\ge k$, one has $n\ge2$. Moreover,
  $$
  (n-1)e=(q-1)d+(d+r-e),\quad d+r-e\ge k
  $$
  by PHASE, because $d+r-e-k\ge d+1-e-k\ge d+1-2e\ge0$. Hence $c_{n-1}=c_n=q$. The preceding stable point is
  $$
  \tau_{n-1}=\tau_n-\theta=(j+P)u-Qv.
  $$
  But $j+P\le D-1+A-1=v-2$ and $0<Q<u$, so this is a $T$-gap, contradicting FS.

Therefore $a_x-y+nm\in H$ for every $n\ge0$, so $a_x-y\in K$. GAP-K then gives $q_x+y\notin\Gamma$, contradicting the actual pseudo-Frobenius consequence $q_x+y\in\Gamma$.

This eliminates every $k_0/e$-case in Branch II. Hence not all RAW4 rows can remain in the Apéry set, and TYPE-BRIDGE yields

$$
\boxed{t(\Gamma)\le4}.
$$


<a id="app-B"></a>

# Appendix B　The relative lattice of three arms and the in-box path argument

In this appendix, $C$ denotes a local $3\times3$ matrix and is unrelated to the CORE-ROOT coefficient $C$.

<a id="fr-A1.1"></a>

## Input and the socle matrix

Let $H=\langle n_1,n_2,n_3\rangle$ be a nonsymmetric three-generated numerical semigroup, and let

$$
\Gamma=\langle m,n_1,n_2,n_3\rangle,\qquad 0<m<\min_i n_i.
$$

We use the standard Herzog package with the following convention. All $a_i,b_i$ are positive integers, and

$$
\rho_i=a_i+b_i,
\quad
\rho_1n_1=b_2n_2+a_3n_3,
\quad
\rho_2n_2=a_1n_1+b_3n_3,
\quad
\rho_3n_3=b_1n_1+a_2n_2.
$$

These are the true critical relations, and we use the primitive integer-kernel lattice. The standard generator formulas are

$$
n_1=a_2a_3+a_3b_2+b_2b_3,
\quad n_2=a_1a_3+a_1b_3+b_1b_3,
\quad n_3=a_1a_2+a_2b_1+b_1b_2.
$$

Let $PF(H)=\{f_A,f_B\}$, $N=n_1+n_2+n_3$, and $s_\varepsilon=f_\varepsilon+N$. With **rows equal to socle factorizations**, the correct matrices are

$$
U_A=\begin{pmatrix}0&\rho_2&a_3\\a_1&0&\rho_3\\\rho_1&a_2&0\end{pmatrix},
\qquad
U_B=\begin{pmatrix}0&b_2&\rho_3\\\rho_1&0&b_3\\b_1&\rho_2&0\end{pmatrix}.
\tag{U}
$$

Differences of rows are the zero relations above, hence $U_\varepsilon n=s_\varepsilon\mathbf1$. Substituting the generator formulas gives

$$
\det U_\varepsilon=s_\varepsilon,
\qquad \operatorname{adj}(U_\varepsilon)\mathbf1=n.
\tag{UD}
$$

<a id="fr-A1.2"></a>

## The minimal factorization forced by three actual arms

Assume three arms of the same color $\varepsilon$:

$$
q_i=f_\varepsilon-\lambda_i n_i\in PF(\Gamma),\qquad
1\le\lambda_i\le\alpha_i-1,
\quad
\alpha_i=\begin{cases}a_i&\varepsilon=A,\\b_i&\varepsilon=B\end{cases}
\tag{ARM}
$$

Then $f=f_\varepsilon\in\Gamma\setminus H$. Every genuine factorization

$$
f=k m+\sum_i x_i n_i
$$

must satisfy $k\ge1$ and $0\le x_i\le\lambda_i-1$. Indeed, if $x_i\ge\lambda_i$, removing $\lambda_i n_i$ from that same factorization would give $q_i\in\Gamma$.

Choose a factorization with the positive $m$-coefficient minimal:

$$
f=k m+\sum_i(p_i-1)n_i,
\qquad1\le p_i\le\lambda_i\le\alpha_i-1.
\tag{MIN}
$$

Thus $s-p\cdot n=km$. No uniqueness of factorization is assumed at this stage.

<a id="fr-A1.3"></a>

## Empty tetrahedron and the cyclic quotient

Let $L_d=\{z\in\mathbb Z^3:z\cdot n\equiv0\pmod d\}$. Since $n$ is primitive, $[\mathbb Z^3:L_d]=d$. Define

$$
C=U-\mathbf1p^T,
\qquad c_i=U_i-p
$$

Then $Cn=km\mathbf1$, and by (UD) and the determinant lemma, $\det C=km$. Hence

$$
\operatorname{row}_{\mathbb Z}C=L_{km},
\qquad L_m/L_{km}\cong\mathbb Z/k\mathbb Z,
\quad [z]\mapsto z\cdot n/m\pmod k.
\tag{LAT}
$$

The simplex $\Delta=\operatorname{conv}(p,U_1,U_2,U_3)$ is empty with respect to the affine lattice $p+L_m$. Indeed, if

$$
u=(1-\tau)p+\sum_i\tau_iU_i,
\quad \tau_i\ge0,\quad\tau=\sum_i\tau_i\le1
$$

is a lattice point, then $\ell=(s-u\cdot n)/m=(1-\tau)k$ is an integer.

* If $0<\ell<k$, then $u>0$ coefficientwise, so $f=\ell m+\sum_i(u_i-1)n_i$ is a genuine factorization, contradicting minimality of $k$.
* If $\ell=k$, then $u=p$.
* If $\ell=0$, then $u$ lies on the top face. At a nonvertex point at least two of the $U_i$ occur, and since each row of (U) has its unique zero in a different coordinate, $u>0$. Then $f=\sum_i(u_i-1)n_i\in H$, a contradiction.

Thus the only lattice points are the four vertices. The relative lattice volume is $\det C/[\mathbb Z^3:L_m]=k$.

<a id="fr-A1.4"></a>

## White classes: the only additional standard external theorem

The only result of White used here is the standard theorem that an empty lattice tetrahedron has lattice width one: G. K. White, *Lattice Tetrahedra*, Canad. J. Math. 16 (1964), 389–396. An exposition of the proof is given by Khan–Rogers, *An Exposition of White's Characterization of Empty Lattice Tetrahedra*. The quotient, height, and companion constructions below are proved within the present argument.

Assume $k\ge2$. In the half-open parallelepiped, choose a representative of class $j\in\{1,\ldots,k-1\}$:

$$
r_j=\sum_i\theta_{j,i}c_i,\qquad0\le\theta_{j,i}<1
$$

Emptiness gives $\sum_i\theta_{j,i}>1$. For the negative class, the nonzero coordinates have coefficients $1-\theta_{j,i}$. Since both sums are $>1$, all three coordinates are nonzero, and

$$
0<\theta_{j,i}<1,
\qquad1<\sum_i\theta_{j,i}<2.
$$

Moreover, $k\sum_i\theta_{j,i}=r_j\cdot n/m\equiv j\pmod k$, so

$$
\sum_i\theta_{j,i}=1+j/k.
\tag{AGE}
$$

White's width-one planes separate the vertices into two pairs. A $1+3$ split would have an empty triangular facet that is unimodular in its own lattice and height one, forcing simplex volume one, contrary to $k\ge2$. After a row permutation, the planes may therefore be taken to separate $(p,U_1)$ from $(U_2,U_3)$. Normalize the corresponding primitive affine functional to be linear with $p=0$; then $c_1\mapsto0,c_2,c_3\mapsto1$. Since $r_1$ is a lattice point, $\theta_{1,2}+\theta_{1,3}$ is an integer in $(0,2)$, equivalently $0<\cdot<2$ for this quantity, and hence equals one. By AGE, $\theta_{1,1}=1/k$.

Thus, for some $1\le r<k$,

$$
\theta_1=(1/k,r/k,(k-r)/k).
$$

Nonvanishing of all coordinates in every class gives $\gcd(r,k)=1$. Let $q<k$ be the positive integer and let $\ell$ be the nonnegative integer determined by $rq=1+\ell k$. If the rows in the natural ordering are denoted by $R_i$, then

$$
z=\frac{R_1+r(R_2-R_3)-p}{k}\in\mathbb Z^3,
\qquad z_q=qz-\ell(R_2-R_3)\in\mathbb Z^3.
\tag{Z}
$$

Here $r_1=c_3+z,r_q=c_3+z_q$. For $v=z$ or $z_q$, the lower companions of class $j$ and $k-j$ are

$$
\begin{array}{lll}
p+R_3-R_1+v,&p+R_3-R_2+v,&p+v,\\
R_2-v,&R_1-v,&R_1+R_2-R_3-v.
\end{array}
\tag{COMP}
$$

They satisfy $s-u\cdot n=(k-j)m$ or $jm$, respectively. Minimality therefore implies that **none of the six vectors is coefficientwise strictly positive**. The argument is unchanged if classes coincide when $q=1$ or $k=2$.

<a id="fr-A1.5"></a>

## Exact failure inequalities for color A

For $U_A$ in the natural ordering,

$$
z=(-X,Y,Z),
\quad X=\frac{rb_1+p_1}{k},
\quad Y=\frac{b_2-(r-1)a_2-p_2}{k},
\quad Z=\frac{(r+1)a_3+rb_3-p_3}{k}.
$$

The arm bounds give $X>0,X<p_1+\rho_1,X<p_1+b_1$, $-a_2<Y<b_2$, and $0<Z<\rho_3$. Apply failure of the six vectors in COMP in the following order.

1. Failure of $R_2-z=(a_1+X,-Y,\rho_3-Z)$ gives $Y\ge0$.
2. Failure of $R_1-z=(X,\rho_2-Y,a_3-Z)$ gives $Z\ge a_3$.
3. From $p+R_3-R_2+z=(p_1+b_1-X,p_2+a_2+Y,p_3-\rho_3+Z)$, obtain $Z\le\rho_3-p_3$.
4. From $p+R_3-R_1+z=(p_1+\rho_1-X,p_2-b_2+Y,p_3-a_3+Z)$, obtain $Y\le b_2-p_2$.
5. Failure of $p+z$ gives $X\ge p_1$.
6. Failure of $R_1+R_2-R_3-z=(X-b_1,b_2-Y,2a_3+b_3-Z)$ gives $X\le b_1$.

Therefore

$$
p_1\le X\le b_1,\quad0\le Y\le b_2-p_2,
\quad a_3\le Z\le\rho_3-p_3.
\tag{BA}
$$

For $z_q=(-X_q,Y_q,Z_q)$, direct calculation gives

$$
X_q=(b_1+qp_1)/k,
\quad Y_q=[q(b_2-p_2)+(q-1)a_2]/k,
\quad Z_q=[(q+1)a_3+b_3-qp_3]/k.
$$

Since $b_2-p_2\ge(r-1)a_2$, one has $Y_q\ge0$. Also

$$
kb_2-kY_q=(k-q)b_2+qp_2-(q-1)a_2
\ge k(r-\ell-1)a_2+kp_2>0.
$$

Thus $Y_q<b_2$. The remaining bounds $0<X_q<p_1+b_1$ and $0<Z_q<\rho_3$ are immediate, so the same six-vector argument applies (BA) to $z_q$ as well.

Using only $X_q\ge p_1,Y\ge0,Z_q\ge a_3$ and integrality, and writing $s=k-q\ge1$, we obtain

$$
b_1=sp_1+ku,
\quad b_2=p_2+(r-1)a_2+ky,
\quad b_3=qp_3+(s-1)a_3+kv,
\quad u,y,v\in\mathbb Z_{\ge0}.
\tag{AP}
$$

The final proof does not require a converse classification of the failure cone or its redundant inequalities.

<a id="fr-A1.6"></a>

## Color A multiplicity contradiction for all $k\ge2$

Put $e_i=a_i-p_i\ge1$. The three socle rows give

$$
\begin{aligned}
km&=(e_1+b_1)n_1+e_2n_2-p_3n_3,\\
km&=-p_1n_1+(e_2+b_2)n_2+e_3n_3,\\
km&=e_1n_1-p_2n_2+(e_3+b_3)n_3.
\end{aligned}
$$

Multiply them respectively by $1,s,rs$ and add. With $D=1+s+rs$, (AP) gives

$$
w\cdot n=kDm,
\quad
\begin{cases}
w_1=(1+rs)e_1+ku,\\
w_2=(1+rs)e_2+sky,\\
w_3=((k-1)rs-1)p_3+s(1+rs)e_3+rskv.
\end{cases}
$$

We have $(k-1)rs-1\ge0$ and each $w_i>0$. Since $rs+1=k(r-\ell)$ and $r-\ell\ge1$,

$$
\sum_iw_i-kD\ge(s+1)(rs+1-k)
=k(s+1)(r-\ell-1)\ge0.
$$

But $n_i>m$, so $w\cdot n>m\sum_iw_i\ge kDm$, a contradiction.

<a id="fr-A1.7"></a>

## Color B failure inequalities and multiplicity contradiction

For the correct natural ordering of $U_B$,

$$
z=(X,-Y,Z),
\quad X=(ra_1-p_1)/k,
\quad Y=[r\rho_2-b_2+p_2]/k,
\quad Z=[a_3+(r+1)b_3-p_3]/k.
$$

The arm bounds give $-p_1<X<a_1,0<Y<\rho_2,0<Z<\rho_3$. Apply failure of COMP in order.

1. From $p+z$, obtain $Y\ge p_2$.
2. From $R_2-z=(\rho_1-X,Y,b_3-Z)$, obtain $Z\ge b_3$.
3. From $R_1-z=(-X,b_2+Y,\rho_3-Z)$, obtain $X\ge0$.
4. From $R_1+R_2-R_3-z=(a_1-X,Y-a_2,a_3+2b_3-Z)$, obtain $Y\le a_2$.
5. From $p+R_3-R_1+z=(p_1+b_1+X,p_2+a_2-Y,p_3-\rho_3+Z)$, obtain $Z\le\rho_3-p_3$.
6. From $p+R_3-R_2+z=(p_1-a_1+X,p_2+\rho_2-Y,p_3-b_3+Z)$, obtain $X\le a_1-p_1$.

Hence

$$
0\le X\le a_1-p_1,\quad p_2\le Y\le a_2,
\quad b_3\le Z\le\rho_3-p_3.
\tag{BB}
$$

For $z_q=(X_q,-Y_q,Z_q)$, direct calculation gives

$$
X_q=(a_1-qp_1)/k,
\quad Y_q=[a_2-(q-1)b_2+qp_2]/k,
\quad Z_q=[qa_3+(q+1)b_3-qp_3]/k.
$$

The arm bounds directly give $-p_1<X_q<a_1$, $0<Z_q<\rho_3$, and $Y_q<\rho_2$. Failure of $p+z_q$ first gives $Y_q\ge p_2>0$. Continuing the same six-vector argument in the same order applies (BB) to $z_q$ as well.

From $X_q\ge0,Y_q\ge p_2,Z\ge b_3$ and integrality, with $t=k-r\ge1$,

$$
a_1=qp_1+ku,
\quad a_2=(q-1)b_2+(k-q)p_2+ky,
\quad a_3=p_3+(t-1)b_3+kv,
\quad u,y,v\ge0.
\tag{BP}
$$

Let $f_i=b_i-p_i\ge1$. The three socle rows are

$$
\begin{aligned}
km&=-p_1n_1+f_2n_2+(a_3+f_3)n_3,\\
km&=(a_1+f_1)n_1-p_2n_2+f_3n_3,\\
km&=f_1n_1+(a_2+f_2)n_2-p_3n_3.
\end{aligned}
$$

Multiply them respectively by **$q,1,qt$** and set $D=1+q+qt$. Then

$$
w\cdot n=kDm,
\quad
\begin{cases}
w_1=(1+qt)f_1+ku,\\
w_2=(qt(k-1)-1)p_2+q(1+qt)f_2+qtk y,\\
w_3=(1+qt)f_3+qkv.
\end{cases}
$$

All $w_i>0$. Since $qt+1=k(q-\ell)$ and $q-\ell\ge1$,

$$
\sum_iw_i-kD\ge(q+1)(qt+1-k)
=k(q+1)(q-\ell-1)\ge0.
$$

Again this contradicts $n_i>m$.

<a id="fr-A1.8"></a>

## White row ordering and conclusion

The row ordering selected by White may be arbitrary. Apply a simultaneous generator permutation that returns the unique zero coordinate of each row to the corresponding index. An even permutation preserves both $A/B$ and $a/b$; an odd permutation exchanges $a/b$ and $A/B$ simultaneously. The arm box $p_i\le a_i-1$ is correspondingly carried to $p_i'\le b_i'-1$. This can be checked directly by simultaneously permuting rows and columns in (U). Thus the two natural master orderings exhaust all possibilities.

It follows that $k\ge2$ is impossible, and therefore

$$
\boxed{k=1,\qquad f_\varepsilon=m+\sum_i(p_i-1)n_i,
\quad1\le p_i\le\lambda_i\le\alpha_i-1.}
\tag{MINBOX}
$$

This stage uses only lattice algebra and the **minimal positive $m$-coefficient**. No signed intermediate is called actual. A lower companion used for contradiction is converted into a genuine factorization only when all three coordinates are positive.

<a id="fr-A1.9"></a>

## Exact interface to the $k=1$ dynamics

After color reversal if necessary, take color A. Put $x=p\ge1,y=a-p\ge1,z=y+b\ge2$. Then

$$
C=U_A-\mathbf1p^T
=\begin{pmatrix}-x_1&z_2&y_3\\y_1&-x_2&z_3\\z_1&y_2&-x_3\end{pmatrix},
\quad Cn=m\mathbf1,\quad\det C=m.
\tag{BOX}
$$

The three-arm coordinate caps further imply that, for every $u\in\mathbb Z_{>0}^3$ satisfying

$$
s-u\cdot n\in m\mathbb Z_{\ge0}
$$

we have $u_i\le\lambda_i\le a_i-1=x_i+y_i-1$. This is the LOWER-BOX condition in [A2.0](#fr-A2.0).

For example, eliminating rows 1 and 3 of (BOX) gives, for $\Delta_2=x_1x_3-z_1y_3$,

$$
\Delta_2 n_3=(x_1y_2+z_1z_2)n_2-(x_1+z_1)m>0
$$

Indeed, $y_2\ge1,z_2\ge2,n_2>m$, so the right-hand side is positive. The other relevant cyclic minors are positive in the same way. Hence the positive minors needed downstream do not rely on an independent older master lemma.

The matrix $C$, the box $\mathcal B$, and the local integers introduced here are used only in this appendix.

<a id="fr-A2.0"></a>

## Exact input inherited from MINBOX

Let $x_i,y_i,b_i$ be positive integers, with $z_i=y_i+b_i$ and $a_i=x_i+y_i$. Assume

$$
C=\begin{pmatrix}-x_1&z_2&y_3\\y_1&-x_2&z_3\\z_1&y_2&-x_3\end{pmatrix},
\quad Cn=m\mathbf1,
\quad 0<m<\min(n_1,n_2,n_3).
\tag{INPUT}
$$

Let $\mathcal B=\prod_i[1,a_i-1]\cap\mathbb Z^3$, with initial point $p=x$.

Firing row $i$ means $u\mapsto u-c_i$. A firing is *positive* if all coordinates remain positive, and *in-box* if the result also lies in $\mathcal B$. **Theorem DPE:** a maximal in-box path from $p$ cannot terminate at a positivity sink; it has a positive out-of-box firing.

Neither $\det C=m$ nor $\operatorname{adj}C\mathbf1=n$ is an additional requirement for this dynamics theorem. INPUT is already sufficient.

<a id="fr-A2.1"></a>

## The finite unique in-box path

The three source regions for in-box firings are

$$
F_1:\ u_1\le y_1-1,\ u_2\ge z_2+1,\ u_3\ge y_3+1,
$$
$$
F_2:\ u_1\ge y_1+1,\ u_2\le y_2-1,\ u_3\ge z_3+1,
$$
$$
F_3:\ u_1\ge z_1+1,\ u_2\ge y_2+1,\ u_3\le y_3-1.
$$

These regions are pairwise disjoint. Every firing decreases $u\cdot n$ by exactly $m$, so no path is infinite.

A state with no positive firing lies in the union of the following four regions; this follows by negating the two positivity conditions for each row and expanding:

$$
\mathsf A:\ u_1\le y_1,u_2\le z_2;
\quad\mathsf B:\ u_1\le z_1,u_3\le y_3;
$$
$$
\mathsf C:\ u_2\le y_2,u_3\le z_3;
\quad\mathsf D:\ u_1\le z_1,u_2\le z_2,u_3\le z_3.
\tag{SINK}
$$

The initial point $p$ is not a sink. If $p\in\mathsf A$, then $c_1+c_2$ is coefficientwise nonnegative and its third coefficient is $y_3+z_3\ge3$, giving $2m\ge3n_3$, a contradiction. The cases $\mathsf B,\mathsf C$ are the cyclic analogues. If $p\in\mathsf D$, the sum of the three rows has coefficients $y_i+z_i-x_i\ge y_i\ge1$, giving $3m\ge n_1+n_2+n_3$, again impossible.

If the first firing is out of the box, the theorem is already proved. Otherwise, after cyclic normalization we may assume $p\in F_1$. Then

$$
x_1<y_1,\quad x_2>z_2,\quad x_3>y_3.
\tag{START}
$$

We henceforth suppose, toward a contradiction, that a maximal path terminates at a sink.

<a id="fr-A2.2"></a>

## Positive minors needed for the two-color calculation

Combining the first two rows of INPUT gives

$$
(x_1x_2-y_1z_2)n_2
=(y_1y_3+x_1z_3)n_3-(x_1+y_1)m>0.
$$

This follows from $z_3\ge2,y_3\ge1,n_3>m$. Hence $\Delta_3=x_1x_2-y_1z_2>0$.

Likewise,

$$
(x_1x_3-y_3z_1)n_3
=(z_1z_2+x_1y_2)n_2-(z_1+x_1)m>0,
$$

so $\Delta_2=x_1x_3-y_3z_1>0$. These inequalities establish the orientations of the two Farey corridors used below.

<a id="fr-A2.3"></a>

## Common arithmetic lemma for a two-color prefix

Consider only row 1 and row $r$, where $r=2$ or $3$. Use the following common notation.

| Symbol | $r=2$ | $r=3$ |
|---|---|---|
| x | $x_1$ | $x_1$ |
| A | $y_1$ | $z_1$ |
| B | $z_2$ | $y_3$ |
| v | $x_2$ | $x_3$ |
| b=A−y_1 | 0 | $b_1$ |
| c=B−y_r | $b_2$ | 0 |

In either case $A>x$, $v>B$, and $A/x<v/B$. Write the row counts as $(N-1,q-1)$, and define

$$
X=qA-Nx,\qquad D=NB-qv.
$$

The used coordinates are $u_1=A-X,u_r=B-D$. For row 1 to fire in-box one needs $X\ge b+1$; for row $r$ to fire in-box one needs $D\ge c+1$. These conditions are sufficient once the remaining unused-coordinate threshold is satisfied.

<a id="fr-A2.3.1"></a>

### Successful crossings

At the $q$-th crossing where an in-box firing of row $r$ actually follows a run of row 1,

$$
N_q=\lceil qA/x\rceil,
\quad E_q=N_qx-qA,\quad U_q=qv-(N_q-1)B,
$$
$$
1\le E_q\le x-b-1,
\qquad1\le U_q\le B-c-1=y_r-1.
\tag{RES}
$$

Indeed, the in-box continuation by row 1 ends when $X\le b$. The strip $0\le X\le b$ is an early-exit strip in which switching to row $r$ is impossible. At a successful switch, $X=-E_q<0$, while the preceding row-1 source satisfies $X+x\ge b+1$, giving $E_q\le x-b-1$. The positivity and capacity of the row-$r$ source are exactly the stated range for $U_q$.

Immediately after firing row $r$, one has $u_1=E_q<x<y_1$, so row $r$ cannot fire again immediately. Hence successful crossings occur as the chronological initial prefix $q=1,2,\ldots$. Before the third color appears, the next move is a row-1 run.

RES gives

$$
(N_q-1)/q<A/x<v/B<N_q/q
\tag{CROSS}
$$

Therefore, if all crossings through $q$ are successful, then for every $1\le h\le q$ there is no integral fraction $k/h$ in the closed interval $[A/x,v/B]$. This is the **PREFIX separator rule**; it is a consequence, not an additional assumption.

<a id="fr-A2.3.2"></a>

### Injectivity, anti-chain property, and last-rank bound

For $i<j$, set $h=j-i,k=N_j-N_i$. Then

$$
E_j-E_i=kx-hA,\qquad U_j-U_i=hv-kB.
$$

If the $E$-coordinates are equal, then $k/h=A/x$; if the $U$-coordinates are equal, then $k/h=v/B$. Either contradicts PREFIX. If both coordinates increase, then $A/x<k/h<v/B$, again impossible.

Thus each coordinate is injective, and relative to the last point $(E_q,U_q)$, every earlier point satisfies $E_i>E_q$ or $U_i>U_q$. Counting integer slots gives

$$
q+E_q+U_q\le (x-b)+(B-c)-1.
\tag{LR}
$$

In particular, $q\le x-b-1$ and $q\le y_r-1$.

The same difference calculation applies to a terminal crossing $q=Q$ before success. If indices $1,\ldots,Q-1$ are successful and the terminal point has $N=\lceil QA/x\rceil$, then

$$
Q-1\le(x-b-1-E)_++(y_r-1-U)_+,
\tag{ELR}
$$

provided the relevant terminal residues lie in their stated positive ranges. At every use of ELR below, $E\ge1,U\ge1$, and $E\le x-b-1$ are verified explicitly.

<a id="fr-A2.4"></a>

## Reciprocal-rank lemma, including preservation of the omitted prefix

Consider a state reached by $\ell\ge1$ additional row-1 firings after the last successful crossing $q\ge1$. Put

$$
Q=q+1,\quad N=N_q+\ell,
\quad d=A-x>0,\quad a=v-B>0,
\quad H=N-Q.
$$

Assume that at this state $X=QA-Nx\ge b$. Since $\Delta>0$, one has $D=NB-Qv<0$. Define

$$
E=-D=Qa-HB,\qquad V=d-X=Hx-(Q-1)d.
$$

From RES and $\ell\ge1$,

$$
H\ge1,\quad1\le E\le a-1,\quad1\le V\le d-b.
\tag{DR-BOX}
$$

Indeed, $E=a-\ell B+U_q\le a-c-1$, while $X=A-E_q-\ell x\le d-1$. Therefore

$$
(Q-1)/H<B/a<x/d\le Q/H.
\tag{DR-BRACKET}
$$

<a id="fr-A2.4.1"></a>

### Complete proof of the dual PREFIX

Suppose that for some $s<H$ there were a positive integer $k$ with $B/a\le k/s\le x/d$. Since $sx/d<Hx/d\le Q$, one has $k\le Q-1=q$.

Taking reciprocals and adding one gives

$$
A/x\le(k+s)/k\le v/B,
$$

contradicting the original successful PREFIX at denominator $k\le q$.

Thus, for $s=1,\ldots,H-1$, the dual crossing index

$$
K_s=\lceil sB/a\rceil=\lceil sx/d\rceil
$$

is defined, with dual residues

$$
E_s^*=K_sa-sB\in[1,a-1],
\quad V_s^*=sx-(K_s-1)d\in[1,d-1].
$$

For the terminal value $s=H$, set $K_H=Q$ and use $E,V$ from DR-BOX. This convention is also consistent at right-endpoint equality.

<a id="fr-A2.4.2"></a>

### Preservation of the shifted gap

For $s<H$, the corresponding original count pair is $(N_s,K_s)=(s+K_s,K_s)$. Its original $X$-coordinate is

$$
X_s=K_sd-sx=d-V_s^*\in[1,d-1].
$$

Since $K_s\le Q$, the inequality $X_s>0$ gives $N_s<K_sA/x$, while $X_s<d$ gives $N_s>(K_s-1)A/x+1$. Therefore $N_s$ is an integer count on the row-1 run between the original $(K_s-1)$-st successful firing and the $K_s$-th crossing.

If $K_s<Q$, that run lies in the already successful PREFIX. If $K_s=Q$, then $s<H$ gives $N_s<N$, so the state lies before the terminal point on the current final row-1 run. In either case the path actually passes through this state and continues with row 1.

When $K_s=1$, the “0-th successful firing” means the first row-1 run from the initial state. The inequalities $N_s>1$ and $N_s<N_1$ give the same correspondence directly, without assuming a nonexistent crossing.

Hence $X_s\ge b+1$, so

$$
V_s^*\le d-b-1\quad(s<H).
$$

Thus the assertion that the dual residues avoid the same early-exit strip is established by explicit correspondence with integer counts actually traversed by the path, not by formal analogy.

<a id="fr-A2.4.3"></a>

### Dual rank

Applying the same difference calculation as in [A2.3.2](#fr-A2.3.2) to the dual PREFIX gives injectivity and the anti-chain property. Hence

$$
H-1\le(a-1-E)+\max(d-b-1-V,0).
$$

If $V\le d-b-1$, this directly gives the desired bound; if $V=d-b$, the second term is zero. In either case,

$$
\boxed{H+E+V\le a+d-b.}
\tag{DR}
$$

No infinite descent or new actual row is assumed in this lemma. It counts explicitly specified states in the original finite prefix.

<a id="fr-A2.5"></a>

## Rule for weighted certificates

For every nonzero nonnegative integer row vector $\lambda$, if $v=\lambda C\ge0$ and $|v|_1\ge|\lambda|_1$, then

$$
|λ|_1m=v\cdot n>|v|_1m\ge|λ|_1m,
$$

which is impossible. We use the certificates below according to this rule.

For row counts $c=(r,s,t)$, the universal identity is

$$
(c+\mathbf1)C=(y_1+z_1-u_1,y_2+z_2-u_2,y_3+z_3-u_3).
\tag{MC}
$$

<a id="fr-A2.6"></a>

## A one-color path cannot terminate at a sink

Suppose only row 1 has fired, $N-1\ge1$ times. Then $u_1=Nx_1$, and the box condition gives $(N-1)x_1\le y_1-1$.

$$
N\le y_1-x_1+1,
\quad N(x_1+1)\le2y_1,
\quad y_1+z_1-Nx_1\ge N+b_1.
$$

The first inequality follows from $(x_1-1)(y_1-x_1-1)\ge0$.

For sink $\mathsf A$, take $\lambda=(N,1,0)$. Then $\lambda C=(y_1-u_1,z_2-u_2,Ny_3+z_3)\ge0$, and the third coefficient is at least $N+2>|\lambda|$.

For sink $\mathsf B$, take $\lambda=(N,0,1)$. Then $\lambda C=(z_1-u_1,Nz_2+y_2,y_3-u_3)\ge0$, and the second coefficient is at least $2N+1\ge|\lambda|$.

For sinks $\mathsf C,\mathsf D$, use MC with $\lambda=(N,1,1)$. The first coefficient is at least $N+b_1$, and the remaining two are at least $(z_2,y_3)$ or $(y_2,y_3)$, respectively. Thus $\lambda C\ge\lambda$ componentwise. Every case contradicts the weighted-certificate rule.

<a id="fr-A2.7"></a>

## Excluding all terminal states of a $\{1,2\}$ two-color path

Let $N=r+1,Q=s+1$, and set $X=Qy_1-Nx_1$, $Y=Nz_2-Qx_2-b_2$, $u_1=y_1-X,u_2=y_2-Y$.

There have been $q=Q-1$ successful crossings, so $Q\le x_1,Q\le y_2$. From the box condition and $q\le x_1-1$, we also have $N\le y_1$. For if $N\ge y_1+1$, then $u_1=Nx_1-qy_1\ge x_1+y_1$, contrary to the box condition.

Sink $\mathsf A$ would require $X\ge0,Y\ge-b_2$, but

$$
x_2X+y_1Y=-NΔ_3-y_1b_2<-y_1b_2
$$

which is impossible.

For sink $\mathsf D$, take $\lambda=(N,Q,1)$. By MC, $\lambda C=(z_1+X,z_2+Y,y_3+z_3-u_3)$. The $\mathsf D$-conditions together with $N\le y_1,Q\le y_2$ give $\lambda C\ge\lambda$ componentwise.

<a id="fr-A2.7.1"></a>

### The last firing is row 2

Immediately before the last firing we are at the last successful crossing $q=Q-1$, with $N=N_q,E=E_q,U=U_q,D_q=z_2-U$.

After firing, $u_1=E<x_1<y_1$ and $u_2=x_2+U>z_2$. At a sink, one must have $u_3\le y_3$, since otherwise row 1 would be positive. Thus the sink is $\mathsf B$.

For $\lambda=(N,q,1)$, all coefficients of $\lambda C$ are nonnegative, and the margin is

$$
|λC|-|λ|
=b_1+(y_1-N+D_q-E)+(y_2-q-1)+(y_3-u_3).
$$

By LR, $D_q-E\ge q-x_1+b_2+1$. Since $q<x_1$,
$N-q=\lceil q(y_1-x_1)/x_1\rceil\le y_1-x_1$. Hence the second bracket is at least $b_2+1$, and all other terms are nonnegative.

<a id="fr-A2.7.2"></a>

### The last firing is row 1, sink $\mathsf B$, $X\ge0$: the pre-crossing terminal case

Sink $\mathsf B$ means $X\ge-b_1,u_3\le y_3$. The subcase $X\ge0$ includes states before the crossing.

Apply the reciprocal-rank lemma [A2.4](#fr-A2.4) with $A=y_1,B=z_2,v=x_2,b=0,c=b_2$. Since $\ell\ge1$ row-1 firings follow the last successful crossing $q\ge1$, all hypotheses hold.

With $H=N-Q$, $a=x_2-z_2$, $d=y_1-x_1$, $E=-(Y+b_2)$, and $V=d-X$, we have $H+E+V\le a+d$.

For $\lambda=(N,Q-1,1)$,

$$
λC=(b_1+X,x_2+z_2+Y,y_3-u_3)\ge0.
$$

The second coefficient is nonnegative because the box condition $u_2\le x_2+y_2-1$ gives $x_2+z_2+Y\ge z_2+1$. The margin is

$$
|λC|-|λ|
=b_1+d+x_2+y_2-(H+E+V)-2Q+(y_3-u_3)
$$
$$
\ge b_1+z_2+y_2-2Q+(y_3-u_3)\ge b_1+b_2>0.
\tag{PRE-CROSS-PATCH}
$$

Thus both the pre-crossing cases $X>0$ and $X=0$ are excluded.

<a id="fr-A2.7.3"></a>

### The last firing is row 1, sink $\mathsf B$, $X<0$

Here $N=N_Q$ and $E=-X\in[1,x_1-1]$. Put $D=Y+b_2=Nz_2-Qx_2$. For the same $\lambda=(N,Q-1,1)$, the margin is

$$
(b_1-E)+(x_2-N+D)+(y_2-Q)+(y_3-u_3).
$$

The first, third, and fourth terms are nonnegative. If $D\ge0$, then $N\le x_2$, because $Q\le y_2<z_2$ and $N=\lceil Qy_1/x_1\rceil<Qx_2/z_2+1$, so the second term is also nonnegative.

If $D<0$, put $W=-D>0$. If some prior $U_j\le W$, then with $h=Q-j,k=N-N_j+1$,

$$
kx_1-hy_1=E-E_j+x_1>0,
\quad hx_2-kz_2=W-U_j\ge0,
$$

which is a PREFIX separator. Hence all prior $U_j>W$, and injectivity gives $Q+W\le y_2$.

Also $N-Q\le x_2-z_2$ because $Q<z_2$ and $y_1/x_1<x_2/z_2$. Therefore

$$
x_2-N\ge z_2-Q\ge y_2-Q\ge W.
$$

The second term is nonnegative as well. This is the required predecessor estimate.

<a id="fr-A2.7.4"></a>

### The last firing is row 1, sink $\mathsf C$

Since $Y\ge0$, one has $X<0$ and $N=N_Q$. Put $E=-X$ and $U=u_2=z_2-(Y+b_2)>0$. Apply ELR to all prior points.

If $U>y_2-1$, then $Q+E\le x_1$; otherwise $Q+E+U\le x_1+y_2-1$. In either case,
$Q\le x_1-E+Y=x_1+X+Y$.

For $\lambda=(N-1,Q,1)$,

$$
λC=(x_1+z_1+X,Y,z_3-u_3)\ge0.
$$

The sum of the first two coefficients is at least $z_1+Q\ge N+Q+b_1$. Hence $|\lambda C|\ge|\lambda|$. This exhausts the sink regions for the $\{1,2\}$-path.

<a id="fr-A2.8"></a>

## Excluding all terminal states of a $\{1,3\}$ two-color path

Let $N=r+1,R=t+1$, and set $X=Rz_1-Nx_1$, $Y=Ny_3-Rx_3$, $u_1=z_1-X,u_3=y_3-Y$.

With $q=R-1$ successful crossings, one has $q\le x_1-b_1-1$, $q\le y_3-1$, and $R\le y_3$.

The box condition also gives $N\le y_1$. If $N\ge y_1+1$, then

$$
u_1-(x_1+y_1-1)
\ge b_1(b_1+y_1-x_1+1)+1>0.
$$

Sink $\mathsf B$ would require $X\ge0,Y\ge0$, contradicting $x_3X+z_1Y=-N\Delta_2<0$.

For sink $\mathsf D$, take $\lambda=(N,1,R)$. By MC and $N\le y_1,R\le y_3$, one has $\lambda C\ge\lambda$ componentwise.

<a id="fr-A2.8.1"></a>

### The last firing is row 3

Immediately after the last successful crossing $q$, $u_1=E_q<x_1<y_1$ and $u_3=x_3+U_q>y_3$. If this is a sink, then $u_2\le z_2$, so it lies in $\mathsf A$.

For $\lambda=(N,1,q)$,

$$
λC=(y_1-E_q,z_2-u_2,y_3+z_3-U_q)\ge0.
$$

Using LR, $q+E_q+U_q\le x_1-b_1+y_3-1$, together with $N-q\le z_1-x_1$ and $q\le y_3-1$, the margin is at least $b_3+1>0$.

<a id="fr-A2.8.2"></a>

### The last firing is row 1, sink $\mathsf A$

Here $X\ge b_1,u_2\le z_2$. Apply the reciprocal-rank lemma [A2.4](#fr-A2.4) with $A=z_1,B=y_3,v=x_3,b=b_1,c=0$.

Set $H=N-R$, $d=z_1-x_1$, $a=x_3-y_3$, $E=-Y$, $V=d-X$, and $D_*=a+d-b_1-(H+E+V)\ge0$.

For $\lambda=(N,1,R-1)$,

$$
λC=(X-b_1,z_2-u_2,x_3+z_3+Y).
$$

The first two coordinates are nonnegative by the $\mathsf A$-conditions. For the third, using the residue $U_q$ at the last success $q=R-1$ and $N=N_q+\ell$, $\ell\ge1$,
$x_3+z_3+Y=z_3+(\ell+1)y_3-U_q>0$. Thus all coefficients are nonnegative, and the exact margin is

$$
|λC|-|λ|=D_*+(z_2-u_2)+b_3+2(y_3-R)\ge b_3>0.
$$

<a id="fr-A2.8.3"></a>

### The last firing is row 1, sink $\mathsf C$

Here $u_2\le y_2,Y\ge-b_3$. Since the preceding state lies in $F_1$, one has $X+x_1\ge b_1+1$. Put

$$
P=x_1+X-b_1-1\ge0,\quad B_*=b_3+Y\ge0,
\quad A_*=x_1-b_1-1,\quad C_*=y_3-1.
$$

Every successful index $b_1<i\le q$ satisfies $E_i>A_*-P$ or $U_i>C_*-B_*$.

If both failed, then with $h=R-i,k=N-N_i$,

$$
h z_1-kx_1=E_i+X\le0,
$$
$$
(k+1)y_3-hx_3=U_i+Y\le y_3-b_3-1,
$$

so $z_1/x_1\le k/h<x_3/y_3$, contradicting PREFIX for $1\le h\le q$.

Slot counting using injectivity gives $q-b_1\le P+B_*$ (trivial when $q\le b_1$). Thus $D_*=P+B_*-(q-b_1)\ge0$.

For $\lambda=(N-1,1,R)$, the coefficients are $(x_1+y_1+X,y_2-u_2,b_3+Y)$. The first is positive by the row-1 predecessor condition $X+x_1\ge b_1+1$, and the last two are nonnegative by the $\mathsf C$-conditions. Therefore

$$
|λC|-|λ|=(y_1-N)+(y_2-u_2)+D_*\ge0.
$$

This excludes every two-color sink.

<a id="fr-A2.9"></a>

## Excluding the first occurrence of the third color

The first firing is row 1. The first firing of a third color is therefore either $\{1,2\}\to3$ or $\{1,3\}\to2$.

If row 3 first appeared immediately after row 2, the first coordinate of the preceding state would be at least $y_1+z_1+1=2y_1+b_1+1$, whereas the box upper bound is $x_1+y_1-1$, contradicting START $x_1<y_1$. The same argument excludes row 2 immediately after row 3. Hence in either case the third color first appears immediately after row 1.

<a id="fr-A2.9.1"></a>

### $\{1,2\}\to3$

The source counts for the third color are $(N-1,Q-1,0)$. Substituting the preceding $F_1$-condition and the current $F_3$-condition gives

$$
1-x_1\le X\le-b_1-1,
\quad z_2+1-x_2\le Y\le-1,
\quad1\le u_3\le y_3-1.
$$

Thus $N=N_Q$ and $E=-X\in[1,x_1-1]$. All prior indices $1,\ldots,Q-1$ are successful.

Every prior $E_j>E$. Otherwise, with $h=Q-j,k=N-N_j$, one would have $kx_1-hy_1=E-E_j\ge0$. Meanwhile $D=Nz_2-Qx_2=Y+b_2\le b_2-1$ and $D_j=z_2-U_j\ge b_2+1$, so $kz_2-hx_2=D-D_j<0$, producing a PREFIX separator.

Hence $Q+E\le x_1$. Together with $N-Q\le y_1-x_1$, this gives $N+E\le y_1$.

Also $y_2+D\ge Q$. If $D\ge0$, this follows from $Q\le y_2$. If $D<0$, the same difference calculation as in [A2.7.3](#fr-A2.7.3) shows that all prior $U_j>-D$, hence $Q-D\le y_2$.

For $\lambda=(N,Q,1)$,

$$
λC=(z_1-E,y_2+D,y_3+z_3-u_3)\ge(N+b_1,Q,z_3+1)\geλ.
$$

This is a contradiction.

<a id="fr-A2.9.2"></a>

### $\{1,3\}\to2$

The source counts are $(N-1,0,R-1)$. The preceding $F_1$-condition and the current $F_2$-condition give

$$
b_1+1-x_1\le X\le b_1-1,
\quad1\le u_2\le y_2-1,
\quad y_3+1-x_3\le Y\le-b_3-1.
$$

Set $P=b_1-X\ge1$ and $W_*=-b_3-Y\ge1$. All prior indices $1,\ldots,R-1$ are successful.

Every prior $E_j>P$. Otherwise, with $h=R-j,k=N-N_j$, one has $D_1=hz_1-kx_1=E_j+X\le b_1$.

If $D_1\le0$, then $k/h\ge z_1/x_1$. On the other hand,
$(k+1)y_3-hx_3=U_j+Y\le y_3-b_3-2<y_3$, so $k/h<x_3/y_3$, contradicting PREFIX.

If $1\le D_1\le b_1$, the existence of a successful prefix gives $b_1\le x_1-2$, while $k=\lfloor hz_1/x_1\rfloor$ and $N_h=k+1$. Therefore $E_h=x_1-D_1\ge x_1-b_1$, directly contradicting the successful EBOX bound $E_h\le x_1-b_1-1$ at index $h<R$. This is the integral form of the early-exit strip.

Next, every prior $U_j>W_*$. Otherwise, the already-proved inequality $E_j>P$ gives $b_1+1\le D_1\le x_1-2$. With $k'=k+1$,

$$
k'x_1-hz_1>0,\quad hx_3-k'y_3=W_*-U_j+b_3>0,
$$

again producing a PREFIX separator.

By injectivity, $R+P\le x_1-b_1$ and $R+W_*\le y_3$. Since the preceding state is a row-1 source, $N\le\lceil Rz_1/x_1\rceil$. From $R<x_1$ and $z_1=x_1+d$, we get $N-R\le d$, hence $N+P\le y_1$.

For $\lambda=(N,1,R)$,

$$
λC=(z_1-P,y_2+z_2-u_2,y_3-W_*)\ge(N+b_1,z_2+1,R)\geλ,
$$

again a contradiction.

<a id="fr-A2.10"></a>

## Exhaustion and connection to the upstream argument

Suppose that a finite maximal in-box path terminates at a sink.

- If only row 1 occurs, [A2.6](#fr-A2.6) gives a contradiction.
- If exactly two colors occur, [A2.7](#fr-A2.7)–[A2.8](#fr-A2.8) give a contradiction.
- If all three colors occur, the first firing of the third color contradicts [A2.9](#fr-A2.9).

Therefore the endpoint of every maximal path admits a positive out-of-box firing.

This proves DPE, which applies directly to the matrix INPUT obtained from MINBOX with $k=1$.

<a id="fr-A2.10.1"></a>

### Final connection to the same actual $f_\varepsilon$

By [A1.2](#fr-A1.2), for the same semigroup and the same socle element under the assumption of three actual arms,

$$
f_\varepsilon=m+\sum_i(p_i-1)n_i,\qquad
q_i=f_\varepsilon-\lambda_i n_i\in PF(\Gamma),
\quad1\le p_i\le\lambda_i\le\alpha_i-1
$$

First consider color A, so $\alpha_i=a_i$ and $p=x$.

After a total of $t$ firings, write the state as $u=p-rC$, with $|r|_1=t$. Since $Cn=m\mathbf1$,

$$
\boxed{f_A=(t+1)m+\sum_i(u_i-1)n_i.}
\tag{SAME-F}
$$

At a positive state, every $u_i\ge1$, so this is a genuine factorization of the same $f_A$. The original $\Gamma,m,n_i,f_A$ have not changed.

The first positive out-of-box state $u^*$ supplied by DPE satisfies the same identity. Since it leaves $\mathcal B=\prod_i[1,a_i-1]$ while all coordinates remain positive, some $i$ satisfies $u_i^*\ge a_i$. Hence

$$
u_i^*-1\ge a_i-1\ge\lambda_i.
$$

Removing $\lambda_i n_i$ from this one final coefficient vector gives

$$
q_i=(t+1)m+(u_i^*-1-\lambda_i)n_i
+\sum_{j\ne i}(u_j^*-1)n_j\in\Gamma,
$$

contradicting the fact that $q_i$ is an actual pseudo-Frobenius gap. No semantic subtraction of a signed relation is used.

Color B is carried to color A by an odd generator permutation together with the complete simultaneous exchange of $a/b$ and A/B. The three actual pseudo-Frobenius elements and their arm bounds are exchanged at the same time, so the same conclusion holds.

Thus three actual arms of the same color cannot occur:

$$
\boxed{\text{THREE-ARM CLOSED}.}
$$

For either color, every actual row is either the corner $f_\varepsilon$ or an arm $f_\varepsilon-\lambda n_i$. Two distinct depths in the same direction contradict pseudo-Frobenius comparability. A corner cannot coexist with an arm of the same color for the same reason. Therefore, three rows of one color would have to consist of one arm in each of the three directions, and this has just been excluded. Hence, within the canonical six-arm classification,

$$
\boxed{\text{COLOR-CAP}\le2.}
$$

The chain MINBOX → DPE → SAME-F → THREE-ARM → COLOR-CAP requires no additional upstream lemma.

<a id="prop-B1"></a>

## Proposition B.1 (THREE-ARM / COLOR-CAP)

In the setting of the canonical six-arm classification, three actual arms of the same color do not exist. Moreover, for each color there are at most two actual corner/arm rows.

**Proof.** The first assertion is exactly THREE-ARM CLOSED, proved in [A1.1](#fr-A1.1)–[A2.10.1](#fr-A2.10.1). The second is the already-proved COLOR-CAP conclusion obtained at the end of [A2.10.1](#fr-A2.10.1) from incomparability and uniqueness of depth in a fixed direction. No new hypothesis or conclusion is introduced here.


<a id="app-C"></a>

# Appendix C　Positivity expansions for the root analysis

This appendix contains only the six coefficient polynomials intrinsic to the positivity decomposition for $\mathcal U$. Other positivity comparisons used in the main text are not duplicated here; the table below points to their authoritative locations. The domains $C=\alpha$ and $C>\alpha$ are to be read with the same scope separation as in the main text.

| Former duplicated node | Current authoritative location |
|---|---|
| `copy-C8.2.8` | Section 8 [C8.2.8](#fr-C8.2.8) |
| `copy-C8.2.9.1` | Section 8 [C8.2.9.1](#fr-C8.2.9.1) |
| `copy-C8.2.9.2` | Section 8 [C8.2.9.2](#fr-C8.2.9.2) |
| `copy-C8.2.11.2` | Section 8 [C8.2.11.2](#fr-C8.2.11.2) |
| `copy-C8.4.2` | Section 9 [C8.4.2](#fr-C8.4.2) |
| `copy-C8.4.3` | Section 9 [C8.4.3](#fr-C8.4.3) |
| `copy-C8.4.4` | Section 9 [C8.4.4](#fr-C8.4.4) |

<a id="fr-A3"></a>

## The six coefficient polynomials in the unit case

The following are the exact coefficients in POS-DECOMP. All are nonnegative, and in fact positive, for $t,z\ge1$, $\alpha,\eta>0$, and $r,w\ge0$.

$$
\begin{aligned}
X_\delta={}&\alpha(tz+z+1)\\
&+\eta(t^2z^2+t^2z+2tz^2+2tz+t+z^2+z)\\
&+r(tz^2+2tz+z^2+2z+1)\\
&+w(tz^2+tz+z^2+z),
\end{aligned}
$$

$$
\begin{aligned}
Y_\delta={}&\alpha(tz+z+1)\\
&+\eta(t^2z^2+t^2z+2tz^2+3tz+t+z^2+2z+1)\\
&+r(tz^2+2tz+z^2+3z+1)\\
&+w(tz^2+tz+z^2+2z),
\end{aligned}
$$

$$
\begin{aligned}
X_\beta={}&\alpha(t+1)\\
&+\eta(t^2z+t^2+2tz+t+z)\\
&+r(tz+2t+z+2)+w(tz+t+z+1),
\end{aligned}
$$

$$
\begin{aligned}
Y_\beta={}&\alpha(t+1)\\
&+\eta(t^2z+t^2+2tz+2t+z+1)\\
&+r(tz+2t+z+3)+w(tz+t+z+2),
\end{aligned}
$$

$$
Z_\delta=z[\alpha+\eta(t+1)z+r(z+1)+wz],
$$

$$
Z_\beta=\alpha+\eta((t+1)z-1)+r(z+1)+wz.
$$

To obtain POS-DECOMP, substitute $a=a_*$, $C=\alpha+t\eta+r$, and $b_k=\eta-\alpha+w$ into $\widehat m-\mathcal J$, collect the parts in $\delta,\beta$, and then substitute

$$
Q=(t+1)(a_j+g)+1+q'
$$

Expanding with respect to $a_j-1,g-1,q'$ gives the displayed identity. Expanding the explicit formulas in this appendix provides a direct check.

---


<a id="app-D"></a>

# Appendix D　Specification and reproducibility of the static polynomial certificates

The polynomial identities used in the main text are stored as finite complete coefficient tables. These are not outputs of a finite scan of numerical semigroups.

<a id="fr-A4.1"></a>

## The $i$-fit for linear $\mathcal D$

For $\Phi(a)=\widehat m-\mathcal J$ and $a_*=fB+r$ defined in [C8.4.5](#fr-C8.4.5)–[C8.4.6](#fr-C8.4.6),

$$
\Phi(a_*)=35+\sum_{\gamma\ne0}c_\gamma\mathbf y^\gamma,
\quad c_\gamma\ge0,
$$
$$
\mathbf y=(f-1,r,\delta-1,\beta-1,g-1,\upsilon,
\alpha-1,w,\theta-1,\epsilon,k-1,a_j-1,b_k-1).
$$

All variables are nonnegative. All 715 monomials are contained in the [static coefficient table](supplement/APPENDICES/LINEAR/I_FIT_POSITIVE_COEFFICIENTS.json). Each entry in `terms` has a coefficient and an exponent vector, with exponents listed in the order specified by `variables`. The JSON names `f,delta,beta,g,alpha,theta,k,a_j,b_k` represent the corresponding shifted variables with one subtracted. The variables `r,u,w,eps` are unshifted, with `u=\upsilon` and `eps=\epsilon`. Summing all listed monomials reproduces the defining expression in the main text.

<a id="fr-A4.2"></a>

## The terminal $i$-fit in the Euclidean argument

For $\mathcal P=\Phi(B+\nu A)$ from [E8.4](#fr-E8.4),

$$
\mathcal P=63+\sum_{\gamma\ne0}c_\gamma\mathbf y^\gamma,
\quad c_\gamma\ge0.
$$

The shifts of all variables are defined in [E8.4.3](#fr-E8.4.3), and the variable order is

```text
p0, q0, s0, t0, r0, delta0, beta0, aj0, g0, alpha0, bk0, nu0, h0, z0, x0, w0
```

All 3,234 monomials, total degree 7, and constant term 63 are stored in the [static coefficient table](supplement/APPENDICES/EUCLIDEAN/TERMINAL_POSITIVITY_COEFFICIENTS.json). Since every nonconstant coefficient is also nonnegative, the positivity conclusion follows from this explicit finite polynomial identity.

<a id="fr-A4.3"></a>

## Original and editorial notation

| Mathematical manuscript | Original certificate / code | Meaning |
|---|---|---|
| H_p | H | packet $k$-source coefficient $T+w$ |
| 𝒟_p | D | $\theta\chi-EH_p$ |
| 𝒨 | computed as `E+chi` | positive-integer descent measure |
| υ | u | linear-first residual |

The bytes of the static tables and the mathematical computations performed by the verifiers are unchanged from the adopted source. Only an obsolete `OPEN` status line at the end of the linear verifier was replaced there by a neutral description of the scope of the check. The [linear verifier](supplement/APPENDICES/LINEAR/verify_D_linear.py) and the [Euclidean verifier](supplement/APPENDICES/EUCLIDEAN/verify_euclidean_closure.py) expand their respective defining expressions and compare every coefficient with the static tables. In ordinary use they read the existing tables and do not regenerate them. The following commands are run from the root of the manuscript package:

```bash
python3 supplement/APPENDICES/LINEAR/verify_D_linear.py
python3 supplement/APPENDICES/EUCLIDEAN/verify_euclidean_closure.py
```

Python 3 and SymPy are required. Successful verification is an auxiliary consistency check. The actuality statements, scope conditions, choice of the first point, parameter signs, and proof of termination are established in the manuscript itself.

<a id="certificate-definitions"></a>

## The two defining expressions and evaluation procedures

For the first table, use the notation of [C8.4.5](#fr-C8.4.5)–[C8.4.6](#fr-C8.4.6):

$$
B=k(r+\delta)+(r+\beta),\quad a_*=fB+r,\quad
d=a+k(r+\delta),\quad S=kQ+g+\upsilon
$$

and substitute the formulas for $a_i,b_i,\rho_j,\rho_k$ from the same subsection into

$$
\Phi(a)=-d(\rho_j\rho_k-a_jb_k)
 +S(a_i\rho_k+b_ib_k)+C(b_i\rho_j+a_ia_j)
 -(a_i\rho_k+b_ib_k)
$$

Then set $a=a_*$, $Q=f(a_j+g+\upsilon)+\theta$, $C=\alpha+f\chi+w$, and $\chi=b_k+\alpha+1+\epsilon$. This is the defining polynomial represented by the 715-term table, and its constant term is 35. The nonnegative parameter range used in the proof is stated in [C8.4.6](#fr-C8.4.6).

For the second table, use the definitions from [E8.4.2](#fr-E8.4.2)–[E8.4.3](#fr-E8.4.3) and evaluate

$$
\Phi(P)=(EA+\theta B)\rho_k-a_j(\chi A+H_pB)
 -(\theta\chi-EH_p)(P-\delta)
 -[(P-\delta)\rho_j+(P-\beta)a_j]
$$

at $P=B+\nu A$. The quantities $A,B$ are determined from the source matrix, with $\rho_j=LE+M\theta-a_j$ and $\rho_k=L\chi+MH_p-b_k$. At a terminal state, substitute

$$
\theta=h+z,\quad E=\nu(h+z)+R-h,\quad
H_p=T+w,\quad\chi=\nu(T+w)-T+1+x
$$

Expanding this expression in the following 16 variables yields the table of 3,234 terms, total degree 7, and constant term 63. The determinant-one identity is used when identifying the expression with the actual formula for $m$, but no additional determinant constraint is needed on the nonnegative-variable domain of the expanded polynomial.

Both evaluation points are algebraic thresholds. Neither is assumed itself to satisfy the pseudo-Frobenius or first-point conditions of an actual semigroup; the lower bounds for the actual parameters are obtained by the monotonicity and multiplicity comparisons in the main text.

<a id="linear-shifts"></a>

## The 13 variables in the first certificate

| JSON key | Corresponding nonnegative variable |
|---|---|
| `f` | $f-1$ |
| `r` | $r$ |
| `delta` | $\delta-1$ |
| `beta` | $\beta-1$ |
| `g` | $g-1$ |
| `u` | $\upsilon$ |
| `alpha` | $\alpha-1$ |
| `w` | $w$ |
| `theta` | $\theta-1$ |
| `eps` | $\epsilon$ |
| `k` | $k-1$ |
| `a_j` | $a_j-1$ |
| `b_k` | $b_k-1$ |

<a id="euclidean-shifts"></a>

## The 16 variables in the second certificate

| JSON key | Corresponding nonnegative variable |
|---|---|
| `p0` | $p-s-1$ |
| `q0` | $q-t$ |
| `s0` | $s-1$ |
| `t0` | $t-1$ |
| `r0` | $r$ |
| `delta0` | $\delta-1$ |
| `beta0` | $\beta-1$ |
| `aj0` | $a_j-1$ |
| `g0` | $g-1$ |
| `alpha0` | $\alpha-1$ |
| `bk0` | $b_k-1$ |
| `nu0` | $\nu-2$ |
| `h0` | $h-1$ |
| `z0` | $z$ |
| `x0` | $x$ |
| `w0` | $w$ |

All exponent vectors are read in the order given by `variables` in the JSON file. The key `u` in the first table is the same residual $\upsilon$ used in the manuscript; `p0` in the second table means $p-s-1$, and `q0` means $q-t$, not the original variables themselves. Each `terms` entry specifies one monomial through its `coefficient` and `exponents` fields.

<a id="reproducibility"></a>

## Required proof data and ordinary verification

The complete coefficient tables and verifiers are included with the manuscript under `supplement/APPENDICES/LINEAR/` and `supplement/APPENDICES/EUCLIDEAN/`. Their original bytes are retained. In ordinary verification, each table is read and compared coefficient-by-coefficient with an independently expanded defining expression. The certificate-writing option is not used. Since the verifiers regenerate result JSON files in the same supplementary directories, preservation of a distribution master should be checked on a working copy of the package. From that working-copy root, run

```bash
python3 supplement/APPENDICES/LINEAR/verify_D_linear.py
python3 supplement/APPENDICES/EUCLIDEAN/verify_euclidean_closure.py
```

The Python and SymPy versions, the results of the present run, and SHA-256 hashes of the checked files are recorded in `ENGLISH_REGRESSION_REPORT.md`. Logically, the proof uses the finite identities and their complete coefficient tables specified here; a program's success message is not taken as an axiom. Computer assistance is used for the practical coefficientwise verification of the large expansions. The scope conditions, nonnegative representations, existence of the first point, and termination of the descent are proved in the manuscript. No unverified attribution concerning the discovery process is made.

---



# References

<a id="ref-MS21"></a>

**MS21**　Moscariello, Alessio and Strazzanti, Francesco. [Nearly Gorenstein vs Almost Gorenstein Affine Monomial Curves](https://arxiv.org/pdf/2003.05391). 2021. Preprint: arXiv:2003.05391v1, Question 4.4.

<a id="ref-MoscarielloSammartano"></a>

**MoscarielloSammartano**　Moscariello, Alessio and Sammartano, Alessio. [Open problems on relations of numerical semigroups](https://arxiv.org/html/2406.00790v2). 2026. arXiv:2406.00790v2, Problem 21.

<a id="ref-Herzog1970"></a>

**Herzog1970**　Herzog, J.. [Generators and relations of abelian semigroups and semigroup rings](https://doi.org/10.1007/BF01273309). 1970. .

<a id="ref-Delorme1976"></a>

**Delorme1976**　Delorme, C.. [Sous-monoïdes d'intersection complète de N](https://www.numdam.org/articles/10.24033/asens.1307/). 1976. .

<a id="ref-GarciaMartin2020"></a>

**GarciaMartin2020**　García-Sánchez, P. A. and Martín Cruz, H.. [Numerical semigroups with embedding dimension three and minimal catenary degree](https://math.colgate.edu/~integers/u81/u81.pdf). 2020. Section 3.2, Theorem 6.

<a id="ref-Nari2011"></a>

**Nari2011**　Nari, H. and Numata, T. and Watanabe, K.-i.. [Genus of numerical semigroups generated by three elements](https://arxiv.org/abs/1104.3600v1). 2011. arXiv:1104.3600v1, Sections 1--2, Propositions 2.1--2.2.

<a id="ref-White1964"></a>

**White1964**　White, G. K.. [Lattice Tetrahedra](https://doi.org/10.4153/CJM-1964-040-2). 1964. .

<a id="ref-Khan2016"></a>

**Khan2016**　Khan, M. R. and Rogers, K. M.. [An Exposition of White's Characterization of Empty Lattice Tetrahedra](https://arxiv.org/abs/1610.01981v1). 2016. arXiv:1610.01981v1, Section 1, Theorems 3--4.

<a id="ref-Branco2021"></a>

**Branco2021**　Branco, M. B. and Faria, M. C. and Rosales, J. C.. [Positioned numerical semigroups](https://www.nisc.com/products/abstracts/32832/journals/positioned-numerical-semigroups). 2021. .

<a id="ref-Rahimi2020"></a>

**Rahimi2020**　Rahimi, M.. [Rings with Canonical Reductions](https://arxiv.org/abs/1712.00755v3). 2020. Preprint: arXiv:1712.00755v3.

