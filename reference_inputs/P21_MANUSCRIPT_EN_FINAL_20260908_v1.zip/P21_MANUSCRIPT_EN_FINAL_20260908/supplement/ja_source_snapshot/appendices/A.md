# 対称tailの補助計算と全分岐 {#app-A}

## elementary two-generator facts {#fr-S3.1}

\(T=\langle u,v\rangle\)、\(\gcd(u,v)=1\)、\(u,v\ge2\)とする。任意の整数は一意に
\[
a u+b v,\qquad a\in\mathbb Z,\quad0\le b<u
\]
と書け、T所属と\(a\ge0\)が同値。二つの整数係数表示の差は\((kv,-ku)\)である。このことから次が従う。

* \(F_T=uv-u-v\)、かつ任意の整数\(t\)について\(t\notin T\iff F_T-t\in T\)。実際、上の表示の補元は\((-a-1)u+(u-b-1)v\)。
* \(P<v,Q<u\)かつ\(Pu+Qv\in T\)なら\(P,Q\ge0\)。どちらかの負座標を修復するprimitive shiftは、他方を負にする。
* \(P,Q>0\)なら\(uv-Pu-Qv\notin T\)。所属すれば\(uv\)のu、v両係数が正の表示を生むが、\(Xu+Yv=uv\)の整数解は\(X=v(1-k),Y=uk\)のみ。
* \(0\le P<v,0\le Q<u\)なら\(Pu+Qv-uv\notin T\)。v-normal formのu係数は\(P-v<0\)。

また\(0<A<v,0<B<u\)なら
\[
(Au+T)\cap(Bv+T)=(Au+Bv+T)\cup(uv+T).
\tag{2GI}
\]
実際、\(X=(A+p)u+qv=ru+(B+s)v\)、\(p,q,r,s\ge0\)とする。表示差のprimitive shiftが0なら両係数にA、Bを含む。正なら最初のu係数がv以上、負なら第二表示のv係数がu以上なので\(X\in uv+T\)。逆包含は\(A<v,B<u\)から直ちに従う。

## Branch I：walkとfour-hit necessity {#fr-S3.6}

\(\theta=L=u+v+t_0\)、\(t_0=p_0u+q_0v\in T\)とする。\(k_0=0\)なら\(\mu=L\in T\)となるため\(k_0=1\)。従って
\[
\kappa=d-e,\quad 1\le\kappa\le d-1-s,\quad
m=dL-\kappa w,\quad E=w-L>0.
\]
最後の正値は\(m<w\)、\(\kappa+1\le d-s<d\)から従う。
\[
c_n=\left\lceil\frac{n\kappa-s}{d}\right\rceil,\quad
j_n=s-n\kappa+dc_n,\quad
\tau_n=\rho+nL-c_nw.
\]
FSは\(\tau_n\in T\ (n\ge1)\)と同値。隣接stepはLまたはL−w。returnとは\(j_n=0\)、すなわち\(n\kappa\equiv s\pmod d\)である。

\(a_x-y+nm\)のT-coordinateは\(\tau_n+Au-v\)。Tに属する\(\tau\)について
\[
\tau+Au-v\notin T\iff\tau\in U_x:=\{ju:0\le j<D\}.
\]
これは[S3.1](#fr-S3.1)のnormal formを用いて直接確認できる。\(a_x-y\in H\)である一方、actual PF性から\(q_x+y\in\Gamma\)、従ってGAP-Kから\(a_x-y\notin K\)。ゆえにn≥1でUxへのhitが必要。双対に
\[
U_y=\{jv:0\le j<C\}
\]
にもhitが必要。

同様に\(a_x-w+nm\)はreturnでないnでは自動的にHに属し、returnでだけT-coordinateが\(\tau_n+A'u-\beta v\)となる。これがT-gapになる条件は、同じ\(\tau_n\)が
\[
Z_x=\{pu+qv:0\le p<D',\ 0\le q<\beta\}
\]
に属することである。\(a_x-w\in H\)と\(q_x+w\in\Gamma\)から、このreturn hitが必要。双対にreturn上で
\[
Z_y=\{pu+qv:0\le p<\alpha,\ 0\le q<C'\}
\]
にもhitが必要。四つのhitはいずれも同じactual PF対と同じwalkから生じる。

## Branch I：四つのhitは両立しない {#fr-S3.7}

以下\(a=A'>0,b=B'>0\)。\(\rho=uv-w-au-bv\)。return index Nでは\(c_{N-1}=c_N\)、\(c_{N+1}=c_N+1\)。従ってN>1なら
\[
\tau_{N-1}=\tau_N-L\in T.
\]
\(\tau_N=pu+qv\in Z_x\)またはZyの係数は\(p<v,q<u\)なので、[S3.1](#fr-S3.1)より
\[
p\ge p_0+1,\qquad q\ge q_0+1.
\tag{LOWER}
\]
N=1にはこの制約を適用しない。

Zx、Zyの両hitがN>1なら、\(R=\alpha-p_0-1>0\)、\(Q=\beta-q_0-1>0\)を得る。しかし\(c_1\in\{0,1\}\)であり、
\[
\tau_1=uv-(a+R)u-(b+Q)v-c_1w\notin T
\]
となる（wの正係数表示を入れて[S3.1](#fr-S3.1)を適用）。従って一方のreturn hitはN=1、特に\(\kappa=s\)。base \(\tau_1\)はX-only、Y-only、XYの三つに分かれる。

一般にlater Ux-hit \(\tau_N=ju\)、\(j<D\)への到着はcarryでなければならない。no-carryなら\(\tau_{N-1}=(j-p_0-1)u-(q_0+1)v\notin T\)。Uyも双対。

**X-only。** Zy-hitはlaterなのでLOWERから\(p_0\le\alpha-2,q_0\le u-b-2\)。\(R=\alpha-p_0-1>0\)、\(S=q_0+1-\beta\)とおくと
\[
w-L=Ru-Sv,\qquad\tau_1=(v-a-R)u+(S-b)v.
\]
両係数がfundamental strip上端より小さいのでFSから\(S\ge b\)。また\(1\le R\le\alpha-1,1\le S<u\)。baseがUxに属すにはS=bが必要だが、そのu係数は\(v-a-R\ge D+1\)で大きすぎる。later Ux-hitならcarry predecessorが\((j+R)u-Sv\)、しかし\(j+R\le v-a-2<v\)、\(0<S<u\)なのでT-gap。従ってUx-hitはない。

**Y-only。** 完全にu↔v、A↔B、α↔β、a↔bを交換した同じ議論でUy-hitはない。

**XY。** 両rectangleの座標表示は\(p<v,q<u\)の範囲で一意なので、
\[
\tau_1=pu+qv,\quad 0\le p<\alpha,\quad 0\le q<\beta.
\]
\[
E=uv-(a+p)u-(b+q)v,\qquad
\tau_2=(2p+a)u+(2q+b)v-uv.
\]
Ux-hitがbaseならp≤D−1でもあるため\(2p+a\le(\alpha-1)+(D-1)+a=v-2\)。later \(ju\)、j<Dであればcarry predecessorは
\[
ju+E=uv-(a+p-j)u-(b+q)v.
\]
[S3.1](#fr-S3.1)のinterior-gap判定から\(j\ge a+p\)。これとp≤α−1から再び\(2p+a<v\)。双対にUy-hitは\(2q+b<u\)を強制する。従って[S3.1](#fr-S3.1)最後のgap判定から\(\tau_2\notin T\)、FSに反する。

三場合とも四つのhitが両立しない。Branch Iは排除された。

## Branch II、k0=1：D-row dropまたはBranch I {#fr-S3.8}

\(\theta=\rho+u+v+t_0\)、\(t_0\in T\)。k0=1なら\(e\ge s+1\)、\(\kappa=d-e>0\)、
\[
\mu=\theta-w,\qquad m=d\theta-\kappa w,\qquad
\kappa w<d\theta<(\kappa+1)w.
\]
\(g=w-u-v-t_0=w-\theta+\rho\)とおく。ここでg>0を明記する：r>0から\(\rho>-sw/d\)、m<wから\(\theta<(\kappa+1)w/d\)。従って
\[
\theta-\rho<\frac{\kappa+s+1}{d}w\le w.
\tag{K1-g}
\]

二つのD-rowのbackward pointは
\[
a'_x-m=\kappa w+d(A'u+g),\qquad
a'_y-m=\kappa w+d(B'v+g).
\]
一方がHなら、それはKに属し、CANから対応する\(c'-m\in\Gamma\)。これはALL-APに反する。従って両者H-gap、すなわち\(A'u+g,B'v+g\notin T\)。T対称性から
\[
F_T-g\in(A'u+T)\cap(B'v+T).
\]
2GIを適用する。g>0なので\(F_T-g<uv\)、uv+T成分は不可能。従って
\[
F_T-g-A'u-B'v=\rho+t_0=\theta-u-v\in T.
\]
これは既に排除したBranch I。よってk0=1も排除される。

## Branch II、k0=0,e=0 {#fr-S3.9}

この場合\(\theta=\mu\notin T\)、\(m=d\theta\)。multiplicityから\(0<\theta<\min(u,v)\)。\(c_1=\lfloor(s+e)/d\rfloor=0\)なので、最初のstable coordinateは
\[
\tau_1=\rho+\theta=2\theta-u-v-t_0<0.
\]
FSに反する。

## Branch II、k0=0,e>0：cross-core exclusion {#fr-S3.10}

\(t_0=pu+qv\)とする。\(\theta=\rho+u+v+t_0\notin T\)より\(p\le A-2,q\le B-2\)。従って
\[
P=A-1-p>0,\quad R=B-1-q>0,\quad Q=u-R,\quad S=v-P,
\]
\[
\theta=-Pu+Qv=Su-Rv<0.
\tag{K0}
\]
最後の不等式は\(m=ew+d\theta<w\)、e≥1から従う。\(P\le A-1,R\le B-1\)、\(0<Q<u,0<S<v\)。

\(k=d-s\)、\(c_n=\lfloor(s+ne)/d\rfloor\)、\(\tau_n=\rho+n\theta+c_nw\in T\)。c1=0なら\(\rho+\theta<0\)なので\(e\ge k\)。\(L_0=u+v+t_0\)とすると\(\tau_1=2\theta+w-L_0\ge0\)。\(h_0=-\theta>0\)とおけば\(2h_0\le w-L_0<w\)。これと\(m<w\)から
\[
(e-1)w<dh_0<dw/2,\qquad 2e\le d+1.
\tag{PHASE}
\]

\(\lambda_n=\lceil ne/d\rceil\)、\(\varepsilon_n=\lambda_n-c_n\in\{0,1\}\)。\(c_y-nm\)のH-normal formのT-coordinateをYnとすると、直接
\[
Y_n+\tau_n=Du-\varepsilon_n w.
\tag{COMP}
\]
ALL-APよりすべてn≥1で\(c_y-nm\notin H\)、従って\(Y_n\notin T\)。

一方\(a_x-y+nm\)のT-coordinateは\(\tau_n+Au-v\)。もしこれがT-gapなら、[S3.6](#fr-S3.6)のtranslation判定から\(\tau_n=ju\)、\(0\le j<D\)。

* εn=0ならCOMPから\(Y_n=(D-j)u\in T\)、矛盾。
* εn=1とする。\(ne=qd+r\)、\(0\le r<d\)と書くと\(1\le r<k\)。e≥kなのでn≥2。また
  \[
  (n-1)e=(q-1)d+(d+r-e),\quad d+r-e\ge k
  \]
  がPHASEから従う（\(d+r-e-k\ge d+1-e-k\ge d+1-2e\ge0\)）。従って\(c_{n-1}=c_n=q\)。その前stable点は
  \[
  \tau_{n-1}=\tau_n-\theta=(j+P)u-Qv.
  \]
  しかし\(j+P\le D-1+A-1=v-2\)、\(0<Q<u\)なのでT-gap、FSに反する。

よって全n≥0で\(a_x-y+nm\in H\)、すなわち\(a_x-y\in K\)。GAP-Kから\(q_x+y\notin\Gamma\)。actual PF性の\(q_x+y\in\Gamma\)と矛盾する。

これでBranch IIのk0/e全場合が排除された。RAW4すべてがApéryに残ることはできず、TYPE-BRIDGEにより
\[
\boxed{t(\Gamma)\le4}.
\]
