# Root解析の正値展開 {#app-C}

本付録は \(\mathcal U\) の正値分解に現れる六つの係数多項式という固有内容だけを収録する。本文で使用したその他の正値比較は、重複掲載せず下表の正本箇所を参照する。\(C=\alpha\) と \(C>\alpha\) の適用域は本文の scope のまま分けて読む。

| 旧再掲ノード | 現在の正本箇所 |
|---|---|
| `copy-C8.2.8` | 第8節 [C8.2.8](#fr-C8.2.8) |
| `copy-C8.2.9.1` | 第8節 [C8.2.9.1](#fr-C8.2.9.1) |
| `copy-C8.2.9.2` | 第8節 [C8.2.9.2](#fr-C8.2.9.2) |
| `copy-C8.2.11.2` | 第8節 [C8.2.11.2](#fr-C8.2.11.2) |
| `copy-C8.4.2` | 第9節 [C8.4.2](#fr-C8.4.2) |
| `copy-C8.4.3` | 第9節 [C8.4.3](#fr-C8.4.3) |
| `copy-C8.4.4` | 第9節 [C8.4.4](#fr-C8.4.4) |

## Unit caseの六つの係数多項式 {#fr-A3}

以下は POS-DECOMP の exact coefficients。全て \(t,z\ge1\)、\(\alpha,\eta>0\)、\(r,w\ge0\) で非負、実際には正である。

\[
\begin{aligned}
X_\delta={}&\alpha(tz+z+1)\\
&+\eta(t^2z^2+t^2z+2tz^2+2tz+t+z^2+z)\\
&+r(tz^2+2tz+z^2+2z+1)\\
&+w(tz^2+tz+z^2+z),
\end{aligned}
\]

\[
\begin{aligned}
Y_\delta={}&\alpha(tz+z+1)\\
&+\eta(t^2z^2+t^2z+2tz^2+3tz+t+z^2+2z+1)\\
&+r(tz^2+2tz+z^2+3z+1)\\
&+w(tz^2+tz+z^2+2z),
\end{aligned}
\]

\[
\begin{aligned}
X_\beta={}&\alpha(t+1)\\
&+\eta(t^2z+t^2+2tz+t+z)\\
&+r(tz+2t+z+2)+w(tz+t+z+1),
\end{aligned}
\]

\[
\begin{aligned}
Y_\beta={}&\alpha(t+1)\\
&+\eta(t^2z+t^2+2tz+2t+z+1)\\
&+r(tz+2t+z+3)+w(tz+t+z+2),
\end{aligned}
\]

\[
Z_\delta=z[\alpha+\eta(t+1)z+r(z+1)+wz],
\]

\[
Z_\beta=\alpha+\eta((t+1)z-1)+r(z+1)+wz.
\]

POS-DECOMP を得るには、\(a=a_*\)、\(C=\alpha+t\eta+r\)、\(b_k=\eta-\alpha+w\) を \(\widehat m-\mathcal J\) に代入し、\(\delta,\beta\) を取り出し、さらに

\[
Q=(t+1)(a_j+g)+1+q'
\]

を代入して \(a_j-1,g-1,q'\) ごとに展開すればよい。本付録の明示式を展開すればこの恒等式を直接照合できる。

---
