# 静的多項式証明書の仕様と再現性 {#app-D}

本文の多項式恒等式を有限個の全係数として保存する。これらは半群の有限走査結果ではない。

## linear Dのi-fit {#fr-A4.1}

[C8.4.5](#fr-C8.4.5)–[C8.4.6](#fr-C8.4.6)で定義した \(\Phi(a)=\widehat m-\mathcal J\)、\(a_*=fB+r\) に対し、
\[
\Phi(a_*)=35+\sum_{\gamma\ne0}c_\gamma\mathbf y^\gamma,
\quad c_\gamma\ge0,
\]
\[
\mathbf y=(f-1,r,\delta-1,\beta-1,g-1,\upsilon,
\alpha-1,w,\theta-1,\epsilon,k-1,a_j-1,b_k-1).
\]
全変数は非負である。全715単項式は
[静的係数表](supplement/APPENDICES/LINEAR/I_FIT_POSITIVE_COEFFICIENTS.json)に含まれる。
JSONの各terms行はcoefficientとexponentsを持ち、variablesの順に指数を対応させる。
JSONの名前f,delta,beta,g,alpha,theta,k,a_j,b_kはそれぞれ1を引いた変数を表す。
r,u,w,epsは未shiftで、u=υ、eps=ε。全行の単項式を足すと本文の定義式へ一致する。

## Euclidean終端のi-fit {#fr-A4.2}

[E8.4](#fr-E8.4)の \(\mathcal P=\Phi(B+\nu A)\) は
\[
\mathcal P=63+\sum_{\gamma\ne0}c_\gamma\mathbf y^\gamma,
\quad c_\gamma\ge0.
\]
全変数のshiftを[E8.4.3](#fr-E8.4.3)に定義しており、変数順は

```text
p0, q0, s0, t0, r0, delta0, beta0, aj0, g0, alpha0, bk0, nu0, h0, z0, x0, w0
```

全3,234単項式、総次数7、定数63を
[静的係数表](supplement/APPENDICES/EUCLIDEAN/TERMINAL_POSITIVITY_COEFFICIENTS.json)に保存する。
定数以外も全て非負であるため、正値結論はこの明示的な有限多項式恒等式から従う。

## 元記号と編集記号 {#fr-A4.3}

| 数学本文 | 元certificate／code | 意味 |
|---|---|---|
| H_p | H | packetのk-source係数T+w |
| 𝒟_p | D | θχ−EH_p |
| 𝒨 | E+chiで計算 | 正整数下降測度 |
| υ | u | linear-first残余 |

静的表のbytesとverifierの数学的計算は採用sourceから変更していない。linear verifierの末尾にあった旧時点のOPEN表示だけを、検算の範囲を示す中立的な説明へ更新した。
[linear verifier](supplement/APPENDICES/LINEAR/verify_D_linear.py)、[Euclidean verifier](supplement/APPENDICES/EUCLIDEAN/verify_euclidean_closure.py)は
それぞれの定義式を展開して全係数表と一致することを確認する。
通常実行は既存の静的表を読み、表を新たに作成しない。以下のコマンドは本原稿パッケージのルートを作業ディレクトリとして実行する。

```bash
python3 supplement/APPENDICES/LINEAR/verify_D_linear.py
python3 supplement/APPENDICES/EUCLIDEAN/verify_euclidean_closure.py
```

Python 3とSymPyが必要。検算成功は補助的な整合性確認であり、
actuality、scope、first-point選択、全parameterの符号、停止の証明は本文で与える。


## 二つの定義式と評価手順 {#certificate-definitions}

第一の表では[C8.4.5](#fr-C8.4.5)–[C8.4.6](#fr-C8.4.6)の記号を使い、
\[
B=k(r+\delta)+(r+\beta),\quad a_*=fB+r,\quad
d=a+k(r+\delta),\quad S=kQ+g+\upsilon
\]
および同節の \(a_i,b_i,\rho_j,\rho_k\) の式を
\[
\Phi(a)=-d(\rho_j\rho_k-a_jb_k)
 +S(a_i\rho_k+b_ib_k)+C(b_i\rho_j+a_ia_j)
 -(a_i\rho_k+b_ib_k)
\]
へ代入する。さらに \(a=a_*\)、\(Q=f(a_j+g+\upsilon)+\theta\)、\(C=\alpha+f\chi+w\)、\(\chi=b_k+\alpha+1+\epsilon\) とする。これが715項の表で表す多項式の定義であり、定数は35である。適用時の非負範囲は[C8.4.6](#fr-C8.4.6)にある。

第二の表では[E8.4.2](#fr-E8.4.2)–[E8.4.3](#fr-E8.4.3)の定義を使い、
\[
\Phi(P)=(EA+\theta B)\rho_k-a_j(\chi A+H_pB)
 -(\theta\chi-EH_p)(P-\delta)
 -[(P-\delta)\rho_j+(P-\beta)a_j]
\]
を \(P=B+\nu A\) で評価する。\(A,B\) はsource matrixから定め、\(\rho_j=LE+M\theta-a_j\)、\(\rho_k=L\chi+MH_p-b_k\) を使う。終端の代入は
\[
\theta=h+z,\quad E=\nu(h+z)+R-h,\quad
H_p=T+w,\quad\chi=\nu(T+w)-T+1+x
\]
である。これを次の16変数で展開したものが3,234項・総次数7・定数63の表である。実際の \(m\) の式へ同定するときは行列式1を用いるが、展開した多項式の非負変数域にはその等式を追加する必要はない。

両方の評価点は代数的な閾値である。その点自身に半群のPF条件や第一点条件を要求せず、本文で示した単調性とmultiplicityの比較によって実際のパラメータの下界を得る。

## 第一証明書の13変数 {#linear-shifts}

| JSON key | 対応する非負変数 |
|---|---|
| `f` | \(f-1\) |
| `r` | \(r\) |
| `delta` | \(\delta-1\) |
| `beta` | \(\beta-1\) |
| `g` | \(g-1\) |
| `u` | \(\upsilon\) |
| `alpha` | \(\alpha-1\) |
| `w` | \(w\) |
| `theta` | \(\theta-1\) |
| `eps` | \(\epsilon\) |
| `k` | \(k-1\) |
| `a_j` | \(a_j-1\) |
| `b_k` | \(b_k-1\) |

## 第二証明書の16変数 {#euclidean-shifts}

| JSON key | 対応する非負変数 |
|---|---|
| `p0` | \(p-s-1\) |
| `q0` | \(q-t\) |
| `s0` | \(s-1\) |
| `t0` | \(t-1\) |
| `r0` | \(r\) |
| `delta0` | \(\delta-1\) |
| `beta0` | \(\beta-1\) |
| `aj0` | \(a_j-1\) |
| `g0` | \(g-1\) |
| `alpha0` | \(\alpha-1\) |
| `bk0` | \(b_k-1\) |
| `nu0` | \(\nu-2\) |
| `h0` | \(h-1\) |
| `z0` | \(z\) |
| `x0` | \(x\) |
| `w0` | \(w\) |

すべての指数はJSON内のvariablesに記載された順序で読む。第一表の `u` と本文の \(\upsilon\) は同じ残余、第二表の `p0` は \(p-s-1\)、`q0` は \(q-t\) であり、元変数そのものではない。各terms行のcoefficientとexponentsが一つの単項式を定める。

## 必須の証明データと通常検算 {#reproducibility}

全係数表と検算器は本原稿に付属する `supplement/APPENDICES/LINEAR/` および `supplement/APPENDICES/EUCLIDEAN/` に置く。元のbytesを保持し、通常検算では表を読み込んで独立の定義式からの全係数一致を確かめる。証明書を書き出すオプションは使わない。検算器は結果JSONを同じ補足ディレクトリへ再生成するため、配布正本を保全するときはパッケージ全体の作業コピーを作り、そのルートから次を実行する。

```bash
python3 supplement/APPENDICES/LINEAR/verify_D_linear.py
python3 supplement/APPENDICES/EUCLIDEAN/verify_euclidean_closure.py
```

PythonとSymPyの版、今回の実行結果、照合したファイルのSHA-256は付属の `FINAL_REGRESSION_REPORT.md` に記録する。論理上必要なのはここで定義した有限の恒等式とその全係数であり、プログラムの成功表示を公理とするものではない。係数表の実務的な確認は計算機に支援されている。全体のscope、非負表示、第一点の存在、降下の停止は本文の議論による。発見方法について確認されていない寄与は記載しない。
