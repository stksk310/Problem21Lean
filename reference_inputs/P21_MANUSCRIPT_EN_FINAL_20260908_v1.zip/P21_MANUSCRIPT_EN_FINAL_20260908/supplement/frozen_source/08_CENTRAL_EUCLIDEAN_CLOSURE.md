# 08 — CENTRALとEuclidean two-packet閉鎖

R7のCORE-ROOTから出発する。定理C8.1でactual returnsと数値的境界を得て、
C8.2でboundaryとpacket-windowを処理する。window内の例外UはC8.3、残るDはC8.4を経てE8へ渡す。
各小定理で局所記号を定義し直す。半群H、canonical T=b_k+α、root係数Cは区別する。

## C8.1 — COREから後期閉鎖への入力
### C8.1.0 最小の十分な入力 CORE

以下を仮定する。

1. 数値半群 \(\Gamma=\langle m,n_i,n_j,n_k\rangle\)、\(0<m<\min(n_i,n_j,n_k)\)、Frobenius 数 \(F\notin\Gamma\)。
2. 正整数 \(\lambda,\delta,\beta,g,\alpha,a_j,b_j,a_k,b_k\) と
   \[
   a_i=\lambda+\delta,\quad b_i=\lambda+\beta,\quad
   \rho_r=a_r+b_r,\quad P=\lambda+\delta+\beta,\quad
   R=a_j+g,\quad T=b_k+\alpha.
   \]
   pure \(H=\langle n_i,n_j,n_k\rangle\) における真の critical relations
   \[
   \rho_i n_i=b_jn_j+a_kn_k,\qquad
   \rho_j n_j=a_in_i+b_kn_k,\qquad
   \rho_k n_k=b_in_i+a_jn_j.
   \]
   「critical」とは、\(\rho_r\) が他の二生成元による非負表示を持つ \(n_r\) の最小の正整数倍であること。符号付き関係一般の最小性は仮定しない。
3. 同じ一個の actual 要素
   \[
   W=F+m=(P-1)n_i+(R-1)n_j+(T-1)n_k.
   \]
4. 同じ配置の四つの PF gaps
   \[
   \begin{aligned}
   q_{A_i}&=(P-1)n_i+(a_j-1)n_j-n_k,\\
   q_{B_i}&=(P-1)n_i-n_j+(b_k-1)n_k,\\
   q_{B_j}&=(b_i-1)n_i+(R-1)n_j-n_k,\\
   q_{A_k}&=(a_i-1)n_i-n_j+(T-1)n_k.
   \end{aligned}
   \]
   実際に使うのは各 \(q\notin\Gamma\) と、表示した missing direction の successor が \(\Gamma\) に属すること。その存在は PF 性が保証する。
5. 同じ生成元上の ROOT
   \[
   m+d n_i=S n_j+C n_k,\qquad
   1\le d\le\lambda,\quad S\ge g+1,\quad C\ge\alpha.
   \tag{CORE-ROOT}
   \]

\(C\) は ROOT の係数であり、\(T=b_k+\alpha\) とは別。ここではreturnsのlevel最小性やlevel等号を仮定しない。

**入力補題。** R7の配置は以下のCOREを満たす。以下でC8.2–E8に必要な帰結を導く。

### C8.1.1 missing-coordinate returns と正の m-level は CORE から得られる

PF 性により各 successor は \(\Gamma\) に入る。その任意の genuine factorization に missing generator が一個でも含まれれば、その一個を係数ごとに除いて元の gap が \(\Gamma\) に入る。したがって、それぞれの missing coordinate は常にゼロ。

まず
\[
EA=q_{A_i}+n_i=L_i m+U_jn_j+U_kn_k
\]
の \(L_i=0\) を否定する。canonical row と比較すると
\[
P n_i=(U_j-a_j+1)n_j+(U_k+1)n_k.
\]
\(P<\rho_i\) なので j 係数が非負なら subcritical i contradiction。j 係数が負なら
\[
(U_k+1)n_k=P n_i+(a_j-1-U_j)n_j
\]
より \(U_k+1\ge\rho_k\)。一枚の \(\mathcal R_k\) を比較すると
\[
\delta n_i=(U_j+1)n_j+(U_k+1-\rho_k)n_k,
\]
再び正の subcritical i contradiction。従って \(L_i\ge1\)。

同様に \(EB=q_{B_i}+n_i=L_bm+V_jn_j+V_kn_k\) の \(L_b=0\) は
\[
P n_i=(V_j+1)n_j+(V_k-b_k+1)n_k
\]
から、必要なら \(\mathcal R_j\) を一枚比較して
\[
\beta n_i=(V_j+1-\rho_j)n_j+(V_k+1)n_k
\]
を生むので不可能。\(L_b\ge1\)。ここで criticality を用いた全ての関係は m=0 である。

CORE の W と四行から complements は exact に
\[
c_{A_i}=g n_j+Tn_k,\quad c_{B_i}=R n_j+\alpha n_k,
\quad c_{B_j}=\delta n_i+Tn_k,\quad c_{A_k}=\beta n_i+Rn_j.
\]
EA/EB に対応 complement を加え、実際に含まれる m を一個除くと
\[
F+n_i=(L_i-1)m+(U_j+g)n_j+(U_k+T)n_k,
\]
\[
F+n_i=(L_b-1)m+(V_j+R)n_j+(V_k+\alpha)n_k.
\]
j または k の係数が対応 \(\rho\) 以上なら canonical packet を一枚置換して正の i を作り、その一個を除いて \(F\in\Gamma\)。従って
\[
U_j+g<\rho_j,\quad U_k+T<\rho_k,\quad
V_j+R<\rho_j,\quad V_k+\alpha<\rho_k.
\tag{FI-CAPS}
\]
特に \(R<\rho_j\)、\(T<\rho_k\)、\(g<b_j\)、\(\alpha<a_k\)。

次に \(Q_j=q_{B_j}+n_j=L_jm+A_jn_i+C_jn_k\) の \(L_j=0\) を仮定すると
\[
(b_i-1-A_j)n_i+R n_j=(C_j+1)n_k.
\]
i 係数が非正なら \(R<\rho_j\) に反する。正なら k-criticality から \(C_j+1\ge\rho_k\)。\(\mathcal R_k\) を一枚比較して
\[
g n_j=(A_j+1)n_i+(C_j+1-\rho_k)n_k,
\]
subcritical j contradiction。従って \(L_j\ge1\)。双対に \(Q_k=q_{A_k}+n_k=L_km+A_kn_i+B_kn_j\) の \(L_k=0\) は
\[
\alpha n_k=(A_k+1)n_i+(B_k+1-\rho_j)n_j
\]
に帰着して不可能。\(L_k\ge1\)。

以上の四本をRETと呼ぶ。全てCOREから得た正levelのactual表示である。

### C8.1.2 追加の caps と slopes

Qj の actual row に complement を加え m を一個除けば
\[
F+n_j=(L_j-1)m+(A_j+\delta)n_i+(C_j+T)n_k.
\tag{FJ}
\]
\(C_j+T\ge\rho_k\) なら \(\mathcal R_k\) を置換して j を \(a_j\ge1\) 個作れるので
\[
C_j+T<\rho_k.
\tag{FJ-KCAP}
\]
特にC_j<ρ_kである。

ROOT を Qj に一回 completed substitution すると
\[
Q_j=(L_j-1)m+(A_j-d)n_i+S n_j+(C_j+C)n_k.
\]
\(A_j\ge d\) なら全係数非負で正の j を持つので gap contradiction。従って \(A_j\le d-1\)。同じ理由で \(A_k\le d-1\)。EA/EB に ROOT と \(\mathcal R_j\) または \(\mathcal R_k\) を一枚ずつ入れると
\[
U_j+S<\rho_j,\quad U_k+C<\rho_k,
\quad V_j+S<\rho_j,\quad V_k+C<\rho_k
\]
も従う。例えば次の四表示で、それぞれ問題となる係数が非負なら元のgapに反する：
\[
q_{A_i}=(L_i-1)m+(a_i-d-1)n_i+(U_j+S-\rho_j)n_j+(U_k+C+b_k)n_k,
\]
\[
q_{A_i}=(L_i-1)m+(b_i-d-1)n_i+(U_j+S+a_j)n_j+(U_k+C-\rho_k)n_k,
\]
\[
q_{B_i}=(L_b-1)m+(a_i-d-1)n_i+(V_j+S-\rho_j)n_j+(V_k+C+b_k)n_k,
\]
\[
q_{B_i}=(L_b-1)m+(b_i-d-1)n_i+(V_j+S+a_j)n_j+(V_k+C-\rho_k)n_k.
\]

一個のiを除く前の係数はa_i−d>0またはb_i−d>0である。

ROOT と \(\mathcal R_j\) の比較は
\[
\rho_jm=(Sa_i-d\rho_j)n_i+(Sb_k+C\rho_j)n_k.
\]
\(d\rho_j-Sa_i\le0\) なら \(m>n_k\)。同様に
\[
\rho_km=(Cb_i-d\rho_k)n_i+(S\rho_k+Ca_j)n_j
\]
から他方の slope も得られる。よって
\[
d\rho_j-Sa_i>0,\qquad d\rho_k-Cb_i>0.
\tag{SLOPES}
\]
特に \(S<\rho_j,C<\rho_k\)。ここは criticality ではなく multiplicity の比較である。

### C8.1.3 intrinsic 二候補と安全な色反転

\[
h=\lfloor\lambda/d\rfloor,\quad q_0=h+1,\quad
r=\lambda-hd,\quad e_0=q_0d-\lambda=d-r.
\]
ROOT と \(-\mathcal R_i\) を用いた completed F-row は、全整数 \(x,y\) に対して
\[
v(x,y)=(x-1,\ P-1+xd-y\rho_i,\ R-1-xS+yb_j,\ T-1-xC+ya_k).
\]
最終非負なら \(x\ge1\)。\(y\le0\) の成功は \((x,y)=(1,0)\) の j,k 成功を必要とし、その点自身で F が非負になる。\(y\ge1\) の i-fit は
\[
xd\ge\lambda+1+(y-1)\rho_i.
\]
恒等式
\[
\rho_i-q_0d-q_0=(q_0-2)(d-1)+2r+\delta+\beta-2\ge0
\tag{RHO-GAP}
\]
から \(x\ge yq_0\)。従って、第二候補
\[
v(q_0,1)=(q_0-1,e_0-1,J_0,K_0),
\]
\[
J_0=\rho_j+g-1-q_0S,\quad K_0=\rho_k+\alpha-1-q_0C
\]
の j または k が負なら、この \(y\ge1\) 領域に成功点はない。逆に両方非負なら第二候補が成功する。これが二候補の全整数判定である。

F は gap なので第二候補は失敗する。さらに
\[
q_0m=(\rho_i-q_0d)n_i+(q_0S-b_j)n_j+(q_0C-a_k)n_k
\tag{QM}
\]
と RHO-GAP により、j,k 同時不足は不可能。より強く
\[
J_0<0\Longrightarrow q_0C\le a_k-1,
\quad K_0<0\Longrightarrow q_0S\le b_j-1.
\]
例えば前者で \(q_0C\ge a_k\) なら、QM の i 係数は \(\ge q_0\)、j 係数は \(\ge R>0\) なので \(m>n_i\)。

K0 側だけが負なら j,k を交換し、同時に
\[
(a_i,b_i)\mapsto(b_i,a_i),\quad
(a_j,b_j)\mapsto(b_k,a_k),\quad
(a_k,b_k)\mapsto(b_j,a_j).
\]
従って
\[
(\delta,\beta,g,\alpha,R,T,S,C)
\mapsto(\beta,\delta,\alpha,g,T,R,C,S).
\]
四 PF 行は \(q_{A_i}\leftrightarrow q_{B_i}\)、\(q_{B_j}\leftrightarrow q_{A_k}\) と交換され、\(\Gamma,F,m,W,\lambda,d\) は変わらない。

反転前の \(hC<\rho_k\) と \(K_0<0\) より
\[
1\le-K_0\le C-\alpha,
\]
すなわち \(C\ge\alpha+1\)。反転後も \(S'\ge g'+1\) が成立し、\(C'=S\ge\alpha'\) も成立する。CORE全体が保存される。

以後 \(J_0<0\) に向きを取れる。そのとき
\[
\Delta_0=q_0S-\rho_j-g+1\ge1,\quad
A_0=e_0-\delta-1\ge0,\quad C_0=a_k-q_0C-1\ge0.
\]
A0 の符号は \(q_0S>\rho_j\) と SLOPES が \(q_0d>a_i\) を与えることによる。
\[
\tau_0=\rho_j-hS\ge1,\quad
\Delta_0+\tau_0=S-g+1,
\quad 1\le\Delta_0\le S-g.
\]
第二候補から
\[
\Omega_0=F+\Delta_0n_j=(q_0-1)m+(e_0-1)n_i+(C_0+T)n_k
\tag{COMPACT}
\]
は genuine actual。\(c_{B_j}=\delta n_i+Tn_k\) はこの一個の factorization 内に実際に含まれる。その除去と m の追加により
\[
q_{B_j}+\Delta_0n_j=q_0m+A_0n_i+C_0n_k.
\]


### C8.1.4 必要な return-level 下界を明示する

### Ai/Bi

EA の canonical/actual 比較から m を完全消去して
\[
(P+L_id)n_i=(L_iS+U_j-a_j+1)n_j+(L_iC+U_k+1)n_k.
\]
\(L_id<\lambda\) なら左係数は \(\rho_i\) 未満。j 係数が非負なら直ちに矛盾。負なら右 k 係数は \(\ge\rho_k\) でなければならず、\(\mathcal R_k\) の比較後
\[
(\delta+L_id)n_i=(L_iS+U_j+1)n_j+(L_iC+U_k+1-\rho_k)n_k
\]
が subcritical i contradiction。双対の EB も同様。従って
\[
L_id\ge\lambda,\quad L_bd\ge\lambda,
\quad L_i,L_b\ge\lceil\lambda/d\rceil\ge h.
\tag{I-LEVEL}
\]

### Bj

\(L_j\le h\) なら
\[
(b_i-1-A_j+L_jd)n_i+(R-L_jS)n_j=(C_j+L_jC+1)n_k.
\]
i 係数は \(A_j\le d-1\) により正で、\(L_jd\le\lambda\) により \(\rho_i\) 未満。j が非正なら subcritical i。j が正なら k-criticality 後の \(\mathcal R_k\) 比較が
\[
(L_jd-A_j-1)n_i+(g-L_jS)n_j=(C_j+L_jC+1-\rho_k)n_k
\]
となる。j は負なので、i が非正なら正値性、正なら subcritical i に反する。ゆえに \(L_j\ge q_0\)。

\(L_j=q_0\) の場合は同じ actual \(q_{B_j}+\Delta_0n_j\) の比較により m を消して
\[
0=(A_j-A_0)n_i+(\Delta_0-1)n_j+(C_j-C_0)n_k.
\]
三係数の絶対値は各 \(\rho\) 未満。非零なら符号分離の一方に一種類の subcritical generator が立つので不可能。従って
\[
L_j=q_0\Longrightarrow(\Delta_0,A_j,C_j)=(1,A_0,C_0).
\]
ここで Cj の subcritical bound は本稿 C8.1.2 の FJ-KCAP が供給する。

### Strict C>alpha の Ak

\(L_k\le h\) と仮定して m を消すと
\[
(a_i-1-A_k+L_kd)n_i+(T-L_kC)n_k=(B_k+L_kS+1)n_j.
\]
第一 i は正で \(\rho_i\) 未満。k が非正なら subcritical i。正なら j-criticality 後に \(\mathcal R_j\) を比較して
\[
(L_kd-A_k-1)n_i=(B_k+L_kS+1-\rho_j)n_j+(L_kC-\alpha)n_k.
\tag{K-PURE}
\]
strict \(C>\alpha\) により右 k は正なので、i が非正でも正でも矛盾。ゆえに \(L_k\ge q_0\)。この範囲では K-PURE の右 j も \(q_0S>\rho_j\) により正なので
\[
L_kd-A_k-1\ge\rho_i\ge q_0d+q_0.
\]
従って実際には \(L_k\ge q_0+1\)。

actual FK に q0 個の ROOT と一枚の Rj を入れて、最後に一個の k を除いた completed F-row は
\[
\begin{aligned}
F={}&(L_k-q_0-1)m+(A_k+\beta+\delta-e_0)n_i\\
 &+(B_k+R+q_0S-\rho_j)n_j+(q_0C+b_k-1)n_k.
\end{aligned}
\]
i 以外は非負なので
\[
A_k+\beta+\delta\le e_0-1,
\qquad e_0\ge\beta+\delta+1.
\tag{SUM-NOTCH}
\]
この strict の結論を \(C=\alpha\) に使っていない。

### C8.1.5 intrinsic packetとFKのcap

ROOT を h 回、Rj を一回比較する exact equality は
\[
h m+\tau_0n_j=(a_i-hd)n_i+(b_k+hC)n_k.
\tag{SHIFT-NEW}
\]
全係数は非負、\(a_i-hd=r+\delta>0\)。I-LEVEL により EA/EB の m-source は必ず h 個を含む。従って SAME EA/EB への実際の置換で
\[
U_j,V_j\le\tau_0-1.
\]

strict \(C>\alpha\) では actual FK の m 係数 \(L_k-1\ge h+1\) も h 個を含む。もし \(B_k+R\ge\tau_0\) なら
\[
\begin{aligned}
F={}&(L_k-h-1)m+(A_k+\beta+a_i-hd)n_i\\
 &+(B_k+R-\tau_0)n_j+(b_k+hC-1)n_k\in\Gamma.
\end{aligned}
\]
従って
\[
0\le B_k\le\tau_0-R-1,\qquad \tau_0\ge R+1.
\tag{FK-STRONG}
\]
このFKのτ₀-capをC8.4で使用する。



## C8.2 — 第一点、boundary、strict packet-window

C8.1のCORE、RET、caps、slopesを使う。以下の局所L,MはL_i,L_jを表し、
x,zはpure-H kernel係数、Q=U_j+1、a=A_j+1である。
### C8.2.2 CENTRAL 自身の最初の ROOT / Rj 補填点

W の \(R_k\)-face は genuine に

\[
\boxed{W=(\delta-1)n_i+(g-1)n_j+(\rho_k+T-1)n_k.}\tag{W-K}
\]

ROOT と \(R_j\) から

\[
F=(n-1)m+(\delta-1+nd-\zeta a_i)n_i
 +(g-1+\zeta\rho_j-nS)n_j
 +(\rho_k+T-1-nC-\zeta b_k)n_k.\tag{HRJ}
\]

これは completed family。以下では、全整数 family の新たな完全分類を主張するのではなく、十分な性質を持つ一つの第一点を選ぶ。

\(\zeta\ge1\) に対して

\[
n_\zeta=\left\lceil\frac{\zeta a_i-\delta+1}{d}\right\rceil,
\]
\[
I_\zeta=\delta-1+n_\zeta d-\zeta a_i,
\qquad J_\zeta=g-1+\zeta\rho_j-n_\zeta S.
\]

\(a_i>d\) より \(n_\zeta\) は厳密増加し、\(0\le I_\zeta\le d-1\)。また \(n_1=\lceil(\lambda+1)/d\rceil\ge2\)。

\(V=d\rho_j-Sa_i>0\) により

\[
J_d=V+S\left\lfloor\frac{\delta-1}{d}\right\rfloor+g-1>0.
\]

従って

\[
\widehat\zeta=\min\{\zeta\ge1:J_\zeta\ge0\}\le d
\]

は存在する。書きやすさのため

\[
N=n_{\widehat\zeta},\quad I=I_{\widehat\zeta},\quad J=J_{\widehat\zeta}
\]

と置く。\(\widehat\zeta>1\) では直前の \(J\) は負、\(n\) は少なくとも一つ増えるので

\[
J\le\rho_j-S-1.
\]

\(\widehat\zeta=1\) も含めて安全な共通 cap は

\[
\boxed{N\ge2,\quad 0\le I\le d-1,\quad
0\le J\le\rho_j-S+g-1.}\tag{FIRST-CAPS}
\]

定める：

\[
\boxed{\Xi=NC+\widehat\zeta b_k-(\rho_k+T-1).}
\]

\(\Xi\le0\) なら HRJ 自身が非負の F-row となって閉じる。従って survivor では \(\Xi\ge1\)。

\[
\widehat\Omega=F+\Xi n_k=(N-1)m+In_i+Jn_j
\]

は named actual upper の genuine ZERO-k face である。

---

### C8.2.3 SAME-element packet と FI/FJ level wall

### C8.2.3.1 CENTRAL の FK を導き直す

W と ROOT と \(R_j\) から exact に

\[
\boxed{F+n_k=(d+\beta-1)n_i+(R+\rho_j-S-1)n_j+(\alpha-C)n_k.}\tag{C-FK}
\]

\(C>\alpha\) ではこのまま actual と呼べない。しかし

\[
F+(C-\alpha+1)n_k
=(d+\beta-1)n_i+(R+\rho_j-S-1)n_j
\]

は genuine である。

定める：

\[
D_F=d+\beta-1-I\ge\beta>0,
\]
\[
E_F=R+\rho_j-S-1-J\ge a_j>0,
\]
\[
\boxed{\chi=C-\alpha+1-\Xi.}
\]

二つの actual upper を、\(k\) の追加だけで同じ上界に揃え、共通の \(In_i+Jn_j\) を係数ごとに除くと

\[
\boxed{(N-1)m+\max(\chi,0)n_k
=D_Fn_i+E_Fn_j+\max(-\chi,0)n_k.}\tag{PACKET}
\]

を得る。**この表示の両辺は非負**であり、signed な FK を actual と偽っていない。

### C8.2.3.2 \(C=\alpha\) の強い壁

この境界では \(\chi=1-\Xi\le0\)。従って

\[
(N-1)m=D_Fn_i+E_Fn_j+(\Xi-1)n_k.
\]

\(N-1\le L_i\) なら SAME EA の m 部分に入れて正の i を作り、\(q_{A_i}\in\Gamma\)。EB も同様。\(N-1\le L_j\) なら SAME Qj に正の j を作る。

従って

\[
\boxed{C=\alpha\Longrightarrow N\ge\max(L_i,L_b,L_j)+2.}\tag{BOUNDARY-WALL}
\]

### C8.2.3.3 一般の \(\chi\le T\) の壁

\(\chi\le T\) とする。\(N\le L_i\) なら SAME FI-A に PACKET を適用し、最後に一個の \(n_i\) を除去して

\[
\boxed{
F=(L_i-N)m+(D_F-1)n_i
 +(U_j+g+E_F)n_j+(U_k+T-\chi)n_k\in\Gamma.
}\tag{FI-CERT}
\]

\(N\le L_j\) なら SAME FJ に適用して

\[
\boxed{
F=(L_j-N)m+(A_j+\delta+D_F)n_i
 +(E_F-1)n_j+(C_j+T-\chi)n_k\in\Gamma.
}\tag{FJ-CERT}
\]

\(\chi>0\) の場合には FI/FJ の T 個の k が source を保証する。\(\chi\le0\) の場合は k を消費せず生成する。全最終係数が非負。

従って

\[
\boxed{\chi\le T\Longrightarrow N\ge\max(L_i,L_j)+1.}\tag{WINDOW-WALL}
\]

**一般の EB にこの T-window を無条件で適用してはいない**。FI-B の canonical k 供給は \(\alpha\) だからである。

---

### C8.2.4 pure-H integer basis と二つの係数 1

### C8.2.4.1 Kernel basis

G4.3の整数kernel基底 \(\mathbf r_j=(a_i,-\rho_j,b_k),\mathbf r_k=(b_i,a_j,-\rho_k)\) を使う。以下の係数比較はmを完全に消してから行う。

### C8.2.4.2 EA

以下は WINDOW-WALL の下で行う。\(L=L_i\)、\(M=L_j\)、\(a=A_j+1\ge1\)、\(Q=U_j+1\ge1\) と置く。

EA の canonical row と actual row を比較し、ROOT で m を完全に消す：

\[
(P+Ld,\ a_j-1-LS-U_j,\ -LC-U_k-1)
=x\mathbf r_j+y\mathbf r_k.
\]

\(x,y\) は整数。第一座標は正、第三は負、第二は \(a_j\) 未満である。\(y\le0\) なら第三の符号が x も非正に強制して第一と矛盾。\(x\le0\) なら第二が \(a_j\) 以上になる。従って \(x,y\ge1\)。

係数比較：

\[
Ld=xa_i+(y-1)b_i-\delta,
\quad LS=x\rho_j-(y-1)a_j-Q.
\]

\(y\ge2\) なら HRJ の点 \((\zeta,n)=(x,L)\) で

\[
I=(y-1)b_i-1\ge0,\quad J=Q+g-1+(y-1)a_j\ge0.
\]

同じ \(\zeta=x\) で n を最小化すれば J は増え、\(n_x\le L\)。最初の点の N も \(N\le L\) となるので WINDOW-WALL と矛盾。

従って y=1：

\[
\boxed{Ld=xa_i-\delta,\quad LS=x\rho_j-Q,\quad
\varepsilon:=\rho_k-U_k-1=LC+xb_k.}\tag{EA-ONE}
\]

### C8.2.4.3 SAME Qj

ROOT を使って m を完全消去すると

\[
(Md+b_i-1-A_j,\ R-MS,\ -MC-C_j-1)
=z\mathbf r_j+v\mathbf r_k.
\]

第一座標は \(A_j\le d-1\) により正、第三は負、第二は \(S\ge g+1\) により \(a_j\) 未満。上と同じ符号判定で \(z,v\ge1\)。

\(v\ge2\) なら点 \((z,M)\) で

\[
I=A_j+\delta+(v-1)b_i\ge0,
\quad J=(v-1)a_j-1\ge0.
\]

従って \(N\le M\) と WINDOW-WALL に矛盾する。ゆえに

\[
\boxed{Md=za_i+a,\quad MS=z\rho_j+g,\quad
\rho_k=MC+C_j+1+zb_k.}\tag{QJ-ONE}
\]

---

### C8.2.5 空の整数三角形、determinant 1、level の例外

\((\zeta,n)\) 平面の三角形

\[
O=(0,0),\quad U=(x,L),\quad V_0=(z,M)
\]

を取る。affine functions I,J の頂点値は

| 頂点 | I | J |
|---|---:|---:|
| O | \(\delta-1\) | \(g-1\) |
| U | \(-1\) | \(Q+g-1\) |
| V0 | \(A_j+\delta\) | \(-1\) |

非頂点の整数点では I,J はそれぞれ -1 より大きい整数なので非負。さらに \(0<n\le\max(L,M)\)。その点から first fit が \(N\le\max(L,M)\) となり、WINDOW-WALL と矛盾する。

一方

\[
(xM-zL)d=xa+z\delta>0.
\]

正の整数 determinant が 2 以上なら、基本平行四辺形に非零整数点があり、その点か \(U+V_0\) からの反射が三角形の非頂点整数点になる。よって

\[
\boxed{xM-zL=1.}\tag{DET1}
\]

これから

\[
\boxed{
\begin{aligned}
d&=xa+z\delta,&S&=xg+zQ,\\
a_i&=La+M\delta,&\rho_j&=Lg+MQ,\\
b_i&=La+(M-1)\delta+\beta,&V&=aQ-\delta g>0.
\end{aligned}}\tag{PARAM}
\]

を得る。

\(a_i>d\) と DET1 より、level は正確に

\[
\boxed{
[L\ge x+1\ge2,\ M>z\ge1]
\quad\vee\quad
[L=x=1,\ M=z+1].
}\tag{LEVEL-SPLIT}
\]

証明：\(x\ge2,L\le x\) なら \(xM=zL+1\le zx+1\) から \(M\le z\)、従って \(a_i\le d\)。\(x=1,L=1\) は DET1 から \(M=z+1\)。それ以外は前者になる。

後者はlevel-one例外UとしてC8.3へ渡す。

---

### C8.2.6 FJ absorption が与える正確な k-ceiling

EA-ONE は

\[
\delta n_i+\varepsilon n_k=Lm+Qn_j,
\quad \varepsilon=LC+xb_k.
\]

\(\varepsilon\le C_j+T\) なら SAME FJ 内に左 packet が入り、正の j を作って F を actual にする。従って

\[
\boxed{H_0:=LC+(x-1)b_k-\alpha-C_j-1\ge0.}\tag{H0}
\]

QJ-ONE と合わせて

\[
\boxed{\rho_k=(M+L)C+(z+x-1)b_k-\alpha-H_0.}\tag{K-CEILING}
\]

境界 \(C=\alpha\) に限り

\[
H_0=(L-1)\alpha+(x-1)b_k-C_j-1,
\]
\[
\rho_k=(M+L-1)\alpha+(z+x-1)b_k-H_0.
\]

一般式の \(LC-\alpha\) を \((L-1)C\) に置き換えない。

---

### C8.2.7 C=alpha: actual EA/EB synchronization

ここだけ BOUNDARY-WALL を使う。EB の m を消した pure row は

\[
(P+L_bd,\ -1-L_bS-V_j,\ b_k-1-L_bC-V_k)
=x_b\mathbf r_j+y_b\mathbf r_k.
\]

第一正、第二負、第三が \(b_k\) 未満なので \(x_b,y_b\ge1\)。\(y_b\ge2\) なら点 \((x_b,L_b)\) は I,J とも非負なので \(N\le L_b\)、BOUNDARY-WALL と矛盾。

従って

\[
L_bd=x_ba_i-\delta,
\quad L_bS=x_b\rho_j-(V_j+a_j+1).
\]

EB と SAME Qj の三角形にも同じ議論を適用できるので

\[
x_bM-zL_b=1.
\]

EA 側の DET1 を引き、i-equation の差を合わせると

\[
(Md-za_i)(x_b-x)=a(x_b-x)=0.
\]

\(a\ge1\) なので

\[
\boxed{L_b=L_i=L,\quad x_b=x,\quad
U_j=V_j+a_j,\quad V_k=U_k+b_k.}\tag{SYNC}
\]

特に

\[
\boxed{Q=U_j+1\ge a_j+1\ge2.}
\]

これは CENTRAL の actual equations と walls から証明した同期であり、HIGH の equal-POST を移植したものではない。

また LEVEL-SPLIT の \(L=x=1\) は、境界では H0=-Cj-1<0 となるため排除される。従って

\[
L\ge x+1\ge2,\qquad M>z\ge1.
\]

---

### C8.2.8 C=alpha 全域の multiplicity contradiction

Canonical cross products を

\[
\mathcal I=\rho_j\rho_k-a_jb_k,
\quad\mathcal J=a_i\rho_k+b_ib_k,
\quad\mathcal K=b_i\rho_j+a_ia_j
\]

と置く。ある \(\sigma>0\) により

\[
(n_i,n_j,n_k)=\sigma(\mathcal I,\mathcal J,\mathcal K),
\quad m=\sigma\widehat m,
\quad\widehat m=-d\mathcal I+S\mathcal J+C\mathcal K.
\]

\(\sigma=1\) は仮定しない。

\[
D_j=da_j+Sb_i,\quad P_0=V+a_i>0,
\]
\[
C_A=\mathcal K-(M+L-1)P_0,
\quad C_B=D_j-b_i-(z+x-1)P_0.
\]

境界の K-CEILING から exact に

\[
\boxed{\widehat m-\mathcal J=H_0P_0+\alpha C_A+b_kC_B.}\tag{BOUND-MULT}
\]

正値分解は

\[
C_A=aA_a+\delta A_\delta+\beta\rho_j,
\quad C_B=aB_a+\delta B_\delta+\beta(S-1),
\]

\[
\begin{aligned}
A_a={}&(L-1)(M-1)(Q-2)+L^2(g-1)+L(a_j-1)+(L-2)M+2,\\
A_\delta={}&M(M-1)(Q-2)+(LM+M-1)(g-1)
 +M(a_j-1)+M^2+M-1,\\
B_a={}&[z(L-1)-x+1](Q-2)+Lx(g-1)+x(a_j-1)\\
&+z(L-x-1)+(z-1)(x-1)+1,\\
B_\delta={}&(xM+z-1)(g-1)+z(M-1)(Q-2)+z(a_j-1)+zM.
\end{aligned}\tag{POS-COEFF}
\]

\(Q\ge2\), \(g,a_j\ge1\), \(L\ge x+1\), \(M>z\) の下で各項の符号は非負で、各係数は正。

特に \(z(L-1)-x+1=x(z-1)+1+z(L-x-1)\ge1\)。従って \(C_A,C_B>0\)。BOUND-MULT により \(m>n_j\)、multiplicity に矛盾。

\[
\boxed{C=\alpha\ \textbf{CLOSED}.}
\]

この結果は \(\Delta_0=1\) と \(\Delta_0\ge2\)、最小 / strict return levels の全域を含む。

---

### C8.2.9 Strict packet-window theorem

#### 主張

\[
\boxed{C>\alpha,\quad \chi\le T,\quad L_i\ge2\Longrightarrow\bot.}\tag{STRICT-WINDOW}
\]

WINDOW-WALL から C8.2.4–6 がそのまま通る。\(L=L_i\ge2\) なので LEVEL-SPLIT の例外はない。従って \(L\ge x+1\), \(M>z\)。ここでは SYNC は使わず、\(Q\ge1\) だけを使う。

\(\gamma=C-\alpha\ge1\) と置く。一般の K-CEILING から

\[
\boxed{
\widehat m-\mathcal J
=H_0P_0+\alpha C_A+\gamma(C_A-P_0)+b_kC_B.
}\tag{STRICT-J}
\]

### C8.2.9.1 Q>=2 の regular 範囲

C8.2.8 の \(C_A,C_B>0\) は有効。

\(C_A-P_0\) の a 係数は

\[
\begin{aligned}
E_a={}&[(L-1)(M-1)-1](Q-2)+L^2(g-1)\\
&+L(a_j-1)+(L-2)M-L.
\end{aligned}
\]

delta 係数は

\[
E_\delta=M(M-1)(Q-2)+(LM+M)(g-1)+M(a_j-1)+M^2>0,
\]

beta 係数は \(\rho_j>0\)。

E_a が負になり得るのは、正確に以下の三つだけ。

1. \(L=2,x=1,M=2z+1,Q=2,g=a_j=1\), \(z\ge1\)。
2. \(L=2,x=1,z=1,M=3,Q=3,g=a_j=1\)。
3. \(L=3,x=2,z=1,M=2,Q=2,g=a_j=1\)。

完全性：L>=4 では \((L-2)M-L\ge L-4\ge0\)。L=3,M>=3 でも非負。L=3,M=2 は determinant と level から x=2,z=1 で、E_a=Q-3+9(g-1)+3(a_j-1)。L=2 では x=1,M=2z+1 なので E_a=(2z-1)(Q-2)+4(g-1)+2(a_j-1)-2。これを整数条件で尽くすと上の三つ。

それ以外では \(C_A-P_0>0\) となり STRICT-J で \(m>n_j\)。

### C8.2.9.2 Q=1 と三つの例外

次の別の正値分解を使う。

\[
A'=\mathcal K-(M+L)V,
\quad B'=D_j-(z+x-1)V.
\]

\[
\begin{aligned}
A'={}&a\{L^2g+[(L-1)M-L]Q+La_j\}\\
&+\delta\{(M-1)\rho_j+Ma_j+(M+L)g\}+\beta\rho_j,\\
B'={}&a\{xa_j+Lxg+[z(L-1)-x+1]Q\}\\
&+\delta\{za_j+(M-1)S+(z+x-1)g\}+\beta S.
\end{aligned}
\]

\(Q\ge1,L\ge x+1,M>z\) で \(A',B'>0\)。

\[
D_{\rm base}=2A'+B'+V-\mathcal K.
\]

正確に

\[
\boxed{
\widehat m-\mathcal K
=H_0V+(\alpha-1)(V+A')+(\gamma-1)A'
 +(b_k-1)B'+D_{\rm base}.
}\tag{STRICT-K}
\]

Dbase の係数分解は

\[
\begin{aligned}
D_{\rm base}={}&a\{(L+x)a_j+L(L+x)g+E Q\}\\
&+\delta\{(M-1)\rho_j+(M+z)a_j+(M-1)S\\
&\hspace{4em}+[2(M+L)+z+x-2]g\}
 +\beta(\rho_j+S),
\end{aligned}
\]

\[
E=(L-2)M+(L-1)z-2L-x+2.
\]

Q=1 では

\[
E-(L-x-3)=(L-2)(M-2)+(L-1)(z-1)\ge0,
\]

従って a 係数は \((L+x)(L+1)-2\) 以上であり、正である。他の係数も正。

上の三例外での a 係数は順に

\[
2z+3,\qquad3,\qquad16
\]

で正。従ってこれらも Dbase>0、STRICT-K により \(m>n_k\)。

以上で Q>=1 の全範囲が尽くされ、STRICT-WINDOW を証明した。

**有限分岐は符号計算から導いたこの三境界だけであり、任意の数値打ち切りを使っていない。**

---

### C8.2.10 閉じた strict 無限領域と exact source shortage

Survivor では \(\Xi\ge1\) だから

\[
\chi=C-\alpha+1-\Xi\le C-\alpha.
\]

従って \(C\le b_k+2\alpha\) なら \(\chi\le b_k+\alpha=T\)。さらに \(\lambda>d\) なら intrinsic bound により \(L_i\ge2\)。よって

\[
\boxed{\lambda>d,\quad\alpha<C\le b_k+2\alpha\ \textbf{CLOSED}.}
\]

一般に \(L_i\ge2\) の survivor は WINDOW 自体に入れないので

\[
\chi\ge T+1
\Longleftrightarrow
\boxed{1\le\Xi\le C-b_k-2\alpha.}\tag{DEEP}
\]

特に \(C\ge b_k+2\alpha+1\)。これは表示したpacketのk-source不足条件である。

---

### C8.2.11 WINDOW 内の残る level-one 境界

\(\chi\le T\) が成り立つ survivor では STRICT-WINDOW により \(L_i=1\)。intrinsic bound と \(d\le\lambda\) から \(\lambda=d\)、\(q_0=2\)。C8.2.4–6 の wall / basis / triangle は依然有効なので、LEVEL-SPLIT は必ず

\[
L=x=1,\qquad M=z+1.
\]

ここで \(\eta=C_j+1\) と置く。PARAM は

\[
\boxed{
\begin{aligned}
d=\lambda&=a+z\delta,&S&=g+zQ,\\
a_i&=d+\delta,&b_i&=d+\beta,\\
\rho_j&=g+(z+1)Q,&L_j&=z+1,\\
A_j&=a-1,&\rho_k&=(z+1)C+\eta+zb_k,\\
U_j&=Q-1,&U_k&=a_k-C-1.
\end{aligned}}
\tag{UNIT-PARAM}
\]

また H0=\(C-\alpha-\eta\ge0\)。

### C8.2.11.1 第一点は exact に計算できる

\(1\le\zeta\le z+1\) では

\[
n_\zeta=\zeta+
\left\lceil\frac{(\zeta-1)\delta+1}{d}\right\rceil
=\zeta+1,
\]

\[
J_\zeta=(\zeta-z)Q-1.
\]

従って

\[
\boxed{\widehat\zeta=z+1,\ N=z+2,\ I=a-1,\ J=Q-1,}
\]
\[
\boxed{\Xi=C-\alpha-\eta+1,\qquad \chi=\eta.}
\]

ゆえに

\[
\boxed{1\le\eta\le\min(C-\alpha,T).}\tag{UNIT-ETA}
\]

Compact data は

\[
\Delta_0=(z-1)Q+1,\qquad \tau_0=Q.
\]

\(z=1\) は \(\Delta_0=1\)、\(z\ge2\) は \(\Delta_0\ge2\)。両方をC8.3で扱う。

なお WINDOW の第一点は EA の選び方に依存しない。従って実際に survivor が存在すれば、**別の EA factorization に level>=2 があっても STRICT-WINDOW で閉じる**。従って、この例外でのすべての missing-i EA factorizations は level1 を持つ必要がある。これは uniqueness の仮定ではなく、上の定理の適用から従う必要条件。

### C8.2.11.2 Unit boundary の新しい multiplicity 排除

\[
\boxed{D_u:=Q\eta-R(C+b_k).}
\]

Unit parameters を cross products に代入する。置く：

\[
M_a=R(C+b_k)-Q\eta=-D_u,
\]
\[
\begin{aligned}
M_\delta={}&C[Qz(z+1)+a_j(z+1)+g(2z+1)]\\
&+b_k[Qz^2+a_jz+2gz]+\eta g>0,\\
M_\beta={}&C[Q(z+1)+g]+b_k[Qz+g]>0.
\end{aligned}
\]

正確に

\[
\widehat m=aM_a+\delta M_\delta+\beta M_\beta,
\]

\[
\boxed{\widehat m-\mathcal I=(a+z+1)M_a
 +(\delta-1)M_\delta+(\beta-1)M_\beta.}\tag{UNIT-MULT}
\]

\(D_u\le0\) なら右辺が非負となり \(m\ge n_i\)、strict multiplicity に矛盾。従って

\[
\boxed{D_u>0.}\tag{UNIT-REMAIN}
\]

\(\eta\le C-\alpha<C+b_k\) なので特に

\[
\boxed{Q>R=a_j+g.}
\]

よって unit boundary の \(Q\le R\) 全域も新たに CLOSED。

また \(U_j=Q-1\ge a_j\) なので、canonical EA/EB差のactual transport により同じ configuration に

\[
EB=m+(Q-a_j-1)n_j+(U_k+b_k)n_k
\]

という level1 の EB が構成される。既に選んだ任意の EB について level を一意だと仮定する主張ではない。

---

### C8.2.12 — 網羅的な受渡し

boundary C=αは排除した。strict C>αでは、χ≤TかつL_i≥2は不可能。
χ≤TならC8.2.11のU-parameter域に入る。一方χ>Tなら
\[
\mathcal D:\quad T<\chi\le C-\alpha,\quad
1\le\Xi\le C-b_k-2\alpha,\quad C\ge b_k+2\alpha+1.
\]
従って残る場合はUまたはDに尽くされる。

## C8.3 — U全域の排除
### C8.3.1 U の exact parameterization

\[
a:=A_j+1\ge1,\qquad z\ge1,\qquad Q:=U_j+1\ge1.
\]

\[
\begin{aligned}
\lambda=d&=a+z\delta,& S&=g+zQ,\\
a_i&=d+\delta,& b_i&=d+\beta,\\
\rho_j&=g+(z+1)Q,&
\rho_k&=(z+1)C+\eta+zb_k.
\end{aligned}
\tag{U-PARAM}
\]

\[
1\le\eta\le\min(C-\alpha,T),\qquad
D_u:=Q\eta-R(C+b_k)>0.
\tag{U-SIGNS}
\]

ここで \(\eta=C_j+1\)、\(L_j=z+1\)。C8.2.11により

\[
\widehat\zeta=z+1,\quad N=z+2,\quad
I=a-1,\quad J=Q-1,
\]
\[
\Xi=C-\alpha-\eta+1,\qquad\chi=\eta
\]

と計算されている。

本証明は \(\Xi=1\) を必要としない。\(D_u>0\) はC8.2.11.2のmultiplicity排除の残存条件であり、追加仮定ではない。

---

### C8.3.2 必要な packet 回数と j-capacity

置く：

\[
H_u:=C-\alpha-\eta\ge0,
\qquad
b_0:=z\delta+\beta>0.
\]

繰返し回数を \(t\) と書く。

\[
t:=\left\lfloor\frac H_u\eta\right\rfloor+1\ge1,
\qquad H_u=(t-1)\eta+r,\qquad0\le r\le\eta-1.
\tag{COUNT}
\]

従って

\[
C=\alpha+t\eta+r.
\]

\(\eta\le T=b_k+\alpha\) により

\[
C+b_k=T+t\eta+r\ge(t+1)\eta.
\]

\(D_u>0\) と整数性から

\[
\boxed{Q\ge(t+1)R+1.}
\tag{J-FIT}
\]

これは回数に上限を課さない全パラメータの評価である。

---

### C8.3.3 Multiplicity が必要な i-capacity を強制する

#### 主張

U の全 survivor は

\[
\boxed{a\ge t(z\delta+\beta)+\beta+1}
\tag{I-FIT}
\]

を満たす。

### C8.3.3.1 Cross-product の使用範囲

定める：

\[
\mathcal I=\rho_j\rho_k-a_jb_k,
\quad\mathcal J=a_i\rho_k+b_ib_k,
\quad\mathcal K=b_i\rho_j+a_ia_j.
\]

canonical relations により、ある共通の \(\sigma>0\) について

\[
(n_i,n_j,n_k)=\sigma(\mathcal I,\mathcal J,\mathcal K).
\]

\(\sigma=1\) や gcd の追加仮定はしない。ROOT から

\[
m=\sigma\widehat m,
\qquad
\widehat m=-d\mathcal I+S\mathcal J+C\mathcal K.
\]

\[
\Phi(a):=\widehat m-\mathcal J
\]

と置く。U-PARAM の下で \(\Phi\) は \(a\) の一次式であり、exact に

\[
\boxed{\frac{\partial\Phi}{\partial a}=-D_u-\rho_k-b_k<0.}
\tag{MONO-A}
\]

### C8.3.3.2 閾値での正値性

\[
a_*:=t(z\delta+\beta)+\beta.
\]

\[
w:=T-\eta\ge0,
\qquad q':=Q-(t+1)(a_j+g)-1\ge0.
\]

\(C=\alpha+t\eta+r\)、\(b_k=\eta-\alpha+w\) を代入すると、exact に

\[
\begin{aligned}
\Phi(a_*)={}&\delta\{P_\delta+(a_j-1)X_\delta+(g-1)Y_\delta+q'Z_\delta\}\\
&+\beta\{P_\beta+(a_j-1)X_\beta+(g-1)Y_\beta+q'Z_\beta\}.
\end{aligned}
\tag{POS-DECOMP}
\]

各 \(X,Y,Z\) は付録A3に明示する非負多項式。主要二項は

\[
\begin{aligned}
P_\delta={}&\alpha(2tz+3z+1)\\
&+\eta(t^2z^2+t^2z+3tz^2+tz+t+2z^2)\\
&+r(tz^2+3tz+2z^2+4z+1)\\
&+wz(tz+t+2z+1)>0,
\end{aligned}
\]

\[
\begin{aligned}
P_\beta={}&2\alpha(t+2)\\
&+\eta(t^2z+t^2+3tz+2z-3)\\
&+r(tz+3t+2z+5)\\
&+w(tz+t+2z+1)>0.
\end{aligned}
\]

唯一一見負号を含む括弧も、\(t,z\ge1\) なので

\[
t^2z+t^2+3tz+2z-3\ge4.
\]

従って \(\Phi(a_*)>0\)。もし \(a\le a_*\) なら MONO-A により

\[
\Phi(a)\ge\Phi(a_*)>0,
\]

すなわち \(m>n_j\) となり multiplicity に矛盾する。整数性から I-FIT が成立する。

この比較は signed relation の criticality ではなく、明示的な正値多項式と strict multiplicity の矛盾である。

---

### C8.3.4 SAME actual upper の中で t 回置換し、PF gap を actualize する

U-PARAM から

\[
\boxed{b_0n_i+Rn_j=(z+1)m+\eta n_k.}
\tag{U-PACKET}
\]

両辺は全係数非負。

同じ \(q_{A_k}\) に対して次の恒等式が成立する：

\[
\boxed{
q_{A_k}+(H_u+1)n_k
=(z+2)m+(a-\beta-1)n_i+(Q-R-1)n_j.
}
\tag{U-UPPER}
\]

左辺は \(q_{A_k}+n_k\in\Gamma\)、\(H_u\ge0\) により named actual upper。

I-FIT と J-FIT により

\[
a-\beta-1\ge t b_0,
\qquad Q-R-1\ge tR.
\]

従って U-UPPER の右辺も genuine で、\(t\) 個の U-PACKET 左辺を coefficientwise に含む。これを全部右辺に置換すると、同じ上界の \(k\) 係数は \(t\eta\) になる。

\[
t\eta-(H_u+1)=\eta-r-1\ge0.
\]

追加した **同じ \((H_u+1)n_k\) を全量除去**でき、残る最終ベクトルは

\[
\boxed{\begin{aligned}
q_{A_k}={}&[z+2+t(z+1)]m\\
&+[a-\beta-1-t(z\delta+\beta)]n_i\\
&+[Q-(t+1)R-1]n_j\\
&+(\eta-r-1)n_k\in\Gamma.
\end{aligned}}
\tag{U-FINAL}
\]

全四係数が非負。これは \(q_{A_k}\in PF(\Gamma)\) に矛盾する。

\[
\boxed{\boxed{\mathcal U=\varnothing.}}
\]

中間の signed row を actual と扱っていない。別の \(Q_k\) factorization の存在も仮定していない。必要回数 \(t\) は上の exact floor で決まる。

## C8.4 — Dのhigh-q、nonlinear first、linear firstの処理

Uを排除したのでDだけを扱う。この小定理のQは後半でτ₀の略記となり、Q(Γ)ではない。
この小定理ではτ=τ₀と書く。C8.1からe₀≥β+δ+1とτ₀≥R+1、C8.2からfirst-pointとgenuine packetを受け取る。
### C8.4.0.1 Dの入力記号

以下のcanonical係数は全て正整数である：
\[
a_i=\lambda+\delta,\quad b_i=\lambda+\beta,\quad
\rho_i=a_i+b_i,\quad\rho_j=a_j+b_j,\quad\rho_k=a_k+b_k,
\]
\[
P=\lambda+\delta+\beta,\quad R=a_j+g,\quad T=b_k+\alpha.
\]
CENTRAL rootとWの表示は
\[
m+d n_i=S n_j+C n_k,\qquad 1\le d\le\lambda,
\]
\[
W=F+m=(P-1)n_i+(R-1)n_j+(T-1)n_k.
\]
Cはroot係数であり、T=b_k+αとは異なる。

\[
0<m<\min(n_i,n_j,n_k),\qquad F\notin\Gamma.
\]
pure-H関係は
\[
\rho_jn_j=a_i n_i+b_k n_k,\qquad
\rho_kn_k=b_i n_i+a_jn_j,\qquad
\rho_in_i=b_jn_j+a_kn_k.
\]
以下ではmを完全消去してから整数kernelを使う。

置く：
\[
h=\lfloor\lambda/d\rfloor,\quad q_0=h+1,\quad
r=\lambda-hd,\quad e_0=d-r,
\]
\[
b=r+\delta,\qquad c=r+\beta,\qquad
\tau=\rho_j-hS.
\]
従って
\[
a_i=hd+b,\quad b_i=hd+c,\quad \rho_j=hS+\tau.
\]
Dの入力は次を満たす：
\[
e_0\ge\beta+\delta+1,\quad
1\le\tau\le S-g,\quad \tau\ge R+1,
\]
\[
V:=d\rho_j-Sa_i=d\tau-bS>0,
\qquad C\ge b_k+2\alpha+1.
\]
特に \(1\le b\le d-\beta-1<d\).

### C8.4.0.2 第一点とpacket

z≥1に対して定める：
\[
n_z=\left\lceil\frac{z a_i-\delta+1}{d}\right\rceil,
\]
\[
I_z=\delta-1+n_zd-z a_i,\qquad
J_z=g-1+z\rho_j-n_zS.
\]
J_z≥0となる最初の添字z=ζ̂を取り、次のように置く：
\[
N=n_z,\quad I=I_z,\quad J=J_z.
\]
定義は
\[
\Xi=NC+z b_k-(\rho_k+T-1),\qquad
\chi=C-\alpha+1-\Xi,
\]
Dの範囲は
\[
\Xi\ge1,\qquad T<\chi\le C-\alpha.
\]
genuineな両辺表示は
\[
D_Fn_i+E_Fn_j=(N-1)m+\chi n_k,
\]
\[
D_F=d+\beta-1-I,\qquad
E_F=R+\rho_j-S-1-J.
\]
同じactual upperは
\[
\Omega_D=F+(C-\alpha+1)n_k
=(d+\beta-1)n_i+(R+\rho_j-S-1)n_j.
\]
このpacketを繰り返す際に必要な最小回数は
\[
b_D=\left\lfloor\frac{C-\alpha}{\chi}\right\rfloor+1\ge2.
\]
この回数がsource内に入る必要十分条件は
\[
b_DD_F\le d+\beta-1,\qquad
b_DE_F\le R+\rho_j-S-1.
\]
以下ではこの適合を記号的に処理する。

---

### C8.4.1 最後のcrossingはh-stepである

a_i=hd+b、0<b<dなので連続するnの差はhまたはh+1。
z=1ではn₁=h+1=q₀であり
\[
J_1=\rho_j+g-1-q_0S=-\Delta_0<0.
\]
従ってz≥2。
最後の増分がh+1なら
\[
J_z-J_{z-1}=\rho_j-(h+1)S=\tau-S\le-g<0,
\]
となり負から非負へ移れない。従って
\[
\boxed{n_z-n_{z-1}=h.}
\]
その結果
\[
\boxed{0\le J\le\tau-1,\qquad
0\le I\le d-b-1=e_0-\delta-1.}
\tag{FIRST-CAPS}
\]
iの上限はI_{z−1}=I+b≤d−1から従う。

以下の二つのexact identitiesを使う：
\[
NV=\rho_j(I-\delta+1)+a_i(J-g+1),
\]
\[
zV=S(I-\delta+1)+d(J-g+1).
\tag{NV-ZV}
\]
FIRST-CAPSから
\[
NV\le hV+(d-\delta)\rho_j-a_i g,
\]
\[
(z-1)V\le S(d-\delta)-dg.
\tag{FIRST-BOUNDS}
\]

h≥2では
\[
E_F\ge R+(h-1)S>\tau-1\ge J.
\]
R+ρ_j−S−1=E_F+Jより二個以上のpacketはΩ_Dのj-sourceに入らない。high-hの場合は以下のmultiplicity比較を使う。

---

### C8.4.2 共通のmultiplicity certificate

定める：
\[
\mathcal I=\rho_j\rho_k-a_jb_k,\quad
\mathcal J=a_i\rho_k+b_i b_k,\quad
\mathcal K=b_i\rho_j+a_i a_j.
\]
共通の正のscale σ>0が存在し、
\[
(n_i,n_j,n_k)=\sigma(\mathcal I,\mathcal J,\mathcal K),\qquad
m=\sigma\widehat m,
\]
\[
\widehat m=-d\mathcal I+S\mathcal J+C\mathcal K.
\]
σ=1とは仮定しない。

定める：
\[
D_j=da_j+Sb_i,\quad
A=\mathcal K-NV,\quad B=D_j-(z-1)V.
\]
次の関係から
\[
\rho_k=NC+(z-1)b_k-\alpha+1-\Xi,
\]
次のexact identityを得る：
\[
\widehat m=C A+b_kB+(\alpha-1+\Xi)V.
\]
特に
\[
\begin{aligned}
\widehat m-\mathcal K={}&
(C-b_k-2\alpha-1)A\\
&+(b_k-1)(A+B)+(\alpha-1)(2A+V)\\
&+(\Xi-1)V+[4A+B+V-\mathcal K].
\end{aligned}
\tag{M-MASTER}
\]
最後の括弧以外の前置係数は全てDで非負である。
従ってA、Bと最後の括弧に正の下限を示せばよい。

---

### C8.4.3 q₀≥3のDを排除する

h≥2とする。FIRST-BOUNDSから
\[
A\ge A_0:=\mathcal K-hV-(d-\delta)\rho_j+a_i g,
\]
\[
B\ge B_0:=dR+S(P-d)>0.
\]
置く：
\[
A_0=S A_S+\tau A_\tau+a_iR,
\]
ここで
\[
A_S=h[(h-1)d+\beta+2\delta+2r],\quad
A_\tau=\beta-d+\delta+r.
\]
また
\[
A_S+A_\tau=[h(h-1)-1]d+(h+1)\beta+(2h+1)(\delta+r)>0.
\]
S>τ>0なのでA₀>0を得る。

直接展開により
\[
4A_0+B_0+V-\mathcal K=S H_S+\tau H_\tau+H_c,
\]
ただし
\[
H_S=(3h^2-3h-1)d+(3h+1)\beta+8h\delta+7hr>0,
\]
\[
H_\tau=3\beta-(h+3)d+4\delta+3r,
\]
\[
H_c=a_j[(3h+1)d+3(\delta+r)]
+g[(4h+1)d+4(\delta+r)]>0.
\]
二係数の和は
\[
H_S+H_\tau=(h-2)(3h+2)d
+(3h+4)\beta+(8h+4)\delta+(7h+3)r>0.
\]
従って
\[
S H_S+\tau H_\tau
=(S-\tau)H_S+\tau(H_S+H_\tau)>0.
\]
M-MASTERからm̂>𝒦、すなわちm>n_kとなり矛盾する。

\[
\boxed{\mathcal D\cap\{q_0\ge3\}=\varnothing.}
\tag{HIGH-Q-CLOSED}
\]

従ってDに残るのはh=1、すなわちd≤λ<2dだけである。

---

### C8.4.4 q₀=2では第一点がN=z+1を満たす

λ=d+r、a_i=d+b、b=r+δとすると
\[
n_z=z+\ell_z,\qquad
\ell_z=\left\lceil\frac{zb-\delta+1}{d}\right\rceil\ge1.
\]
Dでℓ_z≥2となる第一点が存在しないことを示す。

反対を仮定し、置く：
\[
\kappa=\left\lfloor\frac{d+\delta-1}{b}\right\rfloor\ge1.
\]
1≤v≤κの候補はℓ_v=1であり、いずれも最初の成功点ではないため
\[
\boxed{S\ge\kappa\tau+g.}
\]
r′=d−κbとおく。slopeの式
\[
V=d\tau-bS\le r'\tau-bg>0
\]
からr′>0。floorの定義から
\[
\boxed{1\le r'\le b-\delta.}
\tag{SMALL-R}
\]

第一点でI≥r′なら、それより前の整数点
\[
(z-\kappa,\ \ell_z-1)
\]
はi係数I−r′≥0、j係数J+S−κτ≥g>0を持つ。そのz添字は正で元のzより小さい。nを許される最小値にすればjは増えるので、第一点の定義に反する。従って
\[
\boxed{0\le I\le r'-1.}
\]
J≤τ−1とNV-ZVを合わせると
\[
A\ge A_1:=((\kappa+1)b+\beta)S+(\beta-r')\tau+a_iR>0,
\]
\[
B\ge B_1:=(\kappa b+\beta)S+dR>0.
\]

A₁のS係数は正で、そのτ係数との和は
\[
(\kappa+1)b+2\beta-r'\ge\kappa b+\delta+2\beta>0.
\]
S>τによりA₁>0。
最後の括弧について
\[
4A_1+B_1+V-\mathcal K=S E_S+\tau E_\tau+E_c,
\]
\[
E_S=(4\kappa+2)b+4\beta+\delta-r'>0,
\]
\[
E_\tau=-b+3\beta+\delta-4r',
\]
\[
E_c=a_j[(4\kappa+3)b+4r']
+g[(5\kappa+4)b+5r']>0.
\]
b≥r′+δを使うと
\[
\begin{aligned}
\kappa E_S+E_\tau
&=(4\kappa^2+2\kappa-1)b+(4\kappa+3)\beta
 +(\kappa+1)\delta-(\kappa+4)r'\\
&\ge(\kappa-1)(4\kappa+5)r'
 +\kappa(4\kappa+3)\delta+(4\kappa+3)\beta>0.
\end{aligned}
\]
S≥κτ+gなので
\[
S E_S+\tau E_\tau=(S-\kappa\tau)E_S+
\tau(\kappa E_S+E_\tau)>0.
\]
M-MASTERから再びm>n_kとなる。

\[
\boxed{q_0=2,\quad N\ge z+2\Longrightarrow\bot.}
\tag{NONLINEAR-FIRST-CLOSED}
\]
従って残るDの全てが
\[
\boxed{q_0=2,\qquad N=z+1.}
\]
を満たす。これはzの全範囲の記号的証明である。

---

### C8.4.5 残る第一点の正確なparameter表示

置く：
\[
k=z-1\ge1,\quad Q=\tau,\quad
\upsilon=Q-1-J\ge0,\quad G=g+\upsilon,\quad E=R+\upsilon,
\]
\[
b=r+\delta,\quad c=r+\beta,\quad
B=kb+c=D_F,\quad a=d-kb.
\]
ここからQはτの略記、υはこの第一点の新しい残余である。静的係数表と検算コードではυをuと記す。

正確な式は
\[
S=kQ+G,\quad\rho_j=(k+1)Q+G,
\]
\[
\rho_k=(k+1)C+kb_k+\chi,
\]
\[
a_i=d+b,\quad b_i=d+c,\quad d=a+kb,
\]
\[
I=d+\delta-1-(k+1)b,\quad J=Q-\upsilon-1.
\]
特に \(a\ge r+1\ge1\).

二つのgenuine packetsは
\[
\boxed{Bn_i+En_j=(k+1)m+\chi n_k,}
\tag{D-LINEAR}
\]
\[
\boxed{m+Qn_j=bn_i+(C+b_k)n_k.}
\tag{INTRINSIC-LINEAR}
\]

### C8.4.5.1 正のpacket determinant

定める：
\[
\mathscr D:=Q\chi-E(C+b_k).
\]
この量の正値性を、このparameter域内で直接示す。

定める：
\[
\begin{aligned}
M_b={}&C[Qk(k+1)+a_j(k+1)+G(2k+1)]\\
&+b_k[Qk^2+a_jk+2Gk]+\chi G>0,\\
M_c={}&C[Q(k+1)+G]+b_k[Qk+G]>0.
\end{aligned}
\]
直接展開により
\[
\boxed{\widehat m-\mathcal I
=-(a+k+1)\mathscr D+(b-1)M_b+(c-1)M_c.}
\]
𝒟≤0なら右辺は非負となりm<n_iに反する。
従って
\[
\boxed{\mathscr D>0.}
\tag{DSCR}
\]

---

### C8.4.6 最小回数のpacketのi-sourceは必ず入る

最小繰返し回数をb_D=f+1とする。
\[
f=\left\lfloor\frac{C-\alpha}{\chi}\right\rfloor\ge1,
\qquad C=\alpha+f\chi+w,\quad 0\le w<\chi.
\]
DSCRから
\[
Q\chi>E(f\chi+T+w),\qquad
\boxed{\theta:=Q-fE\ge1.}
\]
同値に
\[
\boxed{\theta\chi>E(T+w).}
\tag{REMAINDER-SLOPE}
\]

#### i-source適合主張

\[
\boxed{d\ge(f+1)B-\beta+1.}
\tag{I-FIT}
\]
c=r+βなので、同値にa≥fB+r+1。

#### 証明

C8.4.5のparameter表示で他を固定しΦ(a)=m̂−𝒥と置く。直接微分すると
\[
\boxed{\Phi'(a)=-\mathscr D-\rho_k-b_k<0.}
\]
閾値a_*=fB+rを考える。
代入する：
\[
Q=f(a_j+g+\upsilon)+\theta,\quad
C=\alpha+f\chi+w,\quad
\chi=b_k+\alpha+1+\epsilon,\quad\epsilon\ge0,
\]
\[
b=r+\delta,\quad c=r+\beta,\quad G=g+\upsilon.
\]
Φ(a_*)は以下の非負変数に関する非負係数certificateを持つ：
\[
\mathbf y=(f-1,r,\delta-1,\beta-1,g-1,\upsilon,
\alpha-1,w,\theta-1,\epsilon,k-1,a_j-1,b_k-1).
\]
正確には
\[
\boxed{\Phi(a_*)=35+\sum_{\gamma\ne0}c_\gamma\mathbf y^\gamma,
\qquad c_\gamma\in\mathbb Z_{\ge0}.}
\tag{I-POS-CERT}
\]
定数項を含め715単項式である。全係数と全指数を記録した静的表は `APPENDICES/LINEAR/I_FIT_POSITIVE_COEFFICIENTS.json`にある。付録A4に定義式、変数対応、表の再構成法を示す。全係数非負と正の定数項から全parameterで正となる。

従ってΦ(a_*)>0。a≤a_*なら単調減少性からΦ(a)≥Φ(a_*)>0となりm>n_jで矛盾。整数性からa≥a_*+1、従ってI-FITを得る。

閾値a_*は多項式の評価点であり、その点がactual半群や第一点の条件を満たすとは仮定しない。

---

### C8.4.7 最小packet試験で残るj不足

同じΩ_Dの表示にb_D=f+1個のpacketを置換すると
\[
\boxed{
\begin{aligned}
F={}&(f+1)(k+1)m\\
&+[d+\beta-1-(f+1)B]n_i\\
&+(\theta-\upsilon-1)n_j+(\chi-w-1)n_k.
\end{aligned}}
\tag{J-ONLY}
\]
m係数は正、i係数はI-FITにより非負、k係数は0≤w<χにより非負。
従って
\[
\boxed{\theta\ge\upsilon+1\Longrightarrow\bot.}
\]
残る場合は
\[
\boxed{1\le\theta\le\upsilon,\qquad
\Delta_1:=\upsilon+1-\theta\ge1.}
\tag{J-FAIL}
\]
同じactual upperは
\[
\boxed{
F+\Delta_1n_j=(f+1)(k+1)m+
[d+\beta-1-(f+1)B]n_i+(\chi-w-1)n_k
}
\]
というgenuineなzero-j表示を持つ。

このpacket族のi不足は排除された。残るj不足を次の二packet定理へ渡す。

---

### C8.4.8 相補的なgenuine packet

D-LINEARをf回、INTRINSIC-LINEARを一回加えたexact identityは
\[
\boxed{
L_\diamond m+\theta n_j=B_\diamond n_i+(T+w)n_k,
}
\tag{COMPLEMENTARY}
\]
ここで
\[
L_\diamond=1+f(k+1),\qquad B_\diamond=b+fB.
\]
両辺の全係数は非負でありgenuine packet equalityである。

C8.4.5のD-LINEARと本節のCOMPLEMENTARYを、同じΓ,F,m,W上の二つのgenuine packetsとしてE8へ渡す。


## E8 — Euclidean two-packet閉鎖定理

ここで新しい局所packet記号を導入する。C8.4の第一点の添字N,I,Jはこの定理へ継承しない。
共通の \(\delta,\beta,g,\alpha,a_j,b_k\) は正整数、Pは正整数、
\(a_i=P-\beta>0,b_i=P-\delta>0\)、\(R=a_j+g,T=b_k+\alpha\)。
元のHCRと \(W=(P-1)n_i+(R-1)n_j+(T-1)n_k=F+m\) を保持する。
packet係数をH_p、determinantを𝒟_p、下降測度を𝒨と記す。u,θ,w,χは整数とし、u≥1、w≥0、χ≥1を仮定する。


### E8.2.1 定義

全て同じ \(m,n_i,n_j,n_k,F,W\) に対し、以下を仮定する。

\[
\mathsf M=\begin{pmatrix}p&q\\s&t\end{pmatrix},\qquad
p,q,s,t\in\mathbb Z_{\ge1},\qquad pt-qs=1,
\]
\[
L=p+q>M=s+t.
\tag{MATRIX}
\]

\[
r\in\mathbb Z_{\ge0},\qquad
A=p(r+\delta)+q(r+\beta),\quad
B=s(r+\delta)+t(r+\beta).
\tag{SOURCES}
\]

\[
E=R+u,\quad H_p=T+w,\qquad
1\le\theta\le u,\quad w\ge0,\quad \chi\ge1,
\]
\[
\boxed{\mathcal D_p:=\theta\chi-EH_p>0.}
\tag{DET-POS}
\]



二つの genuine equality は
\[
\boxed{Bn_i+En_j=Mm+\chi n_k,}
\tag{DP}
\]
\[
\boxed{An_i+H_p n_k=Lm+\theta n_j.}
\tag{PP}
\]

canonical multipliers には
\[
\boxed{\rho_j=LE+M\theta-a_j,\qquad
\rho_k=L\chi+MH_p-b_k.}
\tag{RHO}
\]
を要求する。\(a_i=P-\beta>0\)、\(b_i=P-\delta>0\) と (HCR)、元の \(W\)-表示も package に含む。

### E8.2.2 定理

**Euclidean two-packet closure theorem.**  
この package と \(m<\min(n_i,n_j,n_k)\) が成立するとき、
\[
\boxed{F\in\Gamma.}
\]
従って \(F\) が gap である package は存在しない。

証明は正整数
\[
\boxed{\mathcal M:=E+\chi}
\]
についての強い帰納法による。\(\mathcal M\) は本書だけの下降測度であり、以前の枝の深さではない。

### E8.2.3 初期残党の埋め込み

C8.4の二packetに
\[
\mathsf M_0=\begin{pmatrix}fk+1&f\\k&1\end{pmatrix}
\]
を取ると、determinant は \(1\)、
\[
L=1+f(k+1)>M=k+1,
\]
\[
A=(fk+1)b+fc=b+fB,
\quad B=kb+c.
\]
さらに
\[
LE+M\theta-a_j=(k+1)Q+g+\upsilon=\rho_j,
\]
\[
L\chi+M(T+w)-b_k=(k+1)C+kb_k+\chi=\rho_k.
\]
従って初期残党はこの package に完全に含まれる。
\(w=0\)、\(w\ge1\)、\(\Delta_0=1\)、\(\Delta_0\ge2\) による取りこぼしはない。

---

### E8.3 終端候補 — SAME W 内で除去すべき packet

\[
\nu=\left\lfloor\frac u\theta\right\rfloor+1\ge2
\]
とする。
(DP) と \(\nu\) 回の (PP) の completed sum は
\[
\boxed{
Zn_i+j_*n_j+k_*n_k=Nm,
}
\tag{TERMINAL-PACKET}
\]
\[
Z=B+\nu A,\quad N=M+\nu L,
\quad j_*=E-\nu\theta,\quad k_*=\nu H_p-\chi.
\]
常に
\[
j_*\le R-1.
\]

終端条件は
\[
\boxed{k_*\le T-1.}
\tag{TERMINAL}
\]
これが成立すれば、次節で証明する \(P\ge Z+1\) により
\[
\boxed{
F=(N-1)m+(P-1-Z)n_i+(R-1-j_*)n_j+(T-1-k_*)n_k
\in\Gamma.
}
\tag{FINAL-F}
\]

#### 同じW内でのactual置換

\(j_*\)、\(k_*\) は負の場合もある。その場合、(TERMINAL-PACKET) を
\[
Zn_i+(j_*)_+n_j+(k_*)_+n_k
=Nm+(-j_*)_+n_j+(-k_*)_+n_k
\]
と書き直す。両辺の全係数は非負である。

SAME \(W\) の既存 face は左 source を coefficientwise に含む。
この source を右辺へ置換することで \(W\) の新しい genuine factorization を得る。
\(N\ge1\) なので、その最終ベクトルから **一個の \(m\)** を除去して (FINAL-F) を得る。
追加した external packet は存在せず、未除去の shift もない。

---

### E8.4 終端の i-source-fit — multiplicity による全域証明

### E8.4.1 行列の正値順序

(MATRIX) から
\[
\boxed{p\ge s+1,\qquad q\ge t.}
\tag{ORDER}
\]

実際、\(p\le s\) なら determinant が正であるため \(q<t\) であり、\(L<M\) となる。
したがって \(p>s\)。次に \(q<t\) なら \(p=s+a\)、\(t=q+b\)、\(a,b\ge1\) と書けて
\[
pt-qs=sb+aq+ab\ge s+q+1>1,
\]
矛盾。

### E8.4.2 Cross products と正しい scale

\[
\mathcal I=\rho_j\rho_k-a_jb_k,
\quad \mathcal J=a_i\rho_k+b_ib_k,
\quad \mathcal K=b_i\rho_j+a_ia_j.
\]
(HCR) の二行は独立であり、共通の \(\sigma>0\) に対し
\[
(n_i,n_j,n_k)=\sigma(\mathcal I,\mathcal J,\mathcal K).
\]
\(\sigma=1\) や gcd の仮定を置かない。

定める：
\[
I_0=EA+\theta B,\quad J_0=\chi A+H_pB,
\]
\[
M_0=LE+M\theta=\rho_j+a_j,
\quad K_0=L\chi+MH_p=\rho_k+b_k.
\]
二つの packet から
\[
I_0n_i=M_0m+\mathcal D_p n_k.
\]
また
\[
AM-BL=(pt-qs)(\delta-\beta)=\delta-\beta,
\]
\[
I_0K_0-M_0J_0=-\mathcal D_p(\delta-\beta).
\]
これらから、\(m=\sigma\widehat m\) に対し
\[
\boxed{
\widehat m=I_0\rho_k-a_jJ_0-\mathcal D_p(P-\delta).
}
\tag{M-HAT}
\]

\[
\Phi(P):=\widehat m-\mathcal K
\]
は \(P\) の一次式で、他の packet parameters を固定すると
\[
\boxed{\Phi'(P)=-(\mathcal D_p+M_0)<0.}
\tag{MONOTONE}
\]

### E8.4.3 完全に指定された静的正値多項式

終端条件下で
\[
u=(\nu-1)\theta+z,\quad0\le z<\theta,
\quad h=\theta-z\ge1,
\]
\[
x=\chi-\nu H_p+T-1\ge0
\]
と置く。
すなわち
\[
\theta=h+z,
\quad E=\nu(h+z)+R-h,
\quad H_p=T+w,
\quad\chi=\nu(T+w)-T+1+x.
\tag{TERMINAL-SUB}
\]

次の polynomial を定義する。
\[
\mathcal P:=\Phi(B+\nu A),
\tag{POS-POLY}
\]
ここで \(\Phi\) は (M-HAT) と
\[
\mathcal K=(P-\delta)\rho_j+(P-\beta)a_j
\]
による完全に明示された式であり、\(E,H_p,\theta,\chi\) には (TERMINAL-SUB) を代入する。

(ORDER) に従い、独立な非負変数を次のように置く。
\[
s=s_0+1,\ t=t_0+1,\
p=s_0+2+p_0,\ q=t_0+1+q_0,
\]
\[
r=r_0,\ \delta=\delta_0+1,\ \beta=\beta_0+1,
\quad a_j=a_{j0}+1,\quad g=g_0+1,
\]
\[
\alpha=\alpha_0+1,\ b_k=b_{k0}+1,
\quad\nu=\nu_0+2,\ h=h_0+1,
\quad z=z_0,\ x=x_0,\ w=w_0.
\]
すると exact polynomial identity として
\[
\boxed{
\mathcal P=63+\sum_{\gamma\ne0}c_\gamma\mathbf y^\gamma,
\qquad c_\gamma\in\mathbb Z_{\ge0}.
}
\tag{STATIC-POS}
\]

全 coefficient/exponent table は付録 `APPENDICES/EUCLIDEAN/TERMINAL_POSITIVITY_COEFFICIENTS.json` に保存した。
変数順は

```text
p0, q0, s0, t0, r0, delta0, beta0, aj0, g0, alpha0, bk0, nu0, h0, z0, x0, w0
```

である。表は **定数項を含む3,234単項式、総次数7、定数63**。
通常の verifier はこの静的 table を読み込み、上の独立した定義式から展開した polynomial と **全係数が一致すること**を確認する。
全係数は非負、定数は正なので、\(\mathcal P>0\) は全パラメータに対する記号的な証明である。

この positivity は (ORDER) だけを満たす独立変数領域に成立し、その polynomial 展開に determinant-one の追加条件を課す必要はない。
ただし、実際の \(\widehat m\) を (M-HAT) に同定する段階では determinant-one を正しく使用している。

数値半群のパラメータを有限範囲で走査したものではない。閾値 \(P=B+\nu A\) 自身が実際の半群を与えるとも仮定しない。polynomial evaluation と (MONOTONE) だけを使う。

### E8.4.4 i-fit の帰結

もし \(P\le B+\nu A\) なら
\[
\Phi(P)\ge\Phi(B+\nu A)=\mathcal P>0.
\]
したがって \(m>n_k\)、multiplicity に矛盾する。
整数性により
\[
\boxed{P\ge B+\nu A+1.}
\tag{I-FIT}
\]
これで (FINAL-F) の四係数が全て非負になった。
特に終端の最終表示は
\[
\boxed{
F=(M+\nu L-1)m+(P-1-B-\nu A)n_i+(h-1)n_j+x n_k.
}
\tag{FINAL-EXACT}
\]

---

### E8.5 終端に入らない場合の厳密な Euclidean transformation

終端条件の否定は、整数性により
\[
\nu H_p-\chi\ge T.
\tag{FAIL}
\]

\[
e=\left\lfloor\frac E\theta\right\rfloor\ge1,
\quad\rho=E-e\theta,
\quad\kappa=\chi-eH_p
\]
とする。\(0\le\rho<\theta\) であり、
\[
\mathcal D_p=\theta\kappa-\rho H_p>0
\]
から \(\kappa\ge1\)。

\(\nu\le e+1\)。もし \(\nu\le e\) なら \(\nu H_p-\chi\le-\kappa<0\) となり (FAIL) に反する。従って
\[
\nu=e+1.
\]
\(\lfloor u/\theta\rfloor=e\)、\(u=E-R\) より \(\rho\ge R\)。
(FAIL) は \(H_p-\kappa\ge T\)、すなわち \(\kappa\le w\) を与える。
まとめると
\[
\boxed{R\le\rho<\theta,\qquad1\le\kappa\le w.}
\tag{REMAINDERS}
\]
特に failure の場合には \(w\ge1\) である。従ってw=0なら終端条件が必ず成立する。

(DP) と \(e\) 回の (PP) を合わせると、
\[
\boxed{(B+eA)n_i+\rho n_j=(M+eL)m+\kappa n_k.}
\tag{NEW-PACKET}
\]
両辺は全係数非負である。

ここで \(j,k\) の名前を交換し、次の完全な変換を行う。

\[
n_i'=n_i,\quad n_j'=n_k,\quad n_k'=n_j,
\quad m'=m,\ F'=F,\ W'=W,
\]
\[
a_i'=b_i,\ b_i'=a_i,
\quad a_j'=b_k,\ b_j'=a_k,
\quad a_k'=b_j,\ b_k'=a_j,
\]
\[
\delta'=\beta,\ \beta'=\delta,
\quad g'=\alpha,\ \alpha'=g,
\quad R'=T,\ T'=R,\ P'=P,\ r'=r.
\tag{COLOR}
\]

packet parameters は
\[
\boxed{
E'=H_p,\quad\theta'=\kappa,\quad
\chi'=\theta,\quad H_p'=\rho,
\quad u'=w,\quad w'=\rho-R.
}
\tag{EUCLID}
\]
source matrix は
\[
\boxed{
\mathsf M'=\begin{pmatrix}t+eq&s+ep\\q&p\end{pmatrix}.
}
\tag{M-UPDATE}
\]

---

### E8.6 全仮定の保存と well-foundedness

### E8.6.1 行列・source・level

新しい行列の全成分は正であり、
\[
(t+eq)p-(s+ep)q=pt-qs=1.
\]
\[
L'=M+eL>M'=L.
\]
色交換で \(r+\delta\) と \(r+\beta\) が入れ替わるため
\[
A'=B+eA,\qquad B'=A.
\]
従って (SOURCES) も保存される。

### E8.6.2 二つの genuine packets

新しい (DP) は、色交換した旧 (PP) そのもの：
\[
B'n_i'+E'n_j'=An_i+H_p n_k=Lm+\theta n_j=M'm'+\chi'n_k'.
\]
新しい (PP) は、色交換した (NEW-PACKET)：
\[
A'n_i'+H_p'n_k'=(B+eA)n_i+\rho n_j
=(M+eL)m+\kappa n_k=L'm'+\theta'n_j'.
\]
よって、signed intermediate を actual とする仮定は不要。

### E8.6.3 正値性・multipliers・canonical relations

(REMAINDERS) により
\[
E'=R'+u',\quad H_p'=T'+w',\quad
1\le\theta'\le u',\quad w'\ge0,
\]
\[
\mathcal D_p'=\theta'\chi'-E'H_p'=\kappa\theta-H_p\rho=\mathcal D_p>0.
\]
また
\[
L'E'+M'\theta'-a_j'=\rho_k=\rho_j',
\]
\[
L'\chi'+M'H_p'-b_k'=\rho_j=\rho_k'.
\]
(HCR) は二行の交換である。
\(a_i'=P'-\beta'\)、\(b_i'=P'-\delta'\) も保存される。

W は同じ値だけでなく、同じ canonical face の名前交換：
\[
W=(P-1)n_i+(R-1)n_j+(T-1)n_k
=(P'-1)n_i'+(R'-1)n_j'+(T'-1)n_k'.
\]
元の semigroup、Frobenius 数、multiplicity 条件も変わらない。

### E8.6.4 厳密な下降

新しい測度は
\[
\mathcal M'=E'+\chi'=H_p+\theta.
\]
旧表示 \(E=e\theta+\rho\)、\(\chi=eH_p+\kappa\) より
\[
\boxed{
\mathcal M-\mathcal M'
=(e-1)(H_p+\theta)+\rho+\kappa>0.
}
\tag{DESCENT}
\]

正整数が毎回少なくとも一つ減るので、failure が無限に続くことはない。
強い帰納法により、どの abstract state も有限回の failure transformation 後に terminal state に到達し、その state の SAME W 内で (FINAL-EXACT) を得る。
色交換は生成元の名前だけなので、これは元の \(\Gamma\) における \(F\in\Gamma\) である。

これでE8の定理を証明した。

---

## C8.5 — CHAINの閉鎖への結合

R7は全actual CHAINからC8.1のCOREを供給する。C8.2でC=αを排除し、
strictの場合をU∨Dへ分ける。UはC8.3で排除した。
DはC8.4でq₀=2かつN=ζ̂+1へ縮約され、θ≥υ+1なら同じFの非負表示で矛盾する。
残る1≤θ≤υではE8.2.3のdeterminant-one行列によりE8の全仮定が満たされる。
E8の停止と終端source-fitから、元のΓにおけるFの非負表示を得る。
従ってCHAINは存在しない。
