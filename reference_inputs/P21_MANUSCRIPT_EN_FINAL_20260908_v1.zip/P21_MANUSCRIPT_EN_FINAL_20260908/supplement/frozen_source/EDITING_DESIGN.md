# 編集設計 — 本文作成前の固定事項

2026-09-07。入力 00→18→19→20→21 の指定順の読了後に作成。
数学の採択は入力台帳のまま。以下は編集上の設計である。

## A. 記号辞書

| 記号 | 採用する意味／範囲 | 元記号と扱い |
|---|---|---|
| Γ,m,F,W | 元の数値半群、multiplicity、Frobenius数、F+m | 全章を通じ固定 |
| H | 三生成 tail 半群 | scalar H と衝突させない |
| Q(Γ) | PF(Γ)からFを除く集合 | scalar Q は局所命名・節の入口で定義 |
| 𝒜,𝒜₀,𝒜₁ | Apéry集合とcanonical二層 | canonical本文のAから変更 |
| a_r,b_r,ρ_r | Herzog正規形、ρ_r=a_r+b_r | 非対称全章で不変 |
| A_r(λ),B_r(μ) | Herzog色・missing direction・depth | actual PF行に限定して使用 |
| P,R,T | Wのbox係数、T=b_k+α | PATHにも同じW-box規約 |
| q_L,q_A,q_B,q_R | PATHのladderラベル | q_A=A_k(ν),q_B=B_i(λ)。色添字ではない |
| H₀,J₀ | PATH central returnのj係数 | source S117のscalar H,Jを局所改名 |
| κ,τ | PATH旧endpoint係数 | 本文ではP,Tへ統一 |
| λ,δ,β,g,α | CHAIN正整数package | matched-pair単独ではg,α=0も許す |
| d,S,C | CORE-ROOTの係数 | canonical Tと混同しない |
| Δ₀,τ₀,q₀,e₀ | CENTRAL intrinsic first-candidate | 有効範囲を入口に明記 |
| N,I,J,χ,Ξ | CENTRAL first-point/packet | 後続の局所再定義は明示 |
| H_p | Euclidean packetのk-source係数T+w | S302 scalar Hから変更 |
| 𝒟_p | Euclidean packet determinant θχ−EH_p | S302 scalar Dから変更 |
| 𝒨 | Euclidean下降測度E+χ | S302の𝒣から変更 |
| T（S3内のみ） | SYMの二生成半群 | local scopeを明示して原記号を保持。添字内を含む大域renameは行わない |
| C_box | boxed dynamicsの3×3行列 | 付録局所C。CORE係数とは別scope |

局所多項式の変数順は静的certificateの原順序を保持する。renameは数学的仮定の変更ではない。

## B. 定理番号計画

| ID | 内容 | 入力台帳ID |
|---|---|---|
| T1 | 主定理：canonical edim4 ⇒ t≤4 | N13 |
| C2 | 二層、KEY、actual四行、tail gcd | N01 |
| S3 | 対称tail排除 | N02 |
| G4.1–G4.11 | atlas、caps、kernel、pair geometry、四行分類、scalar抽出 | N03,N07 |
| M4 | root-free matched-pair level rigidity | N04 |
| A1 | MINBOX | N05 |
| A2 | boxed dynamicsとCOLOR-CAP | N06 |
| P5.1 | PATHのMSR split | PATH_MSR_BODY |
| P5.2 | PAIRのstrong-port化 | PATH_MSR_BODY |
| P5.3 | root正規化、endpoint-level、PAIR閉鎖 | N11 |
| P5.4 | PFREE符号 | N14 |
| P5.5 | PF-FIXと直接吸収 | PATH_MSR_BODY,E01 |
| P5.6 | double-unit閉鎖 | N12 |
| P5.7 | PATH結合 | E01 |
| T6 | TYPE II全域 | N08 |
| R7 | CHAINからCORE-ROOT | N09 |
| C8.1 | COREから後期入力 | N10 |
| C8.2 | first-packet、window、boundary | S286 |
| C8.3 | U閉鎖 | S289 §§1–4 |
| C8.4 | D high-q、nonlinear、linear first | S293 §§1–8 |
| E8 | Euclidean two-packet閉鎖 | E02,S302 §§2–6 |
| I9 | 全分岐の結合と主定理 | N13 |

IDは安定識別子。各定理内の小節はその証明のlocal番号とし、他定理への参照はIDを併記する。

## C. 章と採用本文

| 章 | 採用する入力 |
|---|---|
| 01 | 19 §1、20 standard_external_inputs、各補完の外部定理の適用形 |
| 02 | review_supplements/P21_LOCAL_CANONICAL_KEY.md |
| 03 | review_pass10/SYM_AUDIT.md 数学本文 §§1–10 |
| 04 | FIVE_SHAPE_COMPLETION.md、HIGH_ENTRY_AUDIT.md §§1–5とextra-arm帰結 |
| 付録A1/A2 | COLOR_CAP_DEPENDENCY_AUDIT.md §§1–9、COLOR_CAP_DYNAMICS_AUDIT.md §§0–10.1 |
| 05 | S117 §§3–4,6–8、S118 §§7–8、S328後半 §§5–6、PATH補完3本文 |
| 06 | TYPEII_COMPLETION.md §§1–5 |
| 07 | CHAIN_ROOT_PROGRESS.md §§1–5 |
| 08 | CENTRAL_ENTRY_AUDIT.md §§0–6、S286必要区間、S289 §§1–4と付録A、S293 §§1–8、S302 §§2–6 |
| 09/10 | 19 spine、20台帳、INTEGRATION_SECOND_REVIEW.md |

## D. 圧縮／置換決定

- SQとTYPE Iの別章を作らず、M4とG4のsingleton補題から排除。
- 対称caseはstable core→RAW4→二分岐の採用本文に一本化。
- PATHのF-ROUTE、first-completion routing、pair普遍存在の旧主張は採用しない。
- PFREEのendpoint再生表示は符号確認前にactualと呼ばない。central kernelからP5.4へ直接接続。
- TYPE IIのlow/high-ν、Branch A/B/CはT6一つに置換。
- CHAINの旧nonmatch/HIGH/ORIGINAL POSJ/K1–K3/A1J/S1/equality/mismatchを依存に戻さない。
- kernel basisをG4.3で一度証明し、CENTRALから参照。
- MINBOX/COLOR-CAPと長い静的係数表は付録。本文の適用仮定・符号・SAME-element接続は残す。
- S302の旧歴史的CHAIN統合 §§7–9は採用せずI9で現行三分岐を結合。

## E. 依存骨格

C2 → S3。
C2＋Herzog → G4局所補題 → M4。
C2＋Herzog＋White → A1 → A2。
G4局所補題＋M4＋A2 → G4四行分類・scalar抽出。
G4分類 → P5 / T6 / R7。
R7 → C8.1 → C8.2 → C8.3 → C8.4 → E8。
S3＋P5＋T6＋E8 → I9。

構造上の循環はない。source内に残る過去時点の未完了宣言を数学的仮定として取り込まない。

## Checkpoint 1

WHAT WAS EDITED: 記号、ID、章-source対応、依存骨格を固定。
SOURCE MATERIAL USED: 指定入口5文書およびそこで指定された局所本文。
MATHEMATICAL CONTENT CHANGED?: なし。
NOTATION CHANGES: 上表。
DEPENDENCY CHANGES: 新規数学入力なし。原台帳のbody groupを章内IDに細分化。
COMPRESSION DECISIONS: 上表D。
OPEN EDITORIAL ISSUES: 本文への実装、参照検査、長いcertificateの移植が未完。
NEXT STEP: 01–04本文と付録A1/A2を作成。
