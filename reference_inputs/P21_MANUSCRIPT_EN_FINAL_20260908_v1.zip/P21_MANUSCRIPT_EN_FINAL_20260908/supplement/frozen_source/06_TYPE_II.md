# 06 — TYPE IIの全域排除

**T6.** G4.11.3の全parameter範囲を以下の一つの二return証明で排除する。

### T6.1 正確な入力定理

\(\Gamma=\langle m,n_i,n_j,n_k\rangle\) は数値半群、\(F\) はそのFrobenius数、\(H=\langle n_i,n_j,n_k\rangle\) とする。正整数 \(a_r,b_r\) と \(\rho_r=a_r+b_r\) に対して

\[
\rho_i n_i=b_jn_j+a_kn_k,\qquad
\rho_j n_j=a_in_i+b_kn_k,\qquad
\rho_k n_k=b_in_i+a_jn_j
\tag{H}
\]

が成立し、\(\rho_r\) は \(n_r\) の他の2生成元に関する最小の正の critical multiplier とする。

整数 \(\lambda,\mu,\nu\) は

\[
1\le\lambda\le a_i-1,\qquad \lambda\le b_i,\qquad
1\le\mu\le b_j-1,\qquad
1\le\nu\le a_k-1
\tag{RANGES}
\]

を満たす。置く

\[
P=\rho_i-\lambda,\quad R=\rho_j-\mu,\quad T=\rho_k-\nu,
\quad g=b_j-\mu\ge1.
\]

同じ実際の \(F,m\) に対して

\[
W=F+m=(P-1)n_i+(R-1)n_j+(T-1)n_k
\tag{W}
\]

が成立する。以下の singleton は実際の pseudo-Frobenius 元であり、missing directions が \(j,k\) である：

\[
q_S=-n_i+(R-1)n_j+(T-1)n_k\in PF(\Gamma),
\quad q_S+n_j\notin H,\quad q_S+n_k\notin H.
\tag{S}
\]

さらに

\[
f_A=(\rho_i-1)n_i+(a_j-1)n_j-n_k
=(a_i-1)n_i-n_j+(\rho_k-1)n_k,
\]

\[
q_{A_i}=f_A-\lambda n_i\notin\Gamma,
\qquad q_{A_k}=f_A-\nu n_k\notin\Gamma.
\tag{A-GAPS}
\]

**定理：この入力配置は存在しない。**

G4.11.3のTYPE II配置はこの入力を満たす。証明では \(B_j\) の actual return は不要だが、その arm が上記の \(\mu\) と canonical \(W\) の由来となる。

### T6.2 2本の actual singleton returns

\(q_S\in PF(\Gamma)\) なので、\(q_S+n_j,q_S+n_k\in\Gamma\)。各 factorization に、その加えた生成元は含まれない。例えば \(q_S+n_j\) の \(n_j\)-係数が正なら、同じ factorization から \(n_j\) を1個除いて \(q_S\in\Gamma\) となるためである。

したがって

\[
q_S+n_j=\ell m+A n_i+C n_k,
\qquad
q_S+n_k=h m+D n_i+B n_j
\tag{SJ/SK}
\]

と書ける。ここで \(A,B,C,D\ge0\)、\(\ell,h\ge1\)。最後の正値性は missing-direction 条件より従う。\(m\)-係数が0なら当該元が \(H\) に入ってしまう。

canonical singletonとの比較から

\[
\ell m=-(A+1)n_i+Rn_j+(T-1-C)n_k,
\tag{JR}
\]

\[
hm=-(D+1)n_i+(R-1-B)n_j+Tn_k.
\tag{KR}
\]

### T6.3 Endpoint caps

\(q_S+Pn_i=W\) なので、SJより

\[
F=(\ell-1)m+(P+A)n_i-n_j+C n_k.
\]

\(-a_in_i+\rho_jn_j-b_kn_k=0\) を加えて

\[
F=(\ell-1)m+(b_i-\lambda+A)n_i+(\rho_j-1)n_j+(C-b_k)n_k.
\]

\(\lambda\le b_i\) より、もし \(C\ge b_k\) なら全係数非負となり \(F\in\Gamma\)。よって

\[
0\le C\le b_k-1.
\tag{C-CAP}
\]

SKより同様に

\[
F=(h-1)m+(P+D)n_i+B n_j-n_k
\]

へ \(-b_in_i-a_jn_j+\rho_kn_k=0\) を加えると

\[
F=(h-1)m+(a_i-\lambda+D)n_i+(B-a_j)n_j+(\rho_k-1)n_k.
\]

\(a_i-\lambda\ge1\) なので

\[
0\le B\le a_j-1.
\tag{B-CAP}
\]

ここまでの補正は signed identity として行い、矛盾に使う場合のみ全最終係数が非負であることを確認した。

### T6.4 新しい統一 cap：\(A,D\le b_i-1\)

置く

\[
\eta=\nu-b_k,\qquad \theta=\mu-a_j.
\]

canonical relationsから

\[
f_A-q_S=\mu n_j+\eta n_k.
\tag{ANCH-A}
\]

また

\[
f_B=(\rho_i-1)n_i-n_j+(b_k-1)n_k,
\qquad f_B-q_S=\theta n_j+\nu n_k.
\tag{ANCH-B}
\]

\(f_B\) の gap status は仮定も使用もしない。これは値の恒等式としてのみ用いる。

### T6.4.1 \(\eta\ge1\)

SJ/SKを同じ \(f_A\) へ持ち上げると

\[
f_A=\ell m+A n_i+(\mu-1)n_j+(C+\eta)n_k,
\]

\[
f_A=hm+D n_i+(B+\mu)n_j+(\eta-1)n_k.
\]

いずれも genuine factorization。もし \(A\ge\lambda\) または \(D\ge\lambda\) なら、その同じ factorization から \(\lambda n_i\) を除いて \(q_{A_i}\in\Gamma\)。従って

\[
A,D\le\lambda-1\le b_i-1.
\]

### T6.4.2 \(\theta\ge1\)

\(q_{A_k}=f_A-\nu n_k=q_S+\mu n_j-b_kn_k\) を SJ と組み合わせ、\(\mathcal R_k\) を completed identity として加えると

\[
\boxed{
q_{A_k}=\ell m+(A-b_i)n_i+(\mu-a_j-1)n_j+(C+a_k)n_k.
}
\tag{AK-J}
\]

したがって \(A\ge b_i\) なら全係数が非負となって \(q_{A_k}\in\Gamma\)。よって \(A\le b_i-1\)。

SKからは同じ操作で

\[
\boxed{
q_{A_k}=hm+(D-b_i)n_i+(B+\mu-a_j)n_j+(a_k-1)n_k.
}
\tag{AK-K}
\]

\(D\ge b_i\) ならやはり genuine な gap factorization になる。従って \(D\le b_i-1\)。

AK-J/AK-Kの使用には \(\eta\) の符号を一切仮定していない。

### T6.4.3 \(\eta=\theta=0\)

SJから

\[
f_A=\ell m+A n_i+(\mu-1)n_j+C n_k
\]

は genuine。従って \(A\le\lambda-1\le b_i-1\)。

AK-Kでは \(B+\mu-a_j=B\ge0\) だから \(D\le b_i-1\) も従う。

### T6.4.4 残る符号領域は singleton status に反する

- \(\eta=0,\theta\le-1\)：\(\mu\le a_j-1\) であり
  \[
  q_S+n_k=(\rho_i-1)n_i+(a_j-\mu-1)n_j\in H,
  \]
  missing \(k\) に反する。
- \(\theta=0,\eta\le-1\)：\(\nu\le b_k-1\) であり
  \[
  q_S+n_j=(\rho_i-1)n_i+(b_k-\nu-1)n_k\in H,
  \]
  missing \(j\) に反する。
- \(\eta,\theta\le-1\)：
  \[
  q_S=(\rho_i-1)n_i+(-\theta-1)n_j+(-\eta-1)n_k\in H\subseteq\Gamma,
  \]
  gap status に反する。

この整数符号分岐は網羅的。以上より

\[
\boxed{0\le A,D\le b_i-1.}
\tag{UNIFORM-I-CAP}
\]

### T6.5 Return levelsの全分岐

### T6.5.1 \(\ell=h\)

JR−KRより

\[
(D-A)n_i+(B+1)n_j=(C+1)n_k.
\]

\(D\ge A\) なら \(1\le C+1\le b_k<\rho_k\) が \(n_k\)-criticality に反する。\(D<A\) なら

\[
(B+1)n_j=(A-D)n_i+(C+1)n_k
\]

であり \(1\le B+1\le a_j<\rho_j\) が \(n_j\)-criticality に反する。

ここでは \(m\)-係数は完全に消去されている。

### T6.5.2 \(\ell>h\)

SJに由来するFの式にKRをちょうど一度代入し、

\[
\boxed{
F=(\ell-h-1)m+(P+A-D-1)n_i+(R-2-B)n_j+(C+T)n_k.
}
\tag{ABS-L}
\]

係数は

\[
\ell-h-1\ge0,
\quad P+A-D-1\ge P-b_i=a_i-\lambda\ge1,
\]

\[
R-2-B\ge R-a_j-1=g-1\ge0,
\quad C+T\ge0.
\]

よって \(F\in\Gamma\)、矛盾。

### T6.5.3 \(h>\ell\)

逆にSKのFの式にJRを一度代入して

\[
\boxed{
F=(h-\ell-1)m+(P+D-A-1)n_i+(B+R)n_j+(T-2-C)n_k.
}
\tag{ABS-R}
\]

ここでも

\[
h-\ell-1\ge0,
\quad P+D-A-1\ge P-b_i=a_i-\lambda\ge1,
\]

\[
B+R\ge0,
\quad T-2-C\ge T-b_k-1=a_k-\nu-1\ge0.
\]

従って \(F\in\Gamma\)、矛盾。

3つの場合を尽くしたので入力配置は不存在。

\[
\boxed{\textbf{TYPE II CLOSED}}
\]
