# 07 — CHAINから同じ配置のCORE-ROOTへ

## R7 — unit rootの存在

G4.11.2のstrict CHAINに対し、同じΓ,F,m,Wと四つのactual PF行を保持して、必要なら完全な色交換の後に
\[
\boxed{m+dn_i=Sn_j+Cn_k,\quad1\le d\le\lambda,\ S\ge g+1,\ C\ge\alpha}
\]
を得る。以下ではこの結論をCORE-ROOTと呼ぶ。

### R7.1 正確な仮定

Γ=⟨m,n_i,n_j,n_k⟩、m<min(n_i,n_j,n_k)、F は Frobenius number、W=F+m。

正の canonical Herzog data は

\[
ρ_i n_i=b_j n_j+a_k n_k,\quad
ρ_j n_j=a_i n_i+b_k n_k,\quad
ρ_k n_k=b_i n_i+a_j n_j,
\quad ρ_r=a_r+b_r.
\tag{HCR}
\]

λ,δ,β,g,α≥1 として

\[
a_i=λ+δ,\quad b_i=λ+β,\quad
P=ρ_i-λ=a_i+β=b_i+δ,
\quad R=a_j+g,\quad T=b_k+α.
\]

同じ actual W の表示

\[
W=(P-1)n_i+(R-1)n_j+(T-1)n_k
\tag{W}
\]

を持ち、次の四つが actual PF gaps であるとする。

\[
q_A=(P-1)n_i+(a_j-1)n_j-n_k,
\]
\[
q_B=(P-1)n_i-n_j+(b_k-1)n_k,
\]
\[
q_J=(b_i-1)n_i+(R-1)n_j-n_k,
\]
\[
q_K=(a_i-1)n_i-n_j+(T-1)n_k.
\tag{CHAIN-PF}
\]

M4 により

\[
P n_i=Lm+(t+1)n_j+(u+1)n_k,
\quad L\ge1,\quad t,u\ge0.
\tag{PFIBER}
\]

が genuine に成立する。

本 root-existence 証明自体は q_A と PFIBER だけを使用し、他の三つの gap は color reversal と downstream theorem の scope を確保するために保持する。

### R7.2 名前を固定した actual h_A 上での選択

\[
h_A=q_A+m.
\]

PF 性から h_A∈Γ。どの Γ-factorization も m-coordinate はゼロ。正なら同じ factorization から m を一個除いて q_A∈Γ となる。従って h_A∈H=⟨n_i,n_j,n_k⟩。

全ての H-factorizations of this same h_A の中で i-coordinate が最大のものを一つ選ぶ。

\[
h_A=Xn_i+Yn_j+Zn_k,
\quad X,Y,Z\ge0.
\tag{MAX-I}
\]

各生成元は正なので factorization 集合は有限かつ非空であり、この最大値は明示的に存在する。

### R7.2.1 X≤P−1

PFIBER より

\[
P n_i-m=(L-1)m+(t+1)n_j+(u+1)n_k\inΓ.
\]

もし X≥P なら、同じ actual h_A 表示に coefficientwise に含まれる Pn_i を上の表示で置き換えることにより

\[
q_A=h_A-m=(h_A-Pn_i)+(Pn_i-m)\inΓ,
\]

矛盾。従って X≤P−1。

### R7.2.2 Y≤ρ_j−1、Z≤ρ_k−1

もし Y≥ρ_j なら、含まれた ρ_jn_j を a_in_i+b_kn_k に置き換えた same-h_A factorization は i-coordinate が X+a_i>X になる。MAX-I に反する。

もし Z≥ρ_k なら R_k により同様に X+b_i>X になる。従って

\[
0\le X\le P-1,\quad 0\le Y\leρ_j-1,\quad0\le Z\leρ_k-1.
\tag{BOX}
\]

generic connectivity や uniqueness は不要。必要なのは、同じ元に対するこの二つの明示的な合法置換だけ。

### R7.3 初期 root と上下界

canonical q_A と MAX-I を比較し

\[
d=P-1-X,\quad S=Y-a_j+1,\quad C=Z+1
\]

と置くと exact に

\[
m=-d n_i+S n_j+C n_k.
\tag{ROOT0}
\]

BOX から

\[
0\le d\le P-1,\quad 1-a_j\le S\le b_j,
\quad1\le C\leρ_k.
\tag{INITIAL}
\]

この時点では S の非負性を仮定しない。

### R7.3.1 S≥g

W を R_k により書き換え、F=W−m と ROOT0 を用いると

\[
F=(δ+d-1)n_i+(g-S-1)n_j+(ρ_k+T-C-1)n_k.
\tag{F-S}
\]

もし S≤g−1 なら、全係数は非負：δ+d−1≥0、g−S−1≥0、ρ_k+T−C−1≥T−1≥0。よって F∈Γ、矛盾。

従って S≥g≥1。

### R7.3.2 C≥α

同様に W を R_j により書き換えると

\[
F=(β+d-1)n_i+(ρ_j+R-S-1)n_j+(α-C-1)n_k.
\tag{F-C}
\]

もし C≤α−1 なら、β+d−1≥0、

\[
ρ_j+R-S-1\geρ_j+R-b_j-1=a_j+R-1\ge0,
\]

かつ α−C−1≥0。従って F∈Γ、矛盾。

ゆえに C≥α≥1。

### R7.3.3 d≥1

d=0 なら m=S n_j+C n_k、しかも S,C≥1 なので m≥n_j+n_k。multiplicity の m<min(n_j,n_k) に反する。

### R7.3.4 d≤λ

F=W−m と ROOT0 から

\[
F=(P+d-1)n_i+(R-S-1)n_j+(T-C-1)n_k.
\]

ここへ R_i を completed zero identity として一回入れると

\[
\boxed{
F=(d-λ-1)n_i+(R+b_j-S-1)n_j+(T+a_k-C-1)n_k.
}
\tag{F-D}
\]

もし d≥λ+1 なら、全係数が非負。実際

\[
R+b_j-S-1\ge R-1\ge0,
\]

\[
T+a_k-C-1\ge T+a_k-ρ_k-1
=T-b_k-1=α-1\ge0.
\]

従って F∈Γ、矛盾。

以上で

\[
\boxed{1\le d\leλ,\qquad g\le S\le b_j,\qquad α\le C\leρ_k.}
\tag{ROOT-BOX}
\]

を得た。signed intermediate は actual と呼ばず、各矛盾で最終 F の全係数を確認している。

### R7.4 少なくとも一方は strict

もし S=g かつ C=α なら、ROOT0 を F=W−m に代入して

\[
F=(P+d-1)n_i+(a_j-1)n_j+(b_k-1)n_k\inΓ,
\]

となる。従って

\[
S\ge g+1\quad\text{or}\quad C\geα+1.
\tag{STRICT}
\]

S≥g+1 なら既に CORE-ROOTの向きである。残る S=g,C≥α+1 では次の完全な色交換をする。

### R7.5 Color reversal の全保存

新記号を

\[
i'=i,\quad j'=k,\quad k'=j,
\]
\[
a_i'=b_i,\ b_i'=a_i,\quad
a_j'=b_k,\ b_j'=a_k,\quad
a_k'=b_j,\ b_k'=a_j
\]

と定める。対応する scalars は

\[
λ'=λ,\quadδ'=β,\quadβ'=δ,
\quad g'=α,\quadα'=g,
\]
\[
P'=P,\quad R'=T,\quad T'=R,
\quad d'=d,\quad S'=C,\quad C'=S.
\]

すると HCR は全て同じ exact equations の名前交換となる。W 自身も

\[
(P'-1)n_{i'}+(R'-1)n_{j'}+(T'-1)n_{k'}
\]

で元の同じ W のまま。Γ,F,m は変更しない。

actual PF gaps は

\[
q_A'=q_B,\qquad q_B'=q_A,\qquad
q_J'=q_K,\qquad q_K'=q_J
\]

に交換される。従って四つの actuality/gap statuses も完全保存。

PFIBER は t'=u,u'=t として同じ元 Pn_i の same nonnegative factorization。

ROOT0 は

\[
m+d'n_{i'}=S'n_{j'}+C'n_{k'},
\]

であり、この場合 では

\[
1\le d'\leλ',\qquad
S'=C\geα+1=g'+1,\qquad
C'=S=g=α'.
\]

したがって UNITROOT の全仮定が同じ配置で成立する。
