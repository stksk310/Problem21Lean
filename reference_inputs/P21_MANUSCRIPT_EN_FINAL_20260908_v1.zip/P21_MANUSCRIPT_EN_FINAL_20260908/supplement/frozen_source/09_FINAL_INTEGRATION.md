# 09 — 最終統合

## I9 — 主定理T1の証明

第01章のcanonical条件を満たす極小4生成数値半群Γについて、
\(|Q(\Gamma)|\ge4\) と仮定する。

C2によって、全てのq∈Q(Γ)でq+m,c_q,W∈Ap(Γ,m)⊆H、
c_q−m∉Γ、KEYが成立する。異なる四行を選んでも同じΓ,F,m,Wと
それらのactuality・PF性・complement条件はそのまま保持される。

ここでtail gcdの第三の分岐を除く。q∈Q(Γ)を一つ取れば
\[
m=(q+m)+(W-q)-W\in\mathbb ZH.
\]
従ってgcd(n₁,n₂,n₃)はmも割る。gcd(m,n₁,n₂,n₃)=1なのでtail gcdは1。
またΓの極小性からtailの三生成元も極小である。
よってHは真の極小3生成数値半群であり、対称または非対称に尽くされる。
上の符号付き式を非負factorizationと呼ぶ必要はない。

Hが対称ならS3が反証仮定を排除する。
Hが非対称ならG4、M4、付録A1/A2から、選んだ四行の残存形は
PATH、TYPE II、CHAINのいずれかである。
三singletonがある場合にQ全体が三行だけとなることはG4.8で別に証明している。
cornerを含む四行はCOLOR-CAPで排除され、matched pairとsingletonはG4.5.3で排除される。
この分類でQ全体を4元と仮定していない。

PATHはP5.7、TYPE IIはT6で存在しない。
CHAINはR7で同じ配置のCORE-ROOTを持ち、C8.1–C8.4からE8へ接続する。
E8の完全色交換は元のΓ,F,m,Wを保存し、非終端では正整数𝒨=E+χを厳密に減少させる。
有限回の後に終端へ達し、その同じWのsource内にpacketを係数ごとに置換することで
元のFの全係数非負factorizationを得る。これはF∉Γに反する。

以上、反証仮定から生じる全場合が矛盾したので
\[
\boxed{|Q(\Gamma)|\le3.}
\]
F∈PF(Γ)であるから
\[
\boxed{t(\Gamma)=|Q(\Gamma)|+1\le4.}
\]
これで第01章の定理T1を証明した。
