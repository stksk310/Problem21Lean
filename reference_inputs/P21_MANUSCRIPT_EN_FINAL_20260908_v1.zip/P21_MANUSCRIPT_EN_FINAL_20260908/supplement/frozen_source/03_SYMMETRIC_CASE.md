# 03 — 対称tail

この章のT=⟨u,v⟩、A,B,C,D、P,Q,R,SはS3内の局所記号。非対称章のcanonical係数へ継承しない。

## S3 — 対称tailの排除

\(\Gamma=\langle m,x,y,z\rangle\)を極小4生成数値半群、\(m\)をmultiplicityとする。\(H=\langle x,y,z\rangle\)が対称な数値半群であり、
\[
m+F(\Gamma)-q\in\Gamma\qquad(q\in PF(\Gamma))
\tag{CAN}
\]
を仮定する。このとき \(t(\Gamma)\le4\)。

以後、\(F=F(\Gamma)\)、\(f=F(H)\)、\(Q=PF(\Gamma)\setminus\{F\}\)。半群のidealの最小生成元は、その半群の正の元を引いてなおidealに残ることができない元をいう。

### S3.1 elementary two-generator facts

\(T=\langle u,v\rangle\)、\(\gcd(u,v)=1\)、\(u,v\ge2\)とする。任意の整数は一意に
\[
a u+b v,\qquad a\in\mathbb Z,\quad0\le b<u
\]
と書け、T所属と\(a\ge0\)が同値。二つの整数係数表示の差は\((kv,-ku)\)である。このことから次が従う。

* \(F_T=uv-u-v\)、かつ任意の整数\(t\)について\(t\notin T\iff F_T-t\in T\)。実際、上の表示の補元は\((-a-1)u+(u-b-1)v\)。
* \(P<v,Q<u\)かつ\(Pu+Qv\in T\)なら\(P,Q\ge0\)。どちらかの負座標を修復するprimitive shiftは、他方を負にする。
* \(P,Q>0\)なら\(uv-Pu-Qv\notin T\)。所属すれば\(uv\)のu、v両係数が正の表示を生むが、\(Xu+Yv=uv\)の整数解は\(X=v(1-k),Y=uk\)のみ。
* \(0\le P<v,0\le Q<u\)なら\(Pu+Qv-uv\notin T\)。v-normal formのu係数は\(P-v<0\)。

また\(0<A<v,0<B<u\)なら
\[
(Au+T)\cap(Bv+T)=(Au+Bv+T)\cup(uv+T).
\tag{2GI}
\]
実際、\(X=(A+p)u+qv=ru+(B+s)v\)、\(p,q,r,s\ge0\)とする。表示差のprimitive shiftが0なら両係数にA、Bを含む。正なら最初のu係数がv以上、負なら第二表示のv係数がu以上なので\(X\in uv+T\)。逆包含は\(A<v,B<u\)から直ちに従う。

### S3.2 stable coreとexact bridge

\[
K=\{a\in H:a+nm\in H\ (n\ge0)\},\qquad h=\min K.
\]
対称性と\(\Gamma=H+\mathbb N m\)から、任意の整数tについて
\[
t\notin\Gamma\iff f-t\in K.
\tag{GAP-K}
\]
よって\(F=f-h\)。\(0\notin K\)（\(m\notin H\)）なので\(h\ge\min(H\setminus\{0\})>m\)。
\[
r=h-m=f-F-m>0,\qquad r+nm\in H\quad(n\ge1).
\tag{FS}
\]
KはΓ-idealで、GAP-Kから\(q\mapsto f-q\)がPFと\(\operatorname{Min}_\Gamma K\)の全単射になる。CANをその最小生成元に適用すると
\[
J:=K-r\subseteq\Gamma,\qquad \min J=m,\qquad m\in J.
\]
\[
I_r=\{c\in H:c+r\in H\}
\]
とおく。FSによって\(c\in I_r\Rightarrow c+r\in K\)なので\(J\cap H=I_r\)。

ここで
\[
\operatorname{Min}_\Gamma J
=\{m\}\sqcup(\operatorname{Min}_H I_r\cap\operatorname{Ap}(\Gamma,m)).
\tag{BRIDGE}
\]
を直接示す。\(j\in\operatorname{Min}_\Gamma J\setminus\{m\}\)が\(j-m\in\Gamma\)を満たすと\(j=m+(j-m)\)、\(m\in J\)に反する。したがってjはApéryに属し、そのfactorizationにmを含まないためHに属する。H-minimalityもΓ-minimalityから従う。

逆に\(c\in\operatorname{Min}_H I_r\cap\operatorname{Ap}\)とする。\(c-m\notin J\)は\(J\subseteq\Gamma\)から従う。\(c-n\in J\)が\(n\in\{x,y,z\}\)で成立すれば、\(c-n\in\Gamma\)かつ\(c-n-m\notin\Gamma\)なので\(c-n\in H\)、従って\(c-n\in J\cap H=I_r\)。これはH-minimalityに反する。これで逆包含を得る。

従って
\[
t(\Gamma)=1+|\operatorname{Min}_H I_r\cap\operatorname{Ap}|.
\tag{TYPE-BRIDGE}
\]
以後\(t\ge5\)と仮定して矛盾を導く。

### S3.3 RAW4の厳密分類

標準CI分類により、生成元を置換して
\[
x=du,\quad y=dv,\quad z=w,\quad H=\langle du,dv,w\rangle,
\quad \gcd(u,v)=\gcd(d,w)=1,\quad w\in T.
\]
極小3生成なので\(d,u,v\ge2\)。任意の整数は一意に\(jw+dt\)、\(0\le j<d\)と書け、H所属と\(t\in T\)が同値。従って
\[
f=(d-1)w+dF_T.
\]
\(r=sw+d\rho\)、\(0\le s<d\)と書く。\(s=0\)ならIrのraw minimaはj=0だけで、以下の2生成補題から高々2個。以後\(1\le s\le d-1\)。Irのraw minimaがあるlayerはj=0とj=d−sだけで、それぞれ
\[
J_0=\{t\in T:t+\rho\in T\},\quad J_1=\{t\in T:t+\rho+w\in T\}
\]
のT-minimaから来る。それ以外はwを一つ引ける。

任意の\(\eta=pu+qv\)、\(0\le q<u\)について\(\{t\in T:t+\eta\in T\}\)は高々2生成。実際\(t=au+bv\)、\(0\le b<u\)では必要なaの閾値が
\[
\max(0,-p)\quad(b<u-q),\qquad \max(0,-p-v)\quad(b\ge u-q)
\]
の二つだけになる。二つのminimaが異なり非比較となるのはちょうど\(0<q<u,-v<p<0\)。この場合
\[
A=-p, C=q, B=u-q, D=v+p,\quad A+D=v, B+C=u,
\]
とおけばminimaはAuとBv、像はCvとDuである。

よって\(|\operatorname{Min}_H I_r|\le4\)。\(t\ge5\)とTYPE-BRIDGEから、四つがすべて存在し、すべてApéryに残る。正整数A,B,C,Dとprimed版を用い、四組は
\[
(c_x,a_x)=(Ax,sw+Cy),\quad(c_y,a_y)=(By,sw+Dx),
\]
\[
(c'_x,a'_x)=((d-s)w+A'x,C'y),\quad
(c'_y,a'_y)=((d-s)w+B'y,D'x),
\tag{RAW4}
\]
である。すべて\(a=c+r\)、\(A+D=A'+D'=v\)、\(B+C=B'+C'=u\)。また
\[
\rho=uv-Au-Bv=-Au+Cv=-Bv+Du.
\]

### S3.4 cross-layer rigidityとactual PF入力

\(A'\ge A\)なら\(c'_x-c_x=(d-s)w+(A'-A)x\in H\)でraw非比較性に反する。したがって\(\alpha:=A-A'>0\)。同様に\(\beta:=B-B'>0\)。二層のthreshold式を引いて
\[
w=\alpha u+\beta v,\quad A'=A-\alpha>0,\quad B'=B-\beta>0,
\quad C'=C+\beta,\quad D'=D+\alpha.
\tag{CROSS-LAYER}
\]

四つのraw行はBRIDGEによりactual PF行\(q=f-a\)に対応する。特に
\[
c_x-m,c_y-m,c'_x-m,c'_y-m\notin\Gamma.
\tag{ALL-AP}
\]
もし\(a_x-m\in H\)なら、\(a_x\in K\)より\(a_x-m\in K\)。CANから\(c_x-m\in\Gamma\)となるため不可能。y側も同様。Hの対称性によって
\[
q_x+m,q_y+m\in H.
\tag{QM}
\]

### S3.5 Branch I／IIの全域分割

\(m=ew+d\mu\)、\(0\le e<d\)と書く。\(m\notin H\)なので\(\mu\notin T\)。\(\ell=d-1-s\)、
\[
k_0=\left\lfloor\frac{\ell+e}{d}\right\rfloor\in\{0,1\},
\qquad\theta=\mu+k_0w
\]
とおく。fの表示から\(q_x=\ell w+d((B-1)v-u)\)、\(q_y=\ell w+d((A-1)u-v)\)。QMは
\[
\theta+(B-1)v-u\in T,\qquad\theta+(A-1)u-v\in T.
\]
従って\(X=\theta+(A-1)u+(B-1)v\)に2GIを適用し、
\[
\theta-u-v\in T\qquad\text{または}\qquad\theta-\rho-u-v\in T.
\tag{SPLIT}
\]
左をBranch I、右をBranch IIと呼ぶ。両者が重なることは問題ない。まずBranch Iを排除する。

### S3.6 Branch I：walkとfour-hit necessity

\(\theta=L=u+v+t_0\)、\(t_0=p_0u+q_0v\in T\)とする。\(k_0=0\)なら\(\mu=L\in T\)となるため\(k_0=1\)。従って
\[
\kappa=d-e,\quad 1\le\kappa\le d-1-s,\quad
m=dL-\kappa w,\quad E=w-L>0.
\]
最後の正値は\(m<w\)、\(\kappa+1\le d-s<d\)から従う。
\[
c_n=\left\lceil\frac{n\kappa-s}{d}\right\rceil,\quad
j_n=s-n\kappa+dc_n,\quad
\tau_n=\rho+nL-c_nw.
\]
FSは\(\tau_n\in T\ (n\ge1)\)と同値。隣接stepはLまたはL−w。returnとは\(j_n=0\)、すなわち\(n\kappa\equiv s\pmod d\)である。

\(a_x-y+nm\)のT-coordinateは\(\tau_n+Au-v\)。Tに属する\(\tau\)について
\[
\tau+Au-v\notin T\iff\tau\in U_x:=\{ju:0\le j<D\}.
\]
これはS3.1のnormal formを用いて直接確認できる。\(a_x-y\in H\)である一方、actual PF性から\(q_x+y\in\Gamma\)、従ってGAP-Kから\(a_x-y\notin K\)。ゆえにn≥1でUxへのhitが必要。双対に
\[
U_y=\{jv:0\le j<C\}
\]
にもhitが必要。

同様に\(a_x-w+nm\)はreturnでないnでは自動的にHに属し、returnでだけT-coordinateが\(\tau_n+A'u-\beta v\)となる。これがT-gapになる条件は、同じ\(\tau_n\)が
\[
Z_x=\{pu+qv:0\le p<D',\ 0\le q<\beta\}
\]
に属することである。\(a_x-w\in H\)と\(q_x+w\in\Gamma\)から、このreturn hitが必要。双対にreturn上で
\[
Z_y=\{pu+qv:0\le p<\alpha,\ 0\le q<C'\}
\]
にもhitが必要。四つのhitはいずれも同じactual PF対と同じwalkから生じる。

### S3.7 Branch I：四つのhitは両立しない

以下\(a=A'>0,b=B'>0\)。\(\rho=uv-w-au-bv\)。return index Nでは\(c_{N-1}=c_N\)、\(c_{N+1}=c_N+1\)。従ってN>1なら
\[
\tau_{N-1}=\tau_N-L\in T.
\]
\(\tau_N=pu+qv\in Z_x\)またはZyの係数は\(p<v,q<u\)なので、S3.1より
\[
p\ge p_0+1,\qquad q\ge q_0+1.
\tag{LOWER}
\]
N=1にはこの制約を適用しない。

Zx、Zyの両hitがN>1なら、\(R=\alpha-p_0-1>0\)、\(Q=\beta-q_0-1>0\)を得る。しかし\(c_1\in\{0,1\}\)であり、
\[
\tau_1=uv-(a+R)u-(b+Q)v-c_1w\notin T
\]
となる（wの正係数表示を入れてS3.1を適用）。従って一方のreturn hitはN=1、特に\(\kappa=s\)。base \(\tau_1\)はX-only、Y-only、XYの三つに分かれる。

一般にlater Ux-hit \(\tau_N=ju\)、\(j<D\)への到着はcarryでなければならない。no-carryなら\(\tau_{N-1}=(j-p_0-1)u-(q_0+1)v\notin T\)。Uyも双対。

**X-only。** Zy-hitはlaterなのでLOWERから\(p_0\le\alpha-2,q_0\le u-b-2\)。\(R=\alpha-p_0-1>0\)、\(S=q_0+1-\beta\)とおくと
\[
w-L=Ru-Sv,\qquad\tau_1=(v-a-R)u+(S-b)v.
\]
両係数がfundamental strip上端より小さいのでFSから\(S\ge b\)。また\(1\le R\le\alpha-1,1\le S<u\)。baseがUxに属すにはS=bが必要だが、そのu係数は\(v-a-R\ge D+1\)で大きすぎる。later Ux-hitならcarry predecessorが\((j+R)u-Sv\)、しかし\(j+R\le v-a-2<v\)、\(0<S<u\)なのでT-gap。従ってUx-hitはない。

**Y-only。** 完全にu↔v、A↔B、α↔β、a↔bを交換した同じ議論でUy-hitはない。

**XY。** 両rectangleの座標表示は\(p<v,q<u\)の範囲で一意なので、
\[
\tau_1=pu+qv,\quad 0\le p<\alpha,\quad 0\le q<\beta.
\]
\[
E=uv-(a+p)u-(b+q)v,\qquad
\tau_2=(2p+a)u+(2q+b)v-uv.
\]
Ux-hitがbaseならp≤D−1でもあるため\(2p+a\le(\alpha-1)+(D-1)+a=v-2\)。later \(ju\)、j<Dであればcarry predecessorは
\[
ju+E=uv-(a+p-j)u-(b+q)v.
\]
S3.1のinterior-gap判定から\(j\ge a+p\)。これとp≤α−1から再び\(2p+a<v\)。双対にUy-hitは\(2q+b<u\)を強制する。従ってS3.1最後のgap判定から\(\tau_2\notin T\)、FSに反する。

三場合とも四つのhitが両立しない。Branch Iは排除された。

### S3.8 Branch II、k0=1：D-row dropまたはBranch I

\(\theta=\rho+u+v+t_0\)、\(t_0\in T\)。k0=1なら\(e\ge s+1\)、\(\kappa=d-e>0\)、
\[
\mu=\theta-w,\qquad m=d\theta-\kappa w,\qquad
\kappa w<d\theta<(\kappa+1)w.
\]
\(g=w-u-v-t_0=w-\theta+\rho\)とおく。ここでg>0を明記する：r>0から\(\rho>-sw/d\)、m<wから\(\theta<(\kappa+1)w/d\)。従って
\[
\theta-\rho<\frac{\kappa+s+1}{d}w\le w.
\tag{K1-g}
\]

二つのD-rowのbackward pointは
\[
a'_x-m=\kappa w+d(A'u+g),\qquad
a'_y-m=\kappa w+d(B'v+g).
\]
一方がHなら、それはKに属し、CANから対応する\(c'-m\in\Gamma\)。これはALL-APに反する。従って両者H-gap、すなわち\(A'u+g,B'v+g\notin T\)。T対称性から
\[
F_T-g\in(A'u+T)\cap(B'v+T).
\]
2GIを適用する。g>0なので\(F_T-g<uv\)、uv+T成分は不可能。従って
\[
F_T-g-A'u-B'v=\rho+t_0=\theta-u-v\in T.
\]
これは既に排除したBranch I。よってk0=1も排除される。

### S3.9 Branch II、k0=0,e=0

この場合\(\theta=\mu\notin T\)、\(m=d\theta\)。multiplicityから\(0<\theta<\min(u,v)\)。\(c_1=\lfloor(s+e)/d\rfloor=0\)なので、最初のstable coordinateは
\[
\tau_1=\rho+\theta=2\theta-u-v-t_0<0.
\]
FSに反する。

### S3.10 Branch II、k0=0,e>0：cross-core exclusion

\(t_0=pu+qv\)とする。\(\theta=\rho+u+v+t_0\notin T\)より\(p\le A-2,q\le B-2\)。従って
\[
P=A-1-p>0,\quad R=B-1-q>0,\quad Q=u-R,\quad S=v-P,
\]
\[
\theta=-Pu+Qv=Su-Rv<0.
\tag{K0}
\]
最後の不等式は\(m=ew+d\theta<w\)、e≥1から従う。\(P\le A-1,R\le B-1\)、\(0<Q<u,0<S<v\)。

\(k=d-s\)、\(c_n=\lfloor(s+ne)/d\rfloor\)、\(\tau_n=\rho+n\theta+c_nw\in T\)。c1=0なら\(\rho+\theta<0\)なので\(e\ge k\)。\(L_0=u+v+t_0\)とすると\(\tau_1=2\theta+w-L_0\ge0\)。\(h_0=-\theta>0\)とおけば\(2h_0\le w-L_0<w\)。これと\(m<w\)から
\[
(e-1)w<dh_0<dw/2,\qquad 2e\le d+1.
\tag{PHASE}
\]

\(\lambda_n=\lceil ne/d\rceil\)、\(\varepsilon_n=\lambda_n-c_n\in\{0,1\}\)。\(c_y-nm\)のH-normal formのT-coordinateをYnとすると、直接
\[
Y_n+\tau_n=Du-\varepsilon_n w.
\tag{COMP}
\]
ALL-APよりすべてn≥1で\(c_y-nm\notin H\)、従って\(Y_n\notin T\)。

一方\(a_x-y+nm\)のT-coordinateは\(\tau_n+Au-v\)。もしこれがT-gapなら、S3.6のtranslation判定から\(\tau_n=ju\)、\(0\le j<D\)。

* εn=0ならCOMPから\(Y_n=(D-j)u\in T\)、矛盾。
* εn=1とする。\(ne=qd+r\)、\(0\le r<d\)と書くと\(1\le r<k\)。e≥kなのでn≥2。また
  \[
  (n-1)e=(q-1)d+(d+r-e),\quad d+r-e\ge k
  \]
  がPHASEから従う（\(d+r-e-k\ge d+1-e-k\ge d+1-2e\ge0\)）。従って\(c_{n-1}=c_n=q\)。その前stable点は
  \[
  \tau_{n-1}=\tau_n-\theta=(j+P)u-Qv.
  \]
  しかし\(j+P\le D-1+A-1=v-2\)、\(0<Q<u\)なのでT-gap、FSに反する。

よって全n≥0で\(a_x-y+nm\in H\)、すなわち\(a_x-y\in K\)。GAP-Kから\(q_x+y\notin\Gamma\)。actual PF性の\(q_x+y\in\Gamma\)と矛盾する。

これでBranch IIのk0/e全場合が排除された。RAW4すべてがApéryに残ることはできず、TYPE-BRIDGEにより
\[
\boxed{t(\Gamma)\le4}.
\]
