# P21 — Package integrity

Freeze identifier: `P21-FROZEN-20260907-v1`。

```text
Files hashed: 69
Files verified: 69
Mismatches: 0
Manifest self-file excluded: 1
ZIP extraction CRC check: PASS
Fresh extracted manifest verification: PASS
```

SHA256SUMS.txtには自己ファイル以外の全69ファイルを格納する。
原監査のmanifestと維持版manifestはそれぞれ原ZIP内容に対して照合する。
最終ZIPは新しい空ディレクトリへ展開し、各ファイルのSHA-256とmanifestの完全な網羅性を再確認する。
最終ZIP自身のSHA-256は外部の `P21_FINAL_FROZEN_VERIFICATION_EDITION_20260907.zip.sha256` に記録する。
自己参照を避けるため、ZIP自身のhashはZIP内に含めない。
