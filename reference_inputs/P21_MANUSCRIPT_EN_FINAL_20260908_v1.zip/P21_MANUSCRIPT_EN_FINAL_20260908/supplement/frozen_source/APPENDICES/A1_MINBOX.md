# 付録 A1 — MINBOX

この付録のCは局所3×3行列であり、CORE-ROOT係数Cではない。

### A1.1 入力と socle matrix

\(H=\langle n_1,n_2,n_3\rangle\) は nonsymmetric 3-generated numerical semigroup、

\[
\Gamma=\langle m,n_1,n_2,n_3\rangle,\qquad 0<m<\min_i n_i.
\]

標準 Herzog package を次の convention で用いる。全 \(a_i,b_i\) は正整数、

\[
\rho_i=a_i+b_i,
\quad
\rho_1n_1=b_2n_2+a_3n_3,
\quad
\rho_2n_2=a_1n_1+b_3n_3,
\quad
\rho_3n_3=b_1n_1+a_2n_2.
\]

ここで true critical relations と primitive integer-kernel lattice を用いる。標準 generator formulas は

\[
n_1=a_2a_3+a_3b_2+b_2b_3,
\quad n_2=a_1a_3+a_1b_3+b_1b_3,
\quad n_3=a_1a_2+a_2b_1+b_1b_2.
\]

\(PF(H)=\{f_A,f_B\}\)、\(N=n_1+n_2+n_3\)、\(s_\varepsilon=f_\varepsilon+N\)。**行が socle factorizations** である正しい行列は

\[
U_A=\begin{pmatrix}0&\rho_2&a_3\\a_1&0&\rho_3\\\rho_1&a_2&0\end{pmatrix},
\qquad
U_B=\begin{pmatrix}0&b_2&\rho_3\\\rho_1&0&b_3\\b_1&\rho_2&0\end{pmatrix}.
\tag{U}
\]

各行の差は上記の zero relations なので \(U_\varepsilon n=s_\varepsilon\mathbf1\)。generator formulas の代入で

\[
\det U_\varepsilon=s_\varepsilon,
\qquad \operatorname{adj}(U_\varepsilon)\mathbf1=n.
\tag{UD}
\]

が成立する。

### A1.2 三本の actual arms が与える minimal factorization

同色 \(\varepsilon\) の三本

\[
q_i=f_\varepsilon-\lambda_i n_i\in PF(\Gamma),\qquad
1\le\lambda_i\le\alpha_i-1,
\quad
\alpha_i=\begin{cases}a_i&\varepsilon=A,\\b_i&\varepsilon=B\end{cases}
\tag{ARM}
\]

を仮定する。すると \(f=f_\varepsilon\in\Gamma\setminus H\)。どの genuine factorization

\[
f=k m+\sum_i x_i n_i
\]

にも \(k\ge1\)、\(0\le x_i\le\lambda_i-1\) が必要。後者は同じ factorization から \(\lambda_i n_i\) を除くと \(q_i\in\Gamma\) になるため。

正の \(m\)-係数を最小に取り

\[
f=k m+\sum_i(p_i-1)n_i,
\qquad1\le p_i\le\lambda_i\le\alpha_i-1.
\tag{MIN}
\]

したがって \(s-p\cdot n=km\)。この時点で factorization uniqueness は仮定していない。

### A1.3 Empty tetrahedron と cyclic quotient

\(L_d=\{z\in\mathbb Z^3:z\cdot n\equiv0\pmod d\}\) とおく。primitive \(n\) により \([\mathbb Z^3:L_d]=d\)。行列

\[
C=U-\mathbf1p^T,
\qquad c_i=U_i-p
\]

は \(Cn=km\mathbf1\)、(UD) と determinant lemma により \(\det C=km\)。従って

\[
\operatorname{row}_{\mathbb Z}C=L_{km},
\qquad L_m/L_{km}\cong\mathbb Z/k\mathbb Z,
\quad [z]\mapsto z\cdot n/m\pmod k.
\tag{LAT}
\]

単体 \(\Delta=\operatorname{conv}(p,U_1,U_2,U_3)\) は affine lattice \(p+L_m\) に関して empty である。実際、

\[
u=(1-\tau)p+\sum_i\tau_iU_i,
\quad \tau_i\ge0,\quad\tau=\sum_i\tau_i\le1
\]

が lattice point なら \(\ell=(s-u\cdot n)/m=(1-\tau)k\) は整数。

* \(0<\ell<k\)：\(u>0\) coefficientwise なので \(f=\ell m+\sum_i(u_i-1)n_i\) が genuine。\(k\) の最小性に反する。
* \(\ell=k\)：\(u=p\)。
* \(\ell=0\)：top face に属する。非頂点では少なくとも二つの \(U_i\) が混ざり、(U) の各行が異なる一座標だけを零に持つため \(u>0\)。すると \(f=\sum_i(u_i-1)n_i\in H\)、矛盾。

従って頂点四つだけ。相対 lattice volume は \(\det C/[\mathbb Z^3:L_m]=k\)。

### A1.4 White classes（唯一の追加標準外部定理）

ここで使う White の定理は「empty lattice tetrahedron は lattice width one」という標準定理だけである。[G. K. White, *Lattice Tetrahedra*, Canad. J. Math. 16 (1964), 389–396](https://doi.org/10.4153/CJM-1964-040-2)。証明を再確認できる論文は [Khan–Rogers, *An Exposition of White's Characterization of Empty Lattice Tetrahedra*](https://arxiv.org/abs/1610.01981)。以下の quotient・height・companion の接続は本証明内で示す。

\(k\ge2\) と仮定する。half-open parallelepiped に class \(j\in\{1,\ldots,k-1\}\) の representative

\[
r_j=\sum_i\theta_{j,i}c_i,\qquad0\le\theta_{j,i}<1
\]

を取る。emptiness より \(\sum_i\theta_{j,i}>1\)。negative class の係数は非零座標で \(1-\theta_{j,i}\)。双方の和が \(>1\) なので、三座標すべてが非零で、

\[
0<\theta_{j,i}<1,
\qquad1<\sum_i\theta_{j,i}<2.
\]

また \(k\sum_i\theta_{j,i}=r_j\cdot n/m\equiv j\pmod k\) だから

\[
\sum_i\theta_{j,i}=1+j/k.
\tag{AGE}
\]

White の width-one planes は頂点を二つずつ分ける。もし \(1+3\) 分割なら、empty triangular facet は自身の lattice 内で unimodular、かつ高さが1なので単体 volume も1となり \(k\ge2\) に反する。従って row permutation により planes を \((p,U_1)\) と \((U_2,U_3)\) にできる。対応 primitive affine functional を \(p=0\) で linear にすれば \(c_1\mapsto0,c_2,c_3\mapsto1\)。\(r_1\) は lattice point なので \(\theta_{1,2}+\theta_{1,3}\) は整数、かつ \(0<\cdot<2\)、従って1。AGE より \(\theta_{1,1}=1/k\)。

よってある \(1\le r<k\) に対し

\[
\theta_1=(1/k,r/k,(k-r)/k).
\]

全 class の座標非零性より \(\gcd(r,k)=1\)。正整数 \(q<k\)、非負整数 \(\ell\) を \(rq=1+\ell k\) で定める。自然 ordering の行を \(R_i\) と記すと

\[
z=\frac{R_1+r(R_2-R_3)-p}{k}\in\mathbb Z^3,
\qquad z_q=qz-\ell(R_2-R_3)\in\mathbb Z^3.
\tag{Z}
\]

ここで \(r_1=c_3+z,r_q=c_3+z_q\)。class \(j\) と \(k-j\) の lower companions は、\(v=z\) または \(z_q\) に対し

\[
\begin{array}{lll}
p+R_3-R_1+v,&p+R_3-R_2+v,&p+v,\\
R_2-v,&R_1-v,&R_1+R_2-R_3-v.
\end{array}
\tag{COMP}
\]

それぞれ \(s-u\cdot n=(k-j)m\) または \(jm\) を満たす。従って最小性から **六本とも coefficientwise strictly positive ではない**。\(q=1\) や \(k=2\) で class が重複してもこの論理は変わらない。

### A1.5 Color A の exact failure inequalities

自然 ordering の \(U_A\) では

\[
z=(-X,Y,Z),
\quad X=\frac{rb_1+p_1}{k},
\quad Y=\frac{b_2-(r-1)a_2-p_2}{k},
\quad Z=\frac{(r+1)a_3+rb_3-p_3}{k}.
\]

arm bounds から \(X>0,X<p_1+\rho_1,X<p_1+b_1\)、\(-a_2<Y<b_2\)、\(0<Z<\rho_3\)。COMP の六本を次の順で見る。

1. \(R_2-z=(a_1+X,-Y,\rho_3-Z)\) の失敗より \(Y\ge0\)。
2. \(R_1-z=(X,\rho_2-Y,a_3-Z)\) の失敗より \(Z\ge a_3\)。
3. \(p+R_3-R_2+z=(p_1+b_1-X,p_2+a_2+Y,p_3-\rho_3+Z)\) より \(Z\le\rho_3-p_3\)。
4. \(p+R_3-R_1+z=(p_1+\rho_1-X,p_2-b_2+Y,p_3-a_3+Z)\) より \(Y\le b_2-p_2\)。
5. \(p+z\) より \(X\ge p_1\)。
6. \(R_1+R_2-R_3-z=(X-b_1,b_2-Y,2a_3+b_3-Z)\) より \(X\le b_1\)。

従って

\[
p_1\le X\le b_1,\quad0\le Y\le b_2-p_2,
\quad a_3\le Z\le\rho_3-p_3.
\tag{BA}
\]

\(z_q=(-X_q,Y_q,Z_q)\) について直接計算で

\[
X_q=(b_1+qp_1)/k,
\quad Y_q=[q(b_2-p_2)+(q-1)a_2]/k,
\quad Z_q=[(q+1)a_3+b_3-qp_3]/k.
\]

\(b_2-p_2\ge(r-1)a_2\) により \(Y_q\ge0\)。また

\[
kb_2-kY_q=(k-q)b_2+qp_2-(q-1)a_2
\ge k(r-\ell-1)a_2+kp_2>0.
\]

従って \(Y_q<b_2\)。残りは直接 \(0<X_q<p_1+b_1\)、\(0<Z_q<\rho_3\) なので、同じ六本の議論から (BA) が \(z_q\) にも適用される。

\(X_q\ge p_1,Y\ge0,Z_q\ge a_3\) と整数性だけで、\(s=k-q\ge1\) とおけば

\[
b_1=sp_1+ku,
\quad b_2=p_2+(r-1)a_2+ky,
\quad b_3=qp_3+(s-1)a_3+kv,
\quad u,y,v\in\mathbb Z_{\ge0}.
\tag{AP}
\]

最終証明には failure cone の逆向き・冗長 inequality の分類は不要。

### A1.6 Color A multiplicity contradiction（全 k≥2）

\(e_i=a_i-p_i\ge1\)。三本の socle rows から

\[
\begin{aligned}
km&=(e_1+b_1)n_1+e_2n_2-p_3n_3,\\
km&=-p_1n_1+(e_2+b_2)n_2+e_3n_3,\\
km&=e_1n_1-p_2n_2+(e_3+b_3)n_3.
\end{aligned}
\]

順に \(1,s,rs\) 倍して加える。\(D=1+s+rs\) とすると (AP) により

\[
w\cdot n=kDm,
\quad
\begin{cases}
w_1=(1+rs)e_1+ku,\\
w_2=(1+rs)e_2+sky,\\
w_3=((k-1)rs-1)p_3+s(1+rs)e_3+rskv.
\end{cases}
\]

\((k-1)rs-1\ge0\)、各 \(w_i>0\)。\(rs+1=k(r-\ell)\) と \(r-\ell\ge1\) から

\[
\sum_iw_i-kD\ge(s+1)(rs+1-k)
=k(s+1)(r-\ell-1)\ge0.
\]

しかし \(n_i>m\) なので \(w\cdot n>m\sum_iw_i\ge kDm\)、矛盾。

### A1.7 Color B の failure inequalities と multiplicity contradiction

正しい \(U_B\) の自然 ordering では

\[
z=(X,-Y,Z),
\quad X=(ra_1-p_1)/k,
\quad Y=[r\rho_2-b_2+p_2]/k,
\quad Z=[a_3+(r+1)b_3-p_3]/k.
\]

arm bounds より \(-p_1<X<a_1,0<Y<\rho_2,0<Z<\rho_3\)。COMP の失敗を順に用いる。

1. \(p+z\) より \(Y\ge p_2\)。
2. \(R_2-z=(\rho_1-X,Y,b_3-Z)\) より \(Z\ge b_3\)。
3. \(R_1-z=(-X,b_2+Y,\rho_3-Z)\) より \(X\ge0\)。
4. \(R_1+R_2-R_3-z=(a_1-X,Y-a_2,a_3+2b_3-Z)\) より \(Y\le a_2\)。
5. \(p+R_3-R_1+z=(p_1+b_1+X,p_2+a_2-Y,p_3-\rho_3+Z)\) より \(Z\le\rho_3-p_3\)。
6. \(p+R_3-R_2+z=(p_1-a_1+X,p_2+\rho_2-Y,p_3-b_3+Z)\) より \(X\le a_1-p_1\)。

従って

\[
0\le X\le a_1-p_1,\quad p_2\le Y\le a_2,
\quad b_3\le Z\le\rho_3-p_3.
\tag{BB}
\]

\(z_q=(X_q,-Y_q,Z_q)\) の直接計算は

\[
X_q=(a_1-qp_1)/k,
\quad Y_q=[a_2-(q-1)b_2+qp_2]/k,
\quad Z_q=[qa_3+(q+1)b_3-qp_3]/k.
\]

ここで \(-p_1<X_q<a_1\)、\(0<Z_q<\rho_3\)、\(Y_q<\rho_2\) は arm bounds から直接成立する。まず \(p+z_q\) の失敗から \(Y_q\ge p_2>0\) を得る。その後、上と同じ順序で六本の議論を進めれば (BB) が \(z_q\) にも適用される。

\(X_q\ge0,Y_q\ge p_2,Z\ge b_3\) と整数性より、\(t=k-r\ge1\) とおくと

\[
a_1=qp_1+ku,
\quad a_2=(q-1)b_2+(k-q)p_2+ky,
\quad a_3=p_3+(t-1)b_3+kv,
\quad u,y,v\ge0.
\tag{BP}
\]

\(f_i=b_i-p_i\ge1\) とおけば三本の socle rows は

\[
\begin{aligned}
km&=-p_1n_1+f_2n_2+(a_3+f_3)n_3,\\
km&=(a_1+f_1)n_1-p_2n_2+f_3n_3,\\
km&=f_1n_1+(a_2+f_2)n_2-p_3n_3.
\end{aligned}
\]

順に **\(q,1,qt\)** 倍し、\(D=1+q+qt\) とすれば

\[
w\cdot n=kDm,
\quad
\begin{cases}
w_1=(1+qt)f_1+ku,\\
w_2=(qt(k-1)-1)p_2+q(1+qt)f_2+qtk y,\\
w_3=(1+qt)f_3+qkv.
\end{cases}
\]

全 \(w_i>0\)、また \(qt+1=k(q-\ell)\)、\(q-\ell\ge1\) より

\[
\sum_iw_i-kD\ge(q+1)(qt+1-k)
=k(q+1)(q-\ell-1)\ge0.
\]

再び \(n_i>m\) に矛盾。

### A1.8 White row ordering と結論

White が選んだ row order は任意でよい。各 row の唯一の零座標を同じ番号へ戻す simultaneous generator permutation を施す。偶 permutation は \(A/B\) と \(a/b\) を保ち、奇 permutation は \(a/b\) と \(A/B\) を同時に交換する。arm box \(p_i\le a_i-1\) も対応する \(p_i'\le b_i'-1\) へ移る。(U) を行・列の同時 permutation で直接確認できる。従って両自然 master が全 ordering を尽くす。

これで \(k\ge2\) は不可能であり、

\[
\boxed{k=1,\qquad f_\varepsilon=m+\sum_i(p_i-1)n_i,
\quad1\le p_i\le\lambda_i\le\alpha_i-1.}
\tag{MINBOX}
\]

特にこの段階は pure lattice algebra と **最小な正の m 係数** を使用するが、signed intermediate を actual と呼ばない。矛盾に使う lower companion は三座標すべて正となった時にだけ genuine factorization へ変換する。

### A1.9 k=1 dynamics への正確な interface

色を必要に応じて反転し A とする。\(x=p\ge1,y=a-p\ge1,z=y+b\ge2\) と置くと

\[
C=U_A-\mathbf1p^T
=\begin{pmatrix}-x_1&z_2&y_3\\y_1&-x_2&z_3\\z_1&y_2&-x_3\end{pmatrix},
\quad Cn=m\mathbf1,\quad\det C=m.
\tag{BOX}
\]

さらに three-arm coordinate caps により、任意の \(u\in\mathbb Z_{>0}^3\) で

\[
s-u\cdot n\in m\mathbb Z_{\ge0}
\]

なら \(u_i\le\lambda_i\le a_i-1=x_i+y_i-1\)。これが付録A2のLOWER-BOX条件である。

例えば minor \(\Delta_2=x_1x_3-z_1y_3\) は (BOX) の row 1,3 を消去して

\[
\Delta_2 n_3=(x_1y_2+z_1z_2)n_2-(x_1+z_1)m>0
\]

となる。実際 \(y_2\ge1,z_2\ge2,n_2>m\) で右辺は正。同様に巡回する relevant minors は正。したがって下流で必要な positive minors は独立の古い master lemma への依存ではない。
