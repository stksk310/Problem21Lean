#!/usr/bin/env python3
"""Rebuild the reading copy from maintained chapters; no mathematical transformations."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parent.parent
CHAPTERS=[next(ROOT.glob(f'{n:02d}_*.md')) for n in range(1,10)]
APPENDICES=[ROOT/'APPENDICES'/x for x in ['A1_MINBOX.md','A2_COLOR_CAP.md','A3_U_POSITIVITY.md','A4_STATIC_CERTIFICATES.md']]
text=['# P21 — 最終凍結検証版・単一通読版\n\n2026-09-07。章別正本と数学付録の連結表示。\n\n**FINAL FROZEN VERIFICATION EDITION — P21-FROZEN-20260907-v1**\n\n定理のscopeと定義は第01章、最終結合は第09章。source・採用監査の対応は10_DEPENDENCY_LEDGER.md。静的係数表は同梱ZIPのAPPENDICES内にある。\n']
for path in CHAPTERS+APPENDICES:
    body=path.read_text()
    if path.parent.name=='APPENDICES':
        body=re.sub(r'\]\((LINEAR/|EUCLIDEAN/)',r'](APPENDICES/\1',body)
    text.append('\n---\n\n'+body)
(ROOT/'P21_FINAL_FROZEN_PROOF_MASTER.md').write_text('\n'.join(text))
print('Reading copy generated from',len(CHAPTERS),'chapters and',len(APPENDICES),'mathematical appendices.')
