"""Run the original deterministic finite probes; redirect output path only."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/'APPENDICES/AUDIT_ORIGINAL/adversarial_probes.py'
exec(compile(SOURCE.read_text(),str(SOURCE),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
