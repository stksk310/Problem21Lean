"""Run the unchanged audit mathematics against the frozen package (path adapter only)."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/'APPENDICES/AUDIT_ORIGINAL/audit_checks.py'
text=SOURCE.read_text()
old="PKG=ROOT/'audit_input/P21_MAINTAINED_PROOF'"
assert text.count(old)==1
text=text.replace(old,"PKG=ROOT.parents[1]")
assert text.count('P21_MAINTAINED_PROOF_MASTER.md')==2
text=text.replace('P21_MAINTAINED_PROOF_MASTER.md','P21_FINAL_FROZEN_PROOF_MASTER.md')
exec(compile(text,str(SOURCE),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
