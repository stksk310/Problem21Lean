"""Verify frozen packaging, source-only authorized edits, links and dependency graph.

This is a freeze integrity check, not a new mathematical audit.
Run after the supplied verifiers and after creating the manifest.
"""
from pathlib import Path
import difflib, hashlib, json, re, subprocess, sys, zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
ID='P21-FROZEN-20260907-v1'
ARCH=ROOT/'APPENDICES/AUDIT_ORIGINAL'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(name):return (ROOT/name).read_text()
def data(name):return (ROOT/name).read_bytes()
with zipfile.ZipFile(ARCH/'P21_MAINTAINED_PROOF_20260907.zip') as z:
    base={n.removeprefix('P21_MAINTAINED_PROOF/'):z.read(n) for n in z.namelist() if not n.endswith('/')}
with zipfile.ZipFile(ARCH/'P21_INDEPENDENT_MASTER_AUDIT_20260907.zip') as z:
    assert all(z.read('audit_input/P21_MAINTAINED_PROOF/'+n)==b for n,b in base.items())
    issues=json.loads(z.read('P21_AUDIT_ISSUES_20260907.json'))
    assert sha((ARCH/'P21_MAINTAINED_PROOF_20260907.zip').read_bytes())==issues['input_zip_sha256']
    for name in ['audit_checks.py','adversarial_probes.py','audit_checks_result.json','adversarial_probes_result.json','P21_INDEPENDENT_MASTER_AUDIT_20260907.md','P21_AUDIT_ISSUES_20260907.json','P21_AUDIT_SHA256SUMS.txt']:
        assert (ARCH/name).read_bytes()==z.read(name),name
    audit_manifest=0
    for line in z.read('P21_AUDIT_SHA256SUMS.txt').decode().splitlines():
        h,n=line.split(None,1);n=n.lstrip('*')
        assert sha(z.read(n))==h,n
        audit_manifest+=1
base_manifest=0
for line in base['SHA256SUMS.txt'].decode().splitlines():
    h,n=line.split(None,1);assert sha(base[n.lstrip('*')])==h,n;base_manifest+=1

repairs=json.loads(read('APPENDICES/FREEZE/AUTHORIZED_REPAIRS.json'))
assert [r['id'] for r in repairs]==['E01','C01','C02','C03']
expected=base['08_CENTRAL_EUCLIDEAN_CLOSURE.md'].decode()
assert expected.count(repairs[0]['old'])==1
expected=expected.replace(repairs[0]['old'],repairs[0]['new'])
assert read('08_CENTRAL_EUCLIDEAN_CLOSURE.md')==expected
expected=base['01_THEOREM_AND_SETUP.md'].decode()
for r in repairs[1:]:
    assert expected.count(r['old'])==1
    # The complete maintained statement column must remain exactly unchanged.
    assert r['old'].split(' | ')[1]==r['new'].split(' | ')[1]
    expected=expected.replace(r['old'],r['new'])
expected=expected.replace('以下の結果自体の証明は本書の対象外。書誌は採用本文にある識別情報を保持し、\n論文化時の定理番号照合欄を残す。プロジェクト固有補題は以下とは分離して本文で証明する。','以下の結果自体の証明は本書の対象外。原典の識別情報を保持し、\n確認済み補助文献の正確な所在を併記する。原典内の未確認の定理番号は主張しない。\nプロジェクト固有補題は以下とは分離して本文で証明する。').replace('引用識別子／定理番号照合欄','引用識別子／確認済み補助引用')
assert read('01_THEOREM_AND_SETUP.md')==expected

changed_allowed={'00_README.md','01_THEOREM_AND_SETUP.md','08_CENTRAL_EUCLIDEAN_CLOSURE.md','10_DEPENDENCY_LEDGER.md','APPENDICES/DEPENDENCY_LEDGER.json','APPENDICES/rebuild_master.py','P21_MAINTAINED_PROOF_MASTER.md','SHA256SUMS.txt'}
unchanged=[]
for n,b in base.items():
    if n not in changed_allowed:
        assert data(n)==b,('unauthorized edit',n)
        unchanged.append(n)
assert not (ROOT/'P21_MAINTAINED_PROOF_MASTER.md').exists()
old_script=base['APPENDICES/rebuild_master.py'].decode()
expected_script=old_script.replace('# P21 — 維持証明・単一通読版','# P21 — 最終凍結検証版・単一通読版').replace('**READY FOR INDEPENDENT MASTER-PROOF AUDIT**',f'**FINAL FROZEN VERIFICATION EDITION — {ID}**').replace("(ROOT/'P21_MAINTAINED_PROOF_MASTER.md')","(ROOT/'P21_FINAL_FROZEN_PROOF_MASTER.md')")
assert read('APPENDICES/rebuild_master.py')==expected_script
master=data('P21_FINAL_FROZEN_PROOF_MASTER.md')
subprocess.run([sys.executable,str(ROOT/'APPENDICES/rebuild_master.py')],check=True,capture_output=True)
assert master==data('P21_FINAL_FROZEN_PROOF_MASTER.md')
paths=[next(ROOT.glob(f'{n:02d}_*.md')) for n in range(1,10)]+[ROOT/'APPENDICES'/n for n in ['A1_MINBOX.md','A2_COLOR_CAP.md','A3_U_POSITIVITY.md','A4_STATIC_CERTIFICATES.md']]
header='# P21 — 最終凍結検証版・単一通読版\n\n2026-09-07。章別正本と数学付録の連結表示。\n\n**FINAL FROZEN VERIFICATION EDITION — '+ID+'**\n\n定理のscopeと定義は第01章、最終結合は第09章。source・採用監査の対応は10_DEPENDENCY_LEDGER.md。静的係数表は同梱ZIPのAPPENDICES内にある。\n'
expected=[header]
for p in paths:
    t=p.read_text()
    if p.parent.name=='APPENDICES':t=re.sub(r'\]\((LINEAR/|EUCLIDEAN/)',r'](APPENDICES/\1',t)
    expected.append('\n---\n\n'+t)
assert '\n'.join(expected).encode()==master

old_ledger=json.loads(base['APPENDICES/DEPENDENCY_LEDGER.json']);ledger=json.loads(read('APPENDICES/DEPENDENCY_LEDGER.json'))
assert ledger.pop('freeze_identifier')==ID and ledger==old_ledger
old_md=base['10_DEPENDENCY_LEDGER.md'].decode();pos=old_md.index('\n')
assert read('10_DEPENDENCY_LEDGER.md')==old_md[:pos+1]+f'\nFreeze identifier: `{ID}`。42 nodesのstatement・scope・依存辺は監査対象版と同一。\n'+old_md[pos+1:]
nodes={r['id']:r for r in ledger['nodes']};ext=set(ledger['external_inputs']);seen=set();active=set()
def dfs(v):
    if v in ext or v in seen:return
    assert v in nodes and v not in active,v
    active.add(v)
    for d in nodes[v]['depends_on']:dfs(d)
    active.remove(v);seen.add(v)
for v,n in nodes.items():
    dfs(v)
    assert v in read(n['location'])
    assert sorted(n['used_in'])==sorted(k for k,r in nodes.items() if v in r['depends_on'])

# Markdown destinations outside math/code: all package Markdown, including archived audit texts.
# Relative file existence is checked; this does not assert all renderer-specific fragment IDs.
links=0;broken=[];md_count=0
for p in sorted(ROOT.rglob('*.md')):
    md_count+=1
    body=re.sub(r'\\\[.*?\\\]|\\\(.*?\\\)|```.*?```','',p.read_text(),flags=re.S)
    for dest in re.findall(r'\]\(([^)]+)\)',body):
        if re.match(r'[a-zA-Z][\w+.-]*:|#',dest):continue
        path=dest.split('#')[0];links+=1
        if not (p.parent/path).is_file():broken.append([str(p.relative_to(ROOT)),dest])
assert not broken,broken

linear=json.loads(read('APPENDICES/LINEAR/verification_result.json'))
eu=json.loads(read('APPENDICES/EUCLIDEAN/verification_result.json'))
assert linear['status']=='PASS' and linear['identity_count']==28
assert linear['positive_polynomial']['monomial_count']==715 and linear['positive_polynomial']['constant_term']==35
assert eu['status']=='PASS' and eu['identity_count']==35
assert eu['terminal_positive_polynomial']['monomial_count']==3234 and eu['terminal_positive_polynomial']['constant_term']==63
audit=json.loads(read('APPENDICES/FREEZE/audit_checks_result.json'))
assert audit['symbolic_identity_count']==23 and audit['ledger_acyclic'] and not audit['reverse_edge_mismatches'] and not audit['broken_file_links']
assert data('APPENDICES/FREEZE/adversarial_probes_result.json')==data('APPENDICES/AUDIT_ORIGINAL/adversarial_probes_result.json')

result={'freeze_identifier':ID,'status':'PASS','mathematical_changes':0,'unauthorized_mathematical_changes':0,
        'source_repairs':['E01','C01','C02','C03'],'base_files':len(base),'base_manifest_verified':base_manifest,'audit_manifest_verified':audit_manifest,
        'byte_unchanged_base_files':len(unchanged),'dependency_graph_changed':False,'dependency_nodes':len(nodes),'dependency_unresolved':0,'dependency_cycles':0,
        'rebuild_exact':True,'chapter_concatenation_exact':True,'markdown_files_checked':md_count,'relative_file_links_checked':links,'broken_internal_file_links':0,
        'linear':[28,715,35],'euclidean':[35,3234,63],'supplemental_symbolic_identities':23,'bounded_probes_byte_identical':True}
(HERE/'freeze_checks_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')

manifest=ROOT/'SHA256SUMS.txt';hashed=set()
for line in manifest.read_text().splitlines():
    h,n=line.split(None,1);n=n.lstrip('*');assert n not in hashed;hashed.add(n)
    assert sha(data(n))==h,('manifest mismatch',n)
actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p!=manifest}
assert hashed==actual,(hashed-actual,actual-hashed)
print(json.dumps({**result,'files_hashed':len(hashed),'files_verified':len(hashed),'manifest_mismatches':0},ensure_ascii=False))
