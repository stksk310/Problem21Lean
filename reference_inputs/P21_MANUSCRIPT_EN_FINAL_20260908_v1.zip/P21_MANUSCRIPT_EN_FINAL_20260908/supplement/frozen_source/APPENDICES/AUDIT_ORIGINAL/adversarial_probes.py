"""Deterministic finite counterexample probes. Not all-parameter proofs."""
from pathlib import Path
from itertools import combinations
from collections import Counter
from heapq import heappush,heappop
import math,random,json
ROOT=Path(__file__).resolve().parent

def apery(gens):
    mod=min(gens);dist=[10**30]*mod;dist[0]=0;heap=[(0,0)]
    while heap:
        d,r=heappop(heap)
        if d!=dist[r]:continue
        for v in gens:
            nd=d+v;nr=nd%mod
            if nd<dist[nr]:dist[nr]=nd;heappush(heap,(nd,nr))
    return dist
def member(v,ap):return v>=0 and v>=ap[v%len(ap)]
def minimal(gs):
    reach=[False]*(max(gs)+1);reach[0]=True
    for v in gs:
        if reach[v]:return False
        for j in range(v,len(reach)):reach[j]|=reach[j-v]
    return True
def pf(gs,ap):
    return [w-min(gs) for w in ap if all(member(w-min(gs)+g,ap) for g in gs)]
stats=Counter();examples={};maxgen=50
for gs in combinations(range(4,maxgen+1),4):
    stats['candidate_tuples']+=1
    if math.gcd(*gs)!=1 or not minimal(gs):continue
    stats['minimal_edim4']+=1
    m=gs[0];ap=apery(gs);pfs=pf(gs,ap);F=max(ap)-m;W=F+m
    if not all(member(W-q,ap) for q in pfs):continue
    stats['canonical']+=1;stats[f'type_{len(pfs)}']+=1
    assert len(pfs)<=4,('P21 counterexample',gs,pfs)
    if not len(pfs)>1:continue
    tail=gs[1:];assert math.gcd(*tail)==1
    ah=apery(tail);ph=pf(tail,ah)
    stats['symmetric_tail' if len(ph)==1 else 'nonsymmetric_tail']+=1
    if len(ph)==1:continue
    arms=[];corners=[];singletons=[]
    for q in pfs:
        if q==F:continue
        supp=[i for i,n in enumerate(tail) if member(q+n,ah)]
        cq=W-q
        assert member(cq,ah) and not member(cq-m,ap)
        for i,n in enumerate(tail):
            if member(cq-n,ah):assert i in supp
        if len(supp)==1:singletons.append(supp[0])
        elif len(supp)==3:corners.append(ph.index(q))
        else:
            assert len(supp)==2
            i=next(i for i in range(3) if i not in supp)
            depth=0
            while not member(q+(depth+1)*tail[i],ah):depth+=1
            corner=q+depth*tail[i]
            assert corner in ph
            arms.append((ph.index(corner),i,depth,q))
    for color in [0,1]:
        assert sum(c==color for c,i,d,q in arms)+corners.count(color)<=2
    for aa in arms:
        for bb in arms:
            if aa[0]<bb[0] and aa[1]==bb[1]:
                stats['matched_pairs']+=1
                assert aa[2]==bb[2] and not singletons
                i=aa[1];j,k0=[v for v in range(3) if v!=i]
                def level(q):
                    E=q+tail[i]
                    for lev in range(1,E//m+1):
                        val=E-lev*m
                        for y in range(val//tail[j]+1):
                            if (val-y*tail[j])%tail[k0]==0:return lev
                    raise AssertionError('missing return')
                assert level(aa[3])==level(bb[3])
                examples.setdefault('matched',{'generators':gs,'PF':pfs})

# A2 INPUT probes use exact integer cross products, not floating-point LP.
rng=random.Random(210907);dpe=Counter();dpe_examples={}
def cross(u,v):return [u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
def dot(u,v):return sum(a*b for a,b in zip(u,v))
for trial in range(200000):
    x=[rng.randint(1,35) for _ in range(3)]
    y=[rng.randint(1,15) for _ in range(3)]
    b=[rng.randint(1,10) for _ in range(3)];z=[y[i]+b[i] for i in range(3)]
    C=[[-x[0],z[1],y[2]],[y[0],-x[1],z[2]],[z[0],y[1],-x[2]]]
    n=cross([C[0][i]-C[1][i] for i in range(3)],[C[1][i]-C[2][i] for i in range(3)])
    if all(a<0 for a in n):n=[-a for a in n]
    m=dot(C[0],n)
    if not (m>0 and min(n)>m):continue
    dpe['input_states']+=1;state=x[:];seq=[]
    while True:
        assert min(state)>0
        opts=[[state[j]-C[i][j] for j in range(3)] for i in range(3)]
        positive=[i for i in range(3) if min(opts[i])>0]
        inbox=[i for i in positive if all(opts[i][j]<=x[j]+y[j]-1 for j in range(3))]
        assert len(inbox)<=1,('nonunique',x,y,b,state)
        if not inbox:
            assert positive,('DPE SINK',x,y,b,n,m,seq,state)
            dpe[f'colors_used_{len(set(seq))}']+=1
            dpe['max_path_length']=max(dpe['max_path_length'],len(seq))
            if seq:dpe_examples.setdefault(str(len(set(seq))),{'x':x,'y':y,'b':b,'path':seq,'terminal':state})
            break
        i=inbox[0];nxt=opts[i]
        assert dot(nxt,n)==dot(state,n)-m
        state=nxt;seq.append(i)
        assert len(seq)<=dot(x,n)//m

# Abstract E8 quotient/remainder map: all triples in a fixed declared box.
eu=Counter()
for R,T,u,w,ch in __import__('itertools').product(range(2,6),range(2,6),range(1,13),range(0,9),range(1,41)):
    E=R+u;H=T+w
    for th in range(1,u+1):
        D=th*ch-E*H
        if D<=0:continue
        eu['det_positive_states']+=1
        nu=u//th+1
        assert E-nu*th<=R-1
        if nu*H-ch<=T-1:
            eu['terminal']+=1
            if w==0:eu['w_zero_terminal']+=1
        else:
            eu['nonterminal']+=1
            e=E//th;rho=E-e*th;kap=ch-e*H
            assert nu==e+1 and R<=rho<th and 1<=kap<=w
            assert kap*th-H*rho==D
            assert E+ch>H+th and E+ch-H-th==(e-1)*(H+th)+rho+kap

out={'note':'Finite probes only; no claim that a bounded search proves any theorem.',
     'semigroup_max_generator':maxgen,'semigroups':dict(stats),'examples':examples,
     'DPE_random_seed':210907,'DPE_trials':200000,'DPE':dict(dpe),'DPE_examples':dpe_examples,
     'euclidean_bounds':'2<=R,T<=5; 1<=u<=12; 0<=w<=8; 1<=chi<=40; 1<=theta<=u',
     'euclidean':dict(eu),'counterexamples':0}
(ROOT/'adversarial_probes_result.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False))
