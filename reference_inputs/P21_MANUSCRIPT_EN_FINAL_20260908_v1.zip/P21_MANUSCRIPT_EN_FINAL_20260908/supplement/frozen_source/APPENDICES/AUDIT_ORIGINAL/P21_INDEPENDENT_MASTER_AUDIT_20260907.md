# P21 — 維持証明の独立全体監査

2026-09-07。対象：`P21_MAINTAINED_PROOF_20260907(1).zip`。

## A. EXECUTIVE VERDICT

\[
\boxed{\boxed{\textbf{FINAL FREEZE: PASS}}}
\]

\[
\boxed{\textbf{P21 CLOSED — maintained master independently audited}}
\]

**提出された維持証明から、明記されたcanonical条件の下で主定理が従うと判定する。** 本監査で検出したFATAL、MATERIAL、MINOR-PROOFはすべて0。非対称分類、各配置の排除、COREからCENTRALへの受渡し、Euclidean定理の終端・非終端双方を本文から点検した。

監査対象の主張は、正確に

\[
\Gamma=\langle m,n_1,n_2,n_3\rangle,\quad
\operatorname{edim}(\Gamma)=4,\quad m=\min(\Gamma\setminus\{0\}),
\]
\[
F(\Gamma)+m-\varphi\in\Gamma\quad(\forall\varphi\in PF(\Gamma))
\quad\Longrightarrow\quad t(\Gamma)\le4
\]

である。canonical条件を外した定理、証明支援系での形式検証、外部査読の完了を意味しない。

過去のPASS/CLOSED、採用監査の判定、編集報告の「unproved input=0」を証明根拠には使っていない。証明01–09、数学付録A1–A4、係数表・検算器と台帳を対象にした。歴史的発掘アーカイブおよびADOPTED_AUDITSの数学的結論へ遡る必要はなかった。

### 対象ファイルと同一性

| 項目 | 確認 |
|---|---|
| 維持master | `P21_MAINTAINED_PROOF_MASTER.md` |
| 編集上の正本 | 01–09の章ファイル |
| 数学付録 | A1 MINBOX、A2 COLOR-CAP、A3 U positivity、A4静的表 |
| 依存台帳 | `10_DEPENDENCY_LEDGER.md`、`APPENDICES/DEPENDENCY_LEDGER.json` |
| 編集資料 | README、EDITING_CHANGELOG、EDITING_AUDIT_REPORT |
| 実行対象 | rebuild_master、verify_D_linear、verify_euclidean_closure |
| 全係数表 | 715項および3,234項のJSON |
| 標準外部入力 | STD_SYM_GLUE、STD_HERZOG、STD_WHITE |
| 入力manifest | 46/46件一致 |
| 検算・master再生成後 | ZIP内の全47ファイルとbyte一致、変更なし |

入力ZIPのSHA-256：

```text
1b274f81215e88e591aacbfaa72211a82377a81dd3dfe61bde4525758534d538
```

### CLAIMED PROOF SPINE — 本監査で確認した接続

| 段階 | 得られること | 次への依存 |
|---|---|---|
| T1の仮定、C2 | 二層Apéry、KEY、actual rows、tail gcd=1、tail極小3生成 | 対称／非対称の二分 |
| S3 | 対称tailのRAW4が全てApéryに残ることは不可能 | 対称側で \(t\le4\) |
| G4.1–8、M4、A1–A2 | six-arm幾何、corner排除、matched制約、COLOR-CAP | G4.9 |
| G4.9 | 四つの異なるactual Q-rowsはPATH、TYPE II、CHAINに尽くされる | 三閉鎖 |
| P5.1–7 | PATH不存在 | I9 |
| T6 | TYPE II不存在 | I9 |
| R7 | 同じCHAINにCORE-ROOTを構成 | C8.1 |
| C8.1–2 | COREから境界・window・U・Dを尽くす | C8.3–4 |
| C8.3 | U不存在 | Dだけが残る |
| C8.4 | high-qとnonlinear first排除、linear firstから二packet | E8.2.3 |
| E8 | source-fit、全仮定保存、正整数下降、同じFの非負表示 | C8.5：CHAIN不存在 |
| I9 | 両tail・三配置に反例なし | \(\lvert Q\rvert\le3\)、\(t=\lvert Q\rvert+1\le4\) |

## B. ISSUE COUNTS

```text
FATAL:       0
MATERIAL:    0
MINOR-PROOF: 0
EDITORIAL:   1
CITATION:    3
```

EDITORIALは下界を等式のように読める日本語1箇所。CITATIONは第01章に残る外部入力3件の正確な引用箇所の整備である。いずれも欠けたプロジェクト固有補題ではなく、閉鎖を妨げない。詳細と変更案はJに記す。

## C. CHAPTER-BY-CHAPTER VERDICT

| 章／付録 | 数学判定 | 監査の要点 |
|---|---|---|
| 01 THEOREM AND SETUP | PASS | PF、Q、m、F、極小性、canonical条件が明示されている。標準入力3件の適用形は妥当 |
| 02 CANONICAL REDUCTION | PASS | 二層、KEY、complementのApéry性、整数群でのtail gcd証明が成立 |
| 03 SYMMETRIC CASE | PASS | GAP-K、BRIDGE、RAW4、Branch I/IIとk0/e分岐を確認 |
| 04 NONSYMMETRIC CLASSIFICATION | PASS | kernel証明、pair幾何、M4境界、SQ・Type Iの上流排除、四行の網羅性を確認 |
| 05 PATH | PASS | PAIR/PFREE、rootの有限正規化、符号先処理、double-unitの両return levelを確認 |
| 06 TYPE II | PASS | 二returnのactuality、全符号域のanchor cap、等level／両不等levelを確認 |
| 07 CHAIN CORE | PASS | 同じh_A上の最大i分解からrootを構成。完全色交換で入力保持 |
| 08 CENTRAL / EUCLIDEAN | PASS | boundary、strict window、U、D、E8が接続。EDITORIAL E01あり |
| 09 FINAL INTEGRATION | PASS | 全Qから選ぶ四行、tail dichotomy、三閉鎖を正しく結合 |
| 10 DEPENDENCY LEDGER | PASS | 42 node、循環・未解決IDなし、逆依存と本文所在も整合 |
| A1 MINBOX | PASS | Whiteの相対格子、全row ordering、両色の正値weight certificate |
| A2 COLOR-CAP | PASS | 初期sink、全一色／二色終端、第三色初出、dual-prefixとSAME-f |
| A3 U POSITIVITY | PASS | 表示された全係数分解を独立に記号照合 |
| A4 STATIC CERTIFICATES | PASS | 元多項式と静的表を全係数で照合。変数shift・正定数を確認 |

### 第02章：canonical reduction

非負gap xから有限集合 \((x+\Gamma)\setminus\Gamma\) の最大元を取る操作は正当で、そこから全gapに \(W-x\in\Gamma\) を拡張できる。非零Apéry元wには \(w>m\) が成り立つため、\(w-m\) への適用範囲も合う。

\(q+m\)、\(W\)、\(c_q=W-q\) は全てApéryに入る。特に \(c_q-m=F-q\in\Gamma\) なら、\(F-q>0\) とqのPF性が \(F\in\Gamma\) を与える。KEYでは

\[
F=(c_q-n_i)+(q+n_i-m)
\]

を使い、\(q+n_i\) のm係数を排除する。その後n_i係数もPF gapから排除する。\(D(c_q)\subseteq SH(q)\) のみを主張し、等号は使わない。

tail gcdは

\[
m=(q+m)+(W-q)-W\in\mathbb ZH
\]

であり、これは整数群の式として正しい。gcdがmも割ることと \(\gcd(\Gamma)=1\) からtail gcd=1。tailの極小性はΓの極小四生成から従い、第三のtop-level branchはない。

### 第03章：対称側

\(t\notin\Gamma\iff f-t\in K\) は、\(t-nm\notin H\) を各nについて対称性で反転することで得られる。\(F=f-h\)、\(r=h-m>0\)、stable condition、\(J\subseteq\Gamma\) へのcanonical条件の使用も整合する。

BRIDGEの逆方向では、\(c-n\in J\) と \(c\in\operatorname{Ap}(\Gamma,m)\) から \(c-n\in H\) としてH-minimalityに矛盾する。Γ-minimalityとH-minimalityを混同していない。

gluingのlayerは0とd−sのみ。二生成idealの各layerに高々2 minimaなのでRAW4が上限となる。\(t\ge5\) は四行全てがApéryに残ることを強制し、cross-layer comparabilityは \(\alpha,\beta>0\) を与える。

Branch Iの四hitは、同じPF行からGAP-Kで強制される。return N=1に前駆点のFSを適用していない。N>1のrectangle lower bounds、X-only／Y-onlyの純軸hit不能、XYでの \(\tau_2\notin T\) を確認した。Branch IIはk0=1、k0=0,e=0、k0=0,e>0を尽くす。最後のcaseではPHASEにより前駆点が同じcarry layerにあり、subcritical strip内のgapとなる。したがってS3の閉鎖は維持本文内にある。

### 第04章とA1–A2：分類

G4.3の整数kernel基底は、real係数の小数部から作る整数kernel vectorをcritical boxに入れて排除しており、primitive性や一般のfactorization connectivityを暗黙に追加していない。

matched pairのdepthとcomplement同期は、整数kernel係数の符号分岐を尽くして得られる。M4では各successorの**正のm-levelの最小値を別々に選ぶ**。不等levelが生む最終ABS±は \(g=0\)／\(\alpha=0\) でも非負である。等level後にのみm係数を消してpure two-ray criticalityを使う。

そのP-FIBERから、A_jとB_kは同じf_A/f_Bの分解内で除去できるので共存不能。S_iは \(\kappa\ge P\) と \(Pn_i-m\in\Gamma\) によりcomplementのApéry性に反する。S_j,S_kは別の局所補題で既に排除される。したがってSQとType Iは本文内で消えている。

A1ではempty tetrahedronを測る格子が \(p+L_m\)、相対体積がkであることを確認した。Whiteからの2+2分割、全非零classのAGE、rとその逆元qのcompanionsが必要なpositive-m分解へ戻る。両色のweightは正で、係数和が少なくともkDとなるため \(n_i>m\) に矛盾する。\(k=2\) や \(q=1\) のclass重複を別classと誤って数えていない。

A2ではu·nの減少が有限性を与える。MINBOXの係数制約とDPEを混同せず、DPE自体のINPUTからpositive exitまでを点検した。二色のsuccessful crossingsはchronological prefixであり、dual-prefixは \((N_s,K_s)=(s+K_s,K_s)\) により実際のrun上の状態へ戻る。この接続があるため、dualのgap回避を未証明で仮定していない。各sink領域のweightは非負で、第三色はその初出で排除される。最後のout-of-boxも全座標正であり、同じfの分解から \(\lambda_i n_i\) を実際に除去できる。

G4.9の4行は、cornerあり、singleton数2、1、0で網羅される。corner+反対色三armはCOLOR-CAPで消え、三singletonがある場合はG4.8がQ全体を3行に抑える。最終分類は

\[
\boxed{\textbf{NONSYMMETRIC TERMINAL CLASSIFICATION: PASS}}
\]

\[
\boxed{\mathrm{PATH}\ \vee\ \mathrm{TYPE\ II}\ \vee\ \mathrm{CHAIN}}.
\]

### PATHとTYPE II

PATHは同じ \(q_A+m,q_B+m\) にPAIRが作れるかどうかで分かれる。no-PAIRで正規化した各係数を比較するpure-H議論からPFREEの左右二方向を尽くす。PAIRのweak rootは \(K\mapsto K-\rho_k\) の際に全仮定を保持し、正整数Kが減る。endpoint level1は \(1\le V\le K<\rho_k\) のPURE-Kに反し、level≥2はLEFT-FABSで閉じる。

PFREEは \(F_0\le0\) を先に右singletonの二returnで排除してから、\(F_0\ge1\) を必要とする吸収へ進む。double-unitはunit差からPINを導き、反対側singletonのr≥2とr=1を両方排除する。最後のpure倍数は \(\alpha+Z+1\le\alpha+\nu=a_k<\rho_k\)。左右交換は生成元・全a/b・depth・PFラベル・P/R/Tを一括して交換している。

TYPE IIでは \(\lambda=b_i\) の境界を落としていない。\(\eta,\theta\) の符号域を使ってA,D≤b_i−1を得る過程も網羅的。equal levelsはpure-H criticality、不等levelsはABS-L/ABS-RでFを表す。ゼロになり得る \(g-1\) と \(a_k-\nu-1\) は非負で足りる。

## D. LOAD-BEARING THEOREM TABLE

| 定理／接続 | 判定 | 決定的な確認 |
|---|---|---|
| Canonical reduction | PASS | W、q+m、W−qのApéry性とKEY、tail gcd |
| SYM closure | PASS | BRIDGE→RAW4→全walk分岐の排除 |
| NONSYM classification | PASS | A1/A2を含むcorner・arm・singletonの網羅性 |
| M4 / SQ / TYPE I | PASS | g=0、α=0を保持したlevel同期とP-FIBER |
| PATH | PASS | PAIR/PFREE、符号、double-unit、左右双対 |
| TYPE II | PASS | 全域二returnとanchor cap |
| CHAIN CORE | PASS | 同じh_Aの最大i分解からunit root |
| CENTRAL exhaustion | PASS | C=α、strict window、U、Dで尽くす |
| U closure | PASS | 二つの供給不等式、全係数分解、U-FINAL |
| D reduction | PASS | first crossing、high-h、earlier lattice point、linear式 |
| Euclidean embedding | PASS | 初期行列・sources・RHO・正のdeterminant |
| Euclidean two-packet theorem | PASS | terminal source-fitと非終端の全仮定保存 |
| Well-foundedness | PASS | 正整数E+χの厳密減少 |
| CHAIN integration | PASS | 全COREから元のFの分解へ |
| NONSYM integration | PASS | 全三形排除をG4.9へ代入 |
| Final SYM/NONSYM integration | PASS | gcdを含む二分、全Qへの復帰、t=\lvert Q\rvert+1 |

### CHAIN CORE → CENTRAL INPUT

R7がC8.1へ渡すのは以下であり、全て同じΓ,F,m,Wと四つのPF行について成立する。

| 入力 | R7での供給 | C8.1との対応 |
|---|---|---|
| m<min n_r、Fがgap | 元の半群 | 同一 |
| 真のHCRと正のa_r,b_r | G4のHerzog package | 同一 |
| λ,δ,β,g,α≥1 | G4.11.2 | 同一 |
| a_i=λ+δ、b_i=λ+β | canonical式 | 同一 |
| P=λ+δ+β、R=a_j+g、T=b_k+α | canonical式 | 同一 |
| Wの非負box表示 | G4.11.2 | 同一 |
| q_Ai,q_Bi,q_Bj,q_Akのactual PF性 | 同じ四行を保持 | 同一 |
| m+dn_i=Sn_j+Cn_k | MAX-I選択から導出 | 同一 |
| 1≤d≤λ、S≥g+1、C≥α | ROOT-BOXとSTRICT、必要なら完全色交換 | 同一 |

R7のS≤b_j、C≤ρ_k等の上限を下流の追加仮定として隠してはいない。C8.1は必要なstrict slopesやreturn capsを自身のCOREから導く。

\[
\boxed{\textbf{CHAIN CORE → CENTRAL INPUT: SCOPE MATCH}}
\]

### CENTRALの受渡しと分岐

C8.1のSLOPESから \(hS<\rho_j\)、\(hC<\rho_k\) が従う。後者は \(h\le\lambda/d\)、\(d\rho_k>Cb_i\)、\(\lambda<b_i\) から直接得られる。このためintrinsic向きを反転する際の \(C\ge\alpha+1\) とCORE保存が成立する。

| 領域 | 排除／移行 |
|---|---|
| 第一点でΞ≤0 | HRJ自身が非負F-row |
| C=α、Ξ≥1 | boundary wall、EA/EB同期、det=1、正値係数でm>n_j |
| C>α、χ≤T、L_i≥2 | strict window。regularはm>n_j、Q=1・三例外はm>n_k |
| C>α、χ≤T、L_i=1 | λ=d、L=x=1、M=z+1、U-PARAMへ |
| UでD_u≤0 | UNIT-MULTからm≥n_i |
| UでD_u>0 | C8.3の全域閉鎖 |
| C>α、χ>T | D。χ≤C−α、C≥b_k+2α+1 |
| Dでq0≥3 | FIRST-BOUNDSとM-MASTER |
| Dでq0=2、N≥z+2 | earlier lattice pointと正値下界 |
| Dでq0=2、N=z+1 | linear-first parameterization |
| linearでθ≥υ+1 | J-ONLYが非負F-row |
| linearで1≤θ≤υ | E8へexact embedding |

FIのT-windowを任意のEBへ流用していない。EAとQjのkernel係数1は、もし2以上なら \(N\le L_i\) または \(N\le L_j\) を構成でき、window wallに反するという論理で得られる。空三角形の非頂点整数点ではI,J≥0となり同じ矛盾が生じるので、determinant 1が正当である。

strict windowの三例外はE_aの符号から導かれ、任意の数値打切りによる分類ではない。境界とstrictではk-ceilingが異なり、\(LC-\alpha\) を \((L-1)C\) と誤置換していない。

Uでは \(H_u=(t-1)\eta+r\)、\(0\le r<\eta\) より回数tを決める。\(D_u>0\) と \(C+b_k\ge(t+1)\eta\) から \(Q\ge(t+1)R+1\)。i-sourceは \(\Phi'(a)<0\) と \(\Phi(a_*)>0\) から得る。最終k係数は \(\eta-r-1\ge0\)。以上はtの全域に成立する。

Dのnonlinear firstでは、仮に \(I\ge r'\) なら \((z-\kappa,\ell_z-1)\) から以前のfitを作れる。ここでz>κなので新しいzも正であり、最初の点の定義に直接反する。linear firstへの移行で未知のbranchを省いていない。

### Euclidean定理の重点監査

全係数・入力範囲は、p,q,s,t≥1、pt−qs=1、L>M、r≥0、δ,β,g,α,a_j,b_k≥1、E=R+u、1≤θ≤u、H_p=T+w、w≥0、χ≥1、\(\mathcal D_p>0\)、二つのgenuine packets、RHO、HCR、同じWである。A,B,L,M,E,H_p,θ,χの正値性もここから従う。

初期行列 \(\begin{pmatrix}fk+1&f\\k&1\end{pmatrix}\) ではf,k≥1なので全成分が正、L>M、det=1。r≥0を保持し、A=b+fB、B=kb+c、E=R+υ、H_p=T+w、\(\theta\chi-EH_p=\mathscr D>0\) となる。RHOの両式も一致する。retired reduced-depth returnを必要としない。

終端は \(\nu=\lfloor u/\theta\rfloor+1\ge2\) により \(j_*=E-\nu\theta\le R-1\)。\(k_*\le T-1\) を満たす場合、以下を確認した。

1. det=1とL>Mからp≥s+1、q≥t。q=tも許す。
2. HCRのcross productsに共通scaleσ>0を残す。σ=1を仮定しない。
3. 二packetとdet=1からM-HATを同定する。
4. 他を固定した形式変数Pに対して \(\Phi'=-(\mathcal D_p+M_0)<0\)。
5. \(P_*=B+\nu A\) での静的多項式は全3,234項、定数63、全係数非負。
6. 閾値がactual半群であることを仮定せず、\(P\le P_*\Rightarrow m>n_k\) を得る。
7. 整数性から \(P\ge B+\nu A+1\)。最終F表示は

\[
F=(M+\nu L-1)m+(P-1-B-\nu A)n_i+(h-1)n_j+x n_k,
\]

で全係数非負。j_*やk_*が負でも、packetを正負部分に分けてから同じW内で置換するのでactualityを失わない。

非終端ではe=⌊E/θ⌋とし、determinant正値からκ≥1。FAILとν≤e+1からν=e+1が強制され、

\[
R\le\rho<\theta,\quad 1\le\kappa\le w
\]

を得る。したがってw=0は必ず終端。変換の全対応は以下である。

| 対象 | 変換 |
|---|---|
| n_i,n_j,n_k | n_i,n_k,n_j |
| a_i,b_i | b_i,a_i |
| a_j,b_j,a_k,b_k | b_k,a_k,b_j,a_j |
| δ,β,g,α | β,δ,α,g |
| P,R,T,r | P,T,R,r |
| ρ_j,ρ_k | ρ_k,ρ_j |
| E,H_p,θ,χ | H_p,ρ,κ,θ |
| u,w | w,ρ−R |
| source matrix | \(\begin{pmatrix}t+eq&s+ep\\q&p\end{pmatrix}\) |
| A,B,L,M | B+eA,A,M+eL,L |
| Γ,F,m,W | 全て不変 |

新しいdetは1、L′>M′、全packet係数は正、\(\mathcal D_p'=\mathcal D_p>0\)。RHOは名前交換後の旧multipliersへ一致する。帰納法が必要とする全仮定が保存される。

\[
(E+\chi)-(E'+\chi')=(e-1)(H_p+\theta)+\rho+\kappa>0
\]

なので下降はwell-founded。同じΓ,F,Wのまま終端へ達するため、終端のFの分解が元の問題の矛盾となる。

## E. ACTUALITY AUDIT

下表では危険な符号付き中間式と、実際に利用する非負表示を区別した。対称・巡回版は同じ全係数変換で含める。

| 箇所 | SAME要素／安全性 |
|---|---|
| C2 KEY | 同じFを二つのΓ元の和にする矛盾。tail gcd式は整数群だけ |
| S3 BRIDGE・backward point | a−m∈Hならstable propertyでKへ入り、canonicalからc−m∈Γ |
| G4 singleton caps | 同じcomplement／Wからκn_rを除く。差0は同じrowであり別行ではない |
| G4 pair幾何 | 元のgenuine complement係数からbox boundsを得る |
| G4.7.1 R=0 | 最初のW式はsigned、BA-W完成後だけをactualとする |
| M4 FI caps | actual successor+complementから1個のmを除き、ρ_j/ρ_k packetでiを作る |
| M4 ABS± | 中間のα−1／g−1が負でも、C≥1／Δ≥1により最終係数を修復 |
| G4.5.2–3 | 同じf_A/f_Bからarmを除去。P-FIBERは同じPn_i |
| A1 companions | strictly positive companionだけからu_i−1≥0の分解を作る |
| A2 SAME-F | firing t回後も同じf。positive exitなら全係数非負のままarmを除去 |
| P5 PAIR正規化 | 同じq_A+m、q_B+mのH分解内でHCR置換 |
| P5 root normalization | Γ、PF行、LJ/LKを固定。signed rootとactual final rowを区別 |
| P5 LEFT-FABS | ℓ−2≥0、P+A−d≥β+1、S−1≥0 |
| P5 PFREE符号処理 | F0≤0ではM+と右singletonを使用。F0≥1が確定後にM−吸収 |
| P5 double-unit | RIGHT-FABSではT−ν≥1。r=1ではZ≤ν−1をgapから得る |
| T6 anchor lifts | η≥1等を確認して同じf_Aへ上げる。f_Bのgap性は不使用 |
| T6 ABS-L/R | m係数はlevel差−1、各source下限で全非負 |
| R7 MAX-I | 名前を固定したh_A上で最大を取る。全分解集合は有限 |
| R7 F-S/F-C/F-D | 仮定した違反があるときだけ最終F係数が全非負 |
| C8.1 caps・notch | actual RETにrootを代入した最終gap／F表示で係数を判断 |
| C8.2 PACKET | 二つのactual upperをk加算で同じ元へ揃え、共通I,Jだけを除く |
| C8.2 FI/FJ | χ>0ではT個のkで供給、χ≤0ではkを生成する |
| C8.2 FJ ceiling | EA-ONEの左packetがactual FJに入る場合に限って使用 |
| U-FINAL | 同じq_Ak+(H_u+1)n_kでt回置換後、追加したkを全量除去 |
| D J-ONLY | i-fit証明後にf+1回置換。θ−υ−1だけが残る符号条件 |
| D complementary | exact packetの和を整理した両辺が非負。別PF rowを仮定しない |
| E8 terminal | signed j_*,k_*は正負部分に分離。sourceが同じWに入り、最後にmを1個除去 |
| E8 nonterminal | 新DPは旧PP、新PPは旧DP+ePP。整列後の全係数が正 |

違法なsigned-to-actual転換、異なる元のfactorizationの混用、除去できないshiftの残留は検出しなかった。

## F. CRITICALITY AUDIT

ここで「m係数=0」は表示式中のmの係数が0という意味であり、multiplicity m自体を0とする意味ではない。

| 使用箇所 | m係数=0の根拠とsubcritical対象 |
|---|---|
| G4.1.1 six-arm上限 | H所属を仮定した二つのH表示。ρ_k−1−Z、または双対のρ_j−1−Y |
| G4.2 SR/CB・二座標一意性 | 全てH-factorization。κ_r<ρ_r、二座標差も各ρ未満 |
| G4.3 box uniqueness | 純H分解の差。一方の符号に一種類だけが立つ |
| G4.3 integer basis | 整数kernelの小数部代表。各座標の絶対値が対応ρ未満 |
| G4.5–7 pair比較 | 二つのcomplement差とPF式を比較した純H kernel。基底補題を使用 |
| M4.2 E_A/E_B∉H | level0を仮定している。P、δ、βが正でρ_i未満 |
| M4.5 等level | L_A=L_B後に差のmを消去。0<|x|<ρ_j、0<|y|<ρ_k |
| G4.8、G4.11.1 | WのH表示にのみbox/kernel補題を使用 |
| P5.1 central comparison | 両方q+mであり差でmが消える。HCR比較後の各短い係数もsubcritical |
| P5.3 PURE-K | ℓ=1とunit ROOTの代入でmを消去。1≤V≤K<ρ_k |
| P5.4 UNIT-DIFF | r=s=1後。X+1≤a_i<ρ_i、U+1≤b_j<ρ_j |
| P5.5 PF-FIX | unit returnとM+を比較。P_c≤ρ_iからHCRを1枚引き、短いj/k倍数を排除 |
| P5.6 EQ/EQ-RJ | 両unit returnsの差。C+1≤b_k<ρ_k、または0<x<ρ_i |
| P5.6 LAST | r=1の右returnへROOT-Tを代入後。α+Z+1≤a_k<ρ_k |
| T6.5 equal levels | ℓ=hでm消去。C+1≤b_k<ρ_kまたはB+1≤a_j<ρ_j |
| C8.1 level0排除 | RETのlevel0を仮定。P、δ、β、g、αの純H subcritical関係 |
| C8.1 I-LEVEL | ROOT代入でmを完全消去。L_id<λを仮定したP+L_id<ρ_i |
| C8.1 Bj level bound | 同じROOT代入。A_j≤d−1とL_jd≤λでi係数を挟む |
| C8.1 L_j=q0比較 | 同じq_Bj+Δ0 n_jの等level表示。三差係数の絶対値が各ρ未満 |
| C8.1 strict Ak | K-PUREでmなし。L_k≤hを仮定した短いi倍数、次にρ_i以上の必要性 |
| C8.2 EA/Qj/EB kernel | actual returnからROOTでmを消去してG4.3を適用 |

S3の二生成normal-form判定をHerzog criticalityにすり替えていない。R7の極値選択、A1/A2のmultiplicity weight、C8の正値多項式比較、E8の下降・source-fitは、正のm係数をもつsigned relationへのbare criticalityではない。

## G. SCOPE AUDIT

| scope transfer | 判定・理由 |
|---|---|
| canonical PF条件→全gap | PASS：C2.1の最大元で直接証明 |
| Q全体→選択四行→Q全体の上界 | PASS：四行への選択でQ全体を4元に固定していない |
| gcd未確認tail→真の3生成数値半群 | PASS：C2.4–5が先行 |
| STD_HERZOG→six-arm | PASS：atlasのdepth上限をG4.1.1で証明 |
| M4の境界→SQ・Type I排除 | PASS：g,α≥0のまま証明済み |
| White→MINBOX | PASS：相対格子・体積・2+2 partition・両色を確認 |
| MINBOX→DPE→COLOR-CAP | PASS：同じsocle elementとarm bounds |
| P5の片側→反対側 | PASS：P5-dualの全parameter表 |
| T6の局所scalar→全TYPE II | PASS：G4.11.3のλ≤b_iを含む入力と一致 |
| 最大i選択→同じactual CHAIN | PASS：PF元やWを再選択していない |
| CORE→CENTRALのintrinsic向き | PASS：反転側でもS′≥g′+1、C′≥α′ |
| strict-Cのnotch→D | PASS：C>αを確定してから使用 |
| FI/FJ window→EA/Qj | PASS：選んだactual returnsだけで足りる。任意EBへのT-window移植なし |
| L_i=1→U | PASS：window下のtriangleを使用。factorization唯一性は不要 |
| D linear→E8 | PASS：J-FAILからu≥1、θ≤u、二packet・RHO・det>0を供給 |
| E8→交換後E8 | PASS：全係数・matrix・RHO・HCR・W・multiplicityを保存 |
| E8終端→元のF | PASS：生成元名の交換のみ、Γ,F,m,W不変 |

### 標準外部定理の照合

**STD_SYM_GLUE。** 必要なのは、極小3生成で対称なら置換後 \(H=\langle du,dv,w\rangle\)、d,u,v≥2、gcd(u,v)=gcd(d,w)=1、\(w\in\langle u,v\rangle\) と書けるという方向。García-Sánchez–Martín CruzのTheorem 6はこの全対称3生成の表示を明記しており、a→d、m1→u、m2→v、bm1+cm2→wで一致する。片方のwの係数が0のgluingもS3は除外していない。[Numerical semigroups with embedding dimension three and minimal catenary degree, Theorem 6](https://math.colgate.edu/~integers/u81/u81.pdf)。Delorme原論文の書誌も確認できる。[Delorme (1976)](https://www.numdam.org/articles/10.24033/asens.1307/)

**STD_HERZOG。** Nari–Numata–Watanabeの式(2.1.1)、Proposition 2.1、Proposition 2.2でgenerator式、真のcritical multipliers、二つのPF式を照合した。原論文の(a,b,c)→(n_i,n_j,n_k)、(α,β,γ)→(a_i,a_j,a_k)、(α′,β′,γ′)→(b_i,b_j,b_k)でHCRに一致する。PF式はHCRを使って本書の巡回式へ一致する。pairwise coprimeの追加条件は不要。[Genus of numerical semigroups generated by three elements, §2](https://arxiv.org/html/1104.3600v1)

**STD_WHITE。** 本文が必要とするのはempty lattice tetrahedronのwidth-oneだけ。Khan–RogersのTheorems 3–4のnormal formからこの形を確認できる。k≥2で1+3分割が不可能であることは、底面のempty triangleと高さ1から体積1になるというA1自身の議論であり、Whiteへ追加の主張を押し付けていない。[An Exposition of White’s Characterization of Empty Lattice Tetrahedra, Theorems 3–4](https://arxiv.org/html/1610.01981v1)。原論文の誌名・年・頁・DOIは出版社の記録と一致する。[White (1964), Lattice Tetrahedra](https://www.cambridge.org/core/journals/canadian-journal-of-mathematics/article/lattice-tetrahedra/636DC00E906DE4E640AB27580B9E90D3)

第01章の原典の「定理番号：公表前照合」はそのまま残るためCITATIONを3件計上する。Herzog原典の本文・White原典の定理番号を今回直接確認できたとは主張しない。適用する数学的形は上記の公開論文本文で照合できている。

## H. COMPUTATIONAL CERTIFICATE AUDIT

### 実行結果

| 検査 | 実測結果 |
|---|---|
| SHA256SUMS | 46/46 PASS |
| rebuild_master | 再生成前後でbyte完全一致 |
| ZIP対再生成・再検算後の全ファイル | 47/47 byte一致 |
| JSON依存台帳 | 42 node、循環0、未解決ID0 |
| used_inとdepends_onの逆対応 | 相違0 |
| nodeの本文所在 | 全件確認 |
| maintained文書の相対ファイルリンク | 113件、壊れたリンク0 |
| verify_D_linear.py | PASS、28恒等式、715単項式、定数35 |
| verify_euclidean_closure.py | PASS、35恒等式、3,234単項式、定数63 |
| 独立に追加した記号検算 | PASS、23恒等式 |

環境はPython 3、SymPy 1.14.0。初回は環境にSymPyがなくimport失敗したが、専用作業ディレクトリへ依存を導入して両方を正常実行した。提出コードの修正はしていない。

113件はmaintained章・README・台帳・数学付録等の**相対ファイルの存在**の検査数。歴史監査内部の古い参照、インラインのあらゆる定理引用、全てのMarkdown rendererでの表示を機械検証したという意味ではない。本文の依存は別途読査した。READMEが報告する原発掘アーカイブ1,077件のhashは、今回のZIP外なので再検算の件数に含めない。

### 静的certificateの証明としての意味

両verifierは既存の全係数表を読み、本文に対応する定義式を記号展開して表そのものと一致することを確認する。`--write-certificate`は使用していない。係数表を都合よく生成し直してからPASSにしたものではない。

linearのshiftはf−1,r,δ−1,β−1,g−1,υ,α−1,w,θ−1,ε,k−1,a_j−1,b_k−1。本文で全変数の非負性が得られる。EuclideanのshiftはORDER、ν≥2、h≥1と残余の非負性に対応する。Euclideanの閾値多項式はdet=1を外したより広いORDER領域でも全係数非負だが、実際のm̂への同定にはdet=1を使用している。この二段階は混同されていない。

追加23検算はA1の両socle matrix・det・adjugate、Uの微分とA3全分解、C8.2のboundary CA/CB・strict J/K・Dbase係数式。C8.2でdet=1が必要な恒等式は、数値代入ではなく多項式 \(xM-zL-1\) による余りを0と照合した。

### 反例探索と境界点検

証明読査とは別に、次の有限検査を行った。いずれも**有限反例探索であり、全パラメータ定理の証明ではない**。

| 探索 | 結果 |
|---|---|
| 4≤m<n1<n2<n3≤50 | 178,365候補、極小四生成・gcd1は82,138件 |
| 上記のcanonical条件 | 21,216件、type>4の反例0 |
| canonical type分布 | t=1：6,703、t=2：8,651、t=3：5,823、t=4：39 |
| Q非空のtail | 対称4,825、非対称9,688。gcdとKEYに反例0 |
| matched pair | 50配置でdepth・最小正m-level同期とsingleton排除に反例0 |
| A2 DPE | seed=210907、200,000抽出、INPUT適合5,194、sink反例0 |
| DPEの経路 | 初手でexit4,360、一色812、二色22、最大7 firings |
| E8余り変換 | 指定範囲でdet>0の198,836状態、終端195,704、非終端3,132、変換破綻0 |
| E8 w=0 | 上記中33,972状態、全て終端 |

E8の有限検査は2≤R,T≤5、1≤u≤12、0≤w≤8、1≤χ≤40、1≤θ≤uに限定し、余り変換の算術を検査した。これらが全てactual semigroupを表すとは仮定していない。DPEの抽出はx_i∈[1,35]、y_i∈[1,15]、b_i∈[1,10]で、浮動小数点を使わずrow差のcross productから正のn,mを構成した。

| 重点境界 | 全域証明での処理 |
|---|---|
| d=1 | strict C>αではSUM-NOTCHとe0≤dに反する。C=αはboundary定理に含む |
| q0=2 | Dのnonlinear／linear firstを両方処理 |
| C=α | strict notchを使わずboundary wallと同期で処理 |
| g=0またはα=0 | M4のABS±最終係数で修復。CHAIN入口では別途strictになる |
| R=0のpair | BA-W完成表示。PATHではpure-ray antichainからR>0 |
| λ=b_i in TYPE II | T6の非厳密上限を保持 |
| level1 | PATHのpure relation／double-unit、CENTRALのU例外で処理 |
| w=0 | E8のFAILが1≤κ≤wを要求するので不可能 |
| Δ0=1 | first-point選択・U/D・E8で除外していない |
| r=0、x=0、h=1 | 正値多項式のshiftで非負境界を許し、最終F係数が0でも可 |
| q=tのsource matrix | ORDERはq≥t。静的certificateのq0=0に含まれる |
| White k=2、逆元q=1 | 重複classに依存せず同じcompanion条件を使用 |
| 完全色交換の固定値 | 不変量にstrict asymmetryを要求しない |

## I. COMPRESSION AUDIT

| 退役した経路 | 維持証明による包含 | 判定 |
|---|---|---|
| SQ個別閉鎖 | M4→G4.5.2がmatched pairへの逆向きextra armを直接排除 | PASS |
| Type I個別閉鎖 | G4.5.3がmatched pairと全singletonの共存を排除 | PASS |
| Type IIの多数のchambers | T6の全符号域capと全level比較 | PASS |
| PATHの旧F-route等 | 現行PAIR/PFREEの網羅性と直接endpoint閉鎖 | PASS |
| CHAIN nonmatch/HIGH/ORIGINAL POSJ等 | 全actual CHAINをR7が直接COREへ送る | PASS |
| CENTRALの歴史的repair ladders | intrinsic向き→boundary/window→U/D→linear→E8で全COREを尽くす | PASS |
| reduced-depth return以降 | E8が二packetと明示的な代数条件だけで完結 | PASS |
| 旧五形による最終結合 | G4.9の現行三形からI9で再結合 | PASS |

現行証明は \(\mathrm{CHAIN}_{res}\subseteq\mathcal H_{unit}\cup\mathcal C_{matched}\) を独立した仮定として使用していない。より上流の全actual CHAINにR7を適用してC8.1へ送るので、退役した \(\mathcal H_{unit}\) を別に引用し直す必要はない。歴史的名称の全てを再分類したという主張ではなく、**上流の全入力が新しい定理のscopeに入ること**により包含を確認した。

## J. REQUIRED REPAIRS

数学上の必須修理リストは空である。以下の4件は文章・書誌の整備であり、P21 CLOSEDを保留する理由にはしない。提出本文は本監査では変更していない。

### E01 — EDITORIAL：C8.2.9.2の「a係数」の下界表現

現行の「従ってa係数は \((L+x)(L+1)-2>0\)」を、次に置き換える。

> 従ってa係数は \((L+x)(L+1)-2\) 以上であり、正である。

これは等式の訂正ではなく、既存の下界を下界として書くための修正。実際、Q=1ではその係数をD_aとすると、直前の表示式とL≥x+1から

\[
D_a=(L+x)(a_j+Lg)+E
\ge(L+x)(L+1)+L-x-3
\ge(L+x)(L+1)-2>0.
\]

すでに与えられた式だけで証明され、正値性の論理に穴はない。MINOR-PROOFへ格上げしない。

### C01 — CITATION：STD_SYM_GLUE

Herzog/Delormeの原典番号を照合して記入するか、確認済みのGarcía-Sánchez–Martín Cruz (2020), Theorem 6を補助引用として追記する。必要なgluingの対応はGに記した。元の適用形を変更する必要はない。

### C02 — CITATION：STD_HERZOG

原典番号を記入するか、確認済みのNari–Numata–Watanabe, §2、式(2.1.1)、Propositions 2.1–2.2を併記する。criticality、generator formulas、PF formulasの三用途をこのlocatorsで対応させられる。

### C03 — CITATION：STD_WHITE

White原典の引用箇所を確定するか、Khan–Rogers, Theorems 3–4を補助引用として併記する。width-oneから本書の相対格子・2+2 partitionへの接続はA1に既にある。

## K. FINAL FREEZE RECOMMENDATION

**最終frozen verification editionの作成へ進んでよい。** 数学本文の新しい補完証明やbranch再探索は要求しない。E01と引用3件を整え、元の章正本・通読master・台帳・静的係数表・検算器・本監査報告を対応させて固定するのが次工程である。

本監査はここで停止し、論文導入の執筆、再圧縮、publication LaTeXへの変換、定理の強化は行わない。

\[
\boxed{\operatorname{edim}(\Gamma)=4\ \&\ \text{CANONICAL}
\Longrightarrow |Q(\Gamma)|\le3
\Longrightarrow t(\Gamma)\le4.}
\]

### 同梱再現資料

監査ZIPにはこの報告書、未変更の監査対象package、`audit_checks.py`と実行結果、`adversarial_probes.py`と実行結果、機械可読issue台帳、SHA-256一覧を収める。

`audit_checks.py`はPython 3とSymPy 1.14.0を必要とし、ZIP展開先で実行できる。`adversarial_probes.py`はPython標準ライブラリだけで実行できる。独立追加検算・有限探索の実施範囲と結果は、各JSONに保存した。
