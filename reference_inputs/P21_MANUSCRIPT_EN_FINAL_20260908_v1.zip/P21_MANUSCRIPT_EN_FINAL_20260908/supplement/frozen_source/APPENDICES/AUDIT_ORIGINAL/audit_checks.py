"""Independent supplemental checks; bounded probes are NOT proofs."""
from pathlib import Path
import hashlib, itertools, json, math, re, subprocess, sys
import sympy as s

ROOT=Path(__file__).resolve().parent
PKG=ROOT/'audit_input/P21_MAINTAINED_PROOF'
checks=[]
def zero(name,expr):
    residual=s.factor(s.expand(expr))
    if residual!=0: raise AssertionError((name,str(residual)))
    checks.append(name)

# A1: row, determinant, companion and positive weight identities.
a1,a2,a3,b1,b2,b3,p1,p2,p3,k,r,q,ell=s.symbols('a1 a2 a3 b1 b2 b3 p1 p2 p3 k r q ell')
n=s.Matrix([a2*a3+a3*b2+b2*b3,a1*a3+a1*b3+b1*b3,a1*a2+a2*b1+b1*b2])
UA=s.Matrix([[0,a2+b2,a3],[a1,0,a3+b3],[a1+b1,a2,0]])
UB=s.Matrix([[0,b2,a3+b3],[a1+b1,0,b3],[b1,a2+b2,0]])
p=s.Matrix([[p1,p2,p3]])
for color,U in [('A',UA),('B',UB)]:
    socle=(U*n)[0]
    for i in range(3): zero(f'A1 {color} socle row {i}',(U*n)[i]-socle)
    zero(f'A1 {color} det U',U.det()-socle)
    for i in range(3): zero(f'A1 {color} adj U {i}',(U.adjugate()*s.ones(3,1))[i]-n[i])
    C=U-s.ones(3,1)*p
    zero(f'A1 {color} det C',C.det()-(socle-(p*n)[0]))

# A3: rebuild the U polynomial directly from the mathematical definitions.
t,z,al,eta,rr,w,aj,g,qp,de,be,aa,Q,C,bk=s.symbols('t z alpha eta r w aj g qp delta beta a Q C bk')
d=aa+z*de; ai=d+de;bi=d+be;rj=g+(z+1)*Q;rk=(z+1)*C+eta+z*bk
II=rj*rk-aj*bk;JJ=ai*rk+bi*bk;KK=bi*rj+ai*aj;mh=-d*II+(g+z*Q)*JJ+C*KK
zero('U derivative',s.diff(mh-JJ,aa)+Q*eta-(aj+g)*(C+bk)+rk+bk)
phi=s.expand((mh-JJ).subs(aa,t*(z*de+be)+be).subs({C:al+t*eta+rr,bk:eta-al+w,Q:(t+1)*(aj+g)+1+qp},simultaneous=True))
Pd=al*(2*t*z+3*z+1)+eta*(t*t*z*z+t*t*z+3*t*z*z+t*z+t+2*z*z)+rr*(t*z*z+3*t*z+2*z*z+4*z+1)+w*z*(t*z+t+2*z+1)
Pb=2*al*(t+2)+eta*(t*t*z+t*t+3*t*z+2*z-3)+rr*(t*z+3*t+2*z+5)+w*(t*z+t+2*z+1)
Xd=al*(t*z+z+1)+eta*(t*t*z*z+t*t*z+2*t*z*z+2*t*z+t+z*z+z)+rr*(t*z*z+2*t*z+z*z+2*z+1)+w*(t*z*z+t*z+z*z+z)
Yd=al*(t*z+z+1)+eta*(t*t*z*z+t*t*z+2*t*z*z+3*t*z+t+z*z+2*z+1)+rr*(t*z*z+2*t*z+z*z+3*z+1)+w*(t*z*z+t*z+z*z+2*z)
Xb=al*(t+1)+eta*(t*t*z+t*t+2*t*z+t+z)+rr*(t*z+2*t+z+2)+w*(t*z+t+z+1)
Yb=al*(t+1)+eta*(t*t*z+t*t+2*t*z+2*t+z+1)+rr*(t*z+2*t+z+3)+w*(t*z+t+z+2)
Zd=z*(al+eta*(t+1)*z+rr*(z+1)+w*z)
Zb=al+eta*((t+1)*z-1)+rr*(z+1)+w*z
zero('A3 U full POS-DECOMP',phi-de*(Pd+(aj-1)*Xd+(g-1)*Yd+qp*Zd)-be*(Pb+(aj-1)*Xb+(g-1)*Yb+qp*Zb))

# C8.2: symbolic identities; reduce only by x*M-z*L=1, never sampled values.
a,de,be,aj,g,Q,L,M,x,z,C,al,bk,H0=s.symbols('a delta beta aj g Q L M x z C alpha bk H0')
def detzero(name,expr):
    poly=s.Poly(s.expand(expr),x,M,z,L,a,de,be,aj,g,Q,C,al,bk,H0)
    divisor=s.Poly(x*M-z*L-1,*poly.gens)
    zero(name,poly.rem(divisor).as_expr())
d=x*a+z*de;S=x*g+z*Q;ai=L*a+M*de;bi=L*a+(M-1)*de+be;rj=L*g+M*Q
V=a*Q-de*g; Dj=d*aj+S*bi;KK=bi*rj+ai*aj;P0=V+ai
CA=KK-(M+L-1)*P0;CB=Dj-bi-(z+x-1)*P0
Aa=(L-1)*(M-1)*(Q-2)+L**2*(g-1)+L*(aj-1)+(L-2)*M+2
Ad=M*(M-1)*(Q-2)+(L*M+M-1)*(g-1)+M*(aj-1)+M**2+M-1
Ba=(z*(L-1)-x+1)*(Q-2)+L*x*(g-1)+x*(aj-1)+z*(L-x-1)+(z-1)*(x-1)+1
Bd=(x*M+z-1)*(g-1)+z*(M-1)*(Q-2)+z*(aj-1)+z*M
detzero('C8 boundary CA',CA-a*Aa-de*Ad-be*rj)
detzero('C8 boundary CB',CB-a*Ba-de*Bd-be*(S-1))
rk=(M+L)*C+(z+x-1)*bk-al-H0
II=rj*rk-aj*bk;JJ=ai*rk+bi*bk;mh=-d*II+S*JJ+C*KK
detzero('C8 strict J',mh-JJ-H0*P0-al*CA-(C-al)*(CA-P0)-bk*CB)
AP=KK-(M+L)*V;BP=Dj-(z+x-1)*V;Db=2*AP+BP+V-KK
detzero('C8 strict K',mh-KK-H0*V-(al-1)*(V+AP)-(C-al-1)*AP-(bk-1)*BP-Db)
E=(L-2)*M+(L-1)*z-2*L-x+2
Da=(L+x)*aj+L*(L+x)*g+E*Q
Dd=(M-1)*rj+(M+z)*aj+(M-1)*S+(2*(M+L)+z+x-2)*g
detzero('C8 Dbase coefficients',Db-a*Da-de*Dd-be*(rj+S))

# Package checks: the rebuilt master must be byte-identical.
before=(PKG/'P21_MAINTAINED_PROOF_MASTER.md').read_bytes()
subprocess.run([sys.executable,str(PKG/'APPENDICES/rebuild_master.py')],check=True,capture_output=True)
assert before==(PKG/'P21_MAINTAINED_PROOF_MASTER.md').read_bytes()
ledger=json.loads((PKG/'APPENDICES/DEPENDENCY_LEDGER.json').read_text())
nodes={r['id']:r for r in ledger['nodes']};ext=set(ledger['external_inputs'])
seen=set();active=set()
def dfs(v):
    if v in ext or v in seen:return
    assert v in nodes and v not in active, v
    active.add(v)
    for c in nodes[v]['depends_on']:dfs(c)
    active.remove(v);seen.add(v)
for v in nodes:dfs(v)
reverse_errors=[]
for v,node in nodes.items():
    assert (PKG/node['location']).is_file()
    assert v in (PKG/node['location']).read_text()
    actual=sorted(k for k,n in nodes.items() if v in n['depends_on'])
    if actual!=sorted(node['used_in']): reverse_errors.append({'id':v,'declared':node['used_in'],'actual':actual})
links=0;badlinks=[]
for f in list(PKG.glob('*.md'))+list((PKG/'APPENDICES').glob('A*.md')):
    body=re.sub(r'\\\[.*?\\\]|\\\(.*?\\\)|```.*?```','',f.read_text(),flags=re.S)
    for dest in re.findall(r'\]\(([^)]+)\)',body):
        if re.match(r'https?://|#',dest):continue
        dest=dest.split('#')[0];links+=1
        if not (f.parent/dest).exists():badlinks.append([str(f.relative_to(PKG)),dest])
assert not badlinks,badlinks

result={'symbolic_identity_count':len(checks),'symbolic_checks':checks,
        'rebuild_byte_identical':True,'ledger_nodes':len(nodes),'ledger_acyclic':True,
        'reverse_edge_mismatches':reverse_errors,'markdown_file_links':links,'broken_file_links':badlinks}
(ROOT/'audit_checks_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
