# CHAIN → CENTRAL ROOT：独立監査・完全な局所証明

2026-09-07。root-free matched-pair level rigidity と、新しい max-i Apéry construction を独立に確認した記録。歴史上の ROOT 原証明を回収したという意味ではない。

## 判定

**PASS。正の canonical CHAIN core から CORE-ROOT が得られる。**

したがって、`CENTRAL_ENTRY_AUDIT.md` の条件付き定理に残っていた ROOT の入口がここで埋まる。正の canonical parameters、同じ W、四つの canonical PF 行が揃えば、旧 \(\mathcal H_{\rm unit}\cup\mathcal C_{\rm matched}\) 分類を再現せず、直接 CENTRAL 閉鎖へ接続できる。

## 1. 仮定と使用する新規補完定理

`CENTRAL_ENTRY_AUDIT.md` §0 の CORE から ROOT 仮定だけを除いたものを仮定する。すなわち
\[
\Gamma=\langle m,n_i,n_j,n_k\rangle,
\quad 0<m<\min(n_i,n_j,n_k),\quad F=F(\Gamma),
\]
正の canonical parameters と真の pure-H critical relations、
\[
P=\lambda+\delta+\beta,\quad a_i=\lambda+\delta,\quad b_i=\lambda+\beta,
\quad R=a_j+g,\quad T=b_k+\alpha,
\]
\[
W=F+m=(P-1)n_i+(R-1)n_j+(T-1)n_k,
\]
および四つの actual PF 行である。特に \(\lambda,\delta,\beta,g,\alpha\ge1\)。

`HIGH_ENTRY_AUDIT.md` §§2–5 の root-free matched-pair level rigidity により
\[
P n_i=Lm+(t+1)n_j+(u+1)n_k,
\qquad L\ge1,\quad t,u\ge0.
\tag{P-FIBER}
\]

この定理の依存も今回独立に確認した。Ai/Bi の任意の successor は missing-i coordinate がゼロで、pure criticality により m-level は正。その正levelの最小値を各元について選ぶ。異なるlevelsならcanonical差から \(\sigma m+C n_k=\Delta n_j\) または双対を得て、\(0<\Delta<\rho_j\)、\(0<C<\rho_k\) とW-J/W-Kの最終非負F表示が矛盾を与える。等levelならsubcriticalな二生成元差はゼロとなり、P-FIBERが得られる。ROOT、HIGH閉鎖、CHAINの旧二成分分類を前提にしていない。

## 2. 同じ Apéry 元の max-i 表示

\[
h_A:=q_{A_i}+m\in\operatorname{Ap}(\Gamma,m)\subseteq H.
\]
PF 性が \(h_A\in\Gamma\) を、\(q_{A_i}\notin\Gamma\) が Apéry 性を与える。従って hA の全 factorization は m-coordinate ゼロ。

hA の H-factorization のうち i-coordinate が最大のものを一つ固定する：
\[
h_A=Xn_i+Yn_j+Zn_k,\qquad X,Y,Z\ge0.
\]
正の整数生成元に関する固定された元のfactorization集合は有限であるため、最大値は存在する。factorization一意性は仮定しない。

P-FIBER により
\[
X\le P-1.
\]
もし X≥P なら、同じ hA 内の Pni を P-FIBER の右辺へ置換すると正の m-coordinate ができ、Apéry 性に反する。

さらに
\[
Y\le\rho_j-1,\qquad Z\le\rho_k-1.
\]
Y≥ρj なら \(\mathcal R_j\) の実際の置換で i-coordinate が ai>0 増え、X の最大性に反する。Z≥ρk も \(\mathcal R_k\) により同様。

定める：
\[
d=P-1-X\ge0,\qquad S=Y-a_j+1\le b_j,\qquad C=Z+1\in[1,\rho_k].
\]
hA の canonical 表示との比較から exact に
\[
m+d n_i=S n_j+C n_k.
\tag{ROOT-INITIAL}
\]
この時点では S の正値性をまだ主張しない。

## 3. W の二つの genuine faces で下限を強制する

canonical relations と正の δ,g,β,α により
\[
W=(\delta-1)n_i+(g-1)n_j+(\rho_k+T-1)n_k
\tag{W-K}
\]
および
\[
W=(\beta-1)n_i+(\rho_j+R-1)n_j+(\alpha-1)n_k
\tag{W-J}
\]
は genuine factorizations。

### S>=g

S≤g−1 と仮定する。W-K と ROOT-INITIAL の exact substitution により
\[
F=(d+\delta-1)n_i+(g-1-S)n_j+(\rho_k+T-1-C)n_k.
\]
第一係数は d≥0、δ≥1 により非負、第二も非負。第三は C≤ρk により T−1≥1 以上である。従って F∈Γ、矛盾。よって S≥g≥1。

### C>=alpha

C≤α−1 と仮定する。W-J を用いると
\[
F=(d+\beta-1)n_i+(\rho_j+R-1-S)n_j+(\alpha-1-C)n_k.
\]
S≤bj により第二係数は少なくとも 2aj+g−1≥2。残りも非負。再び F∈Γ。従って C≥α。

### d>=1

d=0 なら ROOT-INITIAL は \(m=S n_j+C n_k\)。S≥1、C≥1 により m>nj、multiplicity に矛盾。ゆえに d≥1。

## 4. Ri で d<=lambda を強制する

d≥λ+1 と仮定する。canonical W に ROOT-INITIAL を代入した completed F-row から Ri を一枚比較すると
\[
F=(d-\lambda-1)n_i+(R+b_j-S-1)n_j+(T+a_k-C-1)n_k.
\]
第一係数は仮定により非負。S≤bj により第二は R−1≥1 以上。C≤ρk=ak+bk により第三は α−1≥0 以上。

これは全係数非負の一個の最終F表示であり、F∈Γの矛盾。したがって
\[
1\le d\le\lambda,
\quad S\ge g,\quad C\ge\alpha.
\tag{ROOT-BOUNDS}
\]

## 5. 同時等号の除外と安全な色交換

S=g、C=α が同時に成り立つと
\[
F=(P+d-1)n_i+(a_j-1)n_j+(b_k-1)n_k\in\Gamma
\]
という直接の全係数非負表示が既に得られて矛盾する。これは `CHAIN_ROOT_PROGRESS.md` §4 のより短い導出である。

PF-complement の言葉でも、同じ矛盾は
\[
c_{B_i}-m=R n_j+\alpha n_k-m=d n_i+a_jn_j\in\Gamma\setminus\{0\}.
\]
しかも \(c_{B_i}=W-q_{B_i}\) なので左辺は F−qBi。qBi の PF 性により
\[
F=q_{B_i}+(F-q_{B_i})\in\Gamma,
\]
矛盾。従って S>g または C>α。

S>g なら既に
\[
1\le d\le\lambda,\quad S\ge g+1,\quad C\ge\alpha
\]
であり、CENTRAL CORE-ROOTそのものである。

S=g、C>α の場合には j,k を交換し、同時に
\[
(a_i,b_i)\mapsto(b_i,a_i),\quad
(a_j,b_j)\mapsto(b_k,a_k),\quad
(a_k,b_k)\mapsto(b_j,a_j).
\]
新しい scalars は
\[
(\delta,\beta,g,\alpha,R,T,S,C)
\mapsto(\beta,\delta,\alpha,g,T,R,C,S).
\]
よって S'=C≥α+1=g'+1、C'=S=g=α'。\(d,\lambda,P\) は変わらない。

四つの actual PF 行は \(q_{A_i}\leftrightarrow q_{B_i}\)、\(q_{B_j}\leftrightarrow q_{A_k}\) と交換され、critical relations は同じ真の relations の色交換。\(\Gamma,F,m,W\) は全く同じ対象であり、Wのj/k係数が名前に従って交換されるだけである。P-FIBER の j/k 非負係数も必要なら交換できる。

これで色のいずれの向きでも、全CORE入力を保ったまま CORE-ROOTを得た。

## 6. 統合上の帰結

`CENTRAL_ENTRY_AUDIT.md` により CORE から採用済み Euclidean closure まで接続済みである。したがって
\[
\boxed{\text{正のcanonical CHAIN four-PF core は不存在。}}
\]

新しい経路は

**canonical four-PF core → root-free P-FIBER → max-i Apéry ROOT → CENTRAL intrinsic → boundary/U/D → Euclidean closure**。

この経路では、旧 HIGH-unit/central-match二成分分類、ORIGINAL POSJ、nonmatch 個別排除、K1/K2/K3、S1、HIGH親閉鎖を必要入力にする必要がない。それらを誤りと判定したのではなく、新規補完により広い親入力から直接閉鎖できたという意味である。

提出本文 `CHAIN_ROOT_PROGRESS.md` も完成後に照合し、上記と一致することを確認した。HCRのρが真のcritical multiplierであることは、引用するP-FIBER定理の入力として明記する。

全P21で依然別途必要なのは、五形分類と、それぞれの actual shape がここで用いた正のcanonical coreを持つこと。特に g=0 またはα=0の境界まで、このstrict CHAIN定理を拡張したとは主張しない。
