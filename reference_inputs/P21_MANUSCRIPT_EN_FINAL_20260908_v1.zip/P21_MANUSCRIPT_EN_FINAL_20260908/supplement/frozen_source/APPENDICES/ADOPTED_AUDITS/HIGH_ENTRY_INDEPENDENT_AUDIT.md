# Independent audit — HIGH entry / root-free matched-pair master

**2026-09-07。新規補完証明に対する別担当による独立点検。**

監査対象：`HIGH_ENTRY_AUDIT.md` の §1–6、§9、および末尾の boundary 拡張説明。特に §1 が **λ,δ,β≥1, g,α≥0** に更新された版を対象とする。

## Verdict

\[
\boxed{\textbf{PASS — INCLUDING }g=0\textbf{ OR }\alpha=0}
\]

正確には以下を確認した。

1. 明示された canonical W / same-depth actual PF A_i,B_i / positive Herzog package の下で、両 missing-i returns の最小正m-levelが一致する。
2. その同じレベルで係数が matching し、genuine P-FIBER が得られる。
3. g=0 / α=0 を含め、unequal-level の全分岐は signed completed identities の最終係数確認により排除される。
4. extra A_j arm / extra B_k arm の非共存が、同じ f_A / f_B の一個の genuine factorization から直接従う。
5. §6 の追加 strict HIGH root と actual q_J を仮定すれば、S267が要求するEA/P-FIBER/Q_j/FJ/FKを供給できる。

これはS267本体や、任意の反例からこの入力を構築する五形分類／CHAIN入口の独立監査を代替するものではない。

## 1. Actuality と最小値の合法性

E_A=q_A+n_i、E_B=q_B+n_i はPF性によってΓに入る。どのfactorizationも i係数0であることは、q_A,q_Bのgap statusから直接従う。ここに特別なMD-0定理は不要。

E_A,E_B∉Hの2つの短い証明は正しい。いずれも「P<ρ_iでcriticality」「逆向きの場合にR_kまたはR_jを1回差し引いてδ<ρ_iまたはβ<ρ_iでcriticality」という二段階であり、criticalityを使う全箇所でm係数は0。

従って正m-levelの集合は非空な正整数集合であり、各actual元ごとに最小値を選べる。後の低レベル候補は、同じE_AまたはE_Bの完全な非負係数表示なので、この最小性への適用は正当である。generic connectivityや選択後のscope移動は使っていない。

## 2. CAPとBOXは非負boundaryでも成立

c_A=g n_j+Tn_k、c_B=Rn_j+αn_k は g,α≥0 のもとでgenuine。T=b_k+α≥1、R=a_j+g≥1。

従ってFIの4capsはg=0、α=0でも成立する。閾値のHerzog packetを含む場合、その一個のactual F+n_i表示から生成されたn_iを一個除ける。

DIFFの

\[
x=V_j-U_j+a_j,\qquad y=U_k+b_k-V_k
\]

に対して

\[
R+1-ρ_j\le x\leρ_j-g-1,
\quad T+1-ρ_k\le y\leρ_k-α-1
\]

はCAPから正しく従う。R,T≥1なので

\[
-ρ_j<x<ρ_j,\qquad -ρ_k<y<ρ_k
\]

はboundaryでもstrictのまま。

## 3. Unequal levels：最後の−1 defectを確実に回収

### L_A>L_B

V_k≥b_kなら、同じE_Aのより小さい正m-level表示を作る。従ってV_k≤b_k−1。

これによりC=y=U_k+b_k−V_k≥1。DIFFは

\[
σm+Cn_k=Δn_j,\qquad σ\ge1,\quad 1\leΔ<ρ_j.
\]

WJのk係数α−1は、α=0なら−1である。**ここをactualと呼んでいない更新は正しい。** これに上記の零関係をcompleted identityとして加えた最終式

\[
F=(σ-1)m+(β-1)n_i+(ρ_j+R-1-Δ)n_j+(α+C-1)n_k
\]

では

\[
σ-1\ge0,\quad β-1\ge0,\quad ρ_j+R-1-Δ\ge R\ge1,
\quad α+C-1\ge0.
\]

従って最終式そのものがgenuine F-factorization。WJがsignedであることは妨げにならない。

### L_B>L_A

t≥0なら同じE_Bの低い正m-level表示ができるのでt<0。そのためΔ=x=V_j−t≥1であり

\[
σm+Δn_j=Cn_k,\qquad σ\ge1,\quad1\le C<ρ_k.
\]

WKのj係数g−1が−1でも、最終式

\[
F=(σ-1)m+(δ-1)n_i+(g+Δ-1)n_j+(ρ_k+T-C-1)n_k
\]

は

\[
σ-1\ge0,\quad δ-1\ge0,\quad g+Δ-1\ge0,
\quad ρ_k+T-C-1\ge T\ge1
\]

を満たす。こちらも同じFのgenuine factorizationであり矛盾。

**boundaryで供給不足は残らない。** 単に負の一係数を黙認したのではなく、最小性から独立に得たC≥1またはΔ≥1が、その一単位を必ず回収する。

## 4. Equalityとextra-arm absorption

等レベルでxn_j=yn_k。非零ならx,yは同符号であり、BOXからsubcritical二生成元relationとなる。従ってx=y=0。

これによりt=V_j≥0、u=U_k≥0、V_k=u+b_kがexactに従う。P-FIBER

\[
Pn_i=Lm+(t+1)n_j+(u+1)n_k
\]

もgenuine。

その同じE_A/E_B factorizationに(λ−1)n_iを加えた

\[
f_A=Lm+(λ-1)n_i+(a_j+t)n_j+u n_k,
\]

\[
f_B=Lm+(λ-1)n_i+t n_j+(u+b_k)n_k
\]

はgenuineである。従って1≤μ≤a_j−1のactual A_j(μ)または1≤ν≤b_k−1のactual B_k(ν)があれば、その一個の係数ベクトルから該当生成元を指定数除いてgapがΓに入る。

この帰結にはHIGH root、g>0、α>0を必要としない。**nonnegative-coreを持つSQへの適用はPASS。** SQからそのnonnegative-coreを供給する証明は分類担当の別項目。

## 5. Strict HIGHからS267への入力

§6はg,α≥1を改めて仮定しているので、S267のstrict canonical scopeと整合する。

Q_jのj-coordinateが0であること、Q_j∉Hの二段階criticality、positive m representationの存在はすべて合法。FJは同じQ_jと同じc_Jを加え一個のmを除くことで得る。

FKは同じWと固定HIGH rootのcompleted identityから直接計算でき、最終係数d+β−1,R+w−1は非負。古いAK-END return選択を別途仮定していないことは問題にならない。

t<pを使いたい場合の§6.3のpacketは、FIのactual表示内にS n_j+αn_kとして本当に収まる。置換後のF表示の全係数は非負。

## 6. 採択範囲

この新規入口証明は採択可能。個別gap1/2/3/4/large-gap、旧PRE選択と各HIGH子枝を本入口の独立依存として再構築する必要はない。

依然として外部入力として明記するのは：

- canonical actual matched pairと同じWの構築
- SQの場合、そのR,Tがg,α≥0を与えること
- HIGHの場合、strict rootおよびq_Jを得ること
- 最終的なS267の閉鎖定理

本監査は恒等式チェッカーの新規実行を主張しない。原文の導出、各最終係数、最小値選択、同一actual元への帰属を数学的に独立点検した。
