# P21 canonical reduction — second independent review

2026-09-07。監査対象：`review_supplements/P21_LOCAL_CANONICAL_KEY.md` 全文。

今回の担当者はType-II補完とHIGH／CHAIN入口の別監査を行った担当者であり、本canonical本文の作成者とは別に、定義から各含意を点検した。外部定理・旧Hallルート・P23・NS-SHARPは使用しない。

\[
\boxed{\textbf{INDEPENDENT REVIEW: PASS}}
\]

## 1. 正確なscope

\(\Gamma=\langle m,n_1,n_2,n_3\rangle\)は**極小4生成**数値半群、\(m\)はmultiplicity、\(F=F(\Gamma)\)、\(W=F+m\)、\(H=\langle n_1,n_2,n_3\rangle\)、\(A=\operatorname{Ap}(\Gamma,m)\)、\(Q=PF(\Gamma)\setminus\{F\}\)。

入力のcanonical条件は

\[
W-\varphi\in\Gamma\qquad(\varphi\in PF(\Gamma)).
\tag{CAN}
\]

この条件はP21全体で保持する。以下の結果を、任意の4生成数値半群の無条件定理として解釈しない。

## 2. WとApéryのtail actuality

\(W=F+m>F\)なので\(W\in\Gamma\)、\(W-m=F\notin\Gamma\)なので\(W\in A\)。

任意の\(w\in A\)のΓ-factorizationにmが含まれれば、同じfactorizationからmを1個除いて\(w-m\in\Gamma\)となる。従って**全てのfactorizationでm係数は0**であり、特に\(A\subseteq H\)。

また\(w-m\notin\Gamma\)より\(w-m\le F\)、従って\(w\le W\)。ここにはHが数値半群であることも、tail gcd=1もまだ必要ない。

## 3. CANから全gapへの拡張

非負gap xに対して有限非空集合\((x+\Gamma)\setminus\Gamma\)の最大元φを選ぶ。もし正の\(s\in\Gamma\)について\(\varphi+s\notin\Gamma\)なら、それも同じ集合に属しφより大きいので矛盾。従って\(\varphi\in PF(\Gamma)\)、また\(\varphi-x\in\Gamma\)。

CANから

\[
W-x=(W-\varphi)+(\varphi-x)\in\Gamma.
\]

この導出は完全。有限性はΓの有限補集合性から従う。

## 4. 二層分割と順序

正の\(w\in A\)は\(w>m\)を満たす。実際Γの正の最小元はmであり、m自体はAに属さない。従って\(x=w-m\)は非負gapで、前節を適用できる。

\(b=W-w\ge0\)とすると\(b+m\in\Gamma\)。

- \(b\in\Gamma\)なら、\(b-m\in\Gamma\)は\(w+b-m=F\in\Gamma\)を招くため\(b\in A\)。この場合\(b+m\notin A\)。
- \(b\notin\Gamma\)なら\(b+m\in A\)。

\(w=0\)では\(b=W\in A\)と別処理されており、例外は残らない。

したがって

\[
A_0=\{w\in A:W-w\in A\},\qquad A_1=A\setminus A_0
\]

は正確な二層分割。\(A_0\)は\(\le_\Gamma\)についてlower ideal、\(A_1\)はupper filter。

\[
\iota(w)=W+m-w\qquad(w\in A_1)
\]

について、\(\iota(w)\in A\)かつ\(W-\iota(w)=w-m\notin\Gamma\)なので\(\iota(w)\in A_1\)。\(\iota^2=\mathrm{id}\)、\(\iota(x)-\iota(y)=y-x\)より順序反転性も正しい。

さらに

\[
A_0=\{h\in H:W-h\in H\}
\]

も正しい。右辺の元がAに属さないなら\(h-m\in\Gamma\)、従って\(F=(h-m)+(W-h)\in\Gamma\)となる。

## 5. PFとのexact correspondence — 全Qに対して成立

\[
\operatorname{Max}_\Gamma A=PF(\Gamma)+m
\]

は本文にある直接証明で成立する。逆向きでは、maximalな\(w\in A\)に対して\(q=w-m\)を取り、\(q+s\)がgapなら\(w+s\in A\)となる点に注意すればよい。\(w+s\in\Gamma\)自体は\(w,s\in\Gamma\)から従う。

\(q\in Q\)では\(q<F\)。もし\(q+m\in A_0\)なら\(F-q\in\Gamma\setminus\{0\}\)、従ってPF性より\(F=q+(F-q)\in\Gamma\)、矛盾。

\(A_1\)がupper filterであることから、そのmaximal元はA全体のmaximal元のうちW以外と一致する。よって

\[
\operatorname{Max}A_1=Q+m,
\qquad \operatorname{Min}A_1=\{W-q:q\in Q\},
\]

\[
\boxed{|\operatorname{Min}A_1|=|Q|=t(\Gamma)-1.}
\]

**これは\(|Q|=4\)を仮定した等式ではない。全Qについて成立する。**

## 6. 各actual rowのq+m、cのApéry/H表示

任意の\(q\in Q\)について、PF性から\(q+m\in\Gamma\)、そのm-predecessorはqというgapなので\(q+m\in A\subset H\)。

\(c=W-q\in\Gamma\)はCANから従う。\(c-m=F-q>0\)がΓに属すると、qのPF性よりFがΓに入る。従って

\[
\boxed{q+m,\ c=W-q,\ W\in A\subset H.}
\]

特にc>0なので\(D(c)=\{i:c-n_i\in H\}\)は空でない。Hの実際のfactorizationで少なくとも一つのtail生成元が使われるためである。

## 7. KEYとsupport-zeroは直接成立

\(c-n_i\in H\)と仮定する。PF性より\(q+n_i\in\Gamma\)。もし\(q+n_i-m\in\Gamma\)なら

\[
F=(c-n_i)+(q+n_i-m)\in\Gamma,
\]

矛盾。従って\(q+n_i\in A\subset H\)。

この元のfactorizationにn_iが含まれれば、同じ非負係数ベクトルからn_iを1個除いてqがΓに入る。ゆえに

\[
\boxed{c-n_i\in H\Longrightarrow q+n_i\in\langle n_j,n_k\rangle.}
\]

したがって\(\emptyset\ne D(c)\subseteq SH(q)\)。等号は導出していない。

\(x=c-n_i\)について\(x-m\in\Gamma\)なら\(c-m\in\Gamma\)となるので、xもAに入る。従って本文の

\[
h,c,x,y\in H\cap A,\quad h+c=W+m,\quad x+y=W
\]

は全て同じactual q,c,Wに関する正しい表示である。

## 8. Tail gcd firewallとSYM/NONSYM入口

Qが空でないとき、一つのqを取る。前節までで\(q+m,c,W\in H\)が既に成立しているので

\[
m=(q+m)+c-W\in\mathbb ZH.
\]

従って\(d=\gcd(n_1,n_2,n_3)\)はmを割る。Γが数値半群であるため\(\gcd(m,n_1,n_2,n_3)=1\)であり、d=1。

Γの生成系が極小なので、どのn_iも他の2つのtail生成元の非負結合ではない。従ってHは**極小3生成数値半群**。ここからHについてSYM／NONSYMの二分を適用できる。tail gcd>1という第3ケースはない。

この整数群での引き算は非負factorizationと主張されておらず、合法。gcd=1だけを理由に、任意のrelation rowsのlattice indexやcross-product scaleを1とする主張もしていない。

## 9. |Q|≥4の扱いと4行の選択

P21の反例仮定は\(t\ge5\)、すなわち\(|Q|\ge4\)。この時点で\(|Q|=4\)と置き換えてはいけない。

本補完の二層分割・\(\operatorname{Min}A_1\)との対応は**全Q**に対して成立する。SYM側のraw ideal boundは、この全体のcardinalityを受け取る。

NONSYM側で任意の異なる4元\(q_1,q_2,q_3,q_4\in Q\)を選ぶことは合法であり、それらは同じΓ,F,m,Wを共有する。CAN、Apéry表示、KEY、PF incomparabilityは各行または行対ごとに成立するので、4行に制限しても保持される。

一方、4行を選んだだけで、その集合がQ全体である、全体の\(\operatorname{Min}A_1\)を尽くす、あるいは残りのQ元が存在しないとは言えない。分類定理は「任意のactual four-row configurationが列挙形のいずれかに入る」という形で接続するか、全Qの別のcardinality boundから正確に4元へ落とす必要がある。

## 最終採択

canonical二層・actuality・KEY・tail gcdは、表示された前提からの自立した導出として採択できる。これらのために古いHall型存在定理や未回収原会話を追加前提にする必要はない。

独立監査で確認したのは本canonical入力であり、five-shape分類、COLOR-CAP、SYMの後続全分岐を本稿単独で再監査したという意味ではない。
