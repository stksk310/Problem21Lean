# P21 maintained proof — second integration review

2026-09-07。監査対象：`19_MAINTAINED_PROOF_SPINE.md` の番号付きmodules間の入力・出力、scope、依存循環。

本稿は各末端証明を再度すべて証明する作業ではない。新規TYPE-II、root-free matched-pair、CHAIN unit-root、canonical入力について独立に読んだ担当者が、既存の別担当監査および採用済み後期監査への接続を確認した。

## 統合判定

**MODULE INPUT/OUTPUT COMPATIBILITY: PASS。依存循環は検出していない。**

`COLOR_CAP_SECOND_REVIEW.md` の最終 PASS と `PATH_ADOPTED_DEPENDENCIES.md` の実本文を確認した。この判定は、維持証明が明示して採用する PATH／後期 Euclidean の既存独立監査を含む依存体系に対するもの。PATH の既存監査が採用していた二つの上流補題は、新規本文とその独立読査が揃った。追加の PFREE 符号補完も導入した（§8）。

## 1. 全Qからの入口と4行の選択

§1の反例仮定は\(|Q|\ge4\)。canonical二層対応は全Qについて成り立ち、\(\operatorname{Min}A_1\)を4元と初めから仮定していない。

SYM側は全体のtとraw ideal boundを受け取る。NONSYM側は異なる4行を選ぶことができ、同じΓ,F,m,Wの下でPF性・CAN・actual complements・KEY・PF antichainを保持する。

三singleton補題は分類本文で全Qに対して別途示しており、「選んだ4行の中に見えない元は存在しない」という誤った推論ではない。cornerの個数制約も高いtail cornerがQに入れないことから与えられる。

**|Q|=4への無断置換はない。**

## 2. 正しい依存の順序

接続は次の順序で読める。

1. CAN・Apéry・KEY・tail gcd。
2. 対称tailはSYMの閉鎖へ。
3. 非対称tailは標準Herzog入力、six-arm、integer kernel、critical box、局所pair geometry。
4. 局所matched-pair geometryからroot-free level rigidityとP-FIBER。
5. そのextra-arm／singleton排除を使う四行分類。corner残件だけは別系統のCOLOR-CAPを使用。
6. PATH／TYPE II／CHAINの各exact input抽出。
7. PATHは採用済み監査、TYPE IIは新規二-return theorem、CHAINはP-FIBER→unit root→CORE→採用済み後期閉鎖。

局所pair geometryは最終五形分類を仮定せず、root-free theoremもHIGH/CENTRALの閉鎖を仮定しない。従って分類→root-free→分類という見かけのループは、実際には**局所pair lemma→root-free→全体の有限row分類**という順序で解消している。

COLOR-CAPのMINBOX／dynamics側もfour-row terminal classificationを入力としていない。`COLOR_CAP_SECOND_REVIEW.md` は three actual same-color arms のみから MINBOX、dynamics、同じ f_ε の最終 actual factorization へ戻る接続を独立確認している。これにより分類側に残っていた corner＋三反対色 arm の留保も解消する。

## 3. Nonnegative matched boundary

§4ではg,α≥0を明記している。これは実際に独立監査済みのroot-free theoremのscopeと一致する。

g=0またはα=0の場合のWJ/WKはsigned intermediateとなり得るが、最終ABS±の不足一単位はΔ≥1またはC≥1によって回復する。元のWがactualであることと、途中の全表示がactualであることを混同していない。

従ってSQのboundaryを誤って除外していない。extra A_j/B_kの排除とmatched pair＋singleton排除にはstrict g,α>0は必要ない。

## 4. TYPE IIの入力照合

分類本文§11.3は次を供給する。

- actual\(S_i,A_i(\lambda),B_j(\mu),A_k(\nu)\)
- \(1\le\lambda\le a_i-1\)、\(\lambda\le b_i\)
- \(1\le\mu\le b_j-1\)、\(1\le\nu\le a_k-1\)
- 同じWのP/R/T表示
- \(c_S=Pn_i\)とcanonical singleton式
- \(SH(q_S)=\{i\}\)、したがってmissing j,k

これらは`TYPEII_COMPLETION.md` §1の全仮定に一致する。旧low/high-ν分割、旧Branch A/B/C閉鎖、QSEP、COLOR-CAPをTYPE-II内部の証明に再輸入していない。

新規TYPE-IIは全νを扱うため、μ/νの符号領域を落としていない。結論は同じΓ,FにおけるF-factorization矛盾なので、rowを別配置へ移す必要もない。

## 5. Strict CHAINからCOREへの照合

分類本文の該当節は**§11.2**。ここでは

\[
\delta=a_i-\lambda\ge1,\quad\beta=b_i-\lambda\ge1,
\quad g=b_j-\mu\ge1,\quad\alpha=a_k-\nu\ge1
\]

を実際のarm rangesから得る。module4のnonnegative theoremを使った後で、CHAIN固有の追加armsがstrict性を供給しており、ゼロboundaryを理由なく削除したのではない。

四つのPF rows、同じW、P-FIBERが`CHAIN_ROOT_PROGRESS.md`の全入力と一致する。

unit-root theoremは同じ\(h_A=q_A+m\)の最大i表示を選ぶ。色反転では\(q_A\leftrightarrow q_B\)、\(q_J\leftrightarrow q_K\)、\(\delta\leftrightarrow\beta\)、\(g\leftrightarrow\alpha\)、\(R\leftrightarrow T\)となり、Γ,F,m,Wは保持される。

得られる

\[
m+d n_i=S n_j+C n_k,
\quad1\le d\le\lambda,\ S\ge g+1,\ C\ge\alpha
\]

は`CENTRAL_ENTRY_AUDIT.md` §0のCORE-ROOTと完全一致する。同文書の他のCORE仮定も、四つのactual PF rows、strict scalars、critical relations、同じWで全て供給される。

ここに古い\(\mathrm{CHAIN}_{res}\subseteq\mathcal H_{unit}\cup\mathcal C_{matched}\)の引用は不要。新しいCORE入口がその歴史的二分を置き換えている。

## 6. 採用済み監査との境界

PATHはS328の採用済み独立監査を維持する。これは今回全PATHを別担当が新規再監査したという主張とは区別されている。未確認F-ROUTEを入力にせず、採用されたPFREE direct absorptionを使うことも明記されている。

CENTRAL末端は、新規CORE→boundary入力の接続を別担当が確認し、S286/S289/S293/S302についてはS321の採用済み独立監査を保持する。Euclidean最終定理に単なる「似たpacket」を渡すのではなく、明示された初期matrixとgenuine pairを持つ入力を渡す。

この監査区分は§10で正しく限定されている。全331原資料の新しい再監査、proof assistant形式化、外部査読とは主張していない。

## 7. 根拠参照の修正確認

19の草稿について通知した次の点は、更新本文で修正・実体確認済み。

1. §8のCHAIN分類参照は§11.1ではなく**§11.2**。
2. §3で「§§1–5.2が全二-arm geometryを証明」とした箇所は、同色／異方向pairの**§§6–7**も含めて参照する。これらは全体のterminal分類より上流に置ける。
3. `PATH_ADOPTED_DEPENDENCIES.md` は実在し、全文を確認した。S328 後半の §§1–7、MSR split／PAIR／PFREE と旧資料の実箇所を対応させている。

いずれも、このレビューで別の数学的反例やscope矛盾を認定したものではない。

## 8. PATH の本文補完と最後の符号接続

PATH 採用依存表が当初明示した次の二つの本文未回収入力は、新証明で置換された。

| 元の採用入力 | 新しい維持本文 | 本担当の独立読査 |
|---|---|---|
| double-unit \(\mathfrak D_i=\mathfrak D_k=\varnothing\) | `PATH_DOUBLE_UNIT_COMPLETION.md` | `PATH_DOUBLE_UNIT_INDEPENDENT_AUDIT.md`：PASS |
| strong-left endpoint missing-j の \(\ell_L\ge2\) | `PATH_ENDPOINT_LEVEL_COMPLETION.md` | `PATH_ENDPOINT_LEVEL_INDEPENDENT_AUDIT.md`：PASS |

後者は weaker ROOT を同じ q_L,q_A,W の下で正規化し、正整数 K の下降と全仮定保存を証明している。原 ROOT の K-cap や b_i>a_i を無断で仮定していない。

さらに上流の PFREE 表示で K₀+η の符号を確認する必要が見つかった。S117 の指定 endpoint 表示を、signed のまま actual とみなして下流へ渡さないため、新たに `PATH_PFREE_SIGN_INTERFACE_COMPLETION.md` を作成した。

- 入力は central PFREE kernel からの exact M+ と、同じ右 singleton の actual two missing returns。η>0 を仮定しない。
- F₀≤0 なら T≥max(a_k,b_k)。各 return が level≥2 なら M+ と同じ c_R=Tn_k で F-factorization、両方 unit なら endpoint caps から pure-H subcritical contradiction。
- 従って残る枝では F₀≥1 が本文で供給される。その後に S118 の PF-A cap と S328 の PFREE-FABS / FIX-FABS を用いる。
- S118 §8 の PF-FIX の比較は、新 double-unit 本文 §7 の直接三符号 argument を用い、原文の不要な K−a_k 上限に依存しない。

これで PAIR→新 strong-port 閉鎖、および PFREE→新符号補完→採用済み direct absorption→新 double-unit 閉鎖という非循環の順序になる。central MSR kernel を得る前に endpoint regeneration の actuality を使う箇所はない。

`PATH_ADOPTED_DEPENDENCIES.md` §8 がこの最終採用順序と、新旧本文の所在を明記する。S328 後続の新しい「最終独立監査原本」を要求せず、ユーザーの採用方針を維持する。

**確定した結論：全 Q／選択四行、nonnegative matched 境界、strict CHAIN の色交換、CORE 接続、PATH の新補完と採用済み後期監査の区別に入力不整合はなく、依存循環もない。**

この判定の範囲は指定した維持証明であり、全ての旧枝や全331原資料を今回新たに証明し直したという意味ではない。


## 9. 最終確認

`PATH_PFREE_SIGN_INTERFACE_INDEPENDENT_AUDIT.md` の全文と最終 **PASS** を確認した。actual central kernel からの PARAM、四つの F certificates、unit-level の全符号、η の任意符号、same q_R の保持が別担当により点検されている。

従って、本稿で一時留保した COLOR-CAP、PATH double-unit、PATH endpoint level、PFREE sign interface は全て本文と必要な点検が揃った。

**FINAL INTEGRATION REVIEW: PASS。指定した maintained proof の入力・出力・scope・非循環性について未解決の留保なし。**

維持証明に採用する新規補完と既存 PATH／後期 Euclidean 監査の区分は保つ。全歴史資料の完全再証明や形式化を主張しない。
