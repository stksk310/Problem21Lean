# SYM 統合補完本文の第二読査

2026-09-07。対象は同ディレクトリ `SYM_AUDIT.md` の今回の新規統合本文。歴史上の監査結果のコピーではない。

## 判定

**PASS — 明示された3生成対称数値半群のgluing分類を標準外部定理として採用した、SYM枝の証明として。**

全P21の独立監査を意味しない。外部分類そのものの新証明・形式検証を行ったという意味でもない。

## 独立に確認した接続

- GAP-K の任意整数への適用、KのΓ-ideal性、PFと最小Γ生成元の全単射、CANからJ⊆Γを得る方向。
- BRIDGEの両方向。特に c−n∈J のとき c−n−m∉Γ を用いて c−n∈H とする箇所に循環はない。
- 2生成のnormal formとshifted idealのthreshold。端点 p≤−v では二候補が非比較の二生成元を作らず、一方が他方を支配するため、RAW4のstrict条件 −v<p<0 は整合する。
- 二層のraw非比較性からA'<A、B'<Bを得て w=αu+βv に至ること。
- 2GIからSPLITの二選択肢が尽くされること。枝の重なりは許してよく、Branch Iの既排除をBranch II内で使う順序も非循環。
- Branch Iのaxis hitとreturn rectangle hitが同じPF行・同じstable walkから得られること。returnへの到着はno-carry、直後はcarryであり、LOWERをN=1へ誤適用していない。
- Branch IのX-only / Y-only / XYの全域分割。X-onlyではlater axis hitの前stable点が2生成fundamental strip内のgap、XYでは二つのaxis hitが τ2 の二座標をともにsubcriticalに制限して矛盾。
- Branch II k0=1のg>0の導出。r>0とm<wの両方を使うことで正値が保証され、2GIのuv+T側を確実に排除できる。
- Branch II k0=0,e=0の最初のstable点の負値。
- Branch II k0=0,e>0のPHASE、epsilon=0/1の全域、前stable点のresidue計算。epsilon=1でn≥2を得た後だけFSを前の点へ適用している。
- 最後の actual PF contradiction と TYPE-BRIDGE による t≤4 への帰結。

## 局所的な注意

本文のいくつかの表示式に `quad` / `qquad` のバックスラッシュ欠落が見られたため、著者担当へ通知した。担当から修正済みとの報告を受けた。これは数学的欠落ではなく、数式表示の修正。

既に退けられたRDH⇒thin-middleやreturn-only排除を再利用していないことも確認した。Γのfactorization uniquenessを用いている箇所はない。使用する一意性は2生成normal formおよびgluingのresidue表示に限られる。
