# PATH double-unit — 独立読査

2026-09-07。監査対象：`PATH_DOUBLE_UNIT_COMPLETION.md`。新しい証明をその exact input から独立に追い、上流の S118 §§7–8、双対規約の S117 §8 も本文で照合した。

**PASS — PFREE の double-unit configuration は空。**

歴史上の未回収監査を再発見したという判定ではない。今回の新証明は、維持証明で採用する `S328` 後半 §6 の double-unit 入力を置き換える。

## 1. 入力の接続

S118 の κ,τ,H は新本文の P,T,H₀ に対応する。PFREE の Y,K₀,H₀ は実際の return coefficients なので非負。M± の六係数、η=ν−b_k、fixed J-return の A,C は一致する。M± 自体を actual factorization と呼ぶ必要はなく、同じ m の exact identities として使う。

q_L,q_R は同じ Γ の PF gaps、同じ W の complements は Pn_i,Tn_k。q_R+n_j の n_j-coordinate を消す根拠は、非負係数が一つでも残れば同じ factorization から n_j を除いて q_R∈Γ となること。正 m-level は missing-j の H 非所属から従う。新しい return の actuality を他の要素から移植していない。

## 2. PIN の criticality は正しい

C-cap は一つの F 表示の completed repair により C≤b_k−1。A=P−Y−2<P<ρ_i。

二つの unit returns から m を完全に消して

\[
(D-A)n_i+(B+1)n_j=(C+1)n_k
\]

を得る。D≥A は 0<C+1≤b_k<ρ_k に反する。D<A では B+1≥ρ_j が必要であり、R_j を一回差し引いた式に対して x=A−D−a_i を取る。

- x>0：0<x<A<ρ_i の n_i 倍が他の二生成元の非負和となるので矛盾。
- x≤0：式の左辺は非負、右辺は非正。正の生成元により全ての係数がゼロとなる。

従って D=A−a_i、B=ρ_j−1、C=b_k−1。signed m-root に criticality を直接適用した箇所はない。

## 3. 必要な新しい符号は本文内で導出される

fixed C の値との比較から F₀=α、C₀=ν、T−ν=K₀+1≥1 が exact に従う。後者は原入力の ν に勝手な上限を課すものではない。

反対 singleton の return level r≥2 に対して

\[
F=(r-2)m+(X+A_0)n_i+H_0n_j+(T+Z-\nu)n_k
\]

は全係数非負。特に k-coordinate は K₀+1+Z≥1。これは同じ W=F+m に戻る最終表示であり、外部 shift は残らない。

r=1 では ROOT+ を使った q_R の表示から Z≤ν−1。ROOT-T を同じ actual return に入れると

\[
(P+D+a_i-X)n_i=(\alpha+Z+1)n_k.
\]

右係数は 0<α+Z+1≤α+ν=a_k<ρ_k。左係数の事前下限は不要で、正の右辺との等式自体から正整数と分かる。これで pure-H k-criticality に矛盾する。

以上で r=1 と r≥2 の全てを尽くす。

## 4. 双対の actuality・scope

S117 §8 の変換は i↔k、j固定とともに

\[
(a_i',b_i')=(b_k,a_k),\quad
(a_j',b_j')=(b_j,a_j),\quad
(a_k',b_k')=(b_i,a_i),
\]

λ↔ν、α↔β、P↔T を同時に行う。q_L↔q_R、同じ Γ,F,m,W を保ち、critical relations・正の ranges・missing directions も移る。従って D_k の閉鎖を「見た目の対称性」だけで済ませていない。

## 5. 上流 PF-FIX の軽微な記述修理

S118 §8 の Q≥0 部分では、P_cycle=ρ_i を得た後、

\[
(Q-b_j)n_j+(K-a_k)n_k=0
\]

から Q=b_j,K=a_k を示す。この結論に、原文の K−a_k の追加上限は不要である。

- Q<b_j なら 0<b_j−Q≤b_j<ρ_j により j-criticality。
- Q>b_j なら等式から 0<a_k−K<a_k<ρ_k により k-criticality。
- Q=b_j なら K=a_k。

この直接の証明を採用すれば、原文の不要な上限式に依存せず PF-FIX に接続できる。新本文担当へこの修理を通知済み。S118 の Q<0 部分は H₀<a_j に基づく subcritical comparison で別処理されており、この修理で場合を削っていない。

## 結論

**double-unit の新規補完本文、actual PF returns からの符号、criticality の段階、反対 endpoint への接続、全場合排除は独立読査 PASS。**

strong-port の left missing-j level≥2 は別補題であり、本稿の結論から自動的に証明済みと扱わない。
