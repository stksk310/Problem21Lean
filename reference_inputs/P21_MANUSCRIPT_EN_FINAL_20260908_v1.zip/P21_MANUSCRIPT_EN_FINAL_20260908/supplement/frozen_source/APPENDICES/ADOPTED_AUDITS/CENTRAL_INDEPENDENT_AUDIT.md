# CENTRAL入口補完の独立監査

2026-09-07。対象は同じフォルダの `CENTRAL_ENTRY_AUDIT.md`。この監査担当はその本文の作成担当とは別である。

## 判定

**PASS — 明記されたCOREから、採用済みのCENTRAL後期閉鎖への接続が成立する。**

今回の監査で新規補完部分の数学的な破綻、隠れた旧SHIFT/EXT失敗条件、HIGH equal-POSTからの不正なscope移送は認めなかった。以下の限定は維持する。

* これは `CORE ⇒ contradiction` の依存監査である。
* 任意のCHAIN配置からCOREを得る入口は別の定理であり、本監査では証明していない。
* S321で採用されたS286／S289／S293／S302の監査は採用する。本監査はその全多項式certificateや最終Euclidean下降をもう一度独立検証したという意味ではない。
* 原資料は変更せず、新規補完とその独立監査として記録する。

## 1. CORE自体の範囲

入力は、同じΓ・F・m・生成元、正のcanonical parameters、真のpure-H critical relations、一個のactual W、四つのactual PF gaps、そして

\[
m+d n_i=S n_j+C n_k,\qquad
1\le d\le\lambda,\quad S\ge g+1,\quad C\ge\alpha
\]

である。旧matched endpointの選択最小性、旧ROOT/Rkの全失敗、HIGHのlevel equality、P-FIBERを仮定に追加する必要はない。

四つのPF行を単なるformal signed rowsと読むことはできない。各gap性と、指定successorのΓ所属がactualityの入口である。この仮定は明記されている。

## 2. 新規局所導出の確認

| 箇所 | 独立に確認した内容 | 判定 |
|---|---|---|
| 正levelのRET | missing coordinateを含むfactorizationは元のPF gapをΓに入れる。level0ならcanonical rowとの純H比較と一枚のcritical relationでsubcritical矛盾 | PASS |
| FI/FJ caps | 対応complementを同じactual returnへ足し、含まれるmを一個除く。critical packetを置換後にmissing generatorを一個除く操作は係数ごとに合法 | PASS |
| Aj/Ak caps | ROOT一枚のcompleted substitution後、Aj≥dまたはAk≥dなら全係数非負でmissing coordinateが正となる | PASS |
| slopes | rho倍したROOTの係数が非負になる場合にm>njまたはm>nk。mを残したままcriticalityを使っていない | PASS |
| RI-EXACT | y≤0は(1,0)へ、y≥1はRHO-GAPからx≥yq0へ。負座標がより悪化するので二候補が全整数familyを尽くす | PASS |
| 色反転 | j/kとa/bの同時交換で全四行とWを保存。K0<0とhC<rho_kからC≥alpha+1となり、反転後のstrict S'≥g'+1を確保 | PASS |
| compact upper | e0−1≥delta、C0+T≥Tを先に示してから同じOmega0内のcomplementを除く | PASS |
| return-level lower bounds | m消去後の正値・criticality比較でLi,Lb≥ceil(lambda/d)、Lj≥q0。Lj=q0のpinも各座標のsubcritical範囲を確認 | PASS |
| strict Ak／sum-notch | C>alphaを使用する位置を明示。Lk≥q0+1の後でq0個のmを供給し、Fのi係数失敗からsum-notchを得る | PASS |
| intrinsic SHIFT | h m+tau0 njのsourceを実際のEA/EB/FK内に確保。旧SHIFT/EXTの失敗を仮定しない | PASS |
| first point／integer kernel | V>0から有限のj-fit存在。床を引いたpure-H整数残差の三座標がsubcriticalなので非零は不可能 | PASS |

特に、Lj=q0のpinで使うCjの上限が旧endpoint packageから無断で移されていないことを確認した。新本文のFJ-KCAPが `Cj+T<rho_k` を直接供給している。

またstrict側の

\[
L_kd-A_k-1\ge\rho_i\ge q_0d+q_0
\]

は、K-PUREのj,k両係数が正になることを確保した後のpure-H criticalityである。これによりLk≥q0+1を得る順序は正しい。

## 3. actuality上の小さな明文化

最初のpacketではχが負の可能性もある。単に

\[
D_Fn_i+E_Fn_j=(N-1)m+\chi n_k
\]

をgenuineと呼ぶことはできない。S286 §3.1の正しい表示は

\[
(N-1)m+\max(\chi,0)n_k
=D_Fn_i+E_Fn_j+\max(-\chi,0)n_k.
\]

この両辺非負の表示を新本文§6に明記するよう作成担当へ連絡し、**PACKET-ACTUALとして追記済み**。数学の修正ではなく、S286が既に守っていた符号規律の明文化である。

## 4. 後期sourceとの入力照合

### S286 boundary／window

S286 §§0.1–0.3のcanonical data、四つのpositive-level actual returns、FI/FJ caps、compact data、Li/Lb/Lj/Lkの下界、strict sum-notch、二つのslopesは、COREから新本文§§1–5で全て供給される。保持されているstrong diagonal slopeも新本文内で導出可能である。

S286 §2のfirst pointは、今回のCORE上で新しく定義したものでよい。旧first pointの選択履歴は使わない。S286 §§3–6ではそのfirst pointによるwallから係数一化・空の整数三角形・determinant oneを導く。HIGHのL=LBを先に仮定していない。

したがって、S321採用済みのS286境界／window閉鎖を現在のCOREに適用できる。

### S289 U閉鎖

window survivorのLi=1とLi d≥lambda、d≤lambdaからlambda=d、q0=2。S286 §11のUNIT-PARAM、eta範囲、Du>0は、その前段のwall／det1から本文で導出される。Du>0は旧U theoremの引用ではなく、同節のmultiplicity identityによる。

これがS289 §1の入力と一致する。S289が使う同じqAkとactual FKもCORE由来である。Xi=1、Qk-cone係数1、旧source exposureの存在を足す必要はない。

### S293 D縮約

Dでは `T<chi≤C−alpha` から `C≥b_k+2alpha+1` が従う。新本文はさらに

\[
e_0\ge\beta+\delta+1,\qquad
1\le\tau_0\le S-g,\qquad\tau_0\ge R+1,
\]

およびV>0を供給する。従ってS293 §0.1–0.2の実入力に不足はない。first-point minimalityは現在定義した同じ点について成立している。

S293 §§5–8で使うlinear parameterization、正のDscr、universal i-fit、j-only failure、COMPLEMENTARYは同じ入力の下で導かれる。§9のQk追加capは最終Euclidean入力の生成には不要である。

### S302 Euclidean theoremへのexact embedding

新本文の二packetはS302 §1のINPUT-D／INPUT-Pと一致する。特に

\[
\mathsf M_0=\begin{pmatrix}fk+1&f\\k&1\end{pmatrix},\quad
\det\mathsf M_0=1,\quad
L=1+f(k+1)>M=k+1
\]

が成立する。rho式は

\[
LE+M\theta-a_j=(k+1)Q+g+\upsilon,
\]
\[
L\chi+M(T+w)-b_k=(k+1)C+kb_k+\chi
\]

と直接一致する。`theta chi > E(T+w)` はS293 §6から得る。r≥0、f,k≥1、theta≥1、theta≤upsilon、w≥0も揃う。したがってS302 §2のabstract packageを満たし、S321採用済みのterminal source-fitと非terminal保存・下降を適用できる。

## 5. 全体担当への結論

**CENTRAL_ENTRY_AUDIT.mdは、このCORE条件付き定理として採択してよい。** 今回の独立読査で、新たな未証明補題・数学的修正事項は残らなかった。

全体に残るのは別問題である `actual CHAIN配置 ⇒ COREまたは閉鎖可能なHIGH入力`。その入口の確立前に、CENTRALの条件付きPASSだけからCHAIN全域PASSやP21全体の新規独立監査PASSを宣言してはいけない。
