# FIVE-SHAPE completion — 独立監査

作成日：2026-09-07。監査者：sym_audit。対象は今回の新規補完本文 `FIVE_SHAPE_COMPLETION.md`、全527行、22,230 bytes、SHA-256 `168835d2d0343b2337d63ed8c2ab869589956f53ba554115a5a5cec932ef22f6`。

## Verdict

**PASS — 明示された上流入力のもとでの terminal classification と canonical scalar interface。**

§§1.1–9、11 の証明を独立に追い、integer-kernel の全符号場合、singleton/corner 排除、三 singleton、matched synchronization、異色二方向の向き、PATH / TYPE II / CHAIN の scalar 抽出を確認した。新規本文に数学的な破綻は見つからなかった。歴史的 SQ・TYPE I は、ここで使用した新しい root-free matched-pair theorem により分類段階で閉鎖される。

正確な境界は次の通り。

- 標準的な nonsymmetric three-generated Herzog normal form、critical multiplier の最小性、PF(H) が二 corner からなることを外部入力とする。
- canonical elementary reduction（q+m,c_q∈H、complement の Apéry 性、KEY）を上流で使用する。
- `HIGH_ENTRY_AUDIT.md` の **root-free matched-pair level rigidity** を使用する。この定理は matched pair のみを仮定し、CHAIN 分類、HIGH root、g>0、α>0 を前提にしない。今回の依存は循環しない。
- **lower corner ＋反対色の三 arm** だけは COLOR-CAP を別途要する。本監査では S048 の歴史的 COLOR-CAP 全鎖を新規再監査したとは主張しない。COLOR-CAP を採用・別監査すれば actual four-row 配置は PATH / TYPE II / CHAIN で尽くされる。未採用なら、この corner 一族を明示的に併記する。

従って、COLOR-CAP を除く分類本文と三形の canonical input については、追加の project-specific 補題を要求しない。これは各 terminal closure 全文を本監査で再証明した、という判定ではない。

## 1. Six-arm と integer kernel

§1.1 の最大 gap の選択は H が数値半群であるため存在する。q+n_i∉H より最大 ℓ≥1、他二方向の H-membership は ℓn_i を加えて保持されるので終点は PF(H)。f_A 側で ℓ≥a_i を仮定したとき

\[
(\rho_k-1-Z)n_k=(\ell-a_i+1+X)n_i+Yn_j
\]

の右辺は strictly positive。従って左係数が 1,…,ρ_k−1 に入り、m-free criticality に反する。f_B 側も同様。逆方向の二 actual H 表示と gap 性も成立するため、six-arm exact range の新規証明として十分。

§3 の kernel basis 証明では、床を引いた非零剰余 xr_j+yr_k が整数 vector、0≤x,y<1 を満たす。その i 座標は 0 と ρ_i の間、j/k の絶対値も各 critical multiplier 未満。符号のどちらかは一座標だけであり、純粋な H-relation に criticality を適用できる。従って剰余ゼロ。任意の関係に整数係数 u,v を導入する後続処理が正当化される。

critical-box uniqueness も同じ符号論法による局所定理であり、一般の factorization uniqueness を仮定していない。

## 2. Matched pair と zero boundary

§5 の integer possibilities の排除を確認した。u≥1,v≤0、u≤−1,v≥1、u≥0,v≥1、u≤−1,v≤0、残る u=0,v≤−1 が全非零整数対を尽くす。したがって λ=μ と complement synchronization は exact。

得られる g,α は初めは **非負**。R=a_j+g≥1、T=b_k+α≥1 なので MATCH の W はこの段階から genuine。g=0 または α=0 を勝手に捨てていない。

S_j/S_k 排除の completed identities は、P−a_i−1=b_i−λ−1≥0 またはその dual と κ≤ρ−1 によって全係数非負になる。g,α の strict positivity は不要。

root-free EA/EB から f_A の j-coordinate≥a_j、f_B の k-coordinate≥b_k が同じ final factorization 上で実現する。arm-domain は深さ≤a_j−1／b_k−1 なので、除去は coefficientwise。従って追加 A_j / B_k と SQ の排除は正しい。

### Matched＋singleton の新しい直接閉鎖

§5.3 は独立に再計算した。P-FIBER により

\[
Pn_i-m=(L-1)m+(t+1)n_j+(u+1)n_k\in\Gamma.
\]

singleton complement κn_i は、κ≤P−1 なら MATCH の同じ W から q_S∈H を与えるので κ≥P。一方

\[
\kappa n_i-m=(\kappa-P)n_i+(Pn_i-m)\in\Gamma
\]

は complement の Apéry 性に反する。よって matched＋S_i も空。これは g=0 / α=0 を含む matched scope 全体を処理し、TYPE I の境界を別扱いする必要をなくす。§9 の TYPE I 行は歴史的 normal-form orbit の記録であり、新規最終 survivor ではない。

## 3. 同色・異色 pair geometry

| 対象 | 核内の可能性 | 独立確認した境界・用途 |
|---|---|---|
| A_i,A_k | (u,v)=(0,1),(1,1) | i>0、k<0、j-box が u≥0,v≥1 を強制。i-cap が u≤1、続く k-cap が v≤1 を強制する。AA-A と AA-B の全係数は元 complement の係数。 |
| B_i,A_k | (u,v)=(0,1) | u≥1,v=1 は j-bound、u≥1,v≥2 は i-bound、u=0,v≥2 は k-bound に反する。β=b_i−λ>0、α=a_k−ν>0、R≥0。 |
| A_i,B_k | (u,v)=(1,1) | mixed signs と片方ゼロを各座標 bound で排除した後、u≥2 は i-bound、v≥2 は k-bound に反する。 |

AA-A の y=0、AA-B の y'=0 は singleton complement との pure-ray comparability に反する場合にだけ除外される。正係数が必要な分岐ではその除外を先に行っており、端点を取りこぼしていない。

§7.1 の BA 表示は R=0 なら j-coordinate が −1 で signed。しかし BA-W は同じ W の全非負表示である。その actual 表示から S_j を排除するため、signed row を actual と誤認する手順はない。

§7.2 の S_i / S_k 排除でも、それぞれ y'≥1 / y≥1 を pure-ray comparability から先に得る。置換後に κ_i／κ_k を除く全係数は非負。二つの異色 orientation を混同していない。

## 4. Singleton 数と四行の exhaustion

三 singleton の場合、全 W-factorization が各 singleton cap により critical box 内へ入る。その後でのみ一意性を証明・使用する。各座標最大値 κ_r−1 は actual q_S+n_r から実現するため、一意な W の三座標は全部 κ_r−1。第四 row の complement は同じ vector 内に入り q∈H。この論理に hidden uniqueness はない。

四行の s=2 では同色 pair、matched pair、逆向き AB がすべて排除され、BA と S_i,S_k の PATH のみ。s=1 では同色三 arm を残り二方向の AA theorem で排除し、matched の場合は TYPE I orbit（§5.3 で閉鎖）、unmatched の場合は TYPE II。s=0 では pigeonhole で matched direction ができ、extra-arm theorem が B_j,A_k のみを許すため CHAIN。

corner と singleton は同じ q_S+n_r の H-factorization で局所的に排除される。corner と同色 arm は PF antichain。higher corner は F(H)≥F(Γ)>q に反するため actual Q-row にならない。従って未採用の COLOR-CAP が担う配置は、確かに **一 corner と三つの反対色 arm** だけである。

## 5. Scalar interface の完全性

### Singleton saturation

BOX-W との差を整数 ur_j+vr_k と書く。u≥1,v≤0 は j<0、u≤0,v≥1 は k<0、u,v≥1 は i≥ρ_i で singleton cap に反する。残る u,v≤0 では i≤P−1。一方 BOX-W が P−1 を実現し、singleton も κ−1 を最大として実現するので κ=P。これは他の W-factorization が box 内にあるという未証明の仮定を置いていない。

### CHAIN

BA theorem を cyclic (j,k,i) と (i,j,k) で二度用い、同じ missing-direction complement の critical-box uniqueness で比較する。これにより

\[
g=b_j-\mu\ge1,\qquad \alpha=a_k-\nu\ge1,
\]

および δ=a_i−λ≥1、β=b_i−λ≥1 を得る。従って四 complements と W は HIGH/CENTRAL の **strict canonical core** と一致する。strict g,α を matched parent に逆輸入してはいない。

### TYPE II

AA-B は、c_{A_i} の一意な j-coordinate を BA の b_j−μ と比較すると y'=−μ<0 となり消える。AA-A のみが残り、λ≤b_i と三 complements が得られる。BOX-W と S_i saturation から c_S=Pn_i、q_S=−n_i+(R−1)n_j+(T−1)n_k。λ=b_i の境界も許したまま `TYPEII_COMPLETION.md` §1 の全 canonical input に一致する。

### PATH

BA から α,β>0 と R≥0。R=0 では c_{A_k}=βn_i が singleton S_i の complement と比較可能なので排除できる。従って **1≤R<ρ_j**。ここで初めて displayed box の W が genuine であると宣言し、両 singleton saturation を適用できる。

P=ρ_i−λ、T=ρ_k−ν、c_L=Pn_i、c_R=Tn_k と、二中間 complements βn_i+Rn_j／Rn_j+αn_k が得られる。本文の q_A=A_k、q_B=B_i は ladder label として正しく、三つの ladder identities を独立に展開して確認した。R=a_j や g=R−a_j の符号を前提にする手順はない。

## 統合判定

**分類本文・三 terminal scalar interfaces：PASS。**

独立に未処理なのは本稿外の COLOR-CAP 入口だけである。それが別監査または新規 corner closure で処理されれば、本分類から PATH / TYPE II / CHAIN への接続には未記載の bridge は残らない。本報告単独では COLOR-CAP や terminal closure 全文の新規監査済みを主張しない。


## 追補：COLOR-CAP 留保の解消

同日の `COLOR_CAP_SECOND_REVIEW.md` により、THREE-ARM → MINBOX → DPE → 同じ actual f-factorization での矛盾まで独立読査 PASS。上記の COLOR-CAP 留保は解消した。従って標準 Herzog / White 外部定理のもとで、actual four-row nonsymmetric 配置は PATH / TYPE II / CHAIN に尽くされ、各 canonical scalar input への接続も監査済み。
