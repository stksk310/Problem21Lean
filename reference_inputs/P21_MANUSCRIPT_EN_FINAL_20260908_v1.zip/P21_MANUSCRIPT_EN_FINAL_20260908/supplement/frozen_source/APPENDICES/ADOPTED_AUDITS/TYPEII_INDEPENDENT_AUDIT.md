# TYPE II 新規補完 — 独立監査

作成日: 2026-09-07。

監査対象: `review_pass10/TYPEII_COMPLETION.md`、§1–8。

本監査担当は上記証明の作成担当とは別である。証明本文を通読し、式・整数符号分岐・scope を独立に再確認した。付属 symbolic checker の結果を根拠に本文の正当性を推認してはいない。ここでは checker を新たに再実行したとは主張しない。

## Verdict

**PASS — 明示された canonical Type-II input interface の下で TYPE II FULL CLOSED。**

本文内に未処理 branch や additional independent lemma は認めない。原文で明記された `λ≤b_i` を含む input interface の全 Type-II 配置への適用証明は分類側の責任であり、本監査はそこを新たに証明したものではない。

## 1. 入力 scope

実際に用いる不等式は

\[
1≤λ<a_i,\quad λ≤b_i,\quad
1≤μ<b_j,\quad1≤ν<a_k.
\]

したがって

\[
P-b_i=a_i-λ≥1,\quad P-a_i=b_i-λ≥0,
\]
\[
R-a_j=b_j-μ≥1,\quad T-b_k=a_k-ν≥1.
\]

`λ≤b_i` は endpoint C-cap で使う。これを `λ<a_i` から導いたと扱ってはいけない。反対に `λ<b_i` という強化は不要で、λ=b_i も証明に含まれる。

actuality 入力は、同一 Γ,F,m,W、singleton q_S∈PF(Γ) と j,k missing、q_Ai,q_Ak∉Γ。q_Bj の return を別に仮定する必要はない。

## 2. Singleton returns と endpoint caps

PF 性から q_S+n_j,q_S+n_k∈Γ。加えた生成元の係数は常にゼロ（そうでなければ同じ非負係数ベクトルから一個除いて q_S∈Γ）。missing-direction 条件から m 係数は正。ゆえに SJ/SK は actual。

canonical q_S との差による JR/KR は exact。

SJ の F 表示に R_j を completed に加えた i 係数は

\[
P+A-a_i=b_i-λ+A≥0.
\]

従って C≥b_k は F∈Γ を生み C≤b_k−1。

SK の F 表示に R_k を completed に加えた i 係数は

\[
P+D-b_i=a_i-λ+D≥1.
\]

従って B≥a_j は同じく不可能。どちらも signed intermediate と final actual factorization を混同していない。

## 3. Anchor cap の全域性

η=ν−b_k、θ=μ−a_j を置く。HCR から独立に

\[
f_A-q_S=μn_j+ηn_k,
\qquad f_B-q_S=θn_j+νn_k
\]

を再計算し一致。

| 符号領域 | A,D cap の根拠 | 判定 |
|---|---|---|
| η≥1 | SJ/SK をともに actual f_A へ lift。q_Ai=f_A−λn_i gap より A,D≤λ−1≤b_i−1 | PASS |
| θ≥1（η任意） | AK-J/AK-K が A≥b_i または D≥b_i で actual q_Ak factorization | PASS |
| η=θ=0 | SJ→f_A から A≤λ−1、AK-K から D≤b_i−1 | PASS |
| η=0,θ≤−1 | q_S+n_k∈H、missing k と矛盾 | PASS |
| θ=0,η≤−1 | q_S+n_j∈H、missing j と矛盾 | PASS |
| η≤−1,θ≤−1 | q_S∈H、actual gap と矛盾 | PASS |

最初の二行は重複してよい。そこに入らない整数符号は後ろの四行で完全に尽くされる。

特に新しい二式は直接再計算した。

\[
q_{A_k}=\ell m+(A-b_i)n_i+(μ-a_j-1)n_j+(C+a_k)n_k,
\]
\[
q_{A_k}=hm+(D-b_i)n_i+(B+μ-a_j)n_j+(a_k-1)n_k.
\]

θ≥1 なら j 係数はそれぞれ θ−1≥0、B+θ≥0。a_k≥1 なので k 係数も非負。ηの符号を隠れて仮定していない。

f_B は整数値の表記としてのみ用いられ、その PF/gap status はどこにも必要ない。

以上により uniform A,D≤b_i−1 は全域 PASS。

## 4. Return-level exhaustion

等値 ℓ=h のときのみ m 係数を完全消去して tail criticality を使用している。D≥A では C+1≤b_k<ρ_k、D<A では B+1≤a_j<ρ_j。零係数 endpoint も含め両方 contradiction。

ℓ>h では ABS-L の最終係数は

\[
\ell-h-1≥0,
\quad P+A-D-1≥P-b_i≥1,
\]
\[
R-2-B≥R-a_j-1=b_j-μ-1≥0,
\quad C+T≥0.
\]

h>ℓ では ABS-R の最終係数は

\[
h-\ell-1≥0,
\quad P+D-A-1≥P-b_i≥1,
\]
\[
B+R≥0,
\quad T-2-C≥T-b_k-1=a_k-ν-1≥0.
\]

ともに同一 F の genuine factorization。level 差が一の場合も m 係数ゼロで合法。

整数二値の三分岐 ℓ=h,ℓ>h,h>ℓ は完全に網羅しており、他の branch はない。

## 5. Proof policy と採択範囲

- 全 lift は名前を固定した同じ f_A または q_Ak への exact identities。
- signed identity は最終係数が非負と判定された時点でのみ actual と扱う。
- gap からの generator subtraction は単一の非負係数ベクトルに対して実行。
- criticality は pure-H 関係に限る。
- uniqueness、generic connectivity、hidden minimality、子枝の parent への流用を使用しない。
- low/high ν、旧 A/B/C、LOW-B3/B4/P-cell/N-cell 等の旧閉鎖は引用していない。

**独立監査採択:** `TYPE-II SINGLETON / TWO-ANCHOR ABSORPTION` は明示 input の下で証明済み。五形分類が当該 input を供給すれば、Type II の旧残部は全て置き換えられる。
