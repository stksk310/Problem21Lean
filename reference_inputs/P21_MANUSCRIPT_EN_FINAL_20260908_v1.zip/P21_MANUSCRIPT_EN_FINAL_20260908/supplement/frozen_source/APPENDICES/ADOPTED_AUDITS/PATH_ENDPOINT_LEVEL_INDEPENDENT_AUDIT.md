# PATH endpoint level / strong-port — 独立読査

2026-09-07。監査対象：`PATH_ENDPOINT_LEVEL_COMPLETION.md` 全文。入力から各恒等式・係数・ROOT 正規化の仮定保存・完全双対まで独立に確認した。

**PASS — ENDPOINT LEVEL≥2、および WEAK-ROOT strong-port configuration の完全排除。**

本判定は、新本文の証明を追った結果であり、原資料の FROZEN verdict の再引用ではない。

## 1. 仮定と named actual elements

同じ Γ,F,m,W、PF singleton q_L、gap q_A、Herzog critical relations、正の α,β,R、および

\[
m=-dn_i+Sn_j+en_k,
\quad1\le d\le a_i-1,\quad S\ge1,\quad e\ge\alpha
\]

から出発する。m-root の表示は signed identity であり、actual と仮定していない。

q_L+n_j と q_L+n_k は PF 性によって存在する genuine Γ-factorizations。各 missing coordinate は、そこから同じ生成元を一個除くと q_L に入ってしまうためゼロ。正 m-level は SH_H(q_L)={i} により保証される。return-level minimality も同じ return の選び直しも不要。

## 2. WEAK-ROOT からの二つの壁

LK に ROOT を一回代入し、q_A=q_L+a_in_i−Rn_j を使うと

\[
q_A=(L_k-1)m+(A_k-d+a_i)n_i
 +(B_k+S-R)n_j+(e-1)n_k.
\]

d≤a_i−1、e≥α≥1 より、S≥R なら全係数非負。従って 1≤S<R。

同じ W から ROOT を使って m を除くと

\[
F=(P+d-1)n_i+(R-S-1)n_j+(T-e-1)n_k.
\]

先に証明した S<R によって第二係数が非負であり、e≤T−1 は矛盾する。従って e≥T、K=e−α≥b_k。

この順序が重要であり、証明は S-WALL を E-WALL より先に確立している。

## 3. ROOT 正規化は全仮定を保存する

K≥ρ_k なら、純粋な zero identity により

\[
d'=d-b_i,\quad S'=S+a_j,\quad e'=e-\rho_k
\]

と置く。K≥ρ_k から e'≥α、S'≥1。

d'≤0 の場合は全非負表示で m≥n_j>m となり矛盾。生き残る場合は d'>0 で、d'≤d≤a_i−1。従って ROOT の三つの仮定が全て再び成立する。

q_L,q_A,W、LJ/LK の actual factorization は一つも変更していない。第2節の壁を新しい signed ROOT にもう一度適用できるので S'<R、e'≥T が得られる。この適用は親仮定を再供給したもので、子固有の旧 port identity を輸入していない。

K'=K−ρ_k は正で厳密に減少する。よって有限回で矛盾が出るか、b_k≤K<ρ_k に到達する。見かけの類似や未証明の root minimality に依存しない正整数下降である。

特に b_i>a_i を仮定する必要はない。元 ROOT の K が最初から subcritical と結論してもいない。

## 4. Endpoint level の矛盾は完全に pure-H

LJ の F 表示を R_j で completed repair すると C≥b_k が矛盾するため C≤b_k−1。ℓ=1 と仮定し、正規化 ROOT を入れた q_L 表示から A≤d−1。

同じ LJ の canonical 値との比較は

\[
Vn_k=(d-A-1)n_i+(R-S)n_j,
\qquad V=C+K-b_k+1.
\]

右辺は非負かつ正、1≤V≤K<ρ_k。m は完全に消去済みなので、k-criticality の使用は正しい。従って任意の LJ に対し ℓ≥2。

## 5. 最終 factorization

同じ q_L+Pn_i=W に戻すと

\[
F=(\ell-2)m+(P+A-d)n_i+(S-1)n_j+(C+K+\alpha)n_k.
\]

ℓ−2≥0、P+A−d≥β+1>0、S−1≥0、C+K+α>0。これが一個の最終 genuine F-factorization であり、shift、external packet、残存負係数はない。

## 6. 上流・双対との接続

S117 §6 / S118 §2 の左 paired port は d=a_i−1−X、S=H+1、e=Z−b_k+1 を与える。X≤a_i−2、Z≥T−1 により全 WEAK-ROOT 仮定が成立する。

右側への変換は i↔k、j固定と a/b の全交換、α↔β、P↔T。HCR の三関係を保ち、q_L↔q_R、q_A↔q_B、同じ Γ,F,m,W を保持する。したがって右側も同じ証明で閉じる。

本補題は central arm q_A+n_k の level≥2 と別の endpoint q_L+n_j の主張であり、両者を混同していない。PFREE や double-unit は別本文である。

## 最終判定

**新しい endpoint-level 本文と ROOT 正規化、strong-port の最終吸収：独立読査 PASS。**

これにより採用済み PATH 監査が左 endpoint level に置いていた本文未回収の留保は、新証明によって解消する。
