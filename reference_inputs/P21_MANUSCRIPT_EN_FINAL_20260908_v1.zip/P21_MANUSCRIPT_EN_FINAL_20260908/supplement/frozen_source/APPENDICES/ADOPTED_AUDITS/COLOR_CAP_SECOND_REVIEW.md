# COLOR-CAP — 最終独立読査

2026-09-07。監査担当：sym_audit。歴史的 verdict の再引用ではなく、今回作成した以下の二本文を実際に独立に追った。

| 本文 | 監査した snapshot |
|---|---|
| `COLOR_CAP_DEPENDENCY_AUDIT.md` | 13,431 bytes / SHA-256 `73d0d9db8d9623b5583fce6da5aec29ec652e1e966500bfbd2f4468c9615acd1` |
| `COLOR_CAP_DYNAMICS_AUDIT.md` | 20,682 bytes / SHA-256 `c921d389cfe4ae410ac2ed987dd4999b1fb5ab9c8e34a2566ac0ae4634e6c5bb` |

## Verdict

**PASS — THREE SAME-COLOR ARMS EXCLUSION / COLOR-CAP。**

上流の three actual arms → empty tetrahedron → White classes → multiplicity certificate → MINBOX と、下流の distinguished path → two-color prefix/rank → 全 sink 排除 → third-color first firing 排除 → DPE を確認した。二本文の exact interface も以下で閉じる。

標準的外部入力は nonsymmetric three-generated Herzog normal form と **White の empty lattice tetrahedron width-one theorem**。これらの外部定理本体を本読査で新規に証明したとは主張しない。project-specific な COLOR-CAP の未証明 bridge は残らない。

## 1. MINBOX の独立確認

### Empty tetrahedron と White quotient

三 actual arms は同じ f_ε の任意の genuine Γ-factorization の各 n_i-coordinate を λ_i−1 以下に抑える。q_i+n_i∈Γ に必要な n_i を追加するので f_ε∈Γ、一方 f_ε∉H。従って最小正 m-level k と正 vector p の選択が正当。

C=U−1pᵀ の determinant は km。primitive n より row lattice と L_{km} の index が一致し、L_m/L_{km} は位数 k の cyclic quotient。単体内部・側面では p の正係数が正性を与え、top face の非頂点では異なる zero-coordinate の二行が混ざって全座標正となる。従って emptiness の証明に signed-to-actual の飛躍はない。

各非零 class と逆 class の三座標が全て非零になること、age=1+j/k、White の 2+2 split から θ₁=(1/k,r/k,(k−r)/k) が出ること、rq=1+ℓk による inverse class の明示を確認した。1+3 split は empty triangular facet の unimodularity と高さ1から volume1 となるため、k≥2 では排除できる。

六 companions の m-level は j または k−j で正かつ k 未満。全座標正となった companion のみを genuine f-factorization に変換し、k-minimality を使用している。

### 両色の failure cone と weighted certificates

Color A/B の z と z_q の各 strict preliminary bounds、六本の失敗から得る coordinate inequalities を独立に計算した。特に新たに明記された次の二点は適切。

- A の Y_q<b₂ は、先に得た b₂−p₂≥(r−1)a₂ と rq=1+ℓk を用いて証明する。
- B の Y_q の正性は無条件には仮定せず、まず p+z_q の失敗から Y_q≥p₂>0 を得る。

A の重み (1,s,rs)、B の重み (q,1,qt) を各三 socle relation に実際に掛けて、本文の w₁,w₂,w₃ を再導出した。残余 slack はそれぞれ

\[
\sum_iw_i-kD\ge k(s+1)(r-\ell-1)\ge0,
\]
\[
\sum_iw_i-kD\ge k(q+1)(q-\ell-1)\ge0.
\]

全 w_i は正なので n_i>m に矛盾。**k=2,r=q=1** でも一部の p-coefficient がゼロになるだけで他項は正であり、同じ certificate が成立する。別個の k=2 input は不要。

White が選ぶ row ordering は、同時 generator permutation と奇置換での A/B・a/b 交換により両自然型に入る。arm bounds も同時に交換されるため、片色だけの scope を他方へ無断移植していない。

## 2. 記述修理として実際に確認した点

- S037 の B-socle matrix は転置を修理した U_B を使用する。各行の socle identity を Herzog relations から確認できる。
- `COLOR_CAP_DEPENDENCY_AUDIT.md` §9 の minor 定義には読査途中に逆符号の誤記があった。著者が修正済み。正しくは

\[
\Delta_2=x_1x_3-z_1y_3,
\quad
\Delta_2n_3=(x_1y_2+z_1z_2)n_2-(x_1+z_1)m>0.
\]

保存 snapshot は修正後。旧式のまま PASS としたものではない。

- S044 の `{1,2}, S2, last row 1` には pre-cross X>0 を crossing として扱えない場合がある。新本文は X≥0 と X<0 を分離し、前者に新しい reciprocal-rank certificate を与える。原資料を黙って完全とみなしていない。

## 3. Dynamics の exact hypothesis

下流定理は正整数 x_i,y_i,b_i、z_i=y_i+b_i と

\[
C=\begin{pmatrix}-x_1&z_2&y_3\\y_1&-x_2&z_3\\z_1&y_2&-x_3\end{pmatrix},
\qquad Cn=m\mathbf1,
\qquad 0<m<\min_i n_i
\]

だけから DPE を導く。detC=m、adjC1=n は dynamics 自体に不要であることも確認した。上流 MINBOX はこの十分な input を全て与える。

F₁,F₂,F₃ の disjointness、positive-sink 四領域の exhaustion、初期 p が sink でないこと、u⋅n が各 firing で m 減る有限性は直証明される。必要な二 minors の正性は Cn=m1 と n_i>m から導かれる。positive minors だけで multiplicity contradiction を代用していない。

## 4. PREFIX・terminal rank・reciprocal 修理

successful crossings の ceil 値、E/U の strict box、二次色を続けて fire できないことを確認した。従って成功点は chronological initial prefix。CROSS の二つの厳密な分数境界は、閉 corridor 内の小分母 separator の不存在を直接与える。

E/U の injectivity と anti-chain は、差 h=j−i,k=N_j−N_i を用いて corridor separator に戻している。単に「Farey rank」と命名しただけの input ではない。

### ELR

終端 crossing は成功点とは限らない。そのため §3.2 の ELR は正部分を保った

\[
Q-1\le(x-b-1-E)_++(y_r-1-U)_+
\]

として使用される。§7.4 では U>y₂−1 と U≤y₂−1 を実際に分け、それぞれ Q+E≤x₁ と Q+E+U≤x₁+y₂−1 を得る。未証明の terminal U-cap を使っていない。

### 元の actual prefix への dual count の埋込み

§4 で d=A−x、a=v−B、H=N−Q、E=Qa−HB、V=Hx−(Q−1)d と置く。dual separator の逆数に1を足すことで、元の成功 prefix の denominator k≤q に戻ることを確認した。

dual index s<H の count は (N_s,K_s)=(s+K_s,K_s)。0<X_s<d より

\[
(K_s-1)A/x+1<N_s<K_sA/x.
\]

したがって本当に元の row-1 run の整数 count である。K_s<Q は完了した prefix 内、K_s=Q は同じ final run の終端以前。K_s=1 なら前の count は初期点側であり、存在しない「第0成功点」を数学的 input とする必要はない。通過した state は row 1 の source なので X_s≥b+1。これが shifted cap V_s≤d−b−1 を与える。

終端の V=d−b では prior high-V slot は0個であり、max 表示が必要になる。新本文はこの端点を保持して

\[
H+E+V\le a+d-b
\]

を正しく得ている。**X=0、b=0、V=d** も除外していない。

### S044 pre-cross の補完 certificate

{1,2}、sink B、last row1、X≥0 における新 margin は再計算すると

\[
|\lambda C|-|\lambda|
=(a+d-H-E-V)+b_1+b_2+2(y_2-Q)+(y_3-u_3),
\]

\(\lambda=(N,Q-1,1)\)。全項非負で b₁+b₂>0。λC の係数も box と sink 条件で非負。よって省略されていた pre-cross と equality endpoint は閉じる。

## 5. 残りの sink と第三色初出

以下も証明本文を個別に確認した。

| 分岐 | 独立確認した決定箇所 |
|---|---|
| 一色 | box から N(x₁+1)≤2y₁、全四 sink に非負 weighted vector。 |
| {1,2} last row2 | LR による D_q−E 下界と N−q≤y₁−x₁。 |
| {1,2} last row1、X<0 | D<0 なら全 prior U_j>−D。小分母 separator の差式が exact で、Q−D≤y₂ が必要な source slack を与える。 |
| {1,2} sink C | ELR の terminal U 上端を分け、最初の二係数和で必要総量を満たす。 |
| {1,3} last row3 | λ=(N,1,q) の係数は (y₁−E_q,z₂−u₂,y₃+z₃−U_q)。LR、N−q≤z₁−x₁、q≤y₃−1 から margin≥b₃+1。 |
| {1,3} last row1、sink A | shifted reciprocal rank と exact slack decomposition。 |
| {1,3} last row1、sink C | suffix の high-E / high-U cover、slot counting、N≤y₁。q≤b₁ は自明な場合として残す。 |
| {1,2}→3 | 全 prior E_j>E と D<0 時の U_j>−D により source packet が componentwise λ を上回る。 |
| {1,3}→2 | D₁≤0 の corridor contradiction と 1≤D₁≤b₁ の EBOX contradiction を別処理する。後者は N_h=ceil(hz₁/x₁) の直前 residue に戻る。 |

第三色が row2/row3 の直後に出る可能性は、最初の座標の必要量が box upper を超えるため先に排除される。よって二つの first-switch orientation が全てを尽くす。最後に、一色・二色・三色の有限 path の場合分けが完全であり DPE が得られる。

## 6. DPE → COLOR-CAP の最後の SAME-factorization 接続

MINBOX が与えた **同じ** f_ε,p,C を保持する。初期 factorization は

\[
f_\varepsilon=m+\sum_i(p_i-1)n_i.
\]

counts r∈Z³_{≥0} で u=p−rC とすれば、Cn=m1 から

\[
f_\varepsilon=(1+|r|_1)m+\sum_i(u_i-1)n_i.
\tag{ACTUAL-STATE}
\]

従って u の三座標が正である限り、これは同じ f_ε の genuine factorization。signed state を actual と呼んでいない。

DPE の positive out-of-box firing も u>0 を保つが、ある座標 i で u_i≥a_i。三 arm の exact range は λ_i≤a_i−1 なので、この一個の final factorization から λ_i n_i を coefficientwise に除ける：

\[
q_i=f_\varepsilon-\lambda_i n_i
=(1+|r|_1)m+(u_i-1-\lambda_i)n_i
 +\sum_{j\ne i}(u_j-1)n_j\in\Gamma.
\]

actual PF gap q_i に矛盾。Color B は上流と同じ同時 permutation/color exchange で処理する。

これで **同じ色の actual three arms は存在しない**。したがって分類監査が唯一留保していた lower corner＋三反対色 arm も消える。この接続に actual packet の import、要素の shift、hidden uniqueness、bare criticality はない。

## 最終判定の範囲

**COLOR-CAP の上流・dynamics・最終 actual 接続：独立読査 PASS。**

`FIVE_SHAPE_INDEPENDENT_AUDIT.md` が留保した COLOR-CAP は、本報告で解消される。外部標準定理を除く、この分類入口の未補完証明はなし。P21 全体の最終統合判定は、既に別監査した SYM と各 terminal closure を合わせた統合本文で行う。


追補：著者が追記した dynamics §4.2 の K_s=1 初期 run 明記、§9.2 の E_h≥x₁−b₁ という直接式、§10.1 SAME-F bridge も独立確認済み。上記 snapshot はこれらの追記後を指す。
