# PATH PFREE sign interface — 独立読査

2026-09-07。対象：`PATH_PFREE_SIGN_INTERFACE_COMPLETION.md` 全文。本文作成担当と別の担当が、exact identities、final signs、same-element provenance、criticality の適用箇所、S117 / S118 への接続を独立に確認した。

## 判定

\[
\boxed{\textbf{INDEPENDENT REVIEW: PASS}}
\]

`PFREE_i∩{F_0≤0}=∅` が exact input から証明される。生き残る PFREE_i に `F_0≥1` を渡してよい。`η` に隠れた非負仮定はない。

## 1. 上流入力の照合

S118 §§6–7 の actual central returns は
\[
q_A+m=(Y+a_i+\lambda)n_i+H_0n_j+K_0n_k,
\]
\[
q_B+m=Yn_i+(H_0+b_j)n_j+(K_0+\nu)n_k.
\]
canonical q_A を比較すれば、補完本文で使う
\[
m=(Y+\lambda+1)n_i+(H_0+1)n_j-(T-K_0-1)n_k
\]
は exact。`A_0≥1,H_0≥0,K_0≥0` は actual central coefficients と positive arm depth に由来する。

さらに `T=b_k+α`、`α=a_k−ν`、`η=ν−b_k` から
\[
a_k-C_0=a_k-(T-K_0-1)=K_0+\eta+1=F_0.
\]
従って PARAM に符号の輸入はない。

S117 §4.1 の後段には、指定された `q_R+m` の表示を actual と呼ぶ文章がある。しかし本補完は、その段落の直前までに得られた genuine central returns だけを入力とする。`K_0+η` の符号を先取りする循環はない。

## 2. actual returns と同じ q_R

全節で使われるのは同じ actual singleton
\[
q_R=(P-1)n_i+(R-1)n_j-n_k,\qquad q_R+Tn_k=F+m.
\]
PF 性から `q_R+n_i,q_R+n_j∈Γ`。各 return の corresponding missing coordinate は、もし正ならその同じ factorization から一個除いて `q_R∈Γ` となるためゼロ。m-level は `SH_H(q_R)={k}` により正。

したがって RIGHT-I / RIGHT-J は genuine である。別の q、別の upper、選択し直した complement は使われていない。

## 3. 四つの final certificates

以下の四式を独立に再導出した。第一・第二は各 return の一個の m に M+ を代入し、`q_R+Tn_k=F+m` を使う。第三・第四は同じ return-derived F identity に Herzog zero identity を一枚加える。

| certificate | exact final expression | 非負性の必要な入力 |
|---|---|---|
| J-FABS | `(r−2)m+(X+A_0)n_i+H_0n_j+(T+Z−C_0)n_k` | `r≥2`、`A_0≥1`、`H_0≥0`、`T−C_0=K_0+1≥1` |
| I-FABS | `(s−2)m+(A_0−1)n_i+(U+H_0+1)n_j+(T+V−C_0)n_k` | `s≥2`、`A_0≥1`、`H_0≥0`、`T−C_0≥1` |
| U-CERT | `(s−1)m+(ρ_i−1)n_i+(U−b_j)n_j+(T+V−a_k)n_k` | `s≥1`、`U≥b_j`、`T≥a_k` |
| X-CERT | `(r−1)m+(X−a_i)n_i+(ρ_j−1)n_j+(T+Z−b_k)n_k` | `r≥1`、`X≥a_i`、`T≥b_k` |

四式はいずれも **F 自身**の表示。全て exact。

`F_0≤0` なら `C_0≥a_k`、従って `T=C_0+K_0+1≥a_k+1`。また `α≥1` から `T≥b_k+1`。従って後二式の T-bounds はこの枝内で本文から保証される。

よって `r=s=1`、`U≤b_j−1`、`X≤a_i−1` が合法に導かれる。M+ の `−C_0 n_k` を actual と呼ぶ箇所はない。

## 4. pure-H の最後の二場合

unit returns の差は
\[
(X+1)n_i=(U+1)n_j+(V-Z)n_k.
\]
符号・係数を直接確認した。

- `V≥Z` なら `0<X+1≤a_i<ρ_i` の正倍の `n_i` が他の二生成元の非負和になり、i-criticality に反する。
- `V<Z` なら `0<U+1≤b_j<ρ_j` の正倍の `n_j` が `n_i,n_k` の非負和になり、j-criticality に反する。

`V=Z` は最初の枝に含まれる。右辺は `U+1≥1` により正。criticality は m が完全に消えたこの二式でのみ使用している。

## 5. 保存性・scope・結論

`η` は任意の符号のまま扱われる。必要なのは `F_0=a_k−C_0` という等式と、今回排除する枝の `F_0≤0` だけ。

既存の primitive seam の actuality、descent、minimality、return uniqueness は使わない。`Γ,F,m,W,q_R,c_R` と genuine two returns の全てを同じものとして保持する。

S117 §8 の完全 `i/k`・`a/b` involution は Herzog relations と canonical PATH data を保つため、反対側 PFREE_k にも同じ conditional theorem を適用できる。

従って、この補完を **MSR genuine central kernel → F_0≥1 → PFREE direct absorption / PF-FIX** の間に挿入してよい。本文は新規の符号補完として PASS。原 S117 の指定表示を最初から actual だったと遡及して承認するものではない。
