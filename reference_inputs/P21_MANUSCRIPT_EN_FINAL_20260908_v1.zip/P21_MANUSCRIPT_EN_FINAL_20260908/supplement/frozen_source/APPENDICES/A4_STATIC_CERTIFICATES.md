# 付録 A4 — 静的な全parameter正値certificate

本文の多項式恒等式を有限個の全係数として保存する。これらは半群の有限走査結果ではない。

## A4.1 — linear Dのi-fit

C8.4.5–6で定義した \(\Phi(a)=\widehat m-\mathcal J\)、\(a_*=fB+r\) に対し、
\[
\Phi(a_*)=35+\sum_{\gamma\ne0}c_\gamma\mathbf y^\gamma,
\quad c_\gamma\ge0,
\]
\[
\mathbf y=(f-1,r,\delta-1,\beta-1,g-1,\upsilon,
\alpha-1,w,\theta-1,\epsilon,k-1,a_j-1,b_k-1).
\]
全変数は非負である。全715単項式は
[静的係数表](LINEAR/I_FIT_POSITIVE_COEFFICIENTS.json)に含まれる。
JSONの各terms行はcoefficientとexponentsを持ち、variablesの順に指数を対応させる。
JSONの名前f,delta,beta,g,alpha,theta,k,a_j,b_kはそれぞれ1を引いた変数を表す。
r,u,w,epsは未shiftで、u=υ、eps=ε。全行の単項式を足すと本文の定義式へ一致する。

## A4.2 — Euclidean終端のi-fit

E8.4の \(\mathcal P=\Phi(B+\nu A)\) は
\[
\mathcal P=63+\sum_{\gamma\ne0}c_\gamma\mathbf y^\gamma,
\quad c_\gamma\ge0.
\]
全変数のshiftをE8.4.3に定義しており、変数順は

```text
p0, q0, s0, t0, r0, delta0, beta0, aj0, g0, alpha0, bk0, nu0, h0, z0, x0, w0
```

全3,234単項式、総次数7、定数63を
[静的係数表](EUCLIDEAN/TERMINAL_POSITIVITY_COEFFICIENTS.json)に保存する。
定数以外も全て非負であるため、正値結論はこの明示的な有限多項式恒等式から従う。

## A4.3 — 元記号と編集記号

| 数学本文 | 元certificate／code | 意味 |
|---|---|---|
| H_p | H | packetのk-source係数T+w |
| 𝒟_p | D | θχ−EH_p |
| 𝒨 | E+chiで計算 | 正整数下降測度 |
| υ | u | linear-first残余 |

静的表のbytesとverifierの数学的計算は採用sourceから変更していない。linear verifierの末尾にあった旧時点のOPEN表示だけを、検算の範囲を示す中立的な説明へ更新した。
[linear verifier](LINEAR/verify_D_linear.py)、[Euclidean verifier](EUCLIDEAN/verify_euclidean_closure.py)は
それぞれの定義式を展開して全係数表と一致することを確認する。
通常実行は既存の静的表を読み、表を新たに作成しない。

```bash
python3 APPENDICES/LINEAR/verify_D_linear.py
python3 APPENDICES/EUCLIDEAN/verify_euclidean_closure.py
```

Python 3とSymPyが必要。検算成功は補助的な整合性確認であり、
actuality、scope、first-point選択、全parameterの符号、停止の証明は本文で与える。
