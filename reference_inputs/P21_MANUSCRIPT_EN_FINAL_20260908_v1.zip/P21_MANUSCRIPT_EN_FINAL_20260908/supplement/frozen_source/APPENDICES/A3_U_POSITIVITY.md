# 付録 A3. U 正値分解の全係数

以下は POS-DECOMP の exact coefficients。全て \(t,z\ge1\)、\(\alpha,\eta>0\)、\(r,w\ge0\) で非負、実際には正である。

\[
\begin{aligned}
X_\delta={}&\alpha(tz+z+1)\\
&+\eta(t^2z^2+t^2z+2tz^2+2tz+t+z^2+z)\\
&+r(tz^2+2tz+z^2+2z+1)\\
&+w(tz^2+tz+z^2+z),
\end{aligned}
\]

\[
\begin{aligned}
Y_\delta={}&\alpha(tz+z+1)\\
&+\eta(t^2z^2+t^2z+2tz^2+3tz+t+z^2+2z+1)\\
&+r(tz^2+2tz+z^2+3z+1)\\
&+w(tz^2+tz+z^2+2z),
\end{aligned}
\]

\[
\begin{aligned}
X_\beta={}&\alpha(t+1)\\
&+\eta(t^2z+t^2+2tz+t+z)\\
&+r(tz+2t+z+2)+w(tz+t+z+1),
\end{aligned}
\]

\[
\begin{aligned}
Y_\beta={}&\alpha(t+1)\\
&+\eta(t^2z+t^2+2tz+2t+z+1)\\
&+r(tz+2t+z+3)+w(tz+t+z+2),
\end{aligned}
\]

\[
Z_\delta=z[\alpha+\eta(t+1)z+r(z+1)+wz],
\]

\[
Z_\beta=\alpha+\eta((t+1)z-1)+r(z+1)+wz.
\]

POS-DECOMP を得るには、\(a=a_*\)、\(C=\alpha+t\eta+r\)、\(b_k=\eta-\alpha+w\) を \(\widehat m-\mathcal J\) に代入し、\(\delta,\beta\) を取り出し、さらに

\[
Q=(t+1)(a_j+g)+1+q'
\]

を代入して \(a_j-1,g-1,q'\) ごとに展開すればよい。本付録の明示式を展開すればこの恒等式を直接照合できる。

---
