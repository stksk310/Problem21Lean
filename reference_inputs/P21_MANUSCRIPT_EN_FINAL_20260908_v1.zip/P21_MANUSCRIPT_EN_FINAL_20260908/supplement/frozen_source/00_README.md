# P21 — Final Frozen Verification Edition

2026-09-07凍結版。永久識別子：`P21-FROZEN-20260907-v1`。

**P21 CLOSED — canonical仮定下 / independently audited / FINAL FROZEN VERIFICATION EDITION**

独立master-proof監査の FINAL FREEZE: PASS を受け、E01と引用C01–C03だけを反映して固定した。
主定理は厳密に
\[
\operatorname{edim}(\Gamma)=4,\quad
m+F(\Gamma)-\varphi\in\Gamma\quad(\forall\varphi\in PF(\Gamma))
\quad\Longrightarrow\quad t(\Gamma)\le4.
\]
無条件の四生成数値半群定理ではない。

## 読む順序

一続きで読む場合は [P21_FINAL_FROZEN_PROOF_MASTER.md](P21_FINAL_FROZEN_PROOF_MASTER.md)。
本文01–09と数学付録A1–A4を同じ順序で連結してある。
静的全係数表と検算器はAPPENDICESにある。

| 章 | 内容 |
|---|---|
| [01_THEOREM_AND_SETUP.md](01_THEOREM_AND_SETUP.md) | T1、定義、canonical scope、標準外部定理 |
| [02_CANONICAL_REDUCTION.md](02_CANONICAL_REDUCTION.md) | 二層、KEY、actual四行、tail gcd |
| [03_SYMMETRIC_CASE.md](03_SYMMETRIC_CASE.md) | stable core、RAW4、対称caseの全分岐 |
| [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) | 局所geometry、M4、PATH∨TYPE II∨CHAIN |
| [05_PATH.md](05_PATH.md) | PAIR/PFREE、root正規化、符号、double-unit |
| [06_TYPE_II.md](06_TYPE_II.md) | 全域のsingleton二return証明 |
| [07_CHAIN_CORE.md](07_CHAIN_CORE.md) | 同じactual配置からCORE-ROOTへ |
| [08_CENTRAL_EUCLIDEAN_CLOSURE.md](08_CENTRAL_EUCLIDEAN_CLOSURE.md) | boundary、U、D、Euclidean保存・停止・source-fit |
| [09_FINAL_INTEGRATION.md](09_FINAL_INTEGRATION.md) | SYM/NONSYMの結合とt≤4 |
| [10_DEPENDENCY_LEDGER.md](10_DEPENDENCY_LEDGER.md) | 42結果のstatement/scope/source/audit対応 |

数学付録：

- [A1_MINBOX.md](APPENDICES/A1_MINBOX.md)：White、両色の係数certificate、MINBOX。
- [A2_COLOR_CAP.md](APPENDICES/A2_COLOR_CAP.md)：boxed dynamics、prefix/rank、SAME-f、COLOR-CAP。
- [A3_U_POSITIVITY.md](APPENDICES/A3_U_POSITIVITY.md)：Uの明示的な全係数分解。
- [A4_STATIC_CERTIFICATES.md](APPENDICES/A4_STATIC_CERTIFICATES.md)：linear/Euclideanの全係数表と検算方法。

## 編集の境界

数学本文には標準外部定理を除き、採用spineで必要な証明を組み込んだ。
SQ・TYPE Iはmatched-pair補題から排除するため別章を作っていない。
TYPE IIの旧各枝は全域二return定理に、CHAINの長い旧HIGH以下の経路は
同じactual配置のCORE-ROOTに置き換えた。依存の変更理由は台帳と変更履歴に記録する。

[EDITING_DESIGN.md](EDITING_DESIGN.md)は本文作成前の記号・番号・依存設計、
[EDITING_CHANGELOG.md](EDITING_CHANGELOG.md)は実装した変更、
[EDITING_CHECKPOINTS.md](EDITING_CHECKPOINTS.md)は6段階の作業記録、
[EDITING_AUDIT_REPORT.md](EDITING_AUDIT_REPORT.md)は編集後の内部点検である。

原発掘アーカイブは削除・変更していない。歴史的原本の所在未確定10群と、
採用spine上のproject-specific unproved input=0は別の層である。
採用監査14文書はAPPENDICES/ADOPTED_AUDITSに原文保存し、今回の編集版の独立監査とは区別する。
原監査内の過去時点の判定やsource参照を、編集版の現在の依存へ戻すものではない。

## 維持版で記録された検証（歴史的記録）

- 原アーカイブのmanifest 1,077件、採用台帳のbody/audit 32件のhashは全件一致。
- linear/Euclideanの付属検算は計63恒等式PASS。静的表715項・3,234項は定義式と一致。
- Euclideanの69表示式は、記号を逆変換して採用sourceと全件一致。
- 42結果の依存DAGに循環・未解決IDはない。

章ファイルが編集上の正本。通読版は次のコマンドで再生成できる。

```bash
python3 APPENDICES/rebuild_master.py
```

証明支援系による形式化完了、雑誌の査読完了、掲載受理は主張しない。全ての四生成数値半群について無条件にtype≤4とも主張しない。


## 永久freeze policy

**NO MATHEMATICAL CHANGE WITHOUT A NEW AUDIT.** 章正本・付録・係数表・依存構造を固定する。
将来の修正は新しいedition IDを与え、この版を上書きしない。
数学的内容と証明構造の変更は0。actuality・criticality・SAME-element・scope・完全色反転の規律を保持した。

## 今回の凍結記録

- [FINAL_FREEZE_CHANGELOG.md](FINAL_FREEZE_CHANGELOG.md)：許可された4修正と正確な前後文。
- [BIBLIOGRAPHIC_VERIFICATION.md](BIBLIOGRAPHIC_VERIFICATION.md)：外部定理3件の所在・仮定・結論の対応。
- [FINAL_FREEZE_AUDIT_SUMMARY.md](FINAL_FREEZE_AUDIT_SUMMARY.md)：既存監査判定と修正後の確認結果。
- [FINAL_FREEZE_DIFF_REPORT.md](FINAL_FREEZE_DIFF_REPORT.md)：全ファイル差分の分類。
- [PROVENANCE_CHAIN.md](PROVENANCE_CHAIN.md)：原ZIPの同一性と保存連鎖。
- [SHA256SUMS.txt](SHA256SUMS.txt)：自己ファイルを除く全ファイルのSHA-256。

今回再実行した検算は既存linear 28件、Euclidean 35件、独立監査追加23件。
独立監査の有限反例探索も同一範囲・同一seedで再実行した。有限探索は証明の代用ではない。
歴史的な発掘アーカイブ1,077件の再検証は今回の作業に含めない。

```bash
python3 APPENDICES/LINEAR/verify_D_linear.py
python3 APPENDICES/EUCLIDEAN/verify_euclidean_closure.py
python3 APPENDICES/FREEZE/run_audit_checks.py
python3 APPENDICES/FREEZE/run_adversarial_probes.py
python3 APPENDICES/FREEZE/verify_freeze.py
sha256sum -c SHA256SUMS.txt
```

Python 3、SymPy 1.14.0を使用した。検算は既存の係数表を読む通常実行のみ。
旧編集報告・採用監査・原ZIPは過去時点の記録として未変更で保存する。
最終ZIP自体のhashはZIP外の同名 `.sha256` ファイルに記録し、自己参照を避ける。
