# P21 — Provenance chain

Freeze identifier: `P21-FROZEN-20260907-v1`。

historical proof search → proof excavation → maintained proof → independent master audit → final frozen verification edition

| Stage | Artifact | SHA-256 | Role |
|---|---|---|---|
| excavation | 今回未提供。元READMEの来歴記録を保持 | 今回未確認・未主張 | source recovery。今回の数学的入力には使用しない |
| maintained proof | APPENDICES/AUDIT_ORIGINAL/P21_MAINTAINED_PROOF_20260907.zip | `1b274f81215e88e591aacbfaa72211a82377a81dd3dfe61bde4525758534d538` | edited mathematical master |
| independent audit | APPENDICES/AUDIT_ORIGINAL/P21_INDEPENDENT_MASTER_AUDIT_20260907.zip | `447e9a276619d9a3fcb522f5d69b66fef52101681167bb5965a547c46f673d54` | 独立監査の原ZIP |
| frozen edition | P21_FINAL_FROZEN_VERIFICATION_EDITION_20260907.zip | ZIP外の同名 .sha256 に記録 | permanent verified edition |

アップロード名末尾の(1)/(2)は受渡し上のファイル名差。維持版全47ファイルは監査ZIPのaudit_inputとbyte一致。
原ZIPのbytesを上記の凍結packageに保存し、アップロードされた元ファイルも上書きしない。
原監査のhash manifestは原ZIP内のパスに対する記録。今回の最上位SHA256SUMS.txtと混同しない。
最終ZIPやSHA256SUMS.txt自身のhashを、そのファイル自身の中に埋め込む自己参照は行わない。
