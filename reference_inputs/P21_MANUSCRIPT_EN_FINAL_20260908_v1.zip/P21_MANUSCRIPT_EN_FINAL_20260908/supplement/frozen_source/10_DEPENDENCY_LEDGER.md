# 10 — 最終依存台帳

Freeze identifier: `P21-FROZEN-20260907-v1`。42 nodesのstatement・scope・依存辺は監査対象版と同一。

維持する主要結果・独立に引用する局所結果は42項目。小節の計算は各IDの証明の内部であり、別の未記載定理を表さない。
出典は入力アーカイブにおける識別子を保持する。数学本文はLOCATIONに全て組み込み済みであり、出典アーカイブを開かないと証明が読めないという意味ではない。
ADOPTED AUDITは入力時に採用された監査であり、今回の編集版の新しい独立監査ではない。監査原文の内部参照は当時のアーカイブへの記録として保存する。

## 依存の読み方

T1は最終結論への参照、I9はその証明。第01章の定義・仮定はT1の結論を使わず参照できる。
A3/A4の多項式certificateは表示した定義式に対する代数的恒等式であり、適用先の閉鎖結論へ逆依存しない。E8のabstract theorem自体はC8.4を仮定せず、初期embedding E8.2.3だけがC8.4を使う。

機械可読版：[DEPENDENCY_LEDGER.json](APPENDICES/DEPENDENCY_LEDGER.json)。外部標準定理の正確な適用形と書誌は[第01章](01_THEOREM_AND_SETUP.md)。

## C2

| FIELD | 内容 |
|---|---|
| ID | C2 |
| STATEMENT | canonical二層・PF/complement・KEY・tail gcd・四行選択 |
| SCOPE | T1の仮定。gcdはQ非空で使用。 |
| DEPENDS ON | 定義と明示した代数のみ |
| SOURCE | review_supplements/P21_LOCAL_CANONICAL_KEY.md |
| ADOPTED AUDIT | [CANONICAL_SECOND_REVIEW.md](APPENDICES/ADOPTED_AUDITS/CANONICAL_SECOND_REVIEW.md)。入力台帳 N01 |
| USED IN | S3, G4.1, G4.2, A1, I9 |
| LOCATION | [02_CANONICAL_REDUCTION.md](02_CANONICAL_REDUCTION.md) |

## S3

| FIELD | 内容 |
|---|---|
| ID | S3 |
| STATEMENT | 対称tailではt≤4 |
| SCOPE | C2と対称な極小3生成tail。 |
| DEPENDS ON | C2, STD_SYM_GLUE |
| SOURCE | review_pass10/SYM_AUDIT.md |
| ADOPTED AUDIT | [SYM_SECOND_REVIEW.md](APPENDICES/ADOPTED_AUDITS/SYM_SECOND_REVIEW.md)。入力台帳 N02 |
| USED IN | I9 |
| LOCATION | [03_SYMMETRIC_CASE.md](03_SYMMETRIC_CASE.md) |

## G4.1

| FIELD | 内容 |
|---|---|
| ID | G4.1 |
| STATEMENT | singleton／doubleton／cornerとsix-arm atlas |
| SCOPE | 非対称tail、全actual q∈Q。 |
| DEPENDS ON | C2, STD_HERZOG |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md |
| ADOPTED AUDIT | [FIVE_SHAPE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/FIVE_SHAPE_INDEPENDENT_AUDIT.md)。入力台帳 N03 |
| USED IN | G4.2, G4.4, G4.5.2 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## G4.2

| FIELD | 内容 |
|---|---|
| ID | G4.2 |
| STATEMENT | PF/complement antichain、singleton caps、missing-coordinate box |
| SCOPE | G4.1のactual行。 |
| DEPENDS ON | C2, G4.1 |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md |
| ADOPTED AUDIT | [FIVE_SHAPE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/FIVE_SHAPE_INDEPENDENT_AUDIT.md)。入力台帳 N03 |
| USED IN | G4.4, G4.5, G4.5.1, G4.5.3, G4.6, G4.7, G4.8, G4.11.1 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## G4.3

| FIELD | 内容 |
|---|---|
| ID | G4.3 |
| STATEMENT | critical-box uniquenessと整数kernel基底 |
| SCOPE | pure-Hの真のcritical relations。 |
| DEPENDS ON | STD_HERZOG |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md |
| ADOPTED AUDIT | [FIVE_SHAPE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/FIVE_SHAPE_INDEPENDENT_AUDIT.md)。入力台帳 N03 |
| USED IN | G4.5, G4.6, G4.7, G4.8, G4.11.1, C8.2 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## G4.4

| FIELD | 内容 |
|---|---|
| ID | G4.4 |
| STATEMENT | cornerとsingletonは共存しない |
| SCOPE | 同じΓ,F,Wの二行。 |
| DEPENDS ON | G4.1, G4.2 |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md |
| ADOPTED AUDIT | [FIVE_SHAPE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/FIVE_SHAPE_INDEPENDENT_AUDIT.md)。入力台帳 N03 |
| USED IN | G4.9 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## G4.5

| FIELD | 内容 |
|---|---|
| ID | G4.5 |
| STATEMENT | matched pairの同一depthとcomplement同期 |
| SCOPE | actual A_i(λ),B_i(μ)。g,α≥0を許す。 |
| DEPENDS ON | G4.2, G4.3 |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md |
| ADOPTED AUDIT | [FIVE_SHAPE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/FIVE_SHAPE_INDEPENDENT_AUDIT.md)。入力台帳 N03 |
| USED IN | G4.5.1, M4, G4.11.2 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## G4.5.1

| FIELD | 内容 |
|---|---|
| ID | G4.5.1 |
| STATEMENT | matched pairに他方向singletonは共存しない |
| SCOPE | G4.5の非負boundaryを含む。 |
| DEPENDS ON | G4.5, G4.2 |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md |
| ADOPTED AUDIT | [FIVE_SHAPE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/FIVE_SHAPE_INDEPENDENT_AUDIT.md)。入力台帳 N03 |
| USED IN | G4.5.3 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## M4

| FIELD | 内容 |
|---|---|
| ID | M4 |
| STATEMENT | matched pairの最小正levelが一致しP-FIBERを与える |
| SCOPE | G4.5。g=0またはα=0も含む。 |
| DEPENDS ON | G4.5 |
| SOURCE | review_pass10/HIGH_ENTRY_AUDIT.md |
| ADOPTED AUDIT | [HIGH_ENTRY_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/HIGH_ENTRY_INDEPENDENT_AUDIT.md)。入力台帳 N04 |
| USED IN | G4.5.2, G4.5.3, R7 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## G4.5.2

| FIELD | 内容 |
|---|---|
| ID | G4.5.2 |
| STATEMENT | matched pairにA_j、B_kは共存しない |
| SCOPE | G4.5とactual extra arm。 |
| DEPENDS ON | M4, G4.1 |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md §5.2; HIGH_ENTRY_AUDIT.md §9 |
| ADOPTED AUDIT | [HIGH_ENTRY_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/HIGH_ENTRY_INDEPENDENT_AUDIT.md)。入力台帳 N04 |
| USED IN | G4.9 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## G4.5.3

| FIELD | 内容 |
|---|---|
| ID | G4.5.3 |
| STATEMENT | matched pairとsingletonは共存しない |
| SCOPE | 同じW、G4.5。TYPE I排除。 |
| DEPENDS ON | M4, G4.2, G4.5.1 |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md §5.3 |
| ADOPTED AUDIT | [HIGH_ENTRY_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/HIGH_ENTRY_INDEPENDENT_AUDIT.md)。入力台帳 N04 |
| USED IN | G4.9 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## G4.6

| FIELD | 内容 |
|---|---|
| ID | G4.6 |
| STATEMENT | 同色二armの二つのcomplement形とsingleton共存排除 |
| SCOPE | G4.1のactual同色異方向二arm。 |
| DEPENDS ON | G4.2, G4.3 |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md |
| ADOPTED AUDIT | [FIVE_SHAPE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/FIVE_SHAPE_INDEPENDENT_AUDIT.md)。入力台帳 N03 |
| USED IN | G4.9, G4.11.3 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## G4.7

| FIELD | 内容 |
|---|---|
| ID | G4.7 |
| STATEMENT | 異色異方向の二つの向きとsingleton許容方向 |
| SCOPE | G4.1のactual異色異方向二arm。R=0は完成表示で処理。 |
| DEPENDS ON | G4.2, G4.3 |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md |
| ADOPTED AUDIT | [FIVE_SHAPE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/FIVE_SHAPE_INDEPENDENT_AUDIT.md)。入力台帳 N03 |
| USED IN | G4.9, G4.11.2, G4.11.3, G4.11.4 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## G4.8

| FIELD | 内容 |
|---|---|
| ID | G4.8 |
| STATEMENT | 三singletonがあればQ全体が三行だけ |
| SCOPE | 全Qのactual complements。 |
| DEPENDS ON | G4.2, G4.3 |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md |
| ADOPTED AUDIT | [FIVE_SHAPE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/FIVE_SHAPE_INDEPENDENT_AUDIT.md)。入力台帳 N03 |
| USED IN | G4.9 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## A1

| FIELD | 内容 |
|---|---|
| ID | A1 |
| STATEMENT | 三本のactual同色armの最小m-levelは1 |
| SCOPE | multiplicity、Herzog、三本のactual arm、全ordering。 |
| DEPENDS ON | C2, STD_HERZOG, STD_WHITE |
| SOURCE | review_pass10/COLOR_CAP_DEPENDENCY_AUDIT.md |
| ADOPTED AUDIT | [COLOR_CAP_SECOND_REVIEW.md](APPENDICES/ADOPTED_AUDITS/COLOR_CAP_SECOND_REVIEW.md)。入力台帳 N05 |
| USED IN | A2 |
| LOCATION | [APPENDICES/A1_MINBOX.md](APPENDICES/A1_MINBOX.md) |

## A2

| FIELD | 内容 |
|---|---|
| ID | A2 |
| STATEMENT | boxed dynamicsのpositive exitからTHREE-ARMとCOLOR-CAP |
| SCOPE | A1のMINBOX、同じsocle fε。 |
| DEPENDS ON | A1 |
| SOURCE | review_pass10/COLOR_CAP_DYNAMICS_AUDIT.md |
| ADOPTED AUDIT | [COLOR_CAP_SECOND_REVIEW.md](APPENDICES/ADOPTED_AUDITS/COLOR_CAP_SECOND_REVIEW.md)。入力台帳 N06 |
| USED IN | G4.9 |
| LOCATION | [APPENDICES/A2_COLOR_CAP.md](APPENDICES/A2_COLOR_CAP.md) |

## G4.9

| FIELD | 内容 |
|---|---|
| ID | G4.9 |
| STATEMENT | 四行反例はPATH∨TYPE II∨CHAIN |
| SCOPE | |Q|≥4から選んだ異なるactual四行。 |
| DEPENDS ON | G4.4, G4.5.2, G4.5.3, G4.6, G4.7, G4.8, A2 |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md |
| ADOPTED AUDIT | [FIVE_SHAPE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/FIVE_SHAPE_INDEPENDENT_AUDIT.md)。入力台帳 N07 |
| USED IN | G4.11.2, G4.11.3, G4.11.4, I9 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## G4.11.1

| FIELD | 内容 |
|---|---|
| ID | G4.11.1 |
| STATEMENT | singleton saturation：c_S=Pn_i |
| SCOPE | BOX-Wとsingletonの同時成立。 |
| DEPENDS ON | G4.2, G4.3 |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md |
| ADOPTED AUDIT | [FIVE_SHAPE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/FIVE_SHAPE_INDEPENDENT_AUDIT.md)。入力台帳 N07 |
| USED IN | G4.11.3, G4.11.4 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## G4.11.2

| FIELD | 内容 |
|---|---|
| ID | G4.11.2 |
| STATEMENT | CHAINのstrict四行・complement・W-box |
| SCOPE | G4.9のCHAIN。λ,δ,β,g,α≥1。 |
| DEPENDS ON | G4.9, G4.5, G4.7 |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md |
| ADOPTED AUDIT | [FIVE_SHAPE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/FIVE_SHAPE_INDEPENDENT_AUDIT.md)。入力台帳 N07 |
| USED IN | R7 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## G4.11.3

| FIELD | 内容 |
|---|---|
| ID | G4.11.3 |
| STATEMENT | TYPE IIの全scalar範囲、λ≤b_iを含む |
| SCOPE | G4.9のTYPE II。 |
| DEPENDS ON | G4.9, G4.6, G4.7, G4.11.1 |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md |
| ADOPTED AUDIT | [FIVE_SHAPE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/FIVE_SHAPE_INDEPENDENT_AUDIT.md)。入力台帳 N07 |
| USED IN | T6 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## G4.11.4

| FIELD | 内容 |
|---|---|
| ID | G4.11.4 |
| STATEMENT | PATHのendpoint raysとactual ladder |
| SCOPE | G4.9のPATH。 |
| DEPENDS ON | G4.9, G4.7, G4.11.1 |
| SOURCE | review_pass10/FIVE_SHAPE_COMPLETION.md |
| ADOPTED AUDIT | [FIVE_SHAPE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/FIVE_SHAPE_INDEPENDENT_AUDIT.md)。入力台帳 N07 |
| USED IN | P5.1 |
| LOCATION | [04_NONSYMMETRIC_CLASSIFICATION.md](04_NONSYMMETRIC_CLASSIFICATION.md) |

## P5.1

| FIELD | 内容 |
|---|---|
| ID | P5.1 |
| STATEMENT | PAIR∨PFREE_i∨完全双対 |
| SCOPE | G4.11.4、actual central returns。符号未確認のendpointは不使用。 |
| DEPENDS ON | G4.11.4 |
| SOURCE | authoritative_sources/corpus/S117.md §§3–4,7–8 |
| ADOPTED AUDIT | [S328.md](APPENDICES/ADOPTED_AUDITS/S328.md)。入力台帳 E01 |
| USED IN | P5.2, P5.4, P5.7 |
| LOCATION | [05_PATH.md](05_PATH.md) |

## P5.2

| FIELD | 内容 |
|---|---|
| ID | P5.2 |
| STATEMENT | PAIRから左右strong port |
| SCOPE | 同じactual central PAIR。 |
| DEPENDS ON | P5.1 |
| SOURCE | authoritative_sources/corpus/S117.md §6 |
| ADOPTED AUDIT | [S328.md](APPENDICES/ADOPTED_AUDITS/S328.md)。入力台帳 E01 |
| USED IN | P5.3 |
| LOCATION | [05_PATH.md](05_PATH.md) |

## P5.3

| FIELD | 内容 |
|---|---|
| ID | P5.3 |
| STATEMENT | weak ROOTの有限正規化、endpoint level≥2、PAIR閉鎖 |
| SCOPE | 同じq_L,q_A,W、1≤d≤a_i−1、S≥1、e≥α。 |
| DEPENDS ON | P5.2 |
| SOURCE | review_pass10/PATH_ENDPOINT_LEVEL_COMPLETION.md |
| ADOPTED AUDIT | [PATH_ENDPOINT_LEVEL_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/PATH_ENDPOINT_LEVEL_INDEPENDENT_AUDIT.md)。入力台帳 N11 |
| USED IN | P5.7 |
| LOCATION | [05_PATH.md](05_PATH.md) |

## P5.4

| FIELD | 内容 |
|---|---|
| ID | P5.4 |
| STATEMENT | PFREEのF₀≤0排除 |
| SCOPE | central kernelと同じ右singletonの二returns。ηの符号は任意。 |
| DEPENDS ON | P5.1 |
| SOURCE | review_pass10/PATH_PFREE_SIGN_INTERFACE_COMPLETION.md |
| ADOPTED AUDIT | [PATH_PFREE_SIGN_INTERFACE_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/PATH_PFREE_SIGN_INTERFACE_INDEPENDENT_AUDIT.md)。入力台帳 N14 |
| USED IN | P5.5 |
| LOCATION | [05_PATH.md](05_PATH.md) |

## P5.5

| FIELD | 内容 |
|---|---|
| ID | P5.5 |
| STATEMENT | PFREE直接吸収とlevel-one固定形 |
| SCOPE | P5.4でF₀≥1を確定した同じ配置。 |
| DEPENDS ON | P5.4 |
| SOURCE | authoritative_sources/corpus/S118.md §§7–8; S328.md後半 §§5–6; PATH_DOUBLE_UNIT_COMPLETION.md §7 |
| ADOPTED AUDIT | [S328.md](APPENDICES/ADOPTED_AUDITS/S328.md)。入力台帳 E01 |
| USED IN | P5.6 |
| LOCATION | [05_PATH.md](05_PATH.md) |

## P5.6

| FIELD | 内容 |
|---|---|
| ID | P5.6 |
| STATEMENT | double-unit配置の排除 |
| SCOPE | P5-FIX-Jと両unit returns、同じ反対側singleton。 |
| DEPENDS ON | P5.5 |
| SOURCE | review_pass10/PATH_DOUBLE_UNIT_COMPLETION.md |
| ADOPTED AUDIT | [PATH_DOUBLE_UNIT_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/PATH_DOUBLE_UNIT_INDEPENDENT_AUDIT.md)。入力台帳 N12 |
| USED IN | P5.7 |
| LOCATION | [05_PATH.md](05_PATH.md) |

## P5.7

| FIELD | 内容 |
|---|---|
| ID | P5.7 |
| STATEMENT | PATH不存在 |
| SCOPE | 左右の完全parameter交換を含む全PATH。 |
| DEPENDS ON | P5.1, P5.3, P5.6 |
| SOURCE | authoritative_sources/corpus/S328.md |
| ADOPTED AUDIT | [S328.md](APPENDICES/ADOPTED_AUDITS/S328.md)。入力台帳 E01 |
| USED IN | I9 |
| LOCATION | [05_PATH.md](05_PATH.md) |

## T6

| FIELD | 内容 |
|---|---|
| ID | T6 |
| STATEMENT | TYPE II全域の二return排除 |
| SCOPE | λ≤b_i、λ<a_i、μ<b_j、ν<a_k。λ=b_iも含む。 |
| DEPENDS ON | G4.11.3 |
| SOURCE | review_pass10/TYPEII_COMPLETION.md |
| ADOPTED AUDIT | [TYPEII_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/TYPEII_INDEPENDENT_AUDIT.md)。入力台帳 N08 |
| USED IN | I9 |
| LOCATION | [06_TYPE_II.md](06_TYPE_II.md) |

## R7

| FIELD | 内容 |
|---|---|
| ID | R7 |
| STATEMENT | 同じactual CHAINからCORE-ROOTを得る |
| SCOPE | G4.11.2、同じh_A=q_A+mの最大i表示。 |
| DEPENDS ON | G4.11.2, M4 |
| SOURCE | review_pass10/CHAIN_ROOT_PROGRESS.md |
| ADOPTED AUDIT | [CHAIN_ROOT_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/CHAIN_ROOT_INDEPENDENT_AUDIT.md)。入力台帳 N09 |
| USED IN | C8.1, C8.5 |
| LOCATION | [07_CHAIN_CORE.md](07_CHAIN_CORE.md) |

## C8.1

| FIELD | 内容 |
|---|---|
| ID | C8.1 |
| STATEMENT | COREからreturns、caps、intrinsic向き、notchとFK cap |
| SCOPE | R7の全CORE。strict-Cの帰結はC>αに限定。 |
| DEPENDS ON | R7 |
| SOURCE | review_pass10/CENTRAL_ENTRY_AUDIT.md |
| ADOPTED AUDIT | [CENTRAL_INDEPENDENT_AUDIT.md](APPENDICES/ADOPTED_AUDITS/CENTRAL_INDEPENDENT_AUDIT.md)。入力台帳 N10 |
| USED IN | C8.2, C8.4, C8.5 |
| LOCATION | [08_CENTRAL_EUCLIDEAN_CLOSURE.md](08_CENTRAL_EUCLIDEAN_CLOSURE.md) |

## C8.2

| FIELD | 内容 |
|---|---|
| ID | C8.2 |
| STATEMENT | boundary排除、strict window、U∨Dの網羅性 |
| SCOPE | C8.1のCORE、RET、first point。 |
| DEPENDS ON | C8.1, G4.3 |
| SOURCE | authoritative_sources/corpus/S286.md §§2–11 |
| ADOPTED AUDIT | [S321.md](APPENDICES/ADOPTED_AUDITS/S321.md)。入力台帳 E02 |
| USED IN | C8.3, C8.4, C8.5 |
| LOCATION | [08_CENTRAL_EUCLIDEAN_CLOSURE.md](08_CENTRAL_EUCLIDEAN_CLOSURE.md) |

## A3

| FIELD | 内容 |
|---|---|
| ID | A3 |
| STATEMENT | U閾値多項式の全係数恒等式 |
| SCOPE | C8.3の定義式。t,z≥1、α,η>0、r,w≥0。C8.3の結論は不使用。 |
| DEPENDS ON | 定義と明示した代数のみ |
| SOURCE | authoritative_sources/corpus/S289.md 付録A |
| ADOPTED AUDIT | [S321.md](APPENDICES/ADOPTED_AUDITS/S321.md)。入力台帳 E02 |
| USED IN | C8.3 |
| LOCATION | [APPENDICES/A3_U_POSITIVITY.md](APPENDICES/A3_U_POSITIVITY.md) |

## C8.3

| FIELD | 内容 |
|---|---|
| ID | C8.3 |
| STATEMENT | U全域のsource-fitと同じq_Akのgap矛盾 |
| SCOPE | U-PARAM、η範囲、D_u>0。 |
| DEPENDS ON | C8.2, A3 |
| SOURCE | authoritative_sources/corpus/S289.md §§1–4 |
| ADOPTED AUDIT | [S321.md](APPENDICES/ADOPTED_AUDITS/S321.md)。入力台帳 E02 |
| USED IN | C8.4, C8.5 |
| LOCATION | [08_CENTRAL_EUCLIDEAN_CLOSURE.md](08_CENTRAL_EUCLIDEAN_CLOSURE.md) |

## A4.1

| FIELD | 内容 |
|---|---|
| ID | A4.1 |
| STATEMENT | linear D閾値の715項正値恒等式 |
| SCOPE | C8.4.5–6の定義式の非負変数域。定理結論に依存しない。 |
| DEPENDS ON | 定義と明示した代数のみ |
| SOURCE | authoritative_sources/package_members/S291/I_FIT_POSITIVE_COEFFICIENTS.json |
| ADOPTED AUDIT | [S321.md](APPENDICES/ADOPTED_AUDITS/S321.md)。入力台帳 E02 |
| USED IN | C8.4 |
| LOCATION | [APPENDICES/A4_STATIC_CERTIFICATES.md](APPENDICES/A4_STATIC_CERTIFICATES.md) |

## C8.4

| FIELD | 内容 |
|---|---|
| ID | C8.4 |
| STATEMENT | D high-q/nonlinear排除、linear firstと二packet入力 |
| SCOPE | D、sum-notch、τ₀≥R+1、同じfirst point。 |
| DEPENDS ON | C8.1, C8.2, C8.3, A4.1 |
| SOURCE | authoritative_sources/corpus/S293.md §§1–8（§8のCOMPLEMENTARYまで） |
| ADOPTED AUDIT | [S321.md](APPENDICES/ADOPTED_AUDITS/S321.md)。入力台帳 E02 |
| USED IN | E8.2.3, C8.5 |
| LOCATION | [08_CENTRAL_EUCLIDEAN_CLOSURE.md](08_CENTRAL_EUCLIDEAN_CLOSURE.md) |

## A4.2

| FIELD | 内容 |
|---|---|
| ID | A4.2 |
| STATEMENT | Euclidean終端閾値の3,234項正値恒等式 |
| SCOPE | E8.4.3の非負変数域。E8の結論に依存しない。 |
| DEPENDS ON | 定義と明示した代数のみ |
| SOURCE | authoritative_sources/package_members/S301/TERMINAL_POSITIVITY_COEFFICIENTS.json |
| ADOPTED AUDIT | [S321.md](APPENDICES/ADOPTED_AUDITS/S321.md)。入力台帳 E02 |
| USED IN | E8 |
| LOCATION | [APPENDICES/A4_STATIC_CERTIFICATES.md](APPENDICES/A4_STATIC_CERTIFICATES.md) |

## E8

| FIELD | 内容 |
|---|---|
| ID | E8 |
| STATEMENT | Euclidean two-packet closure theorem |
| SCOPE | E8.2.1のabstract全仮定、同じΓ,F,m,W、m<min n。 |
| DEPENDS ON | A4.2 |
| SOURCE | authoritative_sources/corpus/S302.md §§2,3–6 |
| ADOPTED AUDIT | [S321.md](APPENDICES/ADOPTED_AUDITS/S321.md)。入力台帳 E02 |
| USED IN | C8.5 |
| LOCATION | [08_CENTRAL_EUCLIDEAN_CLOSURE.md](08_CENTRAL_EUCLIDEAN_CLOSURE.md) |

## E8.2.3

| FIELD | 内容 |
|---|---|
| ID | E8.2.3 |
| STATEMENT | linear firstからabstract packageへのexact embedding |
| SCOPE | C8.4の二genuine packets、初期matrix [[fk+1,f],[k,1]]。 |
| DEPENDS ON | C8.4 |
| SOURCE | authoritative_sources/corpus/S302.md §2.3 |
| ADOPTED AUDIT | [S321.md](APPENDICES/ADOPTED_AUDITS/S321.md)。入力台帳 E02 |
| USED IN | C8.5 |
| LOCATION | [08_CENTRAL_EUCLIDEAN_CLOSURE.md](08_CENTRAL_EUCLIDEAN_CLOSURE.md) |

## C8.5

| FIELD | 内容 |
|---|---|
| ID | C8.5 |
| STATEMENT | CHAIN全域不存在 |
| SCOPE | R7のCOREからU/D全域とE8へ。 |
| DEPENDS ON | R7, C8.1, C8.2, C8.3, C8.4, E8.2.3, E8 |
| SOURCE | authoritative_sources/corpus/S302.md |
| ADOPTED AUDIT | [S321.md](APPENDICES/ADOPTED_AUDITS/S321.md)。入力台帳 E02 |
| USED IN | I9 |
| LOCATION | [08_CENTRAL_EUCLIDEAN_CLOSURE.md](08_CENTRAL_EUCLIDEAN_CLOSURE.md) |

## I9

| FIELD | 内容 |
|---|---|
| ID | I9 |
| STATEMENT | 全Qに対して|Q|≤3、t=|Q|+1≤4 |
| SCOPE | T1のcanonical scope。tail gcdの第三の枝なし。 |
| DEPENDS ON | C2, S3, G4.9, P5.7, T6, C8.5 |
| SOURCE | 19_MAINTAINED_PROOF_SPINE.md |
| ADOPTED AUDIT | [INTEGRATION_SECOND_REVIEW.md](APPENDICES/ADOPTED_AUDITS/INTEGRATION_SECOND_REVIEW.md)。入力台帳 N13 |
| USED IN | T1 |
| LOCATION | [09_FINAL_INTEGRATION.md](09_FINAL_INTEGRATION.md) |

## T1

| FIELD | 内容 |
|---|---|
| ID | T1 |
| STATEMENT | canonical四生成数値半群のtypeは高々4 |
| SCOPE | 第01章の全仮定。無条件edim4には拡張しない。 |
| DEPENDS ON | I9 |
| SOURCE | 19_MAINTAINED_PROOF_SPINE.md |
| ADOPTED AUDIT | [INTEGRATION_SECOND_REVIEW.md](APPENDICES/ADOPTED_AUDITS/INTEGRATION_SECOND_REVIEW.md)。入力台帳 N13 |
| USED IN | 主定理の結論 |
| LOCATION | [01_THEOREM_AND_SETUP.md](01_THEOREM_AND_SETUP.md) |

## 圧縮とsupersession

| 退役した歴史的経路 | 現行での置換 | 理由 |
|---|---|---|
| SQ個別証明、TYPE I dual-anchor | M4＋G4.5.2–5.3 | 同じnonnegative matched packageから排除 |
| 三生成kernelの繰返し証明 | G4.3 | 後期は同じpure-H基底を引用 |
| MINBOXのk=2個別処理 | A1の両色certificate | 全k≥2を含む |
| PATHのF-ROUTE、first-completion localization | P5.3–P5.6 | endpointとPFREEを直接吸収 |
| TYPE IIのlow/high-ν・Branch A/B/C | T6 | 全域の二return定理 |
| CHAINのnonmatch、HIGH、ORIGINAL POSJ、K1/K2/K3、A1J、S1 strict、equality endpoint、general mismatch | R7→C8.1 | same actual CHAINから直接COREへ |
| S293 §8後半のreduced-depth returnと§9以降 | E8 | abstract packet域に埋め込み、全仮定保存を証明 |
| S302 §7–9の歴史的全体結合 | I9 | 現行PATH∨TYPE II∨CHAIN分類で結合 |

元資料の削除・改変・採択取消しは行っていない。
