# 05 — PATH

## P5.0 — exact入力とラベル

G4.11.4のPATHを取り、\(1\le\lambda<b_i,1\le\nu<a_k\)、
\(\beta=b_i-\lambda\ge1,\alpha=a_k-\nu\ge1\)、
\(P=a_i+\beta,T=b_k+\alpha,1\le R<\rho_j\) とする。同じWの四行は
\[
q_L=-n_i+(R-1)n_j+(T-1)n_k,\quad c_L=Pn_i,
\]
\[
q_A=(a_i-1)n_i-n_j+(T-1)n_k=A_k(\nu),\quad c_A=\beta n_i+Rn_j,
\]
\[
q_B=(P-1)n_i-n_j+(b_k-1)n_k=B_i(\lambda),\quad c_B=Rn_j+\alpha n_k,
\]
\[
q_R=(P-1)n_i+(R-1)n_j-n_k,\quad c_R=Tn_k.
\]
全てactual PF行であり、\(SH(q_L)=\{i\},SH(q_R)=\{k\}\)。ladderは
\[
q_L+a_in_i=q_A+Rn_j,\quad q_A+\beta n_i=q_B+\alpha n_k,
\quad q_R+b_kn_k=q_B+Rn_j.
\]
この章のq_A,q_Bはladderラベルであり、missing directionはそれぞれk,iである。

## P5.1 — central match-or-seamの必要部分

両 \(q_A+m,q_B+m\) はC2によりH内にある。
\[
q_A+m=Xn_i+H_0n_j+(Z+\alpha)n_k,\quad
q_B+m=(X+\beta)n_i+H_0n_j+Zn_k,\qquad X,H_0,Z\ge0
\tag{P5-PAIR}
\]
を満たす一対をPAIRと呼ぶ。PAIRがなければ、任意の前者の表示でk係数はα未満、
任意の後者の表示でi係数はβ未満である。そうでなければladderの中央等式からPAIRを作れる。

同じactual元内でHCRのpacketを置換し、
\[
q_A+m=Xn_i+H_0n_j+Kn_k,\quad
0\le X<\rho_i,\ 0\le H_0<\rho_j,\ 0\le K<\alpha,
\]
\[
q_B+m=Yn_i+J_0n_j+Ln_k,\quad
0\le Y<\beta,\ 0\le J_0<\rho_j,\ 0\le L<\rho_k
\]
と正規化する。前者はj-packetを除くたびにH₀がρ_j減少する。i≥ρ_iならRi置換で
k≥a_k>αとなってPAIR。後者はj-packetを除き、k≥ρ_kならRk置換でi≥b_i>βとなってPAIR。
従ってno-PAIRの場合には上の範囲で停止する。

比較して
\[
A_c n_i+(H_0-J_0)n_j=B_c n_k,
\quad A_c=X+\beta-Y>0,\quad B_c=\alpha+L-K>0.
\]
H₀<J₀なら \(e=J_0-H_0\in[1,\rho_j-1]\)、A_c≥ρ_i。
\(a=A_c-\rho_i\in[0,\beta-1]\) としてRiを比較すると
\[
a n_i=(e-b_j)n_j+(B_c-a_k)n_k.
\]
\(B_c-a_k\le T-1<\rho_k\)。右二係数の四つの符号を分ける。
両非負ならi-criticalityにより全部0。一方だけ負ならjまたはkの正のsubcritical倍を
他二生成元で表すことになり矛盾。両負も不可能。従って
\[
A_c=\rho_i,\quad J_0-H_0=b_j,\quad B_c=a_k.
\]
これは次のactual central kernelを与える：
\[
\boxed{q_A+m=(Y+a_i+\lambda)n_i+H_0n_j+K_0n_k,}
\]
\[
\boxed{q_B+m=Yn_i+(H_0+b_j)n_j+(K_0+\nu)n_k,}
\tag{P5-PFREE-i}
\]
\[
0\le Y<\beta,\quad0\le K_0<\alpha,\quad0\le H_0<a_j.
\]
H₀>J₀は下記の完全な左右反転で同じkernelに移る。
H₀=J₀ならA_c n_i=B_c n_k。criticalityでA_c≥ρ_i,B_c≥ρ_kとなり、
Ri比較後の \((B_c-a_k)n_k=(A_c-\rho_i)n_i+b_jn_j\) は
\(0<B_c-a_k\le T-1<\rho_k\) に反する。
よってPAIRまたはPFREE_i、またはその完全双対に尽くされる。
ここでは符号未確認のendpoint再生表示をactualとして使用していない。

### P5-dual — 全parameterの左右反転

\[
i^\vee=k,\ j^\vee=j,\ k^\vee=i,\qquad
(n_i^\vee,n_j^\vee,n_k^\vee)=(n_k,n_j,n_i),
\]
\[
(a_i^\vee,b_i^\vee)=(b_k,a_k),\quad
(a_j^\vee,b_j^\vee)=(b_j,a_j),\quad
(a_k^\vee,b_k^\vee)=(b_i,a_i),
\]
\[
(\lambda^\vee,\nu^\vee)=(\nu,\lambda),\quad
(\alpha^\vee,\beta^\vee)=(\beta,\alpha),\quad
(P^\vee,R^\vee,T^\vee)=(T,R,P),
\]
\[
(q_L^\vee,q_A^\vee,q_B^\vee,q_R^\vee)=(q_R,q_B,q_A,q_L).
\]
Γ,F,m,Wは不変。HCR、arm bounds、singleton status、ladderを全て保存する。
no-PAIRのH₀>J₀側では新q_Aが旧q_Bとなり、新しいj係数はJ₀<H₀だから、
すでに証明したH₀<J₀の場合へ正確に帰着する。

## P5.2 — PAIRからstrong portへ

PAIRとcanonical行を比較すると
\[
m=(X-a_i+1)n_i+(H_0+1)n_j+(Z-b_k+1)n_k.
\]
\(t_0=\rho_j-H_0-1\) とおけばHCRから
\[
t_0n_j+m=(X+1)n_i+(Z+1)n_k.
\]
右辺はmより大きいので \(1\le t_0<\rho_j\)。同じq_A,q_Bについて
\[
q_A=m+(a_i-X-2)n_i+(t_0-1)n_j+(T-Z-2)n_k,
\]
\[
q_B=m+(P-X-2)n_i+(t_0-1)n_j+(b_k-Z-2)n_k.
\]
最終係数が全非負ならgapに反するため
\[
X\ge a_i-1\ \vee\ Z\ge T-1,\qquad
X\ge P-1\ \vee\ Z\ge b_k-1.
\]
一方、X≥a_i−1かつZ≥b_k−1ならrootは非負表示となりm∈Hで不可能。
従って
\[
X\le a_i-2,\ Z\ge T-1
\quad\text{または}\quad
X\ge P-1,\ Z\le b_k-2.
\]
左右反転で前者にでき、\(d=a_i-1-X,S=H_0+1,e=Z-b_k+1\) は
\[
m=-dn_i+Sn_j+en_k,\quad1\le d\le a_i-1,\ S\ge1,\ e\ge\alpha
\]
を満たす。この式をWEAK-ROOTと呼び、次の定理に渡す。

## P5.3 — weak rootの正規化とPAIR排除

入力はP5.0の同じq_L,q_A,WとP5.2のweak rootである。
### P5.3.2 actual missing-direction returns

PF 性より `q_L+n_j,q_L+n_k∈Γ`。`q_L+n_j` の genuine factorization に `n_j` があれば、その同じ係数ベクトルから一個除いて `q_L∈Γ` となる。従って `j` 係数はゼロ。同様に `q_L+n_k` の `k` 係数もゼロ。

さらに SINGLETON より両 successor は `H` に属さず、m-係数は正。従って任意の genuine returns は
\[
q_L+n_j=\ell m+A n_i+C n_k,
\quad \ell\ge1,\ A,C\ge0,
\tag{LJ}
\]
\[
q_L+n_k=L_km+A_kn_i+B_kn_j,
\quad L_k\ge1,\ A_k,B_k\ge0.
\tag{LK}
\]
と書ける。ここで uniqueness、return-level minimality、selected support の変更は使わない。

### P5.3.3 弱い ROOT は `S<R` と `e≥T` を強制する

LK に WEAK-ROOT を一回だけ代入し、QA の exact identity を使う：
\[
q_A=(L_k-1)m+(A_k-d+a_i)n_i
 +(B_k+S-R)n_j+(e-1)n_k.
\tag{QA-ROOT}
\]
ここで
\[
L_k-1\ge0,\quad A_k-d+a_i\ge1,\quad e-1\ge0.
\]
もし `S≥R` なら残る係数も非負で `q_A∈Γ`。従って
\[
1\le S\le R-1.
\tag{S-WALL}
\]

次に同じ `W` から ROOT の `m` を引く exact identity は
\[
F=(P+d-1)n_i+(R-S-1)n_j+(T-e-1)n_k.
\tag{F-ROOT}
\]
最初の二係数は非負。`e≤T-1` なら三番目も非負で `F∈Γ` となる。よって
\[
e\ge T=b_k+\alpha.
\tag{E-WALL}
\]
従って `K:=e-α` と置けば `K≥b_k`。

この節の結論は、WEAK-ROOT の仮定だけを満たす**どの ROOT** にも適用できる。元の paired port の係数 `X,H,Z` への由来は不要である。

### P5.3.4 有限の ROOT 正規化 — `b_k≤K<ρ_k`

前節から `K=e-α≥b_k`。もし `K≥ρ_k` なら HCR の `ρ_k n_k=b_i n_i+a_j n_j` を使い、同じ等式を
\[
m=-d'n_i+S'n_j+e'n_k,
\quad d'=d-b_i,\ S'=S+a_j,\ e'=e-\rho_k
\tag{ROOT-STEP}
\]
と書く。`e'=K-ρ_k+α≥α`、`S'≥1`。

もし `d'≤0` なら右辺は係数wise 非負で、しかも `S'≥1`。従って `m≥n_j` となり multiplicity に矛盾する。

従って生き残る場合は `d'>0` であり
\[
1\le d'\le a_i-1,\quad S'\ge1,\quad e'\ge\alpha.
\]
つまり WEAK-ROOT の**全仮定が保存**される。元の `Γ,F,m,W,q_L,q_A` は変更せず、LK / LJ も同じ actual returns のまま。P5.3.3を新ROOTに適用して
\[
S'<R,\qquad e'\ge T,\qquad K':=e'-\alpha\ge b_k
\]
を得る。一方
\[
K'=K-\rho_k<K.
\]
正整数 `K` が厳密に減少するため、この置換は有限回で停止する。途中で矛盾が出なければ、最後は
\[
\boxed{
m=-dn_i+Sn_j+(K+\alpha)n_k,
\quad1\le d\le a_i-1,
\quad1\le S<R,
\quad b_k\le K<\rho_k
}
\tag{NORMALIZED-ROOT}
\]
となる。以後はこの正規化後の変数を `d,S,K` と呼ぶ。

これは「当初の ROOT の K が既に subcritical」と主張するものではない。同じ actual data を保った別の ROOT への、全仮定と正整数測度を明示した有限正規化である。特に `b_i>a_i` は仮定していない。

### P5.3.5 endpoint missing-`j` level は必ず 2 以上

任意の LJ を固定する。`q_L+Pn_i=W` から
\[
F=(\ell-1)m+(P+A)n_i-n_j+Cn_k.
\]
HCR の zero identity を一枚入れると
\[
F=(\ell-1)m+(\beta+A)n_i
 +(\rho_j-1)n_j+(C-b_k)n_k.
\tag{C-CERT}
\]
従って `C≥b_k` は `F∈Γ` を与え、不可能。よって
\[
0\le C\le b_k-1.
\tag{C-CAP}
\]

ここで `ℓ=1` と仮定する。正規化 ROOT を LJ に入れた exact identity は
\[
q_L=(A-d)n_i+(S-1)n_j+(C+K+\alpha)n_k.
\tag{QL-CERT}
\]
もし `A≥d` なら全係数非負で `q_L∈Γ`。従って
\[
0\le A\le d-1.
\tag{A-CAP}
\]

他方、LJ と canonical QL を比較すると、m が完全に消えた pure-H identity
\[
(C+K-b_k+1)n_k
 =(d-A-1)n_i+(R-S)n_j
\tag{PURE-K}
\]
を得る。右側の係数は
\[
d-A-1\ge0,\qquad R-S\ge1.
\]
左側の正整数 `V:=C+K-b_k+1` は
\[
1\le K-b_k+1\le V\le K<\rho_k.
\]
従って `V n_k∈⟨n_i,n_j⟩` かつ `0<V<ρ_k`。これは `ρ_k` の Herzog criticality に反する。

したがって、同じ actual `q_L` の任意の genuine missing-`j` return について
\[
\boxed{\ell\ge2.}
\tag{ENDPOINT-LEVEL-2}
\]

criticality を使ったのは PURE-K のみであり、m-係数は既に完全に消えている。

### P5.3.6 一回の Frobenius absorption

LJ に正規化 ROOT を一回だけ入れ、`q_L+Pn_i=W` を使う：
\[
\boxed{
F=(\ell-2)m+(P+A-d)n_i
 +(S-1)n_j+(C+K+\alpha)n_k.
}
\tag{LEFT-FABS}
\]
各係数は
\[
\ell-2\ge0,\quad
P+A-d\ge\beta+1>0,\quad
S-1\ge0,\quad
C+K+\alpha>0.
\]
従って LEFT-FABS は `F` 自身の genuine factorization であり、`F∈Γ`。矛盾。

よってstrong-leftのweak-root配置は存在しない。

## P5.4 — PFREEの符号を先に確定する

PFREE_iのcentral kernelから \(\eta=\nu-b_k\)、
\[
A_0=Y+\lambda+1,\ B_0=H_0+1,\ C_0=T-K_0-1,
\]
\[
D_0=P-Y-1>0,\ E_0=H_0+b_j+1,\ F_0=K_0+\eta+1
\]
と置く。同じmの二つのexact identitiesは
\[
m=A_0n_i+B_0n_j-C_0n_k=-D_0n_i+E_0n_j+F_0n_k.
\tag{P5-M}
\]
\(A_0+D_0=\rho_i,E_0-B_0=b_j,C_0+F_0=a_k\)。P5-Mの左表示をM+、右表示をM−と呼ぶ。
以下でF₀≤0を排除する。この場合C₀≥a_k、T=C₀+K₀+1≥a_k+1かつT≥b_k+1。
### P5.4.2 同じ右 singleton の二つの genuine returns

PF 性と missing directions により

\[
q_R+n_i=s m+U n_j+V n_k,
\qquad s\ge1,\ U,V\ge0,
\tag{RIGHT-I}
\]

\[
q_R+n_j=r m+X n_i+Z n_k,
\qquad r\ge1,\ X,Z\ge0.
\tag{RIGHT-J}
\]

各 missing coordinate が正なら同じ factorization から一個除いて q_R∈Γ。m-level がゼロなら missing direction の定義に反する。従ってこれらの actuality と正の levels は明示的に保証される。

### P5.4.3 r≥2 または s≥2 は一回の F 吸収

RIGHT-J に一個の M+ を入れ、q_R+Tn_k=W に戻すと

\[
F=(r-2)m+(X+A_0)n_i+H_0n_j+(T+Z-C_0)n_k.
\tag{J-FABS}
\]

r≥2 のとき全係数非負。特に T+Z−C₀=K₀+1+Z≥1。

同様に RIGHT-I から

\[
F=(s-2)m+(A_0-1)n_i+(U+H_0+1)n_j+(T+V-C_0)n_k.
\tag{I-FABS}
\]

s≥2 のとき A₀−1≥0、T+V−C₀=K₀+1+V≥1、他も非負。

従って、反例に残るなら

\[
r=s=1.
\tag{UNIT}
\]

### P5.4.4 二つの endpoint caps

RIGHT-I と c_R=Tn_k から

\[
F=(s-1)m-n_i+Un_j+(T+V)n_k.
\]

zero identity ρ_i n_i−b_j n_j−a_k n_k=0 を一回加えると

\[
F=(s-1)m+(\rho_i-1)n_i+(U-b_j)n_j+(T+V-a_k)n_k.
\tag{U-CERT}
\]

T≥a_k により、U≥b_j なら全係数非負。従って

\[
0\le U\le b_j-1.
\tag{U-CAP}
\]

RIGHT-J について同様に R_j を completed repair として使うと

\[
F=(r-1)m+(X-a_i)n_i+(\rho_j-1)n_j+(T+Z-b_k)n_k.
\tag{X-CERT}
\]

T≥b_k により

\[
0\le X\le a_i-1.
\tag{X-CAP}
\]

ここでは強い T-CAPS のうち非厳密不等式だけで十分。

### P5.4.5 等しい unit levels は pure-H criticality に反する

r=s=1 の二 return の m を完全に消すと

\[
(X+1)n_i=(U+1)n_j+(V-Z)n_k.
\tag{UNIT-DIFF}
\]

- V≥Z：右辺は非負かつ正。一方 0<X+1≤a_i<ρ_i なので i-criticality contradiction。
- V<Z：式を `(U+1)n_j=(X+1)n_i+(Z−V)n_k` と書く。一方 0<U+1≤b_j<ρ_j なので j-criticality contradiction。

これで全場合が消える。

\[
\boxed{\mathrm{PFREE}_i\cap\{F_0\le0\}=\varnothing.}
\]

## P5.5 — PFREEの二return吸収とlevel-one固定形

以後F₀≥1が証明済みである。同じ左singletonのreturnを
\[
q_L+n_j=\ell m+A n_i+C n_k,\quad\ell\ge1,\ A,C\ge0
\]
と取る。c_L=Pn_iを足しHCRを一度比較した
\[
F=(\ell-1)m+(\beta+A)n_i+(\rho_j-1)n_j+(C-b_k)n_k
\]
からC≤b_k−1。またM−の一回代入で
\[
q_L=(\ell-1)m+(A-D_0)n_i+(E_0-1)n_j+(C+F_0)n_k
\]
となるためA≤D₀−1。さらに
\[
F=(\ell-2)m+(P+A-D_0)n_i+(E_0-1)n_j+(C+F_0)n_k.
\tag{P5-PFREE-FABS}
\]
\(P+A-D_0=A+Y+1\ge1,E_0-1\ge0,C+F_0\ge1\)。従ってℓ≥2は不可能。

ℓ=1の場合、M+との比較により
\[
P_c n_i=Q_c n_j+K_c n_k,
\quad P_c=A+A_0+1\in[1,\rho_i],
\]
\[
Q_c=R-H_0-1,\quad K_c=2T-K_0-C-2\ge T.
\]
Q_c<0なら \(r_c=-Q_c\in[1,a_j-1]\)。k-criticality後にRkを引いて
\[
(P_c-b_i)n_i=(a_j-r_c)n_j+(K_c-\rho_k)n_k.
\]
P_c≤b_iは正値性に反し、P_c>b_iなら0<P_c−b_i≤a_i<ρ_iでcriticalityに反する。
Q_c≥0ではi-criticalityによりP_c=ρ_i。Riを引いて
\[
(Q_c-b_j)n_j+(K_c-a_k)n_k=0.
\]
Q_c<b_jなら0<b_j−Q_c≤b_j<ρ_jのj-criticality、
Q_c>b_jなら0<a_k−K_c<a_k<ρ_kのk-criticalityに反する。
従ってQ_c=b_j,K_c=a_k、さらに
\[
H_0=R-b_j-1,\quad A=D_0-1,\quad C=T-K_0-\eta-2.
\tag{P5-FIX-J}
\]
この比較にK_c−a_kの一律上限は不要である。

もう一方のactual returnを \(q_L+n_k=Lm+D n_i+B n_j\) とすると
\[
F=(L-2)m+(P+D-D_0)n_i+(B+E_0)n_j+(F_0-1)n_k.
\]
L≥2なら全非負で矛盾。従って残るのは
\[
q_L+n_j=m+A n_i+C n_k,\qquad q_L+n_k=m+D n_i+B n_j,
\quad A,B,C,D\ge0
\tag{P5-DOUBLE-UNIT}
\]
とP5-FIX-Jを同時に満たすdouble-unitだけである。

## P5.6 — double-unit排除

入力はP5.0、P5-M、P5-FIX-J、P5-DOUBLE-UNIT。以下のFIX-JとUNIT-Kは上の二returnを指す。
### P5.6.2 C-capとAの上限

P5.5で既に0≤C≤b_k−1を示した。またA=P−Y−2<P<ρ_iである。

### P5.6.3 二つの unit returns は一点に pin される

(FIX-J),(UNIT-K) の m を消去すると
\[
(D-A)n_i+(B+1)n_j=(C+1)n_k.
\tag{EQ}
\]

D≥A なら右の k-coefficient は 1≤C+1≤b_k<ρ_k で、左は非負かつ正。k-criticality に反する。

従って D<A。すると
\[
(B+1)n_j=(A-D)n_i+(C+1)n_k,
\]
なので B+1≥ρ_j。R_j を一回差し引くと
\[
(B+1-ρ_j)n_j=(A-D-a_i)n_i+(C+1-b_k)n_k.
\tag{EQ-RJ}
\]

x=A−D−a_i と置く。x>0 なら
\[
x n_i=(B+1-ρ_j)n_j+(b_k-C-1)n_k,
\]
右は非負。x<A<ρ_i なので i-criticality contradiction（右ゼロなら x n_i=0 自体が矛盾）。x≤0 なら (EQ-RJ) は左非負、右非正であり、全係数がゼロでなければ成立しない。

従って唯一
\[
\boxed{D=A-a_i,\qquad B=ρ_j-1,\qquad C=b_k-1.}
\tag{PIN}
\]

ここまで criticality は m を完全に消した pure-H relation にだけ用いた。

### P5.6.4 二つの新たな exact roots

(FIX-J) の C と (PIN) を比較すると
\[
T-K_0-η-2=b_k-1
\Longrightarrow
\boxed{α=K_0+η+1=F_0.}
\]

η=ν−b_k より
\[
\boxed{T-ν=α-η=K_0+1≥1,}
\tag{SURPLUS}
\]
および
\[
C_0=T-K_0-1=ν.
\]
従って (M+) は
\[
\boxed{m=A_0n_i+(H_0+1)n_j-νn_k,\qquad A_0>0.}
\tag{ROOT+}
\]

また (UNIT-K) の B=ρ_j−1 を canonical q_L+n_k と比較すると、μ=ρ_j−R≥1 により
\[
\boxed{m=-(D+1)n_i-μn_j+Tn_k.}
\tag{ROOT-T}
\]

これらは同じ m と同じ generators の exact identities である。signed row を actual factorization と呼んでいない。

### P5.6.5 反対側 singleton の missing-j return を取る

q_R∈PF(Γ) かつ j∉SH(q_R) より、genuine return を
\[
q_R+n_j=r m+Xn_i+Zn_k,
\quad r≥1,\quad X,Z≥0
\tag{RIGHT-J}
\]
と取れる。n_j-coordinate があれば n_j を一個除いて q_R∈Γ となるのでゼロ。r=0 は q_R+n_j∈H に反する。

### P5.6.5.1 r≥2 は F の直接 factorization

(RIGHT-J) の一個の m に (ROOT+) を入れ、n_j を一個除いて c_R=Tn_k を加え、W=F+m から一個の m を除く。
\[
\boxed{
F=(r-2)m+(X+A_0)n_i+H_0n_j+(T+Z-ν)n_k.
}
\tag{RIGHT-FABS}
\]
r−2≥0、X+A_0>0、H_0≥0、T+Z−ν≥K_0+1≥1。従って全係数非負で F∈Γ。矛盾。

### P5.6.5.2 r=1 は subcritical pure k/i relation

(ROOT+) を使えば
\[
q_R=(X+A_0)n_i+H_0n_j+(Z-ν)n_k.
\]
Z≥ν なら q_R∈Γ なので
\[
0≤Z≤ν-1.
\tag{RIGHT-Z}
\]

今度は (RIGHT-J),r=1 に (ROOT-T) を入れ、canonical
\[
q_R+n_j=(P-1)n_i+Rn_j-n_k
\]
と比較する：
\[
(P+D-X)n_i+(R+μ)n_j=(T+Z+1)n_k.
\]
R+μ=ρ_j と ρ_jn_j=a_in_i+b_kn_k を代入して
\[
\boxed{(P+D+a_i-X)n_i=(α+Z+1)n_k.}
\tag{LAST}
\]

右係数は
\[
1≤α+Z+1≤α+ν=a_k<ρ_k.
\]
右辺は正なので左係数も正整数。(LAST) は ρ_k 未満の正倍の n_k が n_i の非負倍になることを意味し、k-criticality に反する。

r≥2 と r=1 の全てが矛盾。従って
\[
\boxed{\mathfrak D_i=\varnothing.}
\]
P5-dual を適用して
\[
\boxed{\mathfrak D_k=\varnothing.}
\]

## P5.7 — PATH閉鎖

P5.1は全てのactual central returnsからPAIRまたはPFREEの左右二方向を尽くす。
PAIRはP5.2–P5.3、PFREEはP5.4の符号確定後P5.5–P5.6で排除される。
右向きもP5-dualの全parameter変換によって同じ証明を適用できる。
従ってG4が供給するPATHは存在しない。
