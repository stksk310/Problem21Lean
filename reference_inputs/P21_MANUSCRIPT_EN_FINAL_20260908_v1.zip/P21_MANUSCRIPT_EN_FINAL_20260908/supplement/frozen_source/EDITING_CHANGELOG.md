# 編集変更履歴

2026-09-07。入力：P21_PROOF_EXCAVATION_20260906 (1)(1).zip。
これは採用証明の編集版であり、新規証明探索や全履歴の再監査ではない。

## 1. 数学の採択

主定理のedim=4およびcanonical条件を保持した。新しい結論、補題の仮定の削除、
旧子枝の親scopeへの移植は行っていない。入力台帳のN01–N14（元台帳の採番）、E01/E02を
42個の維持用IDへ対応付けた。各最終結果の採用sourceと監査は10_DEPENDENCY_LEDGER.mdに記載。

## 2. 主な記号整理

| 対象 | 変更 | 理由 |
|---|---|---|
| canonical Apéry集合 | A→𝒜 | arm/係数との衝突回避 |
| PATH endpoint係数 | κ→P、τ→T | Wのcanonical boxに統一 |
| PATH return係数 | H,J→H₀,J₀ | tail半群Hとの混同を解消 |
| PATH PF-FIXのcycle | P,Q,K→P_c,Q_c,K_c | canonical P,R,Tとの衝突回避 |
| U繰返しのscalar | H→H_u | tail半群Hと分離 |
| Euclidean packet | H→H_p、D→𝒟_p、𝒣→𝒨 | 半群、D領域、下降測度を区別 |
| SYMのT、付録のC | 局所記号として保持 | 添字や原式を不必要に大域renameしない |

Euclidean本文の69個のdisplay equationsは、変更した記号を逆変換して空白を除いた比較で
採用sourceと全件一致した。静的係数表の変数順は変更せず、付録A4で対応を示す。

## 3. 本文を実質的に書き直した箇所

- 01：定義、正確なscope、標準外部定理の適用形、証明規律を一箇所へまとめた。
- 02：canonical局所本文の記号を整理し、全Qと選択四行、tailの極小性を明示した。
- 03：採用SYMの数学本文を一つの証明として連結。探索史・旧監査表を外した。
- 04：局所pair geometryの後へM4を挿入。singleton・doubleton・cornerの定義を明文化。
  G4.7.1のR=0でsignedになり得るW表示を「exact表示」と呼び、非負完成後と区別した。
- 05：S117の必要なMSR kernel比較とPAIR吸収を連続した日本語本文へ編集。
  証明済みの完全左右反転表で二方向を統合し、符号未確認のendpoint再生表示を省いた。
  PFREEのF₀符号補完、二return cap、修理済みPF-FIX、直接F吸収、double-unitを順に組み込んだ。
- 06：TYPE II全域の採用二return証明を一つのT6へ編集。分類とのinput対応を明示。
- 07：採用unit-root本文をR7にし、四つのactual PF行と完全色交換を保持。
- 08：CORE→boundary/window→U→D→Euclideanを一章へ接続。
  COREの四つのreturn capで、採用sourceが文章で指示したROOT/HCR置換の最終係数ベクトルを展開した。
  S293の採用部分を日本語化し、未使用のreduced-depth return以降を外した。
  E8の非終端の全仮定保存、正整数測度の厳密下降、終端source-fit、同じWからの最終F表示は全文保持。
- 09：旧五形の歴史的統合を使わず、現行三形とSYM/NONSYMを結合した。

これらは採用済み論証の説明順・記号・明示度の変更であり、数学的な穴を新たに埋める補修は行っていない。

## 4. 重複の統合と退役経路

pure-H整数kernel基底はG4.3に置き、CENTRALではその証明を引用する。
PATHのdouble-unit節でC-capを再証明せずP5.5を参照する。
SQとTYPE IはM4/G4.5に吸収。TYPE IIの旧各枝はT6に吸収。
CHAINの旧nonmatch、HIGH descendants、ORIGINAL POSJ、K1/K2/K3、A1J、
S1 strict、equality endpoint、general mismatch、resonanceの諸段階は維持依存へ戻していない。
MINBOX/COLOR-CAPの長い本文は付録A1/A2へ、正値係数certificateはA3/A4へ移した。

S293 §8のreduced-depth returnはE8へのembeddingに不要なため本文から省いた。
付属検算器にその後の旧恒等式が含まれることは、維持証明がそれらへ依存することを意味しない。

## 5. 検算コードとsource保存

原アーカイブは変更していない。静的係数表とEuclidean verifierはbyte同一。
linear verifierは数学的計算を変更せず、limitationsに残っていた旧「P21 remain OPEN」表示だけを
「検算単独では数学的閉鎖を立証しない」という中立的な説明へ更新した。
この一文の変更を除けば元codeと同じであり、計算を再実行してPASSを確認した。

14件の採用監査本文をAPPENDICES/ADOPTED_AUDITSに原文のまま保存した。
それらの過去時点の判定・内部参照は歴史的監査記録であり、編集版本文の現在の依存を上書きしない。
入力台帳のsnapshotとsource hashを別に保存した。

## 6. 最終版の構造

00–10の章、数学付録A1–A4、全静的係数表、検算器、採用監査、機械可読台帳を含む。
単一通読版P21_MAINTAINED_PROOF_MASTER.mdは01–09と数学付録の連結表示であり、
別系統の証明本文ではない。維持時は章ファイルを編集して通読版を再生成する。

完成判定と実施した点検の範囲はEDITING_AUDIT_REPORT.mdに記録する。
