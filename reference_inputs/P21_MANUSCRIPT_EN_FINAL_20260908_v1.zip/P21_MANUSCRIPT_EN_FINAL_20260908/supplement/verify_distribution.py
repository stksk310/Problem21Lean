#!/usr/bin/env python3
"""Non-mutating distribution verification wrapper for the P21 English final freeze.

Runs the two unchanged symbolic verifiers in temporary copies, so the canonical
package and its SHA-256 manifest are not modified by normal verification.
"""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGETS = [
    ("D-linear", ROOT / "supplement" / "APPENDICES" / "LINEAR", "verify_D_linear.py"),
    ("Euclidean", ROOT / "supplement" / "APPENDICES" / "EUCLIDEAN", "verify_euclidean_closure.py"),
]


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="p21-final-verify-") as td:
        temp_root = Path(td)
        for label, source_dir, script in TARGETS:
            copied = temp_root / source_dir.name
            shutil.copytree(source_dir, copied)
            proc = subprocess.run(
                ["python3", script],
                cwd=copied,
                text=True,
                capture_output=True,
            )
            print(f"[{label}]")
            if proc.stdout:
                print(proc.stdout.rstrip())
            if proc.stderr:
                print(proc.stderr.rstrip())
            if proc.returncode != 0:
                return proc.returncode
    print("[distribution] PASS — canonical package not modified")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
