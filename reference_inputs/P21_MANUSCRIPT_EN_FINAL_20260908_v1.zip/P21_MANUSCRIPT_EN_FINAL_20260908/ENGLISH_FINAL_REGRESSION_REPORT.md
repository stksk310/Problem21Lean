# English final regression report

**Artifact:** `P21-MANUSCRIPT-EN-FINAL-20260908-v1`  
**Regression date:** 2026-09-08

## 1. Mathematical-force regression

```text
Mathematical changes:        0
Translation-force changes:   0

Display math:                791/791
Equation tags:               229/229, exact sequence
Semantic display diff vs EN: 0
Semantic display diff vs JA: 0

changed signs:               0
changed inequalities:        0
changed quantifiers:         0
changed ranges:              0
changed equation tags:       0
```

The semantic comparison normalizes only authorized display-layout wrappers and language inside `\text{}`. The seven EN-06 line breaks therefore do not count as mathematical changes.

## 2. Dependency / scope regression

```text
Maintained dependency nodes:       42/42
Node-ID equality vs Japanese final: PASS
Missing publication anchors:       0
New unresolved dependencies:       0
Duplicate anchors:                 0
Broken internal/local links:       0
CENTRAL EXHAUSTION:                COMPLETE
CHAIN → CENTRAL scope:             PASS
```

The CHAIN handoff table and final integration remain intact; no CHAIN-derived assumption is carried through a Euclidean descent step without the abstract E8 preservation package.

## 3. Symbolic certificates

The original verifier scripts were run unchanged.

```text
D-linear verifier: PASS
  identities:          28/28
  positive monomials:  715
  constant:            c0 = 35

Euclidean verifier: PASS
  identities:          35/35
  positive monomials:  3234
  constant:            c0 = 63
```

Hashes of the verifier scripts, static coefficient tables, and normal verification-result JSON files were unchanged by the direct regression run. `supplement/verify_distribution.py` also reproduced both PASS results in temporary copies, leaving the canonical package untouched.

## 4. Boundary-regression preservation

The already-audited boundary statements were not reproved; source-preservation checks confirmed that the English final edits did not damage them:

```text
d=1                  preserved (draft 2 → final 2 source occurrences)
q_0=2                preserved (draft 6 → final 6)
C=alpha              preserved (draft 19 → final 19 under normalized spelling)
w=0                  preserved (draft 3 → final 3)
Delta_0=1            preserved (draft 3 → final 3 under normalized spelling)
g=0                  preserved (draft 4 → final 4)
alpha=0              preserved (Unicode-aware source count 5 → 5)
```

## 5. Markdown render safety

```text
§5 reader-facing mathematical code spans: 0
§9 remaining code spans:                  2, both genuine code terminology
malformed H_u/eta fraction source:        0
accidental ](Q-2) mathematical links:     0
```

A generic GFM/Pandoc render completed with **0 stderr output**, **0 `href="Q-2"` collisions**, and **0 malformed-math instances**.

## 6. Clean manuscript build

A clean XeLaTeX/BibTeXu build completed in the final-freeze source tree.

```text
PDF pages:              98
build errors:           0
undefined references:   0
undefined citations:    0
broken links:           0
duplicate anchors:      0
missing glyphs:         0
overfull boxes:         0
MATH-RESIZE events:     0
underfull boxes:        2 (non-severe, Appendix D reproducibility-path paragraph)
```

The two underfull boxes reproduce the already-audited harmless Appendix D line-breaking warnings; they do not clip or alter content.

## 7. PDF visual verification

The full 98-page PDF was rendered to page images for verification. Visual spot checks included the title page, table of contents, references, and every EN-06 target display:

- CROSS-LAYER
- P5-PAIR
- NORMALIZED-ROOT
- P5-DOUBLE-UNIT
- HRJ
- POS-COEFF
- TERMINAL-SUB

No clipping, overlap, broken glyph, tag displacement, or unreadable auto-shrink was observed. The temporary render images were removed from the deliverable after inspection.

## 8. Final integrity gates

```text
Unauthorized mathematical diff: 0
Manifest:                       PASS
ZIP integrity:                  PASS
```

## Final verdict

```text
Mathematical changes: 0
Translation-force changes: 0

FATAL outstanding: 0
MATERIAL outstanding: 0
MINOR-PROOF outstanding: 0
TRANSLATION-RISK outstanding: 0

Display math: 791/791
Dependency nodes: 42/42
D-linear verifier: PASS
Euclidean verifier: PASS
Undefined refs: 0
Undefined cites: 0
Broken links: 0
Duplicate anchors: 0
Missing glyphs: 0
Overfull boxes: 0
Unauthorized mathematical diff: 0
Manifest: PASS
ZIP integrity: PASS
```
