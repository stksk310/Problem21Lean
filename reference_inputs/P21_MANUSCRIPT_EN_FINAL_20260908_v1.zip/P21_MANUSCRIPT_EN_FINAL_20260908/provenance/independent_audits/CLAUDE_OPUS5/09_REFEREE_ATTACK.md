# 09 — HOSTILE REFEREE ATTACK

Acting as a competent, unsympathetic referee reading the English only.
22 objections. Classification: **VALID** / **ANSWERED CLEARLY** /
**ANSWERED BUT HARD TO FIND** / **FALSE ALARM**.

---

**R-01. "Is the canonical hypothesis visible enough, or is this being sold as an
unconditional type bound?"**
→ **ANSWERED CLEARLY.** The hypothesis is in the title, the first sentence of the
abstract, §1 ¶2, a boxed display tagged (CANONICAL) in T1, the sentence
"Throughout the paper, the canonical condition displayed above is used at every
stage of the proof", §2's opening, §3's (CAN), §4's G4.1, and §11's I9. No
sentence anywhere reads as unconditional.

**R-02. "Why is the terminal classification exhaustive rather than a list of
shapes you happened to find?"**
→ **ANSWERED CLEARLY.** G4.9 partitions on (s,c,a) with s+c+a=4 and closes every
cell (see file 04 §4.2). The English says "every actual four-row nonsymmetric
counterexample reduces **exhaustively**".

**R-03. "Where did SQ and Type I go? Earlier work in this area distinguishes
them."**
→ **ANSWERED BUT HARD TO FIND.** Both exclusions are present — SQ is EN G4.5.2,
Type I is EN G4.5.3 — but the names were dropped in the Japanese final and the
English inherited that. The sentence "the already excluded intermediate
candidate" (§4 line 667) has no antecedent. **This is the single best objection a
referee can raise against the English.** Repair in file 01, EN-04. No mathematics
is missing.

**R-04. "Is the CHAIN→CENTRAL scope preserved, or do D-specific conditions leak
into the abstract theorem?"**
→ **ANSWERED CLEARLY.** Three independent statements forbid the leak (§10 opening,
§10 E8, §9 handoff preamble), and E8.2.1's hypothesis list demonstrably contains
no ROOT, no d/S/C, no first point, no q₀, no N.

**R-05. "Is the Euclidean descent on the same semigroup, or have you silently
moved to a different one?"**
→ **ANSWERED CLEARLY.** COLOR sets m′=m, F′=F, W′=W and only renames generators.
E8.6.3 adds: "The element W retains not only the same value but the same
canonical face after renaming," and E8.6.4 closes "Since color exchange only
renames generators, this is the assertion F∈Γ in the original Γ."

**R-06. "Does colour reversal really preserve all assumptions, or does some
asymmetric quantity keep its old meaning?"**
→ **ANSWERED CLEARLY.** Every invocation carries or points to a full package (file
06 §6.3). §7 C8.1.3 explicitly re-verifies C≥α+1 before reversal and S′≥g′+1,
C′≥α′ after; Appendix B A1.8 transforms the asymmetric arm box p_i≤a_i−1 to
p_i′≤b_i′−1; §10 has a dedicated preservation table.

**R-07. "Your coefficient tables are finite sampling dressed up as proof."**
→ **FALSE ALARM.** Verified from the verifier source: all identities are
`sympy.expand(...) == 0` on free symbols; the certificates are complete
coefficient expansions in shifted nonnegative variables; positivity follows from
all-coefficients-≥0 plus a positive constant, which is a statement over the whole
orthant. No numeric substitution occurs anywhere. The manuscript says exactly
this in three places, and the code's own docstring says "No finite search over
semigroup parameters is used as proof."

**R-08. "Why is the tail gcd one? You use m in a relation among the n's."**
→ **ANSWERED CLEARLY.** C2.4: m=(q+m)+(W−q)−W ∈ ℤH, so d=gcd(n₁,n₂,n₃) divides m,
and gcd(m,n₁,n₂,n₃)=1 forces d=1. The English pre-empts the obvious follow-up:
"The signed equality above is used only in the group ℤH; it is not called a
nonnegative factorization." Repeated at §11.

**R-09. "Where is actualness established? You keep adding and removing packets."**
→ **ANSWERED CLEARLY.** §2's discipline paragraph, plus per-site nonnegativity
statements at every conclusion of the form F∈Γ (file 06 §6.1 tabulates them), plus
explicit signed-intermediate flags at α=0, g=0, R=0, C>α, and the (·)_+ rewrite in
E8.3.

**R-10. "What happens at w=0, q₀=2, C=α, Δ₀=1?"**
→ **ANSWERED CLEARLY** for all four. w=0 forces the terminal condition (E8.5);
q₀=2 is the surviving 𝒟 branch and is where the whole linear analysis lives;
C=α has three dedicated subsections and a boxed CLOSED; Δ₀=1 vs Δ₀≥2 is
addressed three separate times.

**R-11. "α=0 and g=0 break your representations of W — you write a −1
coefficient."**
→ **ANSWERED CLEARLY.** Both are flagged in bold as signed intermediates, and both
final rows are repaired: ABS+ gives α+C−1≥0 from C≥1; ABS− gives g+Δ−1≥0 from
Δ≥1. §4 G4.5 states outright "We do not assume strict positivity of g or α; the
boundary cases g=0 and α=0 are included."

**R-12. "You apply Herzog criticality to a relation containing m."**
→ **FALSE ALARM.** Every application was located; all are in pure-H relations, and
the English states the m-elimination locally at ten separate risk points
(file 06 §6.2).

**R-13. "You assume factorizations are unique."**
→ **FALSE ALARM.** Only *critical-box* uniqueness (G4.3) is ever used, and the
English disclaims global uniqueness four times, including in G4.8 where uniqueness
of W's factorization is derived rather than assumed.

**R-14. "KEY asserts D(c)=SH(q), which needs a matching theorem."**
→ **FALSE ALARM.** C2.3 states ∅≠D(c)⊆SH(q) and then, in bold, "**Equality is not
asserted.** No Hall-type existence theorem, factorization uniqueness, or generic
connectivity is needed."

**R-15. "Your extremal choices (maximal i-coordinate, minimal m-level) may not
exist."**
→ **ANSWERED CLEARLY.** R7.2: "Because all generators are positive, this
factorization set is finite and nonempty, so the maximum exists explicitly."
M4.2: "These are explicit minima of nonempty subsets of the positive integers."
Appendix B A1.2: "The choice set is nonempty and the minimum exists by
well-ordering." §2 promises this globally.

**R-16. "The descent might not terminate; 'the Euclidean process terminates' is
not a proof."**
→ **FALSE ALARM.** The manuscript never says that. It gives 𝓜=E+χ, declares it a
positive integer, and proves 𝓜−𝓜′=(e−1)(H_p+θ)+ρ+κ>0 in closed form, with e≥1,
ρ≥R≥1, κ≥1.

**R-17. "You evaluate Φ at P=B+νA and a=fB+r. Do those points correspond to
actual semigroups?"**
→ **ANSWERED CLEARLY.** E8.4.3: "Nor do we assume that the threshold P=B+νA itself
determines an actual semigroup. Only polynomial evaluation and (MONOTONE) are
used." §9 C8.4.6: "The threshold a_* is an evaluation point of the polynomial."
Appendix D repeats it: "Both evaluation points are algebraic thresholds."

**R-18. "You set the cross-product scale σ=1 without justification."**
→ **FALSE ALARM.** Stated four times: "We do not assume σ=1" (C8.2.8, C8.3.3.1,
C8.4.2, E8.4.2), and C8.3.3.1 adds "nor any additional gcd assumption."

**R-19. "Selecting four rows tacitly assumes |Q|=4, so your conclusion |Q|≤3 is
circular."**
→ **ANSWERED CLEARLY.** §2: "Selecting four rows does not mean that the total
number of elements of Q is fixed to be four." §11: "This classification does not
assume that the full set Q has exactly four elements." The one place a conclusion
about all of Q appears (G4.8, |Q|=3) is flagged separately in §11.

**R-20. "White's theorem is doing hidden work — how much of the empty-tetrahedron
machinery is external?"**
→ **ANSWERED CLEARLY.** §2 ext-STD_WHITE fixes the exact form used and states "The
application to the relative lattice, the partition of the vertices into two
pairs, and the subsequent coefficient comparisons are all proved in this paper."
Appendix B A1.4 repeats: "The only result of White used here is the standard
theorem that an empty lattice tetrahedron has lattice width one… The quotient,
height, and companion constructions below are proved within the present
argument."

**R-21. "You cite theorem numbers in 1970s originals you cannot have checked."**
→ **ANSWERED CLEARLY.** §2: "We do not assert unverified theorem numbers in the
historical originals." Citations point to *supporting* references with precise
locations (García-Sánchez–Martín Cruz §3.2 Thm 6; Nari–Numata–Watanabe §1 (1.1),
§2 (2.1.1), Props 2.1–2.2; Khan–Rogers §1 Thms 3–4) while Herzog, Delorme and
White are cited without asserted numbers. Bibliography: 10 entries, 10 cited,
0 undefined citations.

**R-22. "A corner with three opposite-colour arms — why isn't THREE-ARM alone
enough, and why do you invoke a second lemma?"**
→ **ANSWERED BUT HARD TO FIND.** G4.4 flags it forward ("A corner with three arms
of the opposite color and no singleton still requires the separate COLOR-CAP
argument below"), and Prop B.1's second assertion supplies COLOR-CAP ≤ 2. But
G4.9 invokes "Proposition B.1" as a unit without saying which half does the work.
One clause fixes it (file 08, TOO TERSE).

---

## Tally

| Classification | Count | Objections |
|---|---:|---|
| **VALID** (a real defect in the English) | **0** | — |
| ANSWERED CLEARLY | 16 | R-01, 02, 04, 05, 06, 08, 09, 10, 11, 15, 17, 19, 20, 21 (+R-07, R-12 arguably) |
| ANSWERED BUT HARD TO FIND | 2 | **R-03**, **R-22** |
| FALSE ALARM | 6 | R-07, 12, 13, 14, 16, 18 |

**No objection reaches VALID.** The two "hard to find" items are both pointer/
antecedent problems in §4 and are fixed by one sentence each; neither is a
mathematical gap. The six false alarms are all pre-empted by explicit disclaimers
already in the English — which is the clearest evidence that the manuscript was
written with a hostile reader in mind.
