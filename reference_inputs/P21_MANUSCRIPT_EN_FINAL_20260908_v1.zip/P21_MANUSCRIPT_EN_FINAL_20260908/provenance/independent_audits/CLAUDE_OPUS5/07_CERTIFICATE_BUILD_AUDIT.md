# 07 — POSITIVITY CERTIFICATES, BUILD, PACKAGE INTEGRITY

## 7.1 Verifiers run

Executed exactly as Appendix D documents, from the package root:

```bash
python3 supplement/APPENDICES/LINEAR/verify_D_linear.py
python3 supplement/APPENDICES/EUCLIDEAN/verify_euclidean_closure.py
```

```
LINEAR    {"status":"PASS","identities":28,"positive_monomials":715,"constant":35}
EUCLIDEAN {"status":"PASS","identities":35,"positive_monomials":3234,"constant":63}
```

$$\boxed{28/28,\;715,\;c_0=35}\qquad\boxed{35/35,\;3234,\;c_0=63}$$

Both match the expected values exactly. Environment: Python 3, SymPy 1.14.0.
The commands also run correctly from inside each certificate directory.

## 7.2 Independent inspection of the coefficient tables

Rather than trusting the verifiers' own PASS, the JSON tables were scanned
directly:

| Table | Monomials | Negative coefficients | Constant | Total degree | Variables |
|---|---:|---:|---:|---:|---:|
| `EUCLIDEAN/TERMINAL_POSITIVITY_COEFFICIENTS.json` | **3234** | **0** | **63** | 7 | 16 |
| `LINEAR/I_FIT_POSITIVE_COEFFICIENTS.json` | **715** | **0** | **35** | 7 | 13 |

Minimum coefficient in the Euclidean table is 1. Both files exist at exactly the
paths the manuscript cites (§9 C8.4.6 and §10 E8.4.3), and both paths resolve.

## 7.3 Are these symbolic all-parameter certificates or finite numerical checks?

**The English description is accurate.** Verified by reading both verifiers.

Evidence for *symbolic*:

- Every identity is checked as `s.expand(expr)` compared to exact zero, on
  `sympy.symbols`, via the helper `zero(name, expression)` which raises on a
  nonzero residual. No numeric substitution anywhere.
- The positivity certificate is produced by `sympy.Poly(...)` expansion in
  shifted symbols and compared term-by-term with the stored table; positivity is
  concluded from *all coefficients ≥ 0 plus a positive constant*, which is a
  statement over the whole nonnegative orthant.
- The stored table is **read, not written**, in normal operation: writing is
  gated behind `--write-certificate`, and the manuscript says so ("In ordinary
  use they read the existing tables and do not regenerate them").
- The Euclidean verifier's own docstring: *"This is not a proof-assistant
  formalization… No finite search over semigroup parameters is used as proof.
  Normal execution checks, rather than creates, the coefficient table."*
- Its `limitations` block, written into `verification_result.json`, includes
  *"No finite parameter search is used as a proof."*

Evidence that the **domain** matches (ORDER), as the manuscript claims:

```python
subs = {p:s0+2+p0, q:t0+1+q0, a:s0+1, b:t0+1, r:r0,
        de:d0+1, be:b0+1, aj:aj0+1, g:g0+1, al:al0+1, bk:bk0+1,
        nu:nu0+2, h:h0+1, z:z0, x:x0, w:w0}
```

i.e. p = s+1+p₀ ≥ s+1 and q = t+q₀ ≥ t — **exactly (ORDER)** — with r ≥ 0,
δ,β,a_j,g,α,b_k ≥ 1, ν ≥ 2, h ≥ 1, z,x,w ≥ 0. And θ=h+z with h ≥ 1 gives z < θ
automatically. The expansion imposes **no** determinant constraint, matching
E8.4.3's claim; the det-1 identity appears only in the three checks that carry an
explicit `(det−1)` correction term.

Corresponding check for the LINEAR table: threshold `a_* = f(kb+c)+r = fB+r`,
matching §9 C8.4.6 exactly, with χ substituted as `bk+al+1+eps` — i.e. χ ≥ T+1,
which is the 𝒟-region condition χ>T. ✔

## 7.4 Appendix D reproducibility spec — sufficient?

**Yes.** Appendix D gives, for each certificate: the defining expression written
out in full, the substitution list, the evaluation point, the variable order, and
a JSON-key → shifted-variable table. Cross-checked against the code:

| Appendix D claim | Verifier reality |
|---|---|
| LINEAR variable order f,r,δ,β,g,υ,α,w,θ,ε,k,a_j,b_k | `variables=[f,r,de,be,g,u,al,w,v,eps,k,aj,bk]` ✔ |
| "f,delta,beta,g,alpha,theta,k,a_j,b_k … shifted down by one; r,u,w,eps unchanged" | `shifted = Pstar.subs({v:v+1 for v in [f,de,be,g,al,v,k,aj,bk]})` ✔ |
| `u` denotes υ, `eps` denotes ε | JSON `interpretation` field says the same ✔ |
| EUCLIDEAN order p0,q0,s0,t0,r0,delta0,beta0,aj0,g0,alpha0,bk0,nu0,h0,z0,x0,w0 | identical list in the code ✔ |
| `p0` means p−s−1, `q0` means q−t, `nu0` means ν−2 | matches `subs` above ✔ |
| Φ(a)=−d𝓘+S𝒥+C𝒦−𝒥 for the first table | matches `m0 - J0` with `cross(...)` ✔ |
| Φ(P)=(EA+θB)ρ_k−a_j(χA+H_pB)−(θχ−EH_p)(P−δ)−[(P−δ)ρ_j+(P−β)a_j] for the second | matches `mh - KK` ✔ |

A reader with only Appendix D and SymPy can rebuild both polynomials. The
appendix also warns correctly that verification regenerates
`verification_result.json`, so a distribution master should be checked on a
working copy — which is exactly the right mitigation for issue EN-08.

Appendix D's honesty is worth recording: *"Logically, the proof uses the finite
identities and their complete coefficient tables specified here; a program's
success message is not taken as an axiom."*

## 7.5 LaTeX regeneration and independent build

**Step 1 — regenerate .tex from .md.**

```
python3 supplement/typeset_english.py
→ "English LaTeX files and reading copy written: 15 sections/appendices; 232 unique anchors"
```

`P21_MANUSCRIPT_EN.tex` came back **byte-identical**. All 15 section/appendix
`.tex` files are identical after stripping a Pandoc-version-dependent
`\hypertarget{…}{%` wrapper (this container has pandoc 3.1.3; the package was
built with 3.1.11.1). Residual difference across the whole manuscript after that
normalisation: **3 lines**, all the same wrapper on Proposition B.1's environment
in `appendices/B.tex`. **The typesetting pipeline is reproducible.**

**Step 2 — independent three-pass XeLaTeX build** on the shipped `.tex` files.
The container lacks the TeX Gyre families under the names `fontspec` expects, so
`\setmainfont`/`\setsansfont` were repointed at the same OTF files already on
disk (`texgyretermes-*.otf`, `texgyreheros-*.otf`). No other change.

| Check | Reported | Independently measured |
|---|---:|---:|
| LaTeX errors | 0 | **0** |
| Undefined references | 0 | **0** |
| Undefined citations | 0 | **0** |
| Missing glyphs | 0 | **0** |
| Overfull boxes | 0 | **0** |
| Underfull boxes | 2 | **2** |
| Multiply-defined labels | 0 (implied) | **0** |
| Duplicate hyperref destinations | 0 | **0** |
| Duplicate Markdown anchors | 0 | **0** (232 unique) |
| Broken internal links | 0 | **0** |
| Broken local-file links | 0 | **0** |
| **Physical pages** | **98** | **98** |

The two underfull hboxes are both in Appendix D's reproducibility paragraph,
caused by the long monospace path `supplement/APPENDICES/LINEAR/` inside
justified text. Harmless, exactly as the build report says.

**Page geometry.** Measured from the shipped PDF's text layer:

| Claimed | Measured | ✔ |
|---|---|---|
| front matter 2 pp | title p.1, contents p.2; §1 starts p.3 | ✔ |
| main text §1–§11, 73 pp (3–75) | §1 p.3 … §11 p.74; Appendix A starts p.76 ⟹ main ends p.75 | ✔ |
| Appendices A–D, 22 pp (76–97) | A p.76, B p.79, C p.93, D p.94; References p.98 ⟹ appendices end p.97 | ✔ |
| references 1 p (98) | p.98 | ✔ |

Rebuilt PDF: 465 782 bytes vs shipped 465 961 bytes — a 179-byte delta fully
explained by the substituted font resource names. Text layers differ only in
horizontal positioning from the font-metric substitution.

**New finding not in the build report (EN-06).** The log records **7
`MATH-RESIZE` events** — displays auto-shrunk by the `\FitMath` macro:

| Tag | natural width | available | approx. scale |
|---|---:|---:|---:|
| NORMALIZED-ROOT | 378.05 pt | 302.28 pt | **80 %** |
| P5-PAIR | 443.13 pt | 393.48 pt | 89 % |
| P5-DOUBLE-UNIT | 363.05 pt | 320.07 pt | 88 % |
| TERMINAL-SUB | 383.31 pt | 331.69 pt | 87 % |
| CROSS-LAYER | 390.34 pt | 343.37 pt | 88 % |
| HRJ | 435.07 pt | 422.26 pt | 97 % |
| POS-COEFF | 372.47 pt | 366.41 pt | 98 % |

NORMALIZED-ROOT at 80 % renders an 11 pt display at roughly 8.8 pt. It is a
boxed load-bearing conclusion (P5.3.4). Content is unaffected — `\resizebox`
changes size only — but this is worth fixing before submission.

## 7.6 Package integrity

| Package | Files in manifest | Verified |
|---|---:|---:|
| `P21_MANUSCRIPT_EN_20260908` | 178 | **178 OK, 0 failures** |
| `P21_MANUSCRIPT_JA_FINAL_20260908` | 194 | **194 OK, 0 failures** |
| `P21_FINAL_FROZEN_VERIFICATION_EDITION_20260907` | 69 | **69 OK, 0 failures** |

ZIP extraction clean for all three; re-verification after extraction clean. The
English manifest covers every package file except itself, including the nested
`supplement/ja_source_snapshot/`, `supplement/frozen_source/` and
`supplement/english_build/` trees retained for provenance — matching the
README/changelog description. Source files used by the manuscript match those
described. ✔

One packaging note (EN-08): running the documented Appendix D commands rewrites
`verification_result.json` inside `supplement/APPENDICES/`, which then breaks
manifest verification on that copy. Appendix D anticipates this and instructs the
reader to work on a copy. Correct mitigation; recorded for completeness.
