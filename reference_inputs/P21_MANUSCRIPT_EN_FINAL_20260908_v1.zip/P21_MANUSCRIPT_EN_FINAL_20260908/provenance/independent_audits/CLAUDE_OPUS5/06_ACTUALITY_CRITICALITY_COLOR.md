# 06 — ACTUALITY, CRITICALITY, COLOUR REVERSAL, BOUNDARY STRESS TEST

## 6.1 Actual vs signed language — HIGH PRIORITY

Vocabulary census over §1–§11 and Appendices A–D:

```
genuine          48        signed            17        coefficientwise  13
actual          111        completed         13        packet           73
nonnegative     112        representation    72        factorization    79
replace          18        subtract          15        remove           11
```

**The discipline is declared once, globally, in §2:**

> "An actual factorization is a representation by the generators with all
> coefficients nonnegative integers. A signed equality or a completed zero
> identity is not, by itself, an actual factorization. Whenever the final
> contradiction uses a coefficient vector, its nonnegativity is stated
> explicitly. Herzog criticality is applied only after the coefficient of m has
> been completely eliminated, so that the relation lies entirely in H. A support
> replacement is performed only when the source occurs coefficientwise within an
> explicitly identified factorization of the same actual element. Every extremal
> choice used below is accompanied by the underlying finite set or well-ordering
> argument."

That paragraph answers, in advance, four of the standard referee attacks.

**Every place the proof concludes F∈Γ or that a PF gap lies in Γ, the English
supports coefficientwise nonnegativity.** Sampled and verified at every such
conclusion:

| Site | Nonnegativity statement in the English |
|---|---|
| §4 ABS+ | "Every coefficient in this final expression is nonnegative… In particular, when α=0, the inequality C≥1 gives α+C−1≥0." |
| §4 ABS− | "Again all coefficients are nonnegative. In particular, when g=0, Δ≥1 gives g+Δ−1≥0." |
| §4 FI/CAP | "removing the resulting copy of n_i from the same final representation would give F∈Γ; the condition a_i≥1 supplies that copy" |
| §5 LEFT-FABS | coefficients listed one by one: ℓ−2≥0, P+A−d≥β+1>0, S−1≥0, C+K+α>0 |
| §5 QL-CERT / F-ROOT | each coefficient's sign argued before the conclusion |
| §6 C-CAP/B-CAP | "if C≥b_k all coefficients would be nonnegative and F∈Γ" |
| §6 ABS-L / ABS-R | four-line coefficient list each |
| §7 F-S, F-C, F-D | "then all coefficients are nonnegative: δ+d−1≥0, g−S−1≥0, ρ_k+T−C−1≥T−1≥0" |
| §8 FI-CERT / FJ-CERT | "Every coefficient in the final displayed representations is nonnegative." |
| §9 U-FINAL | "All four coefficients are nonnegative." |
| §9 J-ONLY | "The coefficient of m is positive; the coefficient of n_i is nonnegative by I-FIT; and the coefficient of n_k is nonnegative because 0≤w<χ." |
| §10 FINAL-F / FINAL-EXACT | I-FIT supplies P−1−B−νA≥0; h−1≥0 and x≥0 by construction |
| App B SAME-F | "At a positive state, every u_i≥1, so this is a genuine factorization of the same f_A." |

**Signed intermediates are flagged wherever they occur**, including at the exact
boundary values where a coefficient goes negative:

- §4 WJ: "**If α=0, the k-coefficient is −1, so this is only a signed intermediate
  equality.**"
- §4 WK: "**If g=0, the j-coefficient is −1, so this is only a signed intermediate
  equality.**"
- §4 BA-W: "If R=0, however, this expression is signed. We call only the
  following completed expression actual:" followed by the repaired form.
- §5 P5.6.4: "These are exact identities for the same m and the same generators.
  The signed rows are not called actual factorizations."
- §8 C-FK: "When C>α, this expression cannot itself be called actual."
- §8 PACKET: "**Both sides of this displayed relation have nonnegative
  coefficients.** In particular, we are not misrepresenting the signed FK relation
  as an actual factorization."
- §10 terminal replacement: negative j_*,k_* rewritten via (·)_+ so that "Every
  coefficient on both sides is nonnegative."
- §2 C2.4 and §11 I9: "The signed equality above is used only in the group ℤH; it
  is not called a nonnegative factorization."
- App B A1.8: "No signed intermediate is called actual. A lower companion used for
  contradiction is converted into a genuine factorization only when all three
  coordinates are positive."

**Verdict: the English never turns a signed completed identity into an actual
factorization.** No violation found.

**Support replacement** is likewise always sourced inside a named element: §7
R7.2.1 ("the same actual factorization of h_A contains Pn_i coefficientwise"),
§7 C8.1.5 ("the m-source in EA and EB always contains at least h copies…
the replacement can be made within those same actual factorizations"),
§9 C8.3.4 ("contains coefficientwise t copies of the left side of U-PACKET"),
§10 E8.3 ("The existing face of the SAME W contains the left source
coefficientwise").

## 6.2 Criticality audit

Every application of Herzog criticality was located and checked for the
m-coordinate. **No sentence suggests criticality is applied to a relation
involving m.** The English states the restriction locally at each risk point, not
only globally:

| Location | Statement |
|---|---|
| §2 discipline | "Herzog criticality is applied only after the coefficient of m has been completely eliminated, so that the relation lies entirely in H." |
| §4 M4.2 | "The coefficient of m has been zero throughout; hence the applications of criticality are legitimate." |
| §5 P5.3.5 | "Criticality was used only in PURE-K, after the m-coordinate had been completely eliminated." |
| §5 P5.6.3 | "Up to this point, criticality has been applied only to pure-H relations after m has been completely eliminated." |
| §6 T6.5.1 | "The coefficient of m has been completely eliminated in this argument." |
| §7 C8.1.1 | "Every use of criticality here occurs in a relation with m-coordinate zero." |
| §7 C8.1.2 | "This argument uses multiplicity, not criticality." |
| §8 C8.2.4.1 | "In all coefficient comparisons below, the m-coordinate is eliminated completely before the comparison is made." |
| §9 C8.3.3.2 | "This comparison does not invoke criticality for a signed relation; it is a contradiction between an explicit positive polynomial and strict multiplicity." |
| §9 C8.4.0.1 | "The integer kernel is used below only after the m-coordinate has been eliminated completely." |

The English also fixes the meaning of "critical" locally where E8/CORE restate
it: §7 C8.1.0 — "Here 'critical' means that ρ_r is the least positive multiple of
n_r admitting a nonnegative representation by the other two generators. **No
minimality is assumed for arbitrary signed relations.**" That last sentence is
precisely the guard a referee would demand. ✔

Uniqueness discipline is equally tight: G4.3 proves only *critical-box*
uniqueness and the English says so four separate times ("This lemma uses no
hidden connectivity or global factorization uniqueness"; "No global factorization
uniqueness is assumed here"; "No global uniqueness of the factorization fiber is
needed"; "No uniqueness, return-level minimality, or change of selected support
is used here").

## 6.3 Colour-reversal audit

Every "by symmetry" / "colour reversal" / "dual" / "colour exchange" invocation
was enumerated. Each either **displays** the full parameter package or **points to
a displayed one**, and no asymmetric quantity silently retains its pre-reversal
meaning.

| Site | Package | Asymmetric quantities handled |
|---|---|---|
| §2 (definition) | "Colour reversal is the combination of an odd permutation and the interchange of all a- and b-parameters… These operations leave Γ,F,m,W and the set of actual pseudo-Frobenius elements unchanged." Points forward to P5, R7, E8. | Γ,F,m,W and PF-set declared invariant |
| §5 P5-dual | **Displayed:** i∨,j∨,k∨; (n_i∨,n_j∨,n_k∨); (a_i,b_i),(a_j,b_j),(a_k,b_k); (λ,ν); (α,β); (P,R,T); (q_L,q_A,q_B,q_R) | ladder, arm bounds, singleton status, HCR, and "the new j-coefficient is J₀<H₀; thus the case reduces exactly to the already proved case H₀<J₀" |
| §7 R7.5 | **Displayed:** i′,j′,k′; all six a/b; λ′,δ′,β′,g′,α′; P′,R′,T′,d′,S′,C′; q_A′,q_B′,q_J′,q_K′ | "all four actuality and gap statuses are preserved"; PFIBER with t′=u, u′=t |
| §7 C8.1.3 | **Displayed:** (a_i,b_i)↦(b_i,a_i), (a_j,b_j)↦(b_k,a_k), (a_k,b_k)↦(b_j,a_j) and (δ,β,g,α,R,T,S,C)↦(β,δ,α,g,T,R,C,S) | **Explicitly re-verifies the CORE inequalities after reversal:** "Before reversal, hC<ρ_k and K₀<0 imply 1≤−K₀≤C−α, so C≥α+1. After reversal, S′≥g′+1 still holds and C′=S≥α′. Hence the whole CORE package is preserved." |
| §10 COLOR + EUCLID + M-UPDATE | **Displayed:** generators, m,F,W; all six a/b; δ′,β′,g′,α′,R′,T′,P′,r′; E′,θ′,χ′,H_p′,u′,w′; 𝖬′ | E8.6.1–E8.6.3 verify matrix, sources, level, both packets, domain, 𝓓_p, both RHO, HCR, a_i′/b_i′, and the W-face — plus a dedicated preservation table |
| App B A1.8 | odd/even permutation rule | "The arm box p_i≤a_i−1 is correspondingly carried to p_i′≤b_i′−1" — the asymmetric bound is transformed explicitly |
| App B A2.10.1 | "an odd generator permutation together with the complete simultaneous exchange of a/b and A/B" | "The three actual pseudo-Frobenius elements and their arm bounds are exchanged at the same time" |
| §4 ×3 (lines 136, 524, 667) | **referenced**, not displayed | rely on the §2 definition |
| §4:202, App A ×3 | inline duals spelled out in the same sentence | ✔ |

Appendix A's "By symmetry of T" (§3 GAP-K, App A S3.8) is a different and correct
usage — the symmetry of the *symmetric* semigroup T, i.e. t∉T ⟺ F_T−t∈T. Not a
colour operation; no confusion in the English.

**The three §4 sites that reference rather than display are the only ones a
referee could push on**, and the §2 definition they invoke is complete and
unambiguous.

## 6.4 Boundary stress test

Every boundary the brief names, located in the English and checked:

| Boundary | English treatment | Verdict |
|---|---|---|
| d = 1 | Tail gcd d=gcd(n₁,n₂,n₃)=1 proved in C2.4 and re-proved in I9. Distinct from the ROOT coefficient d, whose range 1≤d≤λ is boxed in ROOT-BOX; d=1 is inside that range and needs no special case. | ✔ covered |
| q₀ = 2 | The surviving 𝒟 case. Reached in C8.4.3 (q₀≥3 closed by HIGH-Q-CLOSED) and refined in C8.4.4 (N≥z+2 closed by NONLINEAR-FIRST-CLOSED), leaving "q₀=2, N=z+1" boxed. Also arises in C8.2.11 for 𝒰 ("λ=d and q₀=2"). | ✔ explicitly the main surviving branch |
| C = α | 19 occurrences. Own subsections C8.2.3.2 (BOUNDARY-WALL), C8.2.7 (SYNC), C8.2.8 (BOUND-MULT), boxed "C=α **CLOSED**". Guarded twice against scope leakage: "This strict-region conclusion is not used when C=α" (§7 SUM-NOTCH) and "The strong caps on e₀ and FK obtained in the strict case are not applied at the boundary C=α" (§8 table). | ✔ closed, scope-guarded |
| w = 0 | §10 E8.5 — "In particular, failure implies w≥1. Therefore, if w=0, the terminal condition necessarily holds." §9 E8.2.3 — "No cases are lost according to whether w=0 or w≥1." | ✔ |
| Δ₀ = 1 | §8 C8.2.8 — "This covers both Δ₀=1 and Δ₀≥2." §8 C8.2.11.1 — "The case z=1 has Δ₀=1, while z≥2 has Δ₀≥2. Both are treated in C8.3." §9 — "No cases are lost according to whether… Δ₀=1 or Δ₀≥2." | ✔ stated three times |
| g = 0 | §4 G4.5 — "We do not assume strict positivity of g or α; the boundary cases g=0 and α=0 are included." §4 M4 — "The proof retains the cases g=0 and α=0." §4 ABS− — "when g=0, Δ≥1 gives g+Δ−1≥0." Note in CHAIN (G4.11.2) g=b_j−μ≥1 by derivation, so g=0 lives only in the matched-pair/M4 layer, exactly where it is handled. | ✔ |
| α = 0 | §4 G4.5, M4, G4.5.1 ("if equality holds and α=0, the complements coincide"), ABS+ ("when α=0, the inequality C≥1 gives α+C−1≥0"), WJ signed-intermediate flag. | ✔ |
| R = 0 | §4 G4.7.1 — "If R=0, however, this expression is signed", with the repaired BA-W. §4 G4.11.4 — "If R=0, then c_{A_k}=βn_i is comparable on the pure ray with c_{S_i}, or is the same row, which is impossible. Hence R≥1." | ✔ |
| Ξ ≤ 0 | §8 C8.2.2 — "If Ξ≤0, then HRJ itself is a nonnegative F-row, and the case is closed. Thus every survivor has Ξ≥1." | ✔ |
| Q = 1 | §8 C8.2.9.2 — separate positivity decomposition A′,B′,D_base with STRICT-K. | ✔ |
| det-1 extremal | §10 ORDER derives p≥s+1, q≥t from det=1 and L>M; LEVEL-SPLIT isolates the extremal L=x=1, M=z+1; "the alternative L=x=1 in LEVEL-SPLIT is impossible on the boundary, because then H₀=−C_j−1<0." | ✔ |
| colour-reversal boundaries | §7 C8.1.3 re-verifies C≥α+1 before reversal and S′≥g′+1, C′≥α′ after. | ✔ |

**Targeted search for English "positive" where the source says merely
"nonnegative": 1 candidate, adjudicated as a false positive and in fact an
improvement** (§4 M4.2, 自然数 → "positive integers" for the return *levels*
L_A,L_B≥1, while the coefficient *vectors* are correctly called nonnegative in
the same sentence). Reverse test (EN "nonnegative" where JA says 正): **0 hits**.

$$\boxed{\text{Boundary stress test: no gap, no strengthened qualifier}}$$
