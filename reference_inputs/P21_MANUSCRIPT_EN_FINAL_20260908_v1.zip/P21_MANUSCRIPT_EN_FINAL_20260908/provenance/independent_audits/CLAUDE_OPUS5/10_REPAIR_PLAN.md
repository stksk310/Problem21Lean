# 10 — EXACT REPAIR PLAN AND FINAL-FREEZE RECOMMENDATION

The English manuscript was **not modified** by this audit, as instructed.
Everything below is a specification.

## Priority 1 — do before the English freeze (2 items, ~30 minutes)

### P1-a — EN-04: supply the missing antecedent in G4.9

`sections/04.md`, the `s=1,a=3` case. Replace:

> Up to cyclic permutation and full color reversal, the already excluded
> intermediate candidate is
> \[ S_i,\quad A_i(λ),\quad B_i(λ),\quad A_k(ν). \]
> It therefore need not be treated as an independent terminal branch.

with:

> Up to cyclic permutation and full color reversal, the remaining candidate
> \[ S_i,\quad A_i(λ),\quad B_i(λ),\quad A_k(ν) \]
> contains a matched pair in direction \(i\) together with the singleton
> \(S_i\), and is therefore already excluded by [G4.5.3](#fr-G4.5.3). It need not
> be treated as an independent terminal branch.

Closes referee objection R-03. **No mathematical change** — G4.5.3 already proves
exactly this.

### P1-b — EN-01: restore math mode to backticked symbols

`sections/05.md` (56 spans), `sections/09.md` (2). Replace each `X` holding a
mathematical symbol with `\(X\)`: `q_L`, `q_L+n_j`, `q_L+n_k`, `n_j`, `n_k`, `m`,
`W`, `F`, `H`, `K`, `d`, `S`, `d'`, `S'`, `e'`, `K'`, `X,H,Z`, `j`, `k`, `ℓ`,
`r`, `s`, `Γ`. Then re-run `python3 supplement/typeset_english.py`.

**Leave `appendices/D.md` alone** where the backticks name JSON keys, file paths,
shell commands or code identifiers (`terms`, `variables`, `coefficient`,
`exponents`, `u`, `eps`, `p0`, `q0`, `f`, `delta`, …) — those are correctly
monospace. Only convert D's spans that denote mathematics rather than code.

Verify afterwards: `grep -c texttt sections/05.tex` should drop to 0.

## Priority 2 — recommended before submission (3 items)

### P2-a — EN-02: fix the malformed `\frac` in the Markdown

`sections/09.md` line 56:

```
-  t:=\left\lfloor\frac H_u\eta\right\rfloor+1\ge1,
+  t:=\left\lfloor\frac{H_u}{\eta}\right\rfloor+1\ge1,
```

The `.tex` and PDF are already correct; this aligns the Markdown artifact. The
same defect exists in the Japanese final and the frozen edition — fix all three
if the sources are kept in sync.

### P2-b — EN-06: eliminate the 7 `\FitMath` auto-shrinks

Break these displays so no `\resizebox` fires, worst first:

| Tag | Location | Current scale |
|---|---|---:|
| NORMALIZED-ROOT | §5 P5.3.4 | 80 % |
| TERMINAL-SUB | §10 E8.4.3 | 87 % |
| P5-DOUBLE-UNIT | §5 P5.5 | 88 % |
| CROSS-LAYER | §3 S3.4 | 88 % |
| P5-PAIR | §5 P5.1 | 89 % |
| HRJ | §8 C8.2.2 | 97 % |
| POS-COEFF | §9 C8.3.3.2 | 98 % |

Use `aligned`/`split` with a line break at a natural comma. NORMALIZED-ROOT is a
boxed load-bearing conclusion and should not render at ~8.8 pt. Confirm by
`grep -c MATH-RESIZE` on the rebuild log → 0.

### P2-c — EN-03: defuse the `[...](...)` Markdown-link collision

`sections/08.md` line 477 (and the mirrored line in `P21_MANUSCRIPT_EN.md`):

```
-  E_a={}&[(L-1)(M-1)-1](Q-2)+L^2(g-1)\\
+  E_a={}&\bigl[(L-1)(M-1)-1\bigr](Q-2)+L^2(g-1)\\
```

Only matters if the `.md` is distributed or rendered by a generic Markdown
engine; the PDF is unaffected. Purely defensive.

## Priority 3 — optional polish (4 items)

- **EN-05** — convert the two "Common setting" blocks (§2 C2, §4 G4.1) from raw
  Unicode to `\(...\)` with `\Gamma`, `n_1`, `\mathcal A`, `\subseteq`; write
  `Q(\Gamma)` rather than `Q` in §2 to match the notation-scope table.
- **EN-07** — optionally restore the Japanese's active verification claim in §2:
  "…and **we have checked** the precise locations in the supporting references
  used here." The current wording is safe and conservative; this is cosmetic.
- **EN-08** — move `supplement/english_build/` under a `provenance/` subtree, or
  mark it non-normative in `00_README.md`.
- **Prose** — the six "too terse" additions in file 08, especially the G4.9
  corner-case clause (R-22) and the one-line reason for `j_*≤R−1` in E8.3.
  Rename §7 to "A unit root and the CORE input package for the chain
  configuration" so that CORE is findable.

## Explicitly NOT recommended

- **No mathematical change anywhere.** Zero repairs in this plan alter a
  hypothesis, a conclusion, an inequality, a quantifier or a proof step.
- **No compression before the English freeze.** The repeated "no uniqueness is
  assumed" and "signed intermediates are not actual" reassurances are what
  neutralise six of the referee objections in file 09. Revisit only after freeze.
- **No page-count reduction.** 98 pages is appropriate for this argument and is
  not a defect.
- **No re-litigation of the mathematics.** This audit checked the English against
  the Japanese and the frozen edition; it did not re-audit the research history,
  per the governing instruction.

## Post-repair regression checklist

```
1. python3 supplement/typeset_english.py            → 15 files, 232 anchors
2. xelatex ×1, bibtex, xelatex ×2
3. grep -c '^!'            P21_MANUSCRIPT_EN.log     → 0
4. grep -c 'Overfull'      P21_MANUSCRIPT_EN.log     → 0
5. grep -c 'undefined'     P21_MANUSCRIPT_EN.log     → 0
6. grep -c 'MATH-RESIZE'   P21_MANUSCRIPT_EN.log     → 0   (after P2-b)
7. grep -c 'texttt'        sections/05.tex           → 0   (after P1-b)
8. page count                                        → 98 (±1 from P2-b reflow)
9. display-math count vs JA                          → 791 = 791, diff 0
10. python3 supplement/APPENDICES/LINEAR/verify_D_linear.py
                                                     → 28, 715, 35
11. python3 supplement/APPENDICES/EUCLIDEAN/verify_euclidean_closure.py
                                                     → 35, 3234, 63
12. regenerate SHA256SUMS.txt; sha256sum -c          → 0 failures
```

Step 9 is the one that matters most: **any repair above must leave the 791
display-math instances byte-identical to the Japanese final.** All of P1 and P2
touch prose, inline spans, or display *layout* only — none touches display-math
content — so 791 = 791 must still hold after the repairs.

---

## FINAL-FREEZE RECOMMENDATION

$$\boxed{\textbf{B — PASS WITH MINOR ENGLISH REPAIRS}}$$

The English manuscript faithfully and professionally presents exactly the frozen
mathematics. **Zero mathematical-force changes.** All required gates pass:
791/791 display math, 42/42 dependency nodes, CENTRAL exhaustion complete,
CHAIN→CENTRAL scope preserved, both symbolic certificates reproducing at
28/28–715–35 and 35/35–3234–63, 98 pages rebuilt independently with 0 errors and
0 undefined references, and all three manifests clean.

Grade **A** was withheld for one reason and one reason only: EN-04, the
antecedent-free "the already excluded intermediate candidate" in G4.9, which a
competent referee will stop on and which is the English manuscript's only
findable soft spot. It is a one-sentence fix.

**Recommendation: apply P1-a and P1-b, re-run the regression checklist, and
freeze.** P2 and P3 can be folded into the pre-submission pass without a second
audit cycle.
