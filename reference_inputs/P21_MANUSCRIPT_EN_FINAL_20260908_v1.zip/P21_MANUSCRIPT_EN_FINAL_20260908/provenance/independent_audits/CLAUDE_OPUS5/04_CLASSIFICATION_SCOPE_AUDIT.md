# 04 — CLASSIFICATION & DEPENDENCY-NODE AUDIT

## 4.1 Dependency nodes — 42/42

Extracted the 42 maintained nodes from the frozen
`APPENDICES/DEPENDENCY_LEDGER.json` and searched the English corpus for each.

```
NODE COUNT in frozen ledger: 42
present in EN:               42/42
present in JA:               42/42
anchor  fr-<id>  in EN:      40/42
anchor  fr-<id>  in JA:      40/42   (identical set)
```

$$\boxed{42/42}$$

The two nodes without an `fr-<id>` anchor are **A1** and **A2** (frozen locations
`APPENDICES/A1_MINBOX.md`, `APPENDICES/A2_COLOR_CAP.md`). In both the Japanese
and the English manuscript these are expanded into their sub-anchors
`fr-A1.1`–`fr-A1.9` and `fr-A2.0`–`fr-A2.10.1` inside Appendix B, and surfaced to
the main text through `#prop-B1`. **The EN and JA anchor sets are identical**, so
this is inherited structure, not an English-conversion loss.

Per-node checks on the load-bearing nodes:

| Node | Hypotheses | Conclusion | References localised | Proof role |
|---|---|---|---|---|
| C2 | unchanged | unchanged | ✔ | canonical layer + KEY + gcd + 4-row selection |
| S3 | unchanged | unchanged | ✔ | symmetric branch |
| G4.1–G4.8 | unchanged | unchanged | ✔ | atlas, caps, kernel, coexistence, 3-singleton |
| M4 | unchanged | unchanged | ✔ | root-free level rigidity → EA/EB, P-FIBER |
| A1, A2 | unchanged | unchanged | ✔ | MINBOX → DPE, surfaced via Prop B.1 |
| G4.9, G4.11.x | unchanged | unchanged | ✔ | exhaustive classification + scalar extraction |
| P5.1–P5.7 | unchanged | unchanged | ✔ | PATH closure |
| T6 | unchanged | unchanged | ✔ | TYPE II closure |
| R7 | unchanged | unchanged | ✔ | CORE-ROOT existence |
| C8.1–C8.5 | unchanged | unchanged | ✔ | CORE → window → 𝒰/𝒟 |
| A3, A4.1, A4.2 | unchanged | unchanged | ✔ | positivity expansions, static certificates |
| E8, E8.2.3 | unchanged | unchanged | ✔ | abstract theorem + initial embedding |
| I9, T1 | unchanged | unchanged | ✔ | assembly and statement |

## 4.2 Nonsymmetric terminal classification — exhaustive, not illustrative

The audit brief asks whether the English wording turns an exhaustive theorem into
a list of possible examples. **It does not.** The English is explicitly
enumerative and closes with:

> "Thus **every** actual four-row nonsymmetric counterexample reduces
> **exhaustively** to PATH, TYPE II, or CHAIN."

G4.9 partitions on (s,c,a) = (#singletons, #corners, #arms) with s+c+a=4:

| Branch | Argument in the English | Closed by |
|---|---|---|
| c ≥ 2 | "There is at most one lower corner with triple support." A higher corner gives F(H)≥F(Γ) against q<F(Γ). | G4.1 |
| c = 1 | G4.4 forbids any singleton, so s=0, a=3. Corner cannot coexist with a same-colour arm (antichain), so all three arms carry the opposite colour; duplicates impossible, so all three directions occur. **Prop B.1** then applies. | G4.4 + Prop B.1 |
| c=0, s=3 | Three singletons force a unique factorisation of W in the critical box, and then any further row gives q=W−c∈H. | G4.8 (⟹ \|Q\|=3) |
| c=0, s=4 | Impossible: no two singletons share a direction (pure-ray comparability), and there are only three directions. | G4.2 |
| c=0, s=2, a=2 | G4.5.1 (matched pair allows a singleton in ≤1 direction), G4.6 (two same-colour arms cannot coexist with two singletons), G4.7.2 (opposite orientation allows ≤1 singleton) ⟹ orientation of G4.7.1 with singletons in i,k. | **= PATH** |
| c=0, s=1, a=3 | Same colour ×3 excluded via G4.6.1; so colour split is 2+1. Matched pair excluded by G4.5.3. Remaining shape reduced by G4.7.2 to S_i,A_i,B_j,A_k. | **= TYPE II** |
| c=0, s=0, a=4 | Three directions, at most one arm per (colour,direction), so some direction carries both A_i and B_i; G4.5.2 caps the extra arms to B_j and A_k. | **= CHAIN** |

The partition is complete: s∈{0,1,2,3,4} and c∈{0,1} are all covered.

**Where SQ / TYPE I went.** The frozen edition states
「SQはG4.5.2、TYPE IはG4.5.3で排除した」 and 「この時点で SQ は直接排除される」.
The Japanese final manuscript removed the project jargon, and the English
faithfully followed. **Mathematically nothing is lost:**

- The **SQ** exclusion is the content of EN G4.5.2 — "Thus the only additional
  arms compatible with a matched pair in direction i are B_j and A_k."
- The **TYPE I** exclusion is EN G4.5.3 — "Thus a matched pair cannot coexist
  with any singleton. This eliminates all configurations containing both a
  matched pair and a singleton."

Both propositions are present, proved and invoked at the right points in G4.9.
What is missing is only the *name*, and one antecedent: the sentence "the already
excluded intermediate candidate" (§4 line 667) never says where the exclusion
happened. Logged as **EN-04, PRESENTATION-RISK**, with a one-sentence repair.
The elimination itself **remains understandable** to a reader who follows the
preceding sentence's citation of G4.5.3.

## 4.3 Proposition B.1 / THREE-ARM / COLOR-CAP

`#prop-B1` exists in both EN and JA, and is cited from EN §4 G4.9 and §11 I9.

> **Proposition B.1.** In the setting of the canonical six-arm classification,
> three actual arms of the same colour do not exist. Moreover, for each colour
> there are at most two actual corner/arm rows.

Its proof text asserts no new content: "The first assertion is exactly THREE-ARM
CLOSED, proved in A1.1–A2.10.1. The second is the already-proved COLOR-CAP
conclusion… No new hypothesis or conclusion is introduced here." Checked against
Appendix B: THREE-ARM CLOSED is boxed at the end of A2.10.1, and COLOR-CAP ≤ 2
is boxed immediately after, derived from PF incomparability plus uniqueness of
depth in a fixed direction. ✔

**Why the corner case needs COLOR-CAP and not just THREE-ARM.** With c=1,a=3 the
three arms all carry the colour opposite to the corner. THREE-ARM alone already
kills three same-colour arms; COLOR-CAP ≤ 2 is the form actually applied, because
it bounds the *total* corner/arm rows of one colour and therefore also covers the
mixed corner-plus-arms bookkeeping. G4.4's forward note — "A corner with three
arms of the opposite colour and no singleton still requires the separate
COLOR-CAP argument below" — correctly signposts this. ✔

Appendix B's own chain is internally exhaustive:

- MINBOX (A1.1–A1.8): k≥2 impossible for both colours, via White width-one, the
  six COMP companions, the failure inequalities (BA)/(BB), the parameter forms
  (AP)/(BP), and the weighted multiplicity contradiction. Row ordering handled in
  A1.8 by simultaneous generator permutation with the a/b and A/B exchange, and
  the arm box p_i≤a_i−1 correctly carried to p_i′≤b_i′−1.
- DPE (A2.0–A2.10): sinks 𝖠,𝖠,𝖡,𝖢,𝖣 enumerated by negating the two positivity
  conditions per row; one-colour paths (A2.6), {1,2} (A2.7), {1,3} (A2.8), and
  the first firing of a third colour (A2.9.1, A2.9.2). A2.10 states the trichotomy
  explicitly.
- SAME-F (A2.10.1): the positive out-of-box state gives u_i*−1 ≥ a_i−1 ≥ λ_i, so
  removing λ_i n_i from that **one** final coefficient vector yields q_i∈Γ.
  The English adds "No semantic subtraction of a signed relation is used." ✔

## 4.4 Does the classification assume |Q| = 4?

No, and the English says so twice:

- §2: "Selecting four rows does not mean that the total number of elements of Q
  is fixed to be four."
- §11: "This classification does not assume that the full set Q has exactly four
  elements."

The three-singleton case is the one place where a conclusion about the *whole* of
Q appears (G4.8: |Q|=3), and §11 flags it separately. ✔

## 4.5 Forward references and appendix ordering

```
internal links with no target anchor:                 0
forward references from main text into later main §:  13
Appendix C display blocks duplicated verbatim in main: 0
```

All 13 forward references are handoff/roadmap pointers (§1→I9, §2→R7/E8 for the
symmetry packages, §4→T6.1 for "the full input to T6.1", §7→C8.2/C8.4/E8, §8→C8.3,
§9→E8). **None is an appeal to an unproved result.** Prop B.1 is used in §4 before
Appendix B is read, but the English announces it explicitly ("At this point we
apply Proposition B.1 (THREE-ARM / COLOR-CAP) from Appendix B"), which is normal
and acceptable practice.

Appendix C's claim that deleted exact duplicates were not reintroduced is
**verified**: none of its 7 display blocks occurs verbatim in the main text, and
its pointer table redirects the seven former `copy-*` nodes to their authoritative
locations.
