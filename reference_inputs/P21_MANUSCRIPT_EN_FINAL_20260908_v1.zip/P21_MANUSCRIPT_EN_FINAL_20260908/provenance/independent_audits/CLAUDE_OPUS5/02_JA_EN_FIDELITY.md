# 02 — JA → EN FIDELITY

## Method

Three independent alignments, none trusting the conversion reports shipped in
the package:

1. **Display-math extraction.** Custom parser walking `\[ … \]` pairs. Normaliser
   strips `\tag`/`\label`, collapses whitespace, unifies the Unicode↔macro Greek
   and relation glyphs the two sources mix (ρ↔`\rho`, ≤↔`\le`, ∈↔`\in`, −↔`-`,
   ₁↔`_1`, 𝒜↔`\mathcal A`, …), removes brace/spacing-only tokens, and replaces
   `\text{…}` contents with a placeholder so that language differences inside
   text-mode do not register as math differences. Multiset-compared per file.
2. **`\text{}` contents compared separately**, since that is exactly where a
   logical connective could be mistranslated.
3. **Prose aligned by the identical display-math sequence.** Because the 791
   displays are identical and in identical order, the prose between consecutive
   displays aligns exactly. 807 math-anchored prose segments, zero segment-count
   mismatch in any of the 16 files.

An earlier heading-based paragraph alignment drifted (EN splits some JA
paragraphs) and produced 152 spurious flags; the math-anchored alignment above
supersedes it and produced 32, all of which are dictionary artifacts (see below).

## Display math — exact

```
TOTAL:  EN = 791    JA = 791    differences = 0
```

| File | EN | JA | JA-only | EN-only |
|---|---:|---:|---:|---:|
| abstract.md | 0 | 0 | 0 | 0 |
| sections/01.md | 4 | 4 | 0 | 0 |
| sections/02.md | 16 | 16 | 0 | 0 |
| sections/03.md | 22 | 22 | 0 | 0 |
| sections/04.md | 105 | 105 | 0 | 0 |
| sections/05.md | 94 | 94 | 0 | 0 |
| sections/06.md | 38 | 38 | 0 | 0 |
| sections/07.md | 95 | 95 | 0 | 0 |
| sections/08.md | 86 | 86 | 0 | 0 |
| sections/09.md | 128 | 128 | 0 | 0 |
| sections/10.md | 64 | 64 | 0 | 0 |
| sections/11.md | 3 | 3 | 0 | 0 |
| appendices/A.md | 28 | 28 | 0 | 0 |
| appendices/B.md | 94 | 94 | 0 | 0 |
| appendices/C.md | 7 | 7 | 0 | 0 |
| appendices/D.md | 7 | 7 | 0 | 0 |

Formula-transfer sub-checks, all clean:

- formulas missing from English — **none**
- changed signs — **none**
- changed inequality direction — **none**
- changed subscripts/superscripts — **none**
- altered quantifiers — **none**
- altered ranges — **none**
- altered equation labels (`\tag`) — **none**

The reported preservation of all 791 display-math instances is **independently confirmed**.

## `\text{}` inside math

| File | EN | JA | Assessment |
|---|---|---|---|
| sections/01.md | ` for every ` | ` for every ` | identical |
| sections/03.md | `or` | `または` | **harmless localisation** — disjunction preserved (SPLIT) |
| sections/05.md | `or` | `または` | **harmless localisation** — disjunction preserved (STRICT-alternative) |
| sections/06.md | `TYPE II CLOSED` | `TYPE II CLOSED` | identical |
| sections/07.md | `or` | `or` | identical |
| sections/08.md | `CLOSED`, `CLOSED` | `CLOSED`, `CLOSED` | identical |
| appendices/B.md | `THREE-ARM CLOSED`, `COLOR-CAP` | same | identical |

**Two differences in total, both `または` → `or`, both genuine disjunctions.**

## Inline math

```
EN = 2663    JA = 1066    JA-only = 0
```

Every JA inline formula appears in the EN. The 1597 additional EN spans are
re-wrappings of symbols the Japanese could set bare in running text (`q`, `H`,
`F`, `m`, `i`, `j`, `k`, `W`, `\mathcal U`, `\mathcal D`) but which English
mathematical typography requires in math mode. This is correct localisation and
improves the English; it removes no content.

## Structure

```
headings compared          247      structural mismatches   0
anchors                    232      JA-only 0   EN-only 0
math-anchored segments     807      count mismatches        0
internal links             all      dangling targets        0
```

## Force-word audit

Scanned every math-anchored segment for the EN terms: positive, nonnegative,
strictly positive, at least, at most, less than, no greater than, exactly, only,
unique, if, only if, if and only if, unless, for every, there exists, must, may,
never, cannot, always, necessarily.

32 segments flagged as lacking a licensing Japanese marker. **All 32 manually
reviewed; all 32 are dictionary artifacts.** Markers my lexicon initially lacked:

| JA form | English rendering | occurrences |
|---|---|---|
| にすぎない | "is only …" | 2 (α=0 and g=0 signed-intermediate notes) |
| たびに | "every removal …" | 1 |
| 反する | "cannot" / "contradicts" | 2 |
| ちょうど二色 | "exactly two colours" | 1 |
| 必ず | "always" / "necessarily" | 2 |
| 残るなら / 生き残る場合 | "any surviving … must" | 2 |
| 必要十分条件 | "if and only if" | 1 |
| があれば | "if … were positive" | 2 |
| — | "ne**ver**theless" matched "never" | 1 |

Four targeted direction tests, run over all 807 segments:

| Test | Hits | Adjudication |
|---|---|---|
| A: EN "positive" where JA says 非負 only | 1 | False positive. §4 M4.2: EN "explicit minima of nonempty subsets of the **positive integers**" ← JA「空でない**自然数**集合の明示的最小値」. The two nouns differ: the *levels* L_A,L_B ≥ 1 are positive integers; the *coefficient vectors* are nonnegative, and EN says "nonnegative" for those in the same sentence. **EN is more precise than JA** (自然数 is ambiguous about 0; the proof needs L ≥ 1). |
| B: EN "nonnegative" where JA says 正 only | **0** | — |
| C: EN "at most"↔JA 以上 / "at least"↔JA 以下 | 2 | Both false positives. §4 G4.5.2 "j-coordinate at least a_j" ← 「j-coordinate≥a_j」; §4 G4.11.1 "i-coordinate at most κ−1" ← 「κ−1<ρ_i **以下**」. The opposite-direction word came from an adjacent clause. |
| D: EN "strictly" where JA is non-strict | 1 | §10 header: EN "strictly decreasing a positive integer measure" ← 「正整数測度の減少」. E8.6.4 proves 𝓜−𝓜′=(e−1)(H_p+θ)+ρ+κ>0 explicitly, so "strictly" is exactly what is proved. Not a force change. |

Two places where the English differs substantively from the Japanese, **both
making the English stronger/more explicit, never weaker**:

- §6 T6.5.2 — EN adds "Thus every coefficient is nonnegative and F∈Γ" where JA
  writes only 「よって F∈Γ、矛盾」. The preceding display in both lists the bounds.
- §10 — EN adds "strictly" to a decrease the Japanese states as 減少 of a
  positive integer measure.

Two places double-checked by direct lookup rather than alignment, both exact:

- §10 E8.5: 「特に failure の場合には w≥1 である。従ってw=0なら終端条件が**必ず**成立する。」
  → "In particular, failure implies w≥1. Therefore, if w=0, the terminal
  condition **necessarily** holds." ✔
- §9 C8.4.7: 「m係数は正、i係数はI-FITにより非負、k係数は0≤w<χにより非負。」
  → "The coefficient of m is **positive**; the coefficient of n_i is
  **nonnegative** by I-FIT; and the coefficient of n_k is **nonnegative**
  because 0≤w<χ." ✔ — positive and nonnegative correctly kept distinct.

## Result

$$\boxed{\textbf{MATHEMATICAL-FORCE CHANGES}=0}$$

All observed JA→EN differences fall into exactly two classes:
harmless language localisation, and stylistic paraphrase that adds explicitness.
