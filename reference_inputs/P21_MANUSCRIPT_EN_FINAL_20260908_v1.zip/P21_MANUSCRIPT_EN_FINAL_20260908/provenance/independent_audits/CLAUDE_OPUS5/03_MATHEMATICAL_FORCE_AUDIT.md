# 03 — MATHEMATICAL-FORCE AUDIT & ENGLISH PROOF-SPINE RECONSTRUCTION

## Part 1 — First pass: English-only reconstruction

Read before any sentence-level comparison with the Japanese.

An independent mathematical reader **can** reconstruct the full spine from the
English alone. Reconstructed without reference to JA or FROZEN:

**Setup (§1–§2).** Γ=⟨m,n₁,n₂,n₃⟩, edim 4, m the multiplicity, F the Frobenius
number, PF(Γ) the pseudo-Frobenius set, t(Γ)=|PF(Γ)|. Hypothesis (CANONICAL):
F+m−φ∈Γ for all φ∈PF(Γ). Goal t(Γ)≤4. Set Q(Γ)=PF(Γ)∖{F}, W=F+m,
H=⟨n₁,n₂,n₃⟩, 𝒜=Ap(Γ,m). Since F∈PF(Γ), t=|Q|+1, so the target is |Q|≤3, and the
contradiction hypothesis is |Q|≥4.

**Canonical reduction (§2).** C2.1 upgrades the PF-only hypothesis to every
nonnegative gap by taking the maximal element of (x+Γ)∖Γ. C2.2 gives the exact
two-layer decomposition: for w∈𝒜 exactly one of W−w∈𝒜, W+m−w∈𝒜 holds; 𝒜₀ is a
lower ideal, 𝒜₁ an upper filter carrying the order-reversing involution
ι(w)=W+m−w; Max 𝒜₁=(PF∖{F})+m and Min 𝒜₁={W−q}, so |Min 𝒜₁|=|Q|=t−1. C2.3 is
KEY: c−n_i∈H ⟹ q+n_i∈⟨n_j,n_k⟩, and ∅≠D(c)⊆SH(q) with equality **not** asserted.
C2.4 is the gcd firewall: m=(q+m)+(W−q)−W∈ℤH, so gcd(n₁,n₂,n₃) | m, hence =1 —
and the manuscript says outright that this signed equality is used only in ℤH.
C2.5 selects four rows and shows H is genuinely minimally three-generated.

**Symmetric branch (§3 + App A).** H=⟨du,dv,w⟩ by the standard gluing form.
Stable core K, r=h−m, ideal I_r, and BRIDGE: Min_Γ J={m}⊔(Min_H I_r ∩ Ap), giving
TYPE-BRIDGE t(Γ)=1+|Min_H I_r ∩ Ap|. Assume t≥5. The two-generated lemma caps
|Min_H I_r|≤4, so all four RAW4 minima must survive in the Apéry set.
CROSS-LAYER forces w=αu+βv with α,β>0. SPLIT divides into Branch I / Branch II,
and Appendix A kills Branch I by the four-hit walk (U_x,U_y,Z_x,Z_y incompatible
in each of X-only / Y-only / XY), Branch II k₀=1 by reduction to Branch I via
2GI, k₀=0,e=0 by τ₁<0, and k₀=0,e>0 by the cross-core complement identity.

**Nonsymmetric branch (§4).** Herzog normal form (HCR) with the six-arm atlas
proved from scratch in G4.1.1. Rows are singleton / doubleton(arm) / corner.
G4.2 antichain + singleton caps; G4.3 critical-box uniqueness and the integer
kernel basis r_j,r_k; G4.4 no corner+singleton; G4.5 matched-pair
synchronisation (MATCH) with boundary cases g=0, α=0 explicitly retained; M4 the
root-free level theorem culminating in EA/EB and P-FIBER; G4.6/G4.7 the exact
complement geometry for the two same-colour and two orientation-mixed cases;
G4.8 three singletons ⟹ |Q|=3; Appendix B's Prop B.1 kills three same-colour
arms and gives COLOR-CAP ≤ 2. G4.9 then exhausts four rows into exactly PATH,
TYPE II, CHAIN. G4.11 extracts the scalar input for each.

**PATH (§5).** Central returns are exhausted by PAIR or the two orientations of
PFREE_i. PAIR → WEAK-ROOT → finite ROOT normalisation (measure K strictly
decreasing by ρ_k) → ENDPOINT-LEVEL-2 → LEFT-FABS gives F∈Γ. PFREE: F₀≤0 killed
by the two right-singleton returns and pure-H criticality; F₀≥1 killed via
P5-FIX-J, PIN, ROOT+, ROOT-T and LAST. The right-oriented case is handled by the
fully displayed P5-dual parameter transformation.

**TYPE II (§6).** Two singleton returns SJ/SK give C-CAP, B-CAP, then
UNIFORM-I-CAP 0≤A,D≤b_i−1 via an exhaustive η/θ sign analysis. The three
orderings ℓ=h, ℓ>h, h>ℓ are each closed by an explicit nonnegative F-row.

**CHAIN (§7–§10).** R7 maximises the i-coordinate over the finite factorisation
set of the same element h_A=q_A+m to produce CORE-ROOT m+dn_i=Sn_j+Cn_k with
1≤d≤λ, S≥g+1, C≥α (after full colour reversal if needed). C8.1 derives the four
positive-level returns RET, FI-CAPS, SLOPES, the two intrinsic candidates, and
the τ₀/e₀ caps. C8.2 defines the first ROOT/R_j fitting point, Ξ, χ, PACKET, and
splits: C=α closed by BOUND-MULT with the POS-COEFF decomposition; strict window
closed by STRICT-WINDOW; residue exhausted by 𝒰 ∨ 𝒟. C8.3 kills 𝒰 by t packet
replacements inside the same upper element, using I-FIT and J-FIT. C8.4 reduces
𝒟 to q₀=2 and N=ẑ+1, secures the i-source with the 715-term certificate, and
emits the two genuine packets D-LINEAR and COMPLEMENTARY. E8.2.3 embeds them in
the abstract package with 𝖬₀=[[fk+1,f],[k,1]], det=1, L>M. E8 then runs the
Euclidean descent on 𝓜=E+χ, terminating in FINAL-EXACT: F∈Γ.

**Assembly (§11 I9).** All branches contradict F∉Γ, so |Q|≤3 and t(Γ)≤4.

**Spine verdict.** Every arrow in the required chain

> canonical reduction → SYM/NONSYM → PATH / TYPE II / CHAIN → CHAIN CORE /
> CENTRAL → Euclidean two-packet closure → |Q|≤3 → t(Γ)≤4

is present, labelled, and traversable in the English alone.

**Passages that read as translated rather than written.** Very few. The two
"Common setting" blocks (§2 C2, §4 G4.1) drop into raw Unicode and a telegraphic
register that breaks from the surrounding prose (EN-05). §5's backticked symbols
read as source-code residue (EN-01). Section 7's heading "Input from CORE to the
late-stage closure" sits oddly as a top-level heading inside a section about the
unit root. Otherwise the register is consistent professional mathematical
English.

## Part 2 — Unconditional-theorem scan

Requirement: flag any English sentence readable as an unconditional theorem for
every four-generated numerical semigroup.

**Result: zero.** The canonical hypothesis is carried at every level:

| Location | Carrier |
|---|---|
| abstract.md | "Under the canonical-reduction condition F+m−φ∈Γ for every pseudo-Frobenius number φ, we prove that the type of Γ is at most 4." |
| §1 ¶2 | "The condition studied here is canonical reduction… We require F+m−φ∈Γ for every pseudo-Frobenius number φ." |
| §1 T1 | The hypothesis is in a `\boxed{}` display tagged (CANONICAL), immediately above the boxed conclusion. |
| §1 T1 closing | "Throughout the paper, the canonical condition displayed above is used at every stage of the proof." |
| §2 opening | "We fix the hypotheses of the main theorem." |
| §2 C2 | "Under the canonical condition of Sections 1–2…" |
| §3 S3 | Restates (CAN) as a hypothesis of the symmetric proposition. |
| §4 G4.1 | "Canonical reduction gives q∈Q ⟹ c_q=W−q∈Γ." |
| §11 I9 | "Let Γ be a minimally four-generated numerical semigroup **satisfying the canonical condition of Sections 1–2**…" |

The title itself — "The type of four-generated numerical semigroups **with
canonical reduction**" — carries the hypothesis. No abstract, introduction,
section-opening or concluding sentence states the bound unconditionally.

## Part 3 — Load-bearing statements checked against FROZEN

Ten statements on which the theorem turns, verified against the frozen edition
and, where they are self-contained, re-derived by hand.

| # | Statement | EN location | Verified |
|---|---|---|---|
| 1 | t=\|Q\|+1, so the goal is \|Q\|≤3 | §2, §11 | ✔ arithmetic |
| 2 | KEY: ∅≠D(c)⊆SH(q), equality **not** asserted | C2.3 | ✔ EN says "**Equality is not asserted.**" |
| 3 | tail gcd = 1, signed identity used only in ℤH | C2.4, I9 | ✔ both state the restriction |
| 4 | TYPE-BRIDGE t(Γ)=1+\|Min_H I_r ∩ Ap\| | S3.2 | ✔ |
| 5 | Four-row classification is exhaustive → PATH∨TYPE II∨CHAIN | G4.9 | ✔ case analysis complete, see file 04 |
| 6 | CORE-ROOT bounds 1≤d≤λ, S≥g+1, C≥α | R7.3–R7.5 | ✔ re-derived; F-S, F-C, F-D each checked |
| 7 | 𝒰∨𝒟 exhausts the strict region | C8.2.12 | ✔ see file 05 |
| 8 | Terminal j-coefficient h−1 and k-coefficient x are ≥0 | E8.3, E8.4.4 | ✔ re-derived by hand |
| 9 | 𝓓_p′=𝓓_p>0 under the Euclidean step | E8.6.3 | ✔ re-derived: θκ−ρH_p = θχ−EH_p |
| 10 | 𝓜−𝓜′=(e−1)(H_p+θ)+ρ+κ>0 | E8.6.4 | ✔ re-derived |

Hand re-derivations performed for the Euclidean theorem (all confirming):

- ν=⌊u/θ⌋+1 ≥ 2 and νθ ≥ u+1, hence j_*=E−νθ ≤ R−1 unconditionally.
- u=(ν−1)θ+z, h=θ−z ≥ 1 ⟹ j_*=R−h ⟹ FINAL-EXACT j-coefficient R−1−j_*=h−1 ≥ 0.
- x=χ−νH_p+T−1 ⟹ FINAL-EXACT k-coefficient T−1−k_*=x ≥ 0, exactly the terminal condition.
- ORDER: p≤s ⟹ q<t ⟹ L<M, contradiction ⟹ p>s; then q<t ⟹ pt−qs≥s+q+1>1, contradiction ⟹ q≥t. ✔
- 𝖬′ entries: A′=(t+eq)(r+β)+(s+ep)(r+δ)=B+eA ✔; B′=q(r+β)+p(r+δ)=A ✔;
  det=(t+eq)p−(s+ep)q=pt−qs=1 ✔; L′=M+eL, M′=L, L′>M′ for e≥1 ✔.
- RHO: L′E′+M′θ′−a_j′=(M+eL)H_p+Lκ−b_k=MH_p+Lχ−b_k=ρ_k=ρ_j′ ✔;
  L′χ′+M′H_p′−b_k′=(M+eL)θ+Lρ−a_j=Mθ+LE−a_j=ρ_j=ρ_k′ ✔.
- ν=e+1: ν≤e+1 always; ν≤e ⟹ νH_p−χ≤−κ<0 contradicting FAIL ✔.
- ρ≥R from u=E−R and ⌊u/θ⌋=e; κ≤w from (e+1)H_p−χ≥T ✔.

Every one matches the manuscript exactly.

## Result

$$\boxed{\textbf{MATHEMATICAL-FORCE CHANGES} = 0}$$
