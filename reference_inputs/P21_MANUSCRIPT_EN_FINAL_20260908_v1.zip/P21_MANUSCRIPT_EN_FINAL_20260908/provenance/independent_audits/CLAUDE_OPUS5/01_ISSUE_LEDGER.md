# 01 — ISSUE LEDGER

Eight issues. None requires a mathematical change.

---

```
ID:                        EN-01
Severity:                  EDITORIAL
English location:          sections/05.md (56 spans); sections/09.md (2); appendices/D.md (53)
                           → sections/05.tex lines 119,121,145,153,174,182,184,186,195,220,241
Japanese source:           sections/05.md (50 spans); 09.md (1); appendices/D.md (41)
Frozen source if needed:   05_PATH.md — same backtick spans present
English text:              "…removing one copy of `n_j` from that same coefficient vector…";
                           "…subtract the copy of `m` represented by ROOT from the same `W`…";
                           "…the positive integer `K` strictly decreases…";
                           "…for every genuine missing-`j` return of the same actual `q_L`…"
Problem:                   Mathematical symbols are wrapped in Markdown inline code, so the
                           typesetter emits \texttt{F}, \texttt{m}, \texttt{K}, \texttt{q\_L},
                           \texttt{W}, \texttt{H}, \texttt{j}. In the PDF these render in
                           DejaVu Sans Mono at 0.86 scale while every neighbouring instance of
                           the same symbol renders in Latin Modern Math italic. A referee sees
                           the same object typeset two different ways within one sentence.
                           EN also *increased* the count (50→56 in §5, 1→2 in §9, 41→53 in App D).
Correct intended force:    Unchanged. These are ordinary mathematical symbols and should be
                           math-italic, exactly as they are everywhere else in the manuscript.
Minimal repair:            In the three .md files replace each `X` span holding a mathematical
                           symbol with \(X\), then re-run supplement/typeset_english.py.
                           Appendix D spans that name JSON keys, file paths, shell commands or
                           code variables (`terms`, `variables`, `u`, `eps`, `p0`) are correct
                           as monospace and must be left alone.
Mathematical change required?  NO
```

---

```
ID:                        EN-02
Severity:                  EDITORIAL  (inherited from FROZEN and JA)
English location:          sections/09.md line 56 (C8.3.2, COUNT)
Japanese source:           sections/09.md line 57 — identical
Frozen source if needed:   08_CENTRAL_EUCLIDEAN_CLOSURE.md line 1128;
                           P21_FINAL_FROZEN_PROOF_MASTER.md line 3652 — identical
English text:              t:=\left\lfloor\frac H_u\eta\right\rfloor+1\ge1,
Problem:                   Malformed LaTeX. \frac takes two brace groups; `\frac H_u\eta`
                           binds \frac's first argument to H and then meets a bare subscript
                           operator. Any generic LaTeX/KaTeX/MathJax rendering of the Markdown
                           artifact errors or renders wrongly.
                           NOTE: sections/09.tex ships the corrected \frac{H_u}{\eta}, so the
                           PDF is CORRECT. The defect is confined to the .md artifact.
Correct intended force:    t = ⌊H_u/η⌋ + 1. Confirmed consistent with the same subsection's
                           H_u=(t−1)η+r, 0≤r≤η−1, and with C=α+tη+r.
Minimal repair:            sections/09.md → \left\lfloor\frac{H_u}{\eta}\right\rfloor
Mathematical change required?  NO
```

---

```
ID:                        EN-03
Severity:                  PRESENTATION-RISK  (Markdown artifact only)
English location:          sections/08.md line 477 (C8.2.9.1, E_a);
                           P21_MANUSCRIPT_EN.md line 3510
Japanese source:           sections/08.md — identical construct
Frozen source if needed:   n/a
English text:              E_a={}&[(L-1)(M-1)-1](Q-2)+L^2(g-1)\\
Problem:                   The substring [(L-1)(M-1)-1](Q-2) matches Markdown's
                           [text](link) inline-link grammar. The project typesetter is
                           math-aware and emits it verbatim (verified: sections/08.tex line 522
                           is byte-identical), so the PDF is correct. But GitHub, pandoc's
                           generic Markdown reader, and most web renderers will convert this
                           to an anchor with href "Q-2", silently destroying the coefficient.
                           This bites only if the .md is distributed or published as-is.
Correct intended force:    E_a = [(L−1)(M−1)−1](Q−2) + L²(g−1) + L(a_j−1) + (L−2)M − L
Minimal repair:            Rewrite as \bigl[(L-1)(M-1)-1\bigr](Q-2), or add a thin space
                           \, between ] and (. Purely defensive.
Mathematical change required?  NO
```

---

```
ID:                        EN-04
Severity:                  PRESENTATION-RISK
English location:          sections/04.md line 667 (G4.9, case s=1,a=3)
Japanese source:           sections/04.md line 680 —「排除済みの中間候補は、巡回置換・完全色反転を除いて」
Frozen source if needed:   04_NONSYMMETRIC_CLASSIFICATION.md line 460
                           「この時点で SQ は直接排除される」 and line 642
                           「SQはG4.5.2、TYPE IはG4.5.3で排除した」
English text:              "Up to cyclic permutation and full color reversal, the already
                           excluded intermediate candidate is
                           S_i, A_i(λ), B_i(λ), A_k(ν).
                           It therefore need not be treated as an independent terminal branch."
Problem:                   "the already excluded intermediate candidate" has no antecedent in
                           the English manuscript. The frozen edition names this configuration
                           (SQ / TYPE I) and states exactly where each was killed; the Japanese
                           final dropped the project jargon, and the English faithfully followed.
                           The mathematics is intact — the immediately preceding sentence cites
                           G4.5.3, which is indeed the exclusion — but a referee must reconstruct
                           the link. This is the single place in the manuscript where a hostile
                           referee can ask "excluded WHERE?" and not be told.
Correct intended force:    The configuration contains the matched pair A_i(λ),B_i(λ) in
                           direction i together with the singleton S_i; G4.5.3 forbids exactly
                           that coexistence. Independently: G4.5.2 caps the additional arms
                           compatible with a matched pair to B_j and A_k, which already excludes
                           this shape.
Minimal repair:            "Up to cyclic permutation and full colour reversal, the remaining
                           candidate S_i, A_i(λ), B_i(λ), A_k(ν) contains a matched pair in
                           direction i together with the singleton S_i, and is therefore already
                           excluded by [G4.5.3](#fr-G4.5.3); it need not be treated as an
                           independent terminal branch."
Mathematical change required?  NO — the sentence is a pointer, not a proof step.
```

---

```
ID:                        EN-05
Severity:                  EDITORIAL  (inherited from JA)
English location:          sections/02.md "Common setting" (C2 preamble);
                           sections/04.md "Common setting" (G4.1 preamble)
Japanese source:           same two blocks
English text:              "Let Γ=⟨m,n₁,n₂,n₃⟩ be a numerical semigroup, with m its
                           multiplicity, F its Frobenius number, H=⟨n₁,n₂,n₃⟩, W=F+m, and
                           𝒜=Ap(Γ,m). Let Q=PF(Γ)\{F}.
                           Every factorization of an element of 𝒜 contains no copy of m, so 𝒜⊆H."
Problem:                   Raw Unicode mathematics (Γ, ⟨⟩, n₁, 𝒜, ⊆, ∈) in body text where the
                           surrounding manuscript uses \(...\). The .tex routes these through
                           \newunicodechar so the PDF is legible, but the font is the text roman,
                           not the math font, so Γ and 𝒜 do not match their appearance elsewhere.
                           §2 also writes Q where the notation-scope table fixes Q(Γ) for the set.
Correct intended force:    Unchanged.
Minimal repair:            Wrap in \(...\) and use \Gamma, n_1, \mathcal A, \subseteq; write Q(Γ).
Mathematical change required?  NO
```

---

```
ID:                        EN-06
Severity:                  PRESENTATION-RISK
English location:          PDF pp. 24, 45, 55, 68 — seven auto-scaled displays, identified from
                           the build log as tags P5-PAIR, NORMALIZED-ROOT, P5-DOUBLE-UNIT,
                           TERMINAL-SUB, CROSS-LAYER, POS-COEFF, HRJ
Japanese source:           same \FitMath mechanism
English text:              (typeset artefact, not wording)
Problem:                   The \FitMath macro silently \resizebox-es a display that overruns the
                           text width. Independent rebuild logged 7 MATH-RESIZE events. The worst
                           is NORMALIZED-ROOT at 378.05pt → 302.28pt, i.e. ~80% linear scale, so
                           an 11pt display renders at roughly 8.8pt. NORMALIZED-ROOT is a boxed
                           load-bearing conclusion of P5.3.4; P5-PAIR (443.13 → 393.48pt) defines
                           the central PATH dichotomy.
Correct intended force:    Unchanged — \resizebox alters size only, never content.
Minimal repair:            Break these seven displays across lines (aligned or split
                           environments) so no auto-shrink fires. Zero mathematical edit.
Mathematical change required?  NO
```

---

```
ID:                        EN-07
Severity:                  CITATION
English location:          sections/02.md line 27
Japanese source:           sections/02.md line 31 —
                           「以下の三結果は本論文の証明対象外である。ここで用いる正確な形と原典の
                            書誌情報を保持し、補助引用については本稿が使用する節・定理番号の所在を
                            確認している。一方、歴史的原典について未確認の定理番号を主張しない。」
English text:              "These results are not proved in this paper. We retain the
                           bibliographic information for the original sources and the precise
                           locations in the supporting references used here. We do not assert
                           unverified theorem numbers in the historical originals."
Problem:                   The Japanese makes an active verification claim about the supporting
                           references —「所在を確認している」("we have verified the locations of the
                           sections/theorem numbers we use"). The English folds this into
                           "We retain … the precise locations", which asserts that the locations
                           are given but not that they were checked.
                           The direction is CONSERVATIVE: the English claims LESS than the source.
                           The load-bearing disclaimer —「歴史的原典について未確認の定理番号を
                           主張しない」— is preserved exactly.
Correct intended force:    Locations in the supporting references are verified; theorem numbers
                           in the historical originals are not asserted.
Minimal repair:            Optional. "…and we have checked the precise locations in the
                           supporting references used here." Logged for completeness; the
                           current wording is safe and no referee can be misled by it.
Mathematical change required?  NO
```

---

```
ID:                        EN-08
Severity:                  EDITORIAL
English location:          supplement/english_build/ — build1.log, build2.log, build3.log,
                           render.log, render_final.log, typeset.log, bibtex.log,
                           P21_MANUSCRIPT_EN.aux (67.9 kB), .toc, .blg, main_generated.tex
Japanese source:           n/a
Problem:                   Intermediate LaTeX build artifacts ship inside the distributed
                           package and are covered by SHA256SUMS.txt. They are provenance, not
                           manuscript. They also make the manifest sensitive to a rebuild: any
                           reviewer who runs the documented Appendix D commands regenerates
                           verification_result.json and breaks manifest verification.
                           Appendix D already warns about this ("preservation of a distribution
                           master should be checked on a working copy"), which is the correct
                           mitigation, so this is a packaging preference only.
Minimal repair:            Move english_build/ under a clearly-labelled provenance/ subtree, or
                           state in 00_README.md that it is non-normative.
Mathematical change required?  NO
```
