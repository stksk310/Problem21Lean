# 05 — CHAIN/CENTRAL SCOPE, CENTRAL EXHAUSTION, EUCLIDEAN THEOREM

## 5.1 CHAIN → CORE → CENTRAL scope

The English carries a dedicated handoff table (§9,
`#chain-core-central-euclidean-handoff`) with a column *"After a nonterminal
descent step"*. Reconstructed from the English alone:

| Quantity | CHAIN/R7 output | Used in CORE/CENTRAL | Initial embedding | After descent |
|---|---|---|---|---|
| Γ, F, m, W | same semigroup, F∉Γ, m multiplicity, same actual W | every SAME-element comparison | E8.2.3 passes the same m,n_i,n_j,n_k,F,W | colour exchange renames generators only; same F,m,W-face |
| HCR / canonical parameters | λ,δ,β,g,α>0; P,R,T; three critical relations | slopes, caps, cross products | a_i=P−β>0, b_i=P−δ>0, R=a_j+g, T=b_k+α; HCR in the E8 package | preserved under the full j↔k and a/b exchange |
| ROOT | m+dn_i=Sn_j+Cn_k, 1≤d≤λ, S≥g+1, C≥α | CORE 5; returns, window, 𝒰/𝒟 packets | upstream only; **not** an abstract E8 hypothesis | **Not required** |
| four actual PF gaps | from the CHAIN four-row shape | CORE 4; missing-coordinate returns and caps | used until the packets and W-face are fixed | **Not required** |
| det-1 matrix | not an R7 output | introduced after the two 𝒟-packets | 𝖬₀=[[fk+1,f],[k,1]], det=1, L>M | 𝖬′ preserves det 1 and L′>M′ |
| genuine packets | D-LINEAR, COMPLEMENTARY | verified as actual equalities, not signed | identified with (DP),(PP) | new DP = old PP; new PP = NEW-PACKET |
| packet determinant | REMAINDER-SLOPE θχ−E(T+w)>0 | slope condition | 𝓓_p=θχ−EH_p>0 | 𝓓_p′=𝓓_p>0 |
| 𝒟-specific: first point, q₀=2, N=ẑ+1 | not CHAIN outputs | only in C8.4 to build the packets | role ends at E8.2.3 | **Not inherited** |
| descent measure | none | none | 𝓜=E+χ | strictly decreases (E8.6.4) |

Three independent statements in the English enforce the scope cut:

1. §10 opening — "This section uses only the abstract inputs listed below. The
   minimality of the first point constructed in the preceding section is not
   required in the descent that follows."
2. §10 E8 — "We introduce new local packet notation here. The indices N,I,J
   attached to the first point in C8.4 are **not carried into** this theorem."
3. §9 handoff-table preamble — "This table only records where already-proved
   inputs enter the argument; it adds no new assumption. In particular, the
   first-point data and q₀-specific conditions used in 𝒟 are not inherited after
   entry into the abstract Euclidean theorem."

**No D-specific assumption is described as an assumption of the abstract
Euclidean theorem after descent.** The E8 hypothesis list (E8.2.1) contains only:
MATRIX, SOURCES, E=R+u / H_p=T+w / 1≤θ≤u / w≥0 / χ≥1, DET-POS, DP, PP, RHO,
a_i=P−β>0, b_i=P−δ>0, HCR, the W-representation, and m<min(n_i,n_j,n_k). Neither
ROOT, nor d, S, C, nor the first point, nor q₀, nor N appears.

$$\boxed{\textbf{CHAIN}\to\textbf{CENTRAL ENGLISH SCOPE VERDICT: PRESERVED}}$$

## 5.2 CENTRAL exhaustion table, built from the English alone

| Region | Entry condition | Treatment | Closed by |
|---|---|---|---|
| C = α (boundary) | ROOT coefficient meets its floor | BOUNDARY-WALL N≥max(L_i,L_b,L_j)+2; SYNC of the same EA/EB representations giving L_b=L_i, x_b=x, U_j=V_j+a_j, V_k=U_k+b_k and Q≥a_j+1≥2; boundary K-CEILING; BOUND-MULT m̂−𝒥=H₀P₀+αC_A+b_kC_B with the POS-COEFF decomposition ⟹ m>n_j | **C8.2.7–C8.2.8** |
| strict packet window | C>α, χ≤T, L_i≥2 | WINDOW-WALL; kernel basis; EA-ONE, QJ-ONE; empty integer triangle and DET1 xM−zL=1; PARAM; LEVEL-SPLIT; STRICT-J for Q≥2 with the three exceptional (L,x,M,z,Q,g,a_j) cases; STRICT-K for Q=1 and those three exceptions | **C8.2.9** |
| U (level-one) | C>α, χ≤T, L_i=1 | forces λ=d, q₀=2, L=x=1, M=z+1; UNIT-PARAM; first point computed exactly (ẑ=z+1, N=z+2, I=a−1, J=Q−1, Ξ=C−α−η+1, χ=η); UNIT-MULT excludes D_u≤0, leaving D_u>0 and Q>R | **C8.2.11 → C8.3** |
| high-q₀ D | h≥2 (q₀≥3) | FIRST-BOUNDS ⟹ A≥A₀>0, B≥B₀>0; 4A₀+B₀+V−𝒦 = S·H_S + τ·H_τ + H_c with H_S>0, H_S+H_τ>0 and S>τ ⟹ M-MASTER gives m>n_k | **C8.4.3** |
| nonlinear first point | q₀=2, ℓ_z≥2 | κ=⌊(d+δ−1)/b⌋; S≥κτ+g; SMALL-R 1≤r′≤b−δ; I≤r′−1; A≥A₁>0, B≥B₁>0; 4A₁+B₁+V−𝒦 = S·E_S+τ·E_τ+E_c with κE_S+E_τ>0 and S≥κτ+g | **C8.4.4** |
| linear first point | q₀=2, N=z+1 | exact parameterisation; DSCR 𝒟>0; I-FIT via the **715-monomial** certificate and Φ′(a)<0; J-ONLY; the surviving range 1≤θ≤υ | **C8.4.5–C8.4.7** |
| Euclidean residual | 1≤θ≤υ | two genuine packets D-LINEAR + COMPLEMENTARY embedded by 𝖬₀ | **E8** |

The exhaustion closes at C8.2.12: "The boundary C=α has been eliminated. In the
strict case C>α, the conjunction χ≤T and L_i≥2 is impossible. If χ≤T, we are in
the 𝒰-parameter region. On the other hand, if χ>T, then 𝒟… Thus the remaining
cases are exhausted by 𝒰 and 𝒟." And 𝒰=∅ is boxed at C8.3.4.

Case-split completeness checked directly: C=α ∨ C>α; within C>α, χ≤T ∨ χ>T;
within χ≤T, L_i≥2 ∨ L_i=1. Nothing is left over.

$$\boxed{\textbf{CENTRAL EXHAUSTION: COMPLETE}}$$

## 5.3 Euclidean two-packet theorem, audited as a standalone theorem

**Package (E8.2.1).** 𝖬=[[p,q],[s,t]] with p,q,s,t ≥ 1 and pt−qs=1; L=p+q>M=s+t;
r≥0; A=p(r+δ)+q(r+β), B=s(r+δ)+t(r+β); E=R+u, H_p=T+w, 1≤θ≤u, w≥0, χ≥1;
𝓓_p=θχ−EH_p>0; the two packet equalities

$$Bn_i+En_j=Mm+\chi n_k \tag{DP}$$
$$An_i+H_pn_k=Lm+\theta n_j \tag{PP}$$

matching the audit brief's required forms; RHO ρ_j=LE+Mθ−a_j, ρ_k=Lχ+MH_p−b_k;
plus a_i=P−β>0, b_i=P−δ>0, HCR, the W-representation, m<min(n_i,n_j,n_k).

All positivity hypotheses and the determinant-one matrix assumption are present
and explicit. ✔

### Terminal case

| Required item | Present | Independently re-derived |
|---|---|---|
| quotient definition | ν=⌊u/θ⌋+1≥2 | ✔ 1≤θ≤u ⟹ ⌊u/θ⌋≥1 |
| j-fit | j_*=E−νθ ≤ R−1 "Always" | ✔ νθ≥u+1 ⟹ j_*=R+u−νθ≤R−1 |
| k-fit | TERMINAL k_*=νH_p−χ ≤ T−1 | ✔ equivalent to x=χ−νH_p+T−1≥0 |
| universal i-fit | I-FIT P≥B+νA+1 | ✔ from Φ(B+νA)=𝒫>0 and Φ′(P)<0 |
| multiplicity proof | Φ(P)=m̂−𝒦, m>n_k contradiction | ✔ MONOTONE Φ′(P)=−(𝓓_p+M₀)<0 |
| SAME-W containment | "The existing face of the SAME W contains the left source coefficientwise" | ✔ and negative j_*,k_* handled by the (·)_+ rewrite with **both sides nonnegative** |
| final nonnegative representation of F | FINAL-EXACT F=(M+νL−1)m+(P−1−B−νA)n_i+(h−1)n_j+xn_k | ✔ all four coefficients ≥0: M+νL−1≥0, I-FIT, h≥1, x≥0 |

### Nonterminal case

| Required item | Present | Re-derived |
|---|---|---|
| remainder formulas | e=⌊E/θ⌋≥1, ρ=E−eθ, κ=χ−eH_p, 0≤ρ<θ, κ≥1 | ✔ θκ−ρH_p=θχ−EH_p=𝓓_p>0 ⟹ κ≥1 |
| new genuine packet | NEW-PACKET (B+eA)n_i+ρn_j=(M+eL)m+κn_k, "Every coefficient on both sides is nonnegative" | ✔ = DP + e·PP |
| full colour exchange | COLOR block: n′, m′,F′,W′; all six a/b; δ′,β′,g′,α′,R′,T′,P′,r′; then EUCLID E′,θ′,χ′,H_p′,u′,w′ | ✔ complete |
| determinant preservation | (t+eq)p−(s+ep)q=pt−qs=1 | ✔ |
| domain preservation | E′=R′+u′, H_p′=T′+w′, 1≤θ′≤u′, w′≥0, χ′≥1 | ✔ via REMAINDERS R≤ρ<θ, 1≤κ≤w |
| packet determinant preservation | 𝓓_p′=κθ−H_pρ=𝓓_p>0 | ✔ |
| RHO preservation | ρ_j′=ρ_k and ρ_k′=ρ_j | ✔ both re-derived |
| W-face preservation | same value **and** same canonical face after renaming | ✔ explicitly stated |

### Termination

The brief forbids accepting bare prose. The English does **not** rely on prose:

$$\mathcal M:=E+\chi,\qquad
\boxed{\mathcal M-\mathcal M'=(e-1)(H_p+\theta)+\rho+\kappa>0}\tag{DESCENT}$$

- 𝓜 is declared a positive integer at E8.2.2 ("strong induction on the positive
  integer 𝓜:=E+χ") and again at §11.
- Positivity of the decrement is exact: e≥1, H_p,θ>0, ρ≥R≥1, κ≥1.
- The manuscript states the decrement is "by at least one at every step".
- E8.6.4 adds the scope guard: "The quantity 𝓜 is the descent measure used only
  in the present argument; it is not a depth parameter inherited from an earlier
  branch."

✔ The exact frozen measure 𝓜=E+χ is explicitly a positive integer and is proved
to decrease strictly, with the decrement given in closed form.

### The one place the theorem interacts with det = 1

E8.4.3 states: "This positivity statement holds on the independent-variable
domain specified only by (ORDER); the determinant-one condition need not be
imposed as an additional constraint on the polynomial expansion. The
determinant-one identity is, however, used exactly where required to identify the
actual m̂ with (M-HAT)."

**Verified against the verifier source.** `verify_euclidean_closure.py` carries
the det-correction terms explicitly in three checks —
`'scaled m formula modulo det=1'` (residual term `−a_j·D·(det−1)·(δ−β)`),
`'D packet modulo det=1'`, `'P packet modulo det=1'` — while the positivity
expansion `phi.subs(subs)` is performed with **no** determinant constraint. The
English description is exactly right. ✔
