# 08 — ENGLISH PROSE REPORT

Target: clear professional mathematical English, not literary prose.
**Overall: the manuscript meets that target.** Register is consistent, terminology
is stable, hedging is absent, and the sentence rhythm is that of a written
research paper rather than a translation.

## Strengths worth preserving

- **Terminology is stable.** "actual", "genuine", "signed", "completed",
  "coefficientwise", "packet", "arm", "corner", "singleton", "doubleton",
  "complement", "return", "level", "cap", "window", "descent measure" are each
  used in exactly one sense throughout. `ENGLISH_TERMINOLOGY_GLOSSARY.md` ships
  with the package.
- **The notation-scope table (§2)** is unusually good practice: it pre-empts
  every collision (Q, H, C, T, A/B, E, L/M, Δ, θ, χ) that a referee would
  otherwise raise as a defect.
- **Discipline paragraphs are placed where the risk is**, not only in a preamble.
- **Handoff tables** at the end of §4, §8, §9 and §10 give the referee a map.
- **Negative statements are explicit** — "Equality is not asserted", "No
  Hall-type existence theorem… is needed", "This does **not** assert that the
  original ROOT already had subcritical K", "No unit-root hypothesis is used in
  this synchronization". These pre-empt exactly the objections a hostile referee
  reaches for.

## MACHINE-TRANSLATED SOUNDING

Few, and mild.

| Location | Text | Comment |
|---|---|---|
| §2 C2 "Common setting" | "Let Γ=⟨m,n₁,n₂,n₃⟩ be a numerical semigroup, with m its multiplicity…" then "Every factorization of an element of 𝒜 contains no copy of m, so 𝒜⊆H." | Telegraphic and in raw Unicode; breaks register from the surrounding §2. See EN-05. |
| §4 G4.1 "Common setting" | "For every actual q, we have q+m,c_q∈H, c_q−m∉Γ, and q∉Γ, by the elementary canonical lemmas." | "the elementary canonical lemmas" is vague where "by C2.2–C2.3" would be precise. |
| §7 heading | "Input from CORE to the late-stage closure" | "late-stage" is project-internal; "Input from CORE to Sections 8–10" would be clearer. |
| §8 C8.2.2 | "This is a completed family." | Terse to the point of opacity on first read; the following sentence rescues it. |
| §4 G4.6 | "From i>0,k<0, and |j|<ρ_j, we get u≥0,v≥1." | Uses i,j,k as *coordinate labels of a kernel vector* while the same letters are direction indices two lines above. Correct but momentarily jarring. |

## AMBIGUOUS MATHEMATICAL ENGLISH

Only one place where scope could be misread, and it is a pointer, not a proof
step:

- **§4 G4.9** — "the already excluded intermediate candidate" (EN-04). No
  antecedent; the reader must infer G4.5.3 from the preceding sentence.

Two near-misses that are in fact fine:

- §7 C8.1.0 "Here C is the coefficient in ROOT and is distinct from T=b_k+α" —
  correctly disambiguated in place.
- §8 C8.2.6 "In the general formula, LC−α must not be replaced by (L−1)C" — an
  explicit anti-error instruction; good practice.

## OVERLONG

Splittable without mathematical change:

- §4 G4.5 — the (u,v) sign elimination is one sentence with five clauses
  ("If u≥1,v≤0… If u≤−1,v≥1… If u≥0,v≥1… If u≤−1,v≤0… The remaining case…").
  A displayed four-row table would be far easier to check.
- §8 C8.2.9.1 — "For completeness: if L≥4… If L=3,M≥3… If L=3,M=2… If L=2…" is a
  dense four-case paragraph establishing the three exceptions. Deserves a list.
- §9 C8.4.4 — the κ / r′ / SMALL-R derivation runs long between displays.
- App B A2.7.3 — the D<0 sub-case packs a PREFIX-separator construction, an
  injectivity count and a predecessor estimate into one paragraph.

## OVER-EXPLAINED (safe compression candidates for *after* the freeze)

- The "no uniqueness is assumed" reassurance appears in six places (§2, G4.3 ×2,
  G4.8, G4.11.1, R7.2.2, P5.3.2). Two or three would carry the point.
- The "signed intermediate is not actual" reassurance appears in eight places.
- §11 C8.5 restates the §8–§10 route that §9's handoff table already gives.
- §9's initial-embedding table partly duplicates the handoff table beneath it.

**Do not compress before the English freeze.** These repetitions are exactly what
answers a hostile referee's fastest objections, and the brief correctly forbids
aggressive compression at this stage.

## TOO TERSE — needs one explanatory sentence for a referee

| Location | Why | Suggested addition |
|---|---|---|
| §4 G4.9, corner case | Jumps from "the three arms all have the opposite color" to "we apply Proposition B.1" without saying which half of B.1 does the work | "…so all three rows of that colour are arms; COLOR-CAP ≤ 2 is contradicted." |
| §4 G4.9, s=1,a=3 | EN-04's missing antecedent | see the repair in file 01 |
| §8 C8.2.2 | Ξ is defined and used immediately without motivation | one clause: "Ξ measures the k-source shortage of the first-point packet." |
| §8 C8.2.3.3 | The bolded warning "We do not apply this T-window unconditionally to a general EB representation. The canonical k-supply in FI-B is α, not T." is correct but compressed | spell out that FI-B carries α copies of n_k where FI-A carries T |
| §10 E8.3 | "Always, j_*≤R−1" is asserted without its one-line reason | "…since νθ ≥ u+1 by the definition of ν." |
| §7 C8.1.3 | RHO-GAP appears as a bare identity | one clause naming what it is for: "which is what converts the i-fit condition into x ≥ yq₀." |

## Article length and flow (§20 of the brief)

98 pages is **not** classified as a defect. Specific observations only:

- **Exact duplication: none.** Verified mechanically — 0 of Appendix C's 7
  display blocks recurs verbatim in the main text, and Appendix C's pointer table
  correctly redirects the seven former `copy-*` nodes.
- **Avoidable prose repetition:** the two reassurance families listed above.
- **Narrative order:** §7 is titled "A unit root for the chain configuration" but
  its second half (from `#fr-C8.1`) is the CORE input package and its
  consequences — arguably §8 material. A reader looking for "CORE" will not
  expect it under a "unit root" heading. Renaming §7 to "A unit root and the CORE
  input package for the chain configuration" would fix this at zero cost.
- **Better placed in supplement:** nothing. Appendices A–D are all load-bearing,
  and Appendix D is required proof data.

## Two places where the English is *better* than the Japanese

Recorded because they show the conversion was done with judgement, not
mechanically:

- **§6 T6.5.2** — JA writes only 「よって F∈Γ、矛盾」; EN writes "Thus every
  coefficient is nonnegative and F∈Γ, a contradiction." The English states the
  nonnegativity the discipline paragraph promises.
- **§4 M4.2** — JA's 「自然数集合」 is ambiguous about 0; EN's "positive integers"
  is what the argument actually needs (L_A,L_B ≥ 1), and the English keeps the
  *coefficient vectors* correctly labelled "nonnegative" in the same sentence.
