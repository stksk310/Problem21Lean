# 09 — Hostile Referee Attack Map

The following objections were generated after the independent proof reconstruction. “ANSWERED BUT HARD TO FIND” means the answer exists and is mathematically sufficient; it is not automatically an issue severity.

| # | Hostile objection | Classification | Where/why it is answered |
|---:|---|---|---|
| 1 | Is the canonical hypothesis visible enough, or is `t≤4` being claimed unconditionally? | ANSWERED CLEARLY | Abstract, main theorem, and final proof all state/use `F+m-φ∈Γ` for every PF number. |
| 2 | Why is the tail gcd one? | ANSWERED CLEARLY | Canonical/tail reduction explains the reduction and retains the original semigroup data needed afterward. |
| 3 | Why may four PF rows be selected if `Q` might have more than four elements? | ANSWERED CLEARLY | Final proof says explicitly that the classification does not assume the full `Q` has exactly four elements. |
| 4 | Is PATH / TYPE II / CHAIN really exhaustive or merely a list of examples? | ANSWERED CLEARLY | Classification states “reduces exhaustively” and records the preceding structural exclusions. |
| 5 | Where did the historical SQ / Type I branches go? | ANSWERED BUT HARD TO FIND | Their underlying structural configurations are eliminated before the final terminal list; the publication manuscript does not preserve campaign labels. |
| 6 | Does Proposition B.1 actually support the classification step? | ANSWERED CLEARLY | It remains formally packaged in Appendix B and is directly anchored/referenced from the geometry argument. |
| 7 | Does COLOR-CAP silently discard a boundary color case? | ANSWERED CLEARLY | Its structural role and the selected-row exclusions are explicit in the classification/final proof. |
| 8 | Does PATH use “by symmetry” without swapping all asymmetric parameters? | FALSE ALARM | Full color-reversal data are displayed/referenced; parameters are relabeled consistently. |
| 9 | Does TYPE II accidentally assume an actual return from the other arm? | FALSE ALARM | The English text explicitly says that return is not required. |
| 10 | Are CHAIN first-point hypotheses carried into the abstract Euclidean theorem? | FALSE ALARM | Handoff table says `q0=2`, first point, `N=ζ̂+1` are not inherited after initial packet construction. |
| 11 | Is first-point minimality secretly used after descent? | FALSE ALARM | Section 10 explicitly says it is not required. |
| 12 | Are the two packet equalities actual/genuine, or only signed identities? | ANSWERED CLEARLY | Packet nonnegativity/genuineness is stated before E8 is invoked. |
| 13 | Is criticality applied to a relation that still contains `m`? | FALSE ALARM | Global and local text says the `m`-coordinate is eliminated first. |
| 14 | At terminal descent, is the replacement inside the same element `W`? | ANSWERED CLEARLY | SAME-`W` containment is a named terminal requirement and is proved coefficientwise. |
| 15 | Does the final `F∈Γ` contradiction use a signed vector with a negative coefficient? | FALSE ALARM | Final representation is explicitly nonnegative. |
| 16 | Is the Euclidean descent occurring in a new semigroup rather than the original `Γ`? | FALSE ALARM | Preservation table and final proof retain the original `Γ,F,m,W`. |
| 17 | Why does the Euclidean process terminate? | ANSWERED CLEARLY | `𝓜=E+χ` is a positive integer and the exact strict decrement is displayed. |
| 18 | Are the 715- and 3234-monomial tables merely finite computational sampling? | FALSE ALARM | Appendix D explicitly says they are complete polynomial coefficient identities, not a finite semigroup scan. |
| 19 | What happens at `w=0`? | ANSWERED CLEARLY | Initial embedding loses no `w=0` case; nonterminal failure forces `w≥1`, so `w=0` is terminal. |
| 20 | What happens at `Δ0=1`? | ANSWERED CLEARLY | Explicit “no cases are lost” statement includes `Δ0=1`; boundary treatment also includes it. |
| 21 | What happens at `C=α`? | ANSWERED CLEARLY | Dedicated boundary synchronization/multiplicity closure; strict-region caps are explicitly not imported. |
| 22 | What happens at `q0=2`? | ANSWERED CLEARLY | Nonlinear first point is closed; surviving first point is forced to `N=z+1`, then embedded into the residual packet analysis. |
| 23 | What about `g=0` or `α=0`, where positivity may degenerate? | ANSWERED CLEARLY | Boundaries are retained; signed intermediates are qualified and final nonnegative representations are checked. |
| 24 | Are determinant-one extremal parameters covered or is there an unstated strict interior assumption? | ANSWERED CLEARLY | Determinant-one/integrality/order assumptions are stated and the positivity domains do not introduce a hidden stronger determinant hypothesis. |
| 25 | Are historical theorem numbers in citations being asserted without verification? | FALSE ALARM | The manuscript explicitly disclaims unverified historical-original theorem numbers and gives the supporting reference locations actually used. |

## Referee-attack conclusion

```text
VALID unresolved objections:      0
ANSWERED CLEARLY:                16
ANSWERED BUT HARD TO FIND:        1
FALSE ALARM after checking:        8
```

The single “hard to find” item concerns historical campaign labels rather than a missing mathematical branch. It does not warrant a repair before freeze because the publication proof is self-contained in structural language.
