# 02 — Japanese → English Fidelity Audit

## Method

The English manuscript was first read independently. Only afterward was it compared with the Japanese final manuscript. Displayed mathematics was extracted in order, normalized only for whitespace and harmless language inside `\text{...}`, and compared. Logical-force vocabulary was then checked around load-bearing statements, with special attention to positivity, exact inequalities, uniqueness, implication direction, quantifiers, and actualness.

## Formula transfer

| Item | Japanese | English | Verdict |
|---|---:|---:|---|
| Display-math instances | 791 | 791 | PASS |
| Ordered display matches after harmless normalization | — | 791/791 | PASS |
| Equation tags | 229 | 229 | PASS — identical sequence |
| HTML/publication anchors | 242 | 242 | PASS — identical set/order, no duplicates |

No missing display, changed sign, reversed inequality, changed subscript/superscript, altered quantifier/range, or changed equation tag was found.

Inline mathematics was compared segment-by-segment around corresponding anchors. The only source token not literally repeated as the same token in the corresponding English segment was a harmless lexical localization in `fr-C8.2.3.1`: Japanese `$k$ の追加だけで` is rendered as “using only additional copies of `$n_k$`”. The referent is made more explicit; mathematical force is unchanged.

## Logical-force table

| Load-bearing content | Japanese → English result | Force verdict |
|---|---|---|
| Main canonical hypothesis `F+m-φ∈Γ (∀φ∈PF)` | Preserved explicitly | EXACT |
| `t(Γ)≤4` / `|Q|≤3` conclusion | Preserved | EXACT |
| Positive vs nonnegative coefficients | Preserved in final actual-factorization steps | EXACT |
| Exhaustive terminal classification | English says “reduces exhaustively to PATH, TYPE II, or CHAIN” | EXACT |
| PATH endpoint/level inequalities | Preserved | EXACT |
| TYPE II arm/range hypotheses | Preserved | EXACT |
| CHAIN unit-root/CORE handoff | Preserved | EXACT |
| `C=α` boundary vs `C>α` strict region | Scope separation preserved | EXACT |
| `q0=2` / first-point split | Preserved | EXACT |
| `1≤θ≤υ` residual range | Preserved | EXACT |
| Two packet equalities and positivity hypotheses | Preserved | EXACT |
| Determinant-one assumptions | Preserved | EXACT |
| Euclidean terminal/nonterminal dichotomy | Preserved | EXACT |
| Termination measure `𝓜=E+χ` | Preserved as a positive integer, strictly decreasing | EXACT |
| SAME-`W` source containment | Preserved | EXACT |
| Historical citation-number disclaimer | Preserved | EXACT |

## Mathematical-force changes

\[
\boxed{\textbf{MATHEMATICAL-FORCE CHANGES}=0}
\]

English sentence restructuring improves readability without changing implication direction, domain, range, positivity, exactness, or proof scope.

## Dependency-node transfer

The English `supplement/FROZEN_NODE_MAP.json` contains 42 maintained nodes. The frozen authoritative `APPENDICES/DEPENDENCY_LEDGER.json` contains the same 42 nodes. For each node, the audited fields `id`, `statement`, `scope`, `depends_on`, `used_in`, and `location` agree exactly.

```text
C2, S3, G4.1, G4.2, G4.3, G4.4, G4.5, G4.5.1, M4,
G4.5.2, G4.5.3, G4.6, G4.7, G4.8, A1, A2, G4.9,
G4.11.1, G4.11.2, G4.11.3, G4.11.4, P5.1, P5.2,
P5.3, P5.4, P5.5, P5.6, P5.7, T6, R7, C8.1, C8.2,
A3, C8.3, A4.1, C8.4, A4.2, E8, E8.2.3, C8.5, I9, T1
```

\[
\boxed{42/42}
\]

The corresponding English anchor segments retain their outgoing internal references and their display mathematics. No node changes proof role.
