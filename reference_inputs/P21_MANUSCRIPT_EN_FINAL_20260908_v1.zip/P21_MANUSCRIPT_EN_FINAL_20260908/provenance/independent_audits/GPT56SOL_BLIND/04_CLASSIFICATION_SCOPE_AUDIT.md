# 04 — Classification and Scope Audit

## Nonsymmetric terminal classification

The English manuscript proves an exhaustive classification rather than listing examples:

\[
\boxed{\mathrm{PATH}\vee\mathrm{TYPE\ II}\vee\mathrm{CHAIN}.}
\]

The classification section explicitly removes the competing structural configurations, invokes the required THREE-ARM / COLOR-CAP / Proposition B.1 machinery, and then states exhaustiveness. The final theorem proof summarizes the same logic and emphasizes that selecting four rows does not assume the whole set `Q` has cardinality four.

### Historical SQ / Type I

The publication manuscript does not need the historical working labels “SQ” and “Type I” as terminal labels. Their underlying configurations are accounted for by the structural elimination preceding the final three-way list: the three-singleton case is handled separately, corner-containing four-row configurations are removed by COLOR-CAP, and matched-pair-plus-singleton coexistence is excluded. Thus the mathematical elimination survives even where the historical campaign names are not reader-facing labels.

## PATH

PASS. The endpoint statements, exact level inequalities, return/factorization arguments, and final contradiction remain scoped to actual representations. Full color reversal is explicit where required. No “positive”/“nonnegative” mistranslation was found in a load-bearing PATH step.

## TYPE II

PASS. The input package retains the one-singleton configuration, arm data, the required range restrictions (including the relevant `λ≤b_i` condition), and the fact that an actual return from the other arm is not silently assumed when not required. The closure is stated as an impossibility theorem, not a heuristic comparison.

## CHAIN → CORE → CENTRAL scope

The dedicated handoff table is one of the strongest parts of the English manuscript. It explicitly distinguishes:

- quantities inherited from the original CHAIN configuration;
- CORE/CENTRAL-only constructions;
- the `D`-specific first-point conditions used solely to construct the initial packet pair;
- the abstract Euclidean input package;
- what remains invariant after a nonterminal descent step.

The manuscript states that first-point data, `q0=2`, and `N=ζ̂+1` are **not inherited** as Euclidean-domain assumptions after the initial embedding. It also states that the minimality of the preceding first point is not required by the Euclidean descent.

\[
\boxed{\textbf{CHAIN→CENTRAL ENGLISH SCOPE VERDICT: PASS}}
\]

No D-specific assumption is accidentally strengthened into an assumption of the abstract Euclidean theorem.

## Classification verdict

```text
Terminal list exhaustive: PASS
Historical intermediate eliminations represented: PASS
PATH closure: PASS
TYPE II closure: PASS
CHAIN→CORE handoff: PASS
CHAIN→CENTRAL scope: PASS
```
