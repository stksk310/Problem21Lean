# 03 — Mathematical-Force Audit

## Theorem scope

The English theorem is correctly conditional. It states a four-minimal-generator numerical semigroup with least positive element `m`, Frobenius number `F`, and the canonical-reduction hypothesis

\[
F+m-\varphi\in\Gamma\qquad(\forall\varphi\in PF(\Gamma)),
\]

and concludes `t(Γ)≤4`. The abstract, theorem statement, proof spine, and final contradiction all retain this condition. No sentence was found that reasonably converts the result into an unconditional theorem for all embedding-dimension-four numerical semigroups.

## Frozen mathematics comparison

The frozen proof master contains 781 displayed mathematical instances. Against the English manuscript:

- 779 agree after basic whitespace normalization;
- the remaining two are TeX-syntax-only equivalents:
  - `\ker_\mathbb Z` vs `\ker_{\mathbb Z}`;
  - `\frac H_u\eta` vs `\frac{H_u}{\eta}`.

Additional English displays correspond to Japanese publication/expository material (including direct appendix anchors and certificate-defining expressions), rather than changed frozen mathematics.

## Canonical reduction

PASS. The English manuscript keeps visible:

- `W=F+m`;
- the pseudo-Frobenius rows and complements;
- tail support and the tail semigroup `H`;
- the tail gcd reduction;
- the selected four-row setup;
- the minimally three-generated tail structure;
- the contradiction mechanism when an `m`-containing representation would force a forbidden semigroup membership.

The tail reduction is not presented as a purely formal change of generators; the relation to the original `Γ`, `F`, `m`, and `W` remains explicit.

## Exhaustive classification force

PASS. The key English sentence is unambiguous: every actual four-row nonsymmetric counterexample “reduces exhaustively to PATH, TYPE II, or CHAIN.” The final proof repeats the structural exclusions and states that the classification does not assume that the full set `Q` has exactly four elements.

## Actuality and coefficientwise force

PASS. The manuscript establishes an explicit global discipline near the start:

> an actual factorization has nonnegative integer coefficients; a signed equality is not by itself an actual factorization; final contradiction vectors have their nonnegativity stated.

This discipline is then applied locally. Signed intermediate identities in boundary cases are not promoted to actual representations before completion. Whenever `F∈Γ` is concluded, the final representation is coefficientwise nonnegative.

## Criticality force

PASS. Bare three-generated criticality is used only after the `m`-coordinate has been eliminated. The text explicitly reiterates this at multiple critical applications, including the statements that the coefficient of `m` has been zero throughout and that criticality was used only in the pure-tail regime.

## Color-reversal force

PASS. Color reversal is not used as a vague “by symmetry” shortcut where asymmetric parameters matter. The relevant parameter/index transformations are displayed or referenced as a complete package; `Γ,F,m,W` are preserved and the exchanged asymmetric quantities are relabeled consistently.

## Force verdict

```text
Lost hypothesis:                0
Changed conclusion:             0
Changed inequality direction:   0
Changed quantifier with effect: 0
Signed→actual promotion error:  0
Illegitimate criticality:       0
Scope leakage:                  0
```

\[
\boxed{\textbf{MATHEMATICAL-FORCE AUDIT: PASS}}
\]
