# 07 — Positivity Certificates, Appendices, Build, and Package Integrity

## Symbolic positivity certificates

Both supplied proof verifiers were executed from an extracted working copy.

### D-linear certificate

```text
status: PASS
identities: 28/28
positive monomials: 715
constant term c0: 35
```

### Euclidean certificate

```text
status: PASS
identities: 35/35
positive monomials: 3234
constant term c0: 63
minimum coefficient: 1
total degree: 7
```

The English manuscript accurately describes these as complete symbolic all-parameter coefficient certificates, not a finite numerical scan of semigroups. Appendix D gives the defining substitutions/expressions, the static coefficient-table paths, and the reproduction commands.

## Appendix audit

- Appendix B direct anchors: present and internally linked.
- Proposition B.1: formally stated and referenced by the classification argument.
- Appendix C: does not restore the deleted exact duplicates; it presents only the retained intrinsic positivity polynomials and points back to authoritative main-text locations.
- Appendix D: static tables, command paths, and computational-assistance disclosure are present.
- Supplement paths used by the manuscript resolve in the package.
- No appendix theorem was found to be silently used without statement/reference.

## Markdown/anchor/link audit

After excluding TeX math regions from Markdown-link parsing (necessary because expressions such as `[...](Q-2)` are mathematical products, not links):

```text
HTML anchors:             242
unique anchors:           242
duplicate anchors:        0
internal # links:         176
broken internal links:    0
real local supplement links: 4
broken local supplement links: 0
```

The four real local supplement links are the two static coefficient tables and the two verifier scripts.

## Independent LaTeX/PDF rebuild

Rebuild sequence on a working copy:

```bash
python3 supplement/typeset_english.py
xelatex -interaction=nonstopmode -halt-on-error P21_MANUSCRIPT_EN.tex
bibtexu P21_MANUSCRIPT_EN
xelatex -interaction=nonstopmode -halt-on-error P21_MANUSCRIPT_EN.tex
xelatex -interaction=nonstopmode -halt-on-error P21_MANUSCRIPT_EN.tex
```

Result:

```text
Build:                 PASS
Pages:                 98
Page size:             A4 (595.28 × 841.89 pt)
Undefined references:  0
Undefined citations:   0
Overfull boxes:        0
Missing glyphs:        0
Severe underfull:      0
Moderate underfull:    2 (badness 4872, 2142; same Appendix-D path paragraph)
Off-page text blocks:  0
```

All 98 rebuilt pages were rasterized for visual inspection. Representative theorem, classification, CHAIN→CENTRAL handoff, Euclidean, Appendix B/C, and Appendix D pages showed no clipping, black boxes, missing glyphs, or broken layout. The reported 98-page geometry is reproduced.

## Input ZIP / manifest audit

All three uploaded ZIPs passed `unzip -t` and all listed SHA-256 entries passed `sha256sum -c`.

| Package | Manifest entries | Verdict |
|---|---:|---|
| English | 178 | PASS |
| Japanese final | 194 | PASS |
| Frozen verification | 69 | PASS |

Uploaded ZIP SHA-256 values:

```text
P21_MANUSCRIPT_EN_20260908.zip
45908a1ba093ab371c812c509465ec794120fe98e36dbf76b556f316b564bdef

P21_MANUSCRIPT_JA_FINAL_20260908.zip
ba1b5190758329c2e64e40db4d195681a137e32d6d4c4dd6992817f7133e425d

P21_FINAL_FROZEN_VERIFICATION_EDITION_20260907(2).zip
f98436c59bf735444e75cc0a133a8ac128ba7c69c049e97da9593a3aeab64bc8
```

## Embedded-source provenance

- English `supplement/frozen_source/`: 70 files compared against the separate frozen package snapshot; **70/70 byte-identical** for the matched frozen source set.
- English `supplement/ja_source_snapshot/`: 16 publication-source files compared against the corresponding Japanese final package files; **16/16 byte-identical**.
- Package README/changelog describe the same source hierarchy and rebuild/verifier paths actually present in the archive.

No manuscript content in the uploaded archive was modified. Rebuilds and verifier runs were performed only in an extracted audit working copy.

\[
\boxed{\textbf{CERTIFICATE / BUILD / INTEGRITY AUDIT: PASS}}
\]
