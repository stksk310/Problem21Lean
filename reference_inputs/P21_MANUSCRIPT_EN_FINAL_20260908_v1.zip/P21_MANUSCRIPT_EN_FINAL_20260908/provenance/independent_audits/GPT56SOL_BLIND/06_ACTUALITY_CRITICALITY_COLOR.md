# 06 — Actuality, Criticality, and Color-Reversal Audit

## Actual vs signed language

This was treated as a high-priority adversarial search. The manuscript uses “factorization”, “representation”, “actual”, “genuine”, “signed”, “packet”, “replace”, “subtract”, and “remove” with the required distinctions.

### Global safeguard

Near the beginning, English explicitly defines an actual factorization as a generator representation with all coefficients nonnegative integers and says a signed equality / completed-zero identity is not enough. It also states that final contradiction vectors have their nonnegativity checked.

### Local stress points

- `α=0`: signed intermediate identities are identified as signed; only the completed nonnegative expression is used as actual.
- `g=0`: same safeguard.
- other zero/boundary remainders: signed rows are not promoted prematurely.
- CENTRAL packet construction: both sides of the genuine packet are nonnegative before packet status is claimed.
- Euclidean nonterminal step: the new packet is explicitly genuine.
- Euclidean terminal step: replacement is coefficientwise inside a representation of the same `W`, followed by an explicit nonnegative representation of `F`.

No conclusion `F∈Γ` or pseudo-Frobenius-gap membership is based only on a signed completed identity.

\[
\boxed{\textbf{ACTUALITY AUDIT: PASS}}
\]

## Criticality

Bare criticality is consistently restricted to pure tail relations. English explicitly states:

- the `m`-coefficient has been zero throughout at a critical application;
- criticality is legitimate for that reason;
- elsewhere, “Criticality was used only in PURE-K, after the m-coordinate had been completely eliminated.”

No sentence was found applying the three-generated critical multiplier to a relation still containing `m`.

\[
\boxed{\textbf{CRITICALITY AUDIT: PASS}}
\]

## Color reversal

Every proof-critical invocation of color reversal either displays or points to the full exchange package. The transformation preserves the underlying semigroup data and correctly swaps asymmetric arm/packet quantities. No parameter was found silently retaining its pre-reversal semantic role.

The Euclidean color exchange is especially explicit: it is part of the nonterminal transformation theorem and is accompanied by determinant/domain/source preservation.

\[
\boxed{\textbf{COLOR-REVERSAL AUDIT: PASS}}
\]

## Boundary stress test

| Boundary | Coverage found | Verdict |
|---|---|---|
| `d=1` | included in the exact range used in the relevant argument; no hidden `d≥2` later | PASS |
| `q0=2` | explicit section; nonlinear first point closed, then `N=z+1` | PASS |
| `C=α` | separate boundary theorem; not fed strict-region inequalities | PASS |
| `w=0` | initial embedding says no cases lost; nonterminal failure implies `w≥1`, hence `w=0` terminal | PASS |
| `Δ0=1` | explicitly included in “no cases lost” statement and boundary closure | PASS |
| `g=0` | retained; signed intermediate qualified | PASS |
| `α=0` | retained; signed intermediate qualified | PASS |
| determinant-one extremal parameters | positivity/integrality domain preserved; no hidden stronger determinant assumption | PASS |
| color-reversal boundaries | full parameter package retained | PASS |

No boundary case exhibited “positive” where only “nonnegative” was source-justified in a way that changes the proof.
