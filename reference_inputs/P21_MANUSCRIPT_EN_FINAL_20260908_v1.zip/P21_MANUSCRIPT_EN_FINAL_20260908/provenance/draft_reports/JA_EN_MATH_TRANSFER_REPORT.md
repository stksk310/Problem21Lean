# Japanese-to-English mathematics transfer report

Japanese freeze: `P21-MANUSCRIPT-JA-FINAL-20260908-v1`  
English draft: `P21-MANUSCRIPT-EN-DRAFT-20260908-v1`

## Results

- Japanese display-math instances: **791**
- English display-math instances: **791**
- Exact display differences before authorized label localization: **2**
- Those two differences are reader-facing text labels only: `\text{または}` → `\text{or}` in Sections 3 and 5. Mathematical symbols, order, signs, indices, and tags are unchanged.
- Display differences after this authorized text-label localization: **0**
- Japanese inline-math source expressions missing from English: **0**
- Frozen verification-master math instances checked: **1589**
- Frozen verification-master math missing from English after the same text-label normalization: **0**
- English source math instances transferred to TeX: **3454**
- English source math missing from generated TeX: **0**

## Verdict

```text
Japanese frozen math missing from English = 0
Japanese → English math transfer = PASS
English source → TeX math transfer = PASS
Mathematical changes = 0
```

Method: display blocks were kept in source order and copied from the frozen Japanese publication source; inline source expressions were checked as a multiplicity-aware normalized multiset. Generated TeX was checked against every Markdown math instance using the same canonicalization rules as the frozen regression pipeline. Machine-readable results are in `supplement/english_verification/math_transfer_results.json`.
