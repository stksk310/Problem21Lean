# English fidelity ledger

Japanese freeze: `P21-MANUSCRIPT-JA-FINAL-20260908-v1`  
English draft: `P21-MANUSCRIPT-EN-DRAFT-20260908-v1`

## Major-module fidelity

| Module | Japanese source | English location | Math changed? | Hypotheses preserved? | Result |
|---|---|---|---|---|---|
| Main theorem | sections/01.md, `fr-T1` | Section 1, `fr-T1` | **NO** | Yes | **PASS** |
| Canonical reduction | sections/02.md, `fr-C2` | Section 2, `fr-C2` | **NO** | Yes | **PASS** |
| SYM | sections/03.md, `fr-S3` | Section 3, `fr-S3` | **NO** | Yes | **PASS** |
| Nonsymmetric classification | sections/04.md, `fr-G4.9` | Section 4, `fr-G4.9` | **NO** | Yes | **PASS** |
| PATH | sections/05.md, `fr-P5.0`–`fr-P5.7` | Section 5, same anchors | **NO** | Yes | **PASS** |
| TYPE II | sections/06.md, `fr-T6`–`fr-T6.5.3` | Section 6, same anchors | **NO** | Yes | **PASS** |
| CHAIN CORE | sections/07.md, `fr-R7`, `fr-C8.1` | Section 7, same anchors | **NO** | Yes | **PASS** |
| CENTRAL entry | sections/07.md, `fr-C8.1.0`–`fr-C8.1.5` | Section 7, same anchors | **NO** | Yes | **PASS** |
| Boundary / window | sections/08.md, `fr-C8.2`–`fr-C8.2.12` | Section 8, same anchors | **NO** | Yes | **PASS** |
| U | sections/09.md, `fr-C8.3`–`fr-C8.3.4` | Section 9, same anchors | **NO** | Yes | **PASS** |
| D | sections/09.md, `fr-C8.4`–`fr-C8.4.8` | Section 9, same anchors | **NO** | Yes | **PASS** |
| Euclidean theorem | sections/10.md, `fr-E8`–`fr-E8.6.4` | Section 10, same anchors | **NO** | Yes | **PASS** |
| Final integration | sections/11.md, `fr-C8.5`, `fr-I9` | Section 11, same anchors | **NO** | Yes | **PASS** |
| Proposition B.1 | appendices/B.md, `prop-B1` | Appendix B, `prop-B1` | **NO** | Yes | **PASS** |

## Maintained dependency nodes

All **42/42** maintained nodes in `FROZEN_NODE_MAP.json` are represented by their prescribed publication anchors in the English source. No publication anchor is missing.

| Node | English publication file | Anchor | Represented |
|---|---|---|---|
| `C2` | `sections/02.md` | `fr-C2` | PASS |
| `S3` | `sections/03.md` | `fr-S3` | PASS |
| `G4.1` | `sections/04.md` | `fr-G4.1` | PASS |
| `G4.2` | `sections/04.md` | `fr-G4.2` | PASS |
| `G4.3` | `sections/04.md` | `fr-G4.3` | PASS |
| `G4.4` | `sections/04.md` | `fr-G4.4` | PASS |
| `G4.5` | `sections/04.md` | `fr-G4.5` | PASS |
| `G4.5.1` | `sections/04.md` | `fr-G4.5.1` | PASS |
| `M4` | `sections/04.md` | `fr-M4` | PASS |
| `G4.5.2` | `sections/04.md` | `fr-G4.5.2` | PASS |
| `G4.5.3` | `sections/04.md` | `fr-G4.5.3` | PASS |
| `G4.6` | `sections/04.md` | `fr-G4.6` | PASS |
| `G4.7` | `sections/04.md` | `fr-G4.7` | PASS |
| `G4.8` | `sections/04.md` | `fr-G4.8` | PASS |
| `A1` | `appendices/B.md` | `fr-A1.1` | PASS |
| `A2` | `appendices/B.md` | `fr-A2.0` | PASS |
| `G4.9` | `sections/04.md` | `fr-G4.9` | PASS |
| `G4.11.1` | `sections/04.md` | `fr-G4.11.1` | PASS |
| `G4.11.2` | `sections/04.md` | `fr-G4.11.2` | PASS |
| `G4.11.3` | `sections/04.md` | `fr-G4.11.3` | PASS |
| `G4.11.4` | `sections/04.md` | `fr-G4.11.4` | PASS |
| `P5.1` | `sections/05.md` | `fr-P5.1` | PASS |
| `P5.2` | `sections/05.md` | `fr-P5.2` | PASS |
| `P5.3` | `sections/05.md` | `fr-P5.3` | PASS |
| `P5.4` | `sections/05.md` | `fr-P5.4` | PASS |
| `P5.5` | `sections/05.md` | `fr-P5.5` | PASS |
| `P5.6` | `sections/05.md` | `fr-P5.6` | PASS |
| `P5.7` | `sections/05.md` | `fr-P5.7` | PASS |
| `T6` | `sections/06.md` | `fr-T6` | PASS |
| `R7` | `sections/07.md` | `fr-R7` | PASS |
| `C8.1` | `sections/07.md` | `fr-C8.1` | PASS |
| `C8.2` | `sections/08.md` | `fr-C8.2` | PASS |
| `A3` | `appendices/C.md` | `fr-A3` | PASS |
| `C8.3` | `sections/09.md` | `fr-C8.3` | PASS |
| `A4.1` | `appendices/D.md` | `fr-A4.1` | PASS |
| `C8.4` | `sections/09.md` | `fr-C8.4` | PASS |
| `A4.2` | `appendices/D.md` | `fr-A4.2` | PASS |
| `E8` | `sections/10.md` | `fr-E8` | PASS |
| `E8.2.3` | `sections/09.md` | `fr-E8.2.3` | PASS |
| `C8.5` | `sections/11.md` | `fr-C8.5` | PASS |
| `I9` | `sections/11.md` | `fr-I9` | PASS |
| `T1` | `sections/01.md` | `fr-T1` | PASS |

## Sentence-level logical-force risk review

The English source was searched for force-bearing terms requested in the conversion specification. All hits were reviewed in context after mathematical formula transfer had been locked. No usage was found that changes a strict/non-strict inequality, positivity condition, uniqueness assertion, implication, converse, or cardinality bound relative to the Japanese source.

| Term | Occurrences reviewed | Result |
|---|---:|---|
| positive | 132 | PASS |
| nonnegative | 112 | PASS |
| strictly | 11 | PASS |
| at most | 18 | PASS |
| less than | 4 | PASS |
| no greater than | 0 | PASS |
| exactly | 31 | PASS |
| unique | 10 | PASS |
| only | 81 | PASS |
| if | 260 | PASS |
| if and only if | 1 | PASS |
| unless | 0 | PASS |
| therefore | 66 | PASS |
| conversely | 5 | PASS |

Machine-readable contexts: `supplement/english_verification/sentence_risk_scan.json`.

## English-only referee read

- **Theorem scope immediately clear:** PASS — embedding dimension four and the canonical pseudo-Frobenius condition are visible in the abstract, introduction, main theorem, and final integration.
- **Introduction explains proof strategy:** PASS — two-layer reduction, three terminal configurations, CHAIN/CENTRAL handoff, and Euclidean descent are summarized.
- **Classification understandable and exhaustive:** PASS — PATH / TYPE II / CHAIN is stated as an exhaustive reduction, not a heuristic list.
- **CHAIN to CENTRAL transparent:** PASS — the dedicated handoff table is retained verbatim in structure.
- **Euclidean argument conceptually readable:** PASS — packet meaning, terminal fit, transformation, preserved conditions, and the decreasing measure are separated.
- **Actual vs signed relations distinguishable:** PASS — the representation firewall and SAME-element wording remain explicit.
- **Computational assistance honestly described:** PASS — coefficient-table verification is separated from the mathematical proof of scope, actuality, and termination.
- **No machine-translation residue:** PASS — no Japanese script remains in the English source; awkward process jargon was removed in the final style pass.
- **No project-history dependency in prose:** PASS — reader-facing prose does not presuppose the research process; reproducibility metadata is confined to the appropriate sections.
- **No mathematics changed during style pass:** PASS.
