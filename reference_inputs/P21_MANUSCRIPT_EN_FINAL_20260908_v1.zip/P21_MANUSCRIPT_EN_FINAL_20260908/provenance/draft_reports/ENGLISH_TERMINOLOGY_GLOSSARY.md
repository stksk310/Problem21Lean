# English terminology glossary

Japanese freeze: `P21-MANUSCRIPT-JA-FINAL-20260908-v1`  
English draft: `P21-MANUSCRIPT-EN-DRAFT-20260908-v1`

Publication terminology is separated from internal audit terminology. Internal freeze/verification terms are not used as reader-facing mathematical vocabulary unless they are necessary to describe supplementary reproducibility data.

| Japanese / project wording | Frozen mathematical meaning | Preferred English | Status |
|---|---|---|---|
| 数値半群 | A cofinite additive submonoid of the nonnegative integers. | numerical semigroup | Publication |
| 擬Frobenius数 / pseudo-Frobenius元 | A gap q such that q+s lies in the semigroup for every nonzero semigroup element s. | pseudo-Frobenius number | Publication |
| Frobenius数 | The largest integer not in the numerical semigroup. | Frobenius number | Publication |
| 埋め込み次元 | The cardinality of the minimal generating set. | embedding dimension | Publication |
| multiplicity | The least positive element of the numerical semigroup. | multiplicity | Publication |
| Apéry集合 | The Apéry set with respect to the indicated generator. | Apéry set | Publication |
| actual factorization | A representation by the generators with every coefficient a nonnegative integer. | actual factorization | Publication; explicitly defined |
| genuine factorization | An actual/nonnegative representation whose coefficient signs have been verified. | genuine factorization | Publication; used as a sign-status safeguard |
| signed relation | An integer linear equality whose coefficients need not all be nonnegative. It is not automatically a factorization. | signed relation / signed identity | Publication; firewall term |
| completed zero identity | A zero relation added to an equality; still not an actual factorization until signs are checked. | completed zero identity | Publication; firewall term |
| complement | For q in Q, the element c_q=F+m-q supplied by the canonical condition. | complement | Publication |
| selected row | A chosen pseudo-Frobenius row/factorization datum in the classification. | selected row | Publication when formally identified |
| tail | The three-generated subsemigroup H=<n_1,n_2,n_3>. | three-generated tail | Publication |
| critical relation | A pure-H minimal critical relation, used only after the m-coordinate has been eliminated. | critical relation | Publication |
| critical multiplier | The minimal positive multiplier in the corresponding tail critical relation. | critical multiplier | Publication |
| color reversal | The odd permutation together with the simultaneous a/b exchange, with the full parameter map stated where used. | color reversal | Publication; formal involution |
| matched pair | A formally defined pair of A_i/B_i arms in the same direction whose return data synchronize. | matched pair | Publication |
| arm | One of the six formally defined nonsymmetric pseudo-Frobenius families. | arm | Publication; formally defined |
| packet | A nonnegative source relation used coefficientwise inside the same actual element. | packet | Publication; formally defined |
| source packet | A packet regarded as the coefficient source for a SAME-element replacement. | source packet | Publication where needed |
| first fit / first crossing | The first index/state at which the stated coefficient fit/crossing inequality is satisfied. | first fit / first crossing | Publication only where explicitly defined |
| terminal state | A Euclidean state satisfying the terminal source-fit condition. | terminal state | Publication |
| Euclidean descent | The state transformation preserving the abstract package while strictly decreasing the positive integer measure M=E+chi. | Euclidean descent | Publication |
| source-fit | Coefficientwise containment of the required source inside the named actual representation. | source fit / source-fit | Publication |
| SAME-element | A reminder that replacement occurs within a factorization of the same actual semigroup element, not by formal subtraction of unrelated identities. | same element / SAME-element | Publication safeguard; capitalization retained only in load-bearing warnings |
| PATH / TYPE II / CHAIN | The three exhaustive terminal configurations defined by the nonsymmetric classification. | PATH / TYPE II / CHAIN | Publication; formally defined labels |
| CORE / CENTRAL | Named intermediate packages in the CHAIN closure, with their hypotheses explicitly handed off. | CORE / CENTRAL | Publication because formally defined and used in the handoff table |
| U / D | Formally defined residual regions in the CENTRAL analysis. | \mathcal U / \mathcal D | Publication only after definition |
| frozen | Internal status meaning mathematically/editorially locked source. | frozen | Internal audit metadata; omitted from reader-facing prose unless unavoidable |
| maintained node | A dependency node tracked in the verification ledger. | maintained dependency node | Internal audit metadata |
| verification edition | The authoritative proof package controlling mathematical correctness. | frozen verification edition | Internal audit metadata |
