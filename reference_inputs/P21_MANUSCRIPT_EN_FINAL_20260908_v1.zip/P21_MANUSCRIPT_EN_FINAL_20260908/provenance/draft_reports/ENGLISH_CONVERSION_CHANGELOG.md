# English conversion changelog

Japanese freeze ID: `P21-MANUSCRIPT-JA-FINAL-20260908-v1`

English draft ID: `P21-MANUSCRIPT-EN-DRAFT-20260908-v1`

## Change classes

- **Translation only:** Japanese mathematical prose converted to natural specialist English.
- **Sentence restructuring:** Japanese clause order was reorganized where necessary for standard mathematical English; logical order was not changed.
- **Terminology normalization:** recurring terms were standardized using `ENGLISH_TERMINOLOGY_GLOSSARY.md`.
- **Cross-reference localization:** all 232 mathematical/publication anchors were retained unchanged.
- **TeX formatting:** neutral English preprint typography, English theorem/proof labels, breakable long reproducibility paths, and two reader-facing math-text labels localized from `または` to `or`.
- **Style pass:** literal/Japanese discourse patterns and unnecessary internal freeze terminology were removed from reader-facing prose.
- **Mathematical change:** **none**. No hypothesis, conclusion, equation, classification branch, descent step, positivity identity, criticality scope, or canonical condition was altered.

## Fixed safeguards retained

- signed relation ≠ actual factorization;
- coefficient nonnegativity is stated when a final representation is used;
- criticality is invoked only after elimination of the `m`-coordinate;
- full color-reversal transformations are displayed;
- Proposition B.1 remains formally packaged;
- the CHAIN→CORE→CENTRAL→Euclidean handoff table is retained;
- Appendix C does not restore the seven duplicates removed before Japanese freeze;
- Appendix D preserves reproducibility commands and the computational-assistance disclosure.

```text
Mathematical changes = 0
```
