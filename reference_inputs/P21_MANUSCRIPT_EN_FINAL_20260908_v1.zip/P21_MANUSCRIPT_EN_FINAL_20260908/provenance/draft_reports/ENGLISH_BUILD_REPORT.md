# English build report

English draft: `P21-MANUSCRIPT-EN-DRAFT-20260908-v1`

## Toolchain

- Pandoc 3.1.11.1
- XeLaTeX / TeX Live 2025/dev
- BibTeXu 0.99d-x4.02
- Neutral `article` preprint layout; no journal template.

## Build commands

```bash
python3 supplement/typeset_english.py
xelatex -interaction=nonstopmode -halt-on-error P21_MANUSCRIPT_EN.tex
bibtexu P21_MANUSCRIPT_EN
xelatex -interaction=nonstopmode -halt-on-error P21_MANUSCRIPT_EN.tex
xelatex -interaction=nonstopmode -halt-on-error P21_MANUSCRIPT_EN.tex
```

## Cross-reference and PDF checks

- Undefined references: **0**
- Undefined citations: **0**
- Duplicate Markdown anchors: **0**
- Duplicate TeX labels: **0**
- Broken Markdown internal links: **0**
- Broken local-file links: **0**
- Missing glyphs: **0**
- LaTeX errors: **0**
- Overfull boxes: **0**
- Underfull boxes: **2** (harmless; listed in `supplement/english_build/build3.log`)
- Off-page text blocks in PDF geometry scan: **0**

## Length

The final PDF has **98 physical pages**:

- front matter: **2 pages** (title + contents);
- main text, Sections 1–11: **73 pages** (physical pages 3–75);
- Appendices A–D: **22 pages** (physical pages 76–97);
- references: **1 page** (physical page 98).

## Visual PDF inspection

The PDF was rendered with the project PDF renderer and visually inspected at representative points: title page; main theorem; nonsymmetric classification; the CHAIN→CORE→CENTRAL→Euclidean handoff table; the Euclidean positivity certificate; Proposition B.1; Appendices C–D; and the references page. No clipping, broken glyphs, unreadable equations, or table overflow was observed.

## Package manifest

The root `SHA256SUMS.txt` covers every package file except the manifest itself, including nested source manifests retained for provenance. Final checksum verification reports **0 failures**.

- Manifest: **PASS**

**Build verdict: PASS.**
