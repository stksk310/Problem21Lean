# English manuscript regression report

English draft: `P21-MANUSCRIPT-EN-DRAFT-20260908-v1`

Environment: Python 3.13.5; SymPy 1.14.0. The verifier scripts and coefficient tables are byte-identical to the Japanese final package.

## D-linear verifier

Command:
```bash
python3 supplement/APPENDICES/LINEAR/verify_D_linear.py
```
Output:
```json
{"status": "PASS", "identities": 28, "positive_monomials": 715, "constant": 35}
```

Expected and obtained: **PASS; 28/28 identities; 715 positive monomials; constant term 35.**

## Euclidean verifier

Command:
```bash
python3 supplement/APPENDICES/EUCLIDEAN/verify_euclidean_closure.py
```
Output:
```json
{"status": "PASS", "identities": 35, "positive_monomials": 3234, "constant": 63}
```

Expected and obtained: **PASS; 35/35 identities; 3234 positive monomials; constant term 63.**

## Static proof-data identity

| File | SHA-256 | Byte-identical to Japanese final package? |
|---|---|---|
| `supplement/APPENDICES/LINEAR/I_FIT_POSITIVE_COEFFICIENTS.json` | `9ba4fdcbdc1b5440785232e97e8cf8d729c3cf1254d87551d3a90d9abbff5916` | Yes |
| `supplement/APPENDICES/LINEAR/verify_D_linear.py` | `bcdedc3525a397601fd49704629e221f0e34e6d5ffcdc0c9c8e22d3f25775ae1` | Yes |
| `supplement/APPENDICES/EUCLIDEAN/TERMINAL_POSITIVITY_COEFFICIENTS.json` | `495504b4bcb8427db04b242cf09b83fbe7bde1188f9324b7e977036a5a4db9b3` | Yes |
| `supplement/APPENDICES/EUCLIDEAN/verify_euclidean_closure.py` | `23fcf03275bbe36ef7b9ca78a6cddb6b75dd1f04216d3675fbe0da759b9d048e` | Yes |

**Regression verdict: PASS.**
