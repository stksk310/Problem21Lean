# Input artifact hashes

These hashes identify the five inputs used for the final English freeze. The two audit packages were identified by their **contents**, not merely by filename.

| Role | Uploaded artifact | SHA-256 | Bytes |
|---|---|---|---:|
| English draft | `P21_MANUSCRIPT_EN_20260908(1).zip` | `45908a1ba093ab371c812c509465ec794120fe98e36dbf76b556f316b564bdef` | 1929914 |
| Japanese final freeze | `P21_MANUSCRIPT_JA_FINAL_20260908(1).zip` | `ba1b5190758329c2e64e40db4d195681a137e32d6d4c4dd6992817f7133e425d` | 3672325 |
| Frozen mathematical edition | `P21_FINAL_FROZEN_VERIFICATION_EDITION_20260907(3).zip` | `f98436c59bf735444e75cc0a133a8ac128ba7c69c049e97da9593a3aeab64bc8` | 829768 |
| GPT-5.6 Sol blind English audit | `P21_MANUSCRIPT_EN_AUDIT_GPT56SOL_BLIND(1).zip` | `bb9e0d9f9db07a8852bb14e810cc1f2a2e815dc80e7250171af59148bb0f3c7e` | 20626 |
| Claude Opus 5 blind English audit | `P21_MANUSCRIPT_EN_AUDIT_CLAUDE_OPUS5.zip` | `86cc0042331856df92bdf48afeff4f2b94022c12a5b6dc766015c53c371ce42a` | 49506 |
