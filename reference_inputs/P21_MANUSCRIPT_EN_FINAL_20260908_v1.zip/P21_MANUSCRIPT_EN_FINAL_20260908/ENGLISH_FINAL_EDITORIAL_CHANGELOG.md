# English final editorial changelog

**Freeze:** `P21-MANUSCRIPT-EN-FINAL-20260908-v1`

This changelog records only the authorized zero-mathematics polish between the audited English draft and the final English freeze.

| ID | Location | Final action | Mathematical force |
|---|---|---|---|
| EN-01 | `source/sections/05.md` and mirror | Replaced reader-facing Markdown code spans containing mathematical objects with inline math. Genuine §9 code identifiers remain monospace. | Unchanged |
| EN-02 | `source/sections/09.md` | Added braces in `\frac{H_u}{\eta}`. | Unchanged |
| EN-03 | `source/sections/08.md` | Made the `E_a` coefficient Markdown-safe; render-safety regression also defused the same `](Q-2)` collision in `B_a`. | Unchanged |
| EN-04 | `source/sections/04.md`, G4.9 | Replaced an antecedent-free exclusion phrase with an explicit pointer to the already-proved G4.5.3 matched-pair-plus-singleton exclusion. | Unchanged |
| EN-05 | `source/sections/02.md`, `source/sections/04.md` | Normalized reader-facing Unicode mathematics to LaTeX math mode in “Common setting” prose. | Unchanged |
| EN-06 | `source/sections/03.md`, `05.md`, `08.md`, `10.md` | Broke seven long displays with `aligned` only; no expression content changed. | Unchanged |
| EN-07 | `source/sections/02.md` | Restored the Japanese manuscript's active claim that supporting-reference locations were checked. | Unchanged |
| EN-08 | package layout | Segregated build provenance, added non-mutating verifier wrapper, and made the final root normative/clean. | Unchanged |
| Freeze metadata | `supplement/typeset_english.py`, principal generated files | Changed draft identifiers/output names to final-freeze identifiers/output names. Translation logic unchanged. | Unchanged |
| Generated artifacts | `.tex`, `.md`, `.pdf`, build logs | Regenerated from the authorized source after the above changes. | Derived only |

No proof compression, theorem strengthening, hypothesis change, quantifier change, inequality change, range change, dependency change, actuality/signed-status change, criticality-scope change, or color-reversal-scope change was authorized.
