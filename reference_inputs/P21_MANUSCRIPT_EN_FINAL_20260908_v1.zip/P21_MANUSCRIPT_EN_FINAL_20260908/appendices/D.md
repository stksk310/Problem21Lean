# Specification and reproducibility of the static polynomial certificates {#app-D}

The polynomial identities used in the main text are stored as finite complete coefficient tables. These are not outputs of a finite scan of numerical semigroups.

## The \(i\)-fit for linear \(\mathcal D\) {#fr-A4.1}

For \(\Phi(a)=\widehat m-\mathcal J\) and \(a_*=fB+r\) defined in [C8.4.5](#fr-C8.4.5)–[C8.4.6](#fr-C8.4.6),

\[
\Phi(a_*)=35+\sum_{\gamma\ne0}c_\gamma\mathbf y^\gamma,
\quad c_\gamma\ge0,
\]
\[
\mathbf y=(f-1,r,\delta-1,\beta-1,g-1,\upsilon,
\alpha-1,w,\theta-1,\epsilon,k-1,a_j-1,b_k-1).
\]

All variables are nonnegative. All 715 monomials are contained in the [static coefficient table](supplement/APPENDICES/LINEAR/I_FIT_POSITIVE_COEFFICIENTS.json). Each entry in `terms` has a coefficient and an exponent vector, with exponents listed in the order specified by `variables`. The JSON names `f,delta,beta,g,alpha,theta,k,a_j,b_k` represent the corresponding shifted variables with one subtracted. The variables `r,u,w,eps` are unshifted, with `u=\upsilon` and `eps=\epsilon`. Summing all listed monomials reproduces the defining expression in the main text.

## The terminal \(i\)-fit in the Euclidean argument {#fr-A4.2}

For \(\mathcal P=\Phi(B+\nu A)\) from [E8.4](#fr-E8.4),

\[
\mathcal P=63+\sum_{\gamma\ne0}c_\gamma\mathbf y^\gamma,
\quad c_\gamma\ge0.
\]

The shifts of all variables are defined in [E8.4.3](#fr-E8.4.3), and the variable order is

```text
p0, q0, s0, t0, r0, delta0, beta0, aj0, g0, alpha0, bk0, nu0, h0, z0, x0, w0
```

All 3,234 monomials, total degree 7, and constant term 63 are stored in the [static coefficient table](supplement/APPENDICES/EUCLIDEAN/TERMINAL_POSITIVITY_COEFFICIENTS.json). Since every nonconstant coefficient is also nonnegative, the positivity conclusion follows from this explicit finite polynomial identity.

## Original and editorial notation {#fr-A4.3}

| Mathematical manuscript | Original certificate / code | Meaning |
|---|---|---|
| H_p | H | packet \(k\)-source coefficient \(T+w\) |
| 𝒟_p | D | \(\theta\chi-EH_p\) |
| 𝒨 | computed as `E+chi` | positive-integer descent measure |
| υ | u | linear-first residual |

The bytes of the static tables and the mathematical computations performed by the verifiers are unchanged from the adopted source. Only an obsolete `OPEN` status line at the end of the linear verifier was replaced there by a neutral description of the scope of the check. The [linear verifier](supplement/APPENDICES/LINEAR/verify_D_linear.py) and the [Euclidean verifier](supplement/APPENDICES/EUCLIDEAN/verify_euclidean_closure.py) expand their respective defining expressions and compare every coefficient with the static tables. In ordinary use they read the existing tables and do not regenerate them. The following commands are run from the root of the manuscript package:

```bash
python3 supplement/APPENDICES/LINEAR/verify_D_linear.py
python3 supplement/APPENDICES/EUCLIDEAN/verify_euclidean_closure.py
```

Python 3 and SymPy are required. Successful verification is an auxiliary consistency check. The actuality statements, scope conditions, choice of the first point, parameter signs, and proof of termination are established in the manuscript itself.

## The two defining expressions and evaluation procedures {#certificate-definitions}

For the first table, use the notation of [C8.4.5](#fr-C8.4.5)–[C8.4.6](#fr-C8.4.6):

\[
B=k(r+\delta)+(r+\beta),\quad a_*=fB+r,\quad
d=a+k(r+\delta),\quad S=kQ+g+\upsilon
\]

and substitute the formulas for \(a_i,b_i,\rho_j,\rho_k\) from the same subsection into

\[
\Phi(a)=-d(\rho_j\rho_k-a_jb_k)
 +S(a_i\rho_k+b_ib_k)+C(b_i\rho_j+a_ia_j)
 -(a_i\rho_k+b_ib_k)
\]

Then set \(a=a_*\), \(Q=f(a_j+g+\upsilon)+\theta\), \(C=\alpha+f\chi+w\), and \(\chi=b_k+\alpha+1+\epsilon\). This is the defining polynomial represented by the 715-term table, and its constant term is 35. The nonnegative parameter range used in the proof is stated in [C8.4.6](#fr-C8.4.6).

For the second table, use the definitions from [E8.4.2](#fr-E8.4.2)–[E8.4.3](#fr-E8.4.3) and evaluate

\[
\Phi(P)=(EA+\theta B)\rho_k-a_j(\chi A+H_pB)
 -(\theta\chi-EH_p)(P-\delta)
 -[(P-\delta)\rho_j+(P-\beta)a_j]
\]

at \(P=B+\nu A\). The quantities \(A,B\) are determined from the source matrix, with \(\rho_j=LE+M\theta-a_j\) and \(\rho_k=L\chi+MH_p-b_k\). At a terminal state, substitute

\[
\theta=h+z,\quad E=\nu(h+z)+R-h,\quad
H_p=T+w,\quad\chi=\nu(T+w)-T+1+x
\]

Expanding this expression in the following 16 variables yields the table of 3,234 terms, total degree 7, and constant term 63. The determinant-one identity is used when identifying the expression with the actual formula for \(m\), but no additional determinant constraint is needed on the nonnegative-variable domain of the expanded polynomial.

Both evaluation points are algebraic thresholds. Neither is assumed itself to satisfy the pseudo-Frobenius or first-point conditions of an actual semigroup; the lower bounds for the actual parameters are obtained by the monotonicity and multiplicity comparisons in the main text.

## The 13 variables in the first certificate {#linear-shifts}

| JSON key | Corresponding nonnegative variable |
|---|---|
| `f` | \(f-1\) |
| `r` | \(r\) |
| `delta` | \(\delta-1\) |
| `beta` | \(\beta-1\) |
| `g` | \(g-1\) |
| `u` | \(\upsilon\) |
| `alpha` | \(\alpha-1\) |
| `w` | \(w\) |
| `theta` | \(\theta-1\) |
| `eps` | \(\epsilon\) |
| `k` | \(k-1\) |
| `a_j` | \(a_j-1\) |
| `b_k` | \(b_k-1\) |

## The 16 variables in the second certificate {#euclidean-shifts}

| JSON key | Corresponding nonnegative variable |
|---|---|
| `p0` | \(p-s-1\) |
| `q0` | \(q-t\) |
| `s0` | \(s-1\) |
| `t0` | \(t-1\) |
| `r0` | \(r\) |
| `delta0` | \(\delta-1\) |
| `beta0` | \(\beta-1\) |
| `aj0` | \(a_j-1\) |
| `g0` | \(g-1\) |
| `alpha0` | \(\alpha-1\) |
| `bk0` | \(b_k-1\) |
| `nu0` | \(\nu-2\) |
| `h0` | \(h-1\) |
| `z0` | \(z\) |
| `x0` | \(x\) |
| `w0` | \(w\) |

All exponent vectors are read in the order given by `variables` in the JSON file. The key `u` in the first table is the same residual \(\upsilon\) used in the manuscript; `p0` in the second table means \(p-s-1\), and `q0` means \(q-t\), not the original variables themselves. Each `terms` entry specifies one monomial through its `coefficient` and `exponents` fields.

## Required proof data and ordinary verification {#reproducibility}

The complete coefficient tables and verifiers are included with the manuscript under `supplement/APPENDICES/LINEAR/` and `supplement/APPENDICES/EUCLIDEAN/`. Their original bytes are retained. In ordinary verification, each table is read and compared coefficient-by-coefficient with an independently expanded defining expression. The certificate-writing option is not used. Since the verifiers regenerate result JSON files in the same supplementary directories, preservation of a distribution master should be checked on a working copy of the package. From that working-copy root, run

```bash
python3 supplement/APPENDICES/LINEAR/verify_D_linear.py
python3 supplement/APPENDICES/EUCLIDEAN/verify_euclidean_closure.py
```

The Python and SymPy versions, the results of the present run, and SHA-256 hashes of the checked files are recorded in `ENGLISH_REGRESSION_REPORT.md`. Logically, the proof uses the finite identities and their complete coefficient tables specified here; a program's success message is not taken as an axiom. Computer assistance is used for the practical coefficientwise verification of the large expansions. The scope conditions, nonnegative representations, existence of the first point, and termination of the descent are proved in the manuscript. No unverified attribution concerning the discovery process is made.

---
