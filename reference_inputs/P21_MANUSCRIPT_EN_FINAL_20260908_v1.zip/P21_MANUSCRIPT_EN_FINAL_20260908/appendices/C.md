# Positivity expansions for the root analysis {#app-C}

This appendix contains only the six coefficient polynomials intrinsic to the positivity decomposition for \(\mathcal U\). Other positivity comparisons used in the main text are not duplicated here; the table below points to their authoritative locations. The domains \(C=\alpha\) and \(C>\alpha\) are to be read with the same scope separation as in the main text.

| Former duplicated node | Current authoritative location |
|---|---|
| `copy-C8.2.8` | Section 8 [C8.2.8](#fr-C8.2.8) |
| `copy-C8.2.9.1` | Section 8 [C8.2.9.1](#fr-C8.2.9.1) |
| `copy-C8.2.9.2` | Section 8 [C8.2.9.2](#fr-C8.2.9.2) |
| `copy-C8.2.11.2` | Section 8 [C8.2.11.2](#fr-C8.2.11.2) |
| `copy-C8.4.2` | Section 9 [C8.4.2](#fr-C8.4.2) |
| `copy-C8.4.3` | Section 9 [C8.4.3](#fr-C8.4.3) |
| `copy-C8.4.4` | Section 9 [C8.4.4](#fr-C8.4.4) |

## The six coefficient polynomials in the unit case {#fr-A3}

The following are the exact coefficients in POS-DECOMP. All are nonnegative, and in fact positive, for \(t,z\ge1\), \(\alpha,\eta>0\), and \(r,w\ge0\).

\[
\begin{aligned}
X_\delta={}&\alpha(tz+z+1)\\
&+\eta(t^2z^2+t^2z+2tz^2+2tz+t+z^2+z)\\
&+r(tz^2+2tz+z^2+2z+1)\\
&+w(tz^2+tz+z^2+z),
\end{aligned}
\]

\[
\begin{aligned}
Y_\delta={}&\alpha(tz+z+1)\\
&+\eta(t^2z^2+t^2z+2tz^2+3tz+t+z^2+2z+1)\\
&+r(tz^2+2tz+z^2+3z+1)\\
&+w(tz^2+tz+z^2+2z),
\end{aligned}
\]

\[
\begin{aligned}
X_\beta={}&\alpha(t+1)\\
&+\eta(t^2z+t^2+2tz+t+z)\\
&+r(tz+2t+z+2)+w(tz+t+z+1),
\end{aligned}
\]

\[
\begin{aligned}
Y_\beta={}&\alpha(t+1)\\
&+\eta(t^2z+t^2+2tz+2t+z+1)\\
&+r(tz+2t+z+3)+w(tz+t+z+2),
\end{aligned}
\]

\[
Z_\delta=z[\alpha+\eta(t+1)z+r(z+1)+wz],
\]

\[
Z_\beta=\alpha+\eta((t+1)z-1)+r(z+1)+wz.
\]

To obtain POS-DECOMP, substitute \(a=a_*\), \(C=\alpha+t\eta+r\), and \(b_k=\eta-\alpha+w\) into \(\widehat m-\mathcal J\), collect the parts in \(\delta,\beta\), and then substitute

\[
Q=(t+1)(a_j+g)+1+q'
\]

Expanding with respect to \(a_j-1,g-1,q'\) gives the displayed identity. Expanding the explicit formulas in this appendix provides a direct check.

---
