# Certificate definitions

The two complete static coefficient tables correspond exactly to Appendix D of the manuscript.

- **D-linear certificate:** manuscript Appendix D, §D.1 (`fr-A4.1`), with defining expression detailed in §D.4 (`certificate-definitions`) and 13 shifted/nonshifted variables in §D.5 (`linear-shifts`).
- **Euclidean terminal certificate:** manuscript Appendix D, §D.2 (`fr-A4.2`), with defining expression detailed in §D.4 and 16 shifted variables in §D.6 (`euclidean-shifts`).

The mathematical scope conditions, actuality statements, first-point existence, and termination argument are proved in the manuscript. The tables are finite symbolic certificates, not numerical-semigroup search output.
