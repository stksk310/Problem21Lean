#!/usr/bin/env python3
"""Exact symbolic certificates. No finite parameter search is used as proof.

Run: python verify_D_linear.py
Use --write-certificate only to reproduce the static coefficient certificate.
Normal verification requires and checks that independent static JSON file.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import sympy as sp

ROOT=Path(__file__).resolve().parent
checks=[]

def zero(name,expr):
    ex=sp.expand(expr)
    if ex!=0:
        raise RuntimeError(f'{name}: nonzero residual {sp.factor(ex)}')
    checks.append({'name':name,'status':'PASS'})

def cross(ai,bi,rj,rk,aj,bk):
    return (rj*rk-aj*bk,ai*rk+bi*bk,bi*rj+ai*aj)

def main(write_certificate: bool=False):
    # Section 1: exact first-point and multiplicity identities.
    h,d,r,de,be,aj,bk,al,g,S,tau,C,N,z,Xi=sp.symbols(
        'h d r delta beta a_j b_k alpha g S tau C N z Xi')
    b=r+de; ai=h*d+b; bi=h*d+r+be; P=h*d+r+de+be
    rj=h*S+tau; R=aj+g; T=bk+al
    V=d*rj-S*ai; Dj=d*aj+S*bi
    rk=N*C+(z-1)*bk-al+1-Xi
    II,JJ,KK=cross(ai,bi,rj,rk,aj,bk)
    mh=-d*II+S*JJ+C*KK
    If=de-1+N*d-z*ai; Jf=g-1+z*rj-N*S
    zero('slope h-cancellation',V-(d*tau-b*S))
    zero('N V identity',N*V-(rj*(If-de+1)+ai*(Jf-g+1)))
    zero('z V identity',z*V-(S*(If-de+1)+d*(Jf-g+1)))
    A=KK-N*V; B=Dj-(z-1)*V
    zero('multiplicity A B decomposition',mh-(C*A+bk*B+(al-1+Xi)*V))
    core=4*A+B+V-KK
    rhs=(C-bk-2*al-1)*A+(bk-1)*(A+B)+(al-1)*(2*A+V)+(Xi-1)*V+core
    zero('master positive-weight decomposition',mh-KK-rhs)
    A0=KK-h*V-(d-de)*rj+ai*g
    B0=d*R+S*(P-d)
    As=h*((h-1)*d+be+2*de+2*r)
    At=be-d+de+r
    zero('high h A lower decomposition',A0-(As*S+At*tau+ai*R))
    zero('high h A combined coefficient',As+At-((h*(h-1)-1)*d+(h+1)*be+(2*h+1)*(de+r)))
    Hs=(3*h*h-3*h-1)*d+(3*h+1)*be+8*h*de+7*h*r
    Ht=3*be-(h+3)*d+4*de+3*r
    Hc=aj*((3*h+1)*d+3*(de+r))+g*((4*h+1)*d+4*(de+r))
    zero('high h master core',4*A0+B0+V-KK-(Hs*S+Ht*tau+Hc))
    zero('high h core combined coefficient',Hs+Ht-((h-2)*(3*h+2)*d+(3*h+4)*be+(8*h+4)*de+(7*h+3)*r))
    # The h=1, first numerator >=2 exclusion.
    kap,rr=sp.symbols('kappa r_prime')
    db=kap*b+rr
    ai1=db+b;bi1=db+r+be;rho1=S+tau;V1=db*tau-b*S
    K1=bi1*rho1+ai1*aj
    A1=((kap+1)*b+be)*S+(be-rr)*tau+ai1*R
    B1=(kap*b+be)*S+db*R
    Ns_bound=rho1*(rr-de)+ai1*(tau-g)
    Zs_bound=S*(rr-de)+db*(tau-g)-V1
    zero('first numerator A lower',K1-Ns_bound-A1)
    zero('first numerator B lower',db*aj+S*bi1-Zs_bound-B1)
    Es=(4*kap+2)*b+4*be+de-rr
    Et=-b+3*be+de-4*rr
    Ec=aj*((4*kap+3)*b+4*rr)+g*((5*kap+4)*b+5*rr)
    zero('first numerator master core',4*A1+B1+V1-K1-(Es*S+Et*tau+Ec))
    comb=(4*kap*kap+2*kap-1)*b+(4*kap+3)*be+(kap+1)*de-(kap+4)*rr
    zero('first numerator combined coefficient',kap*Es+Et-comb)
    lower=(kap-1)*(4*kap+5)*rr+kap*(4*kap+3)*de+(4*kap+3)*be
    zero('first numerator positive lower bound',comb.subs(b,rr+de)-lower)
    # b is r+delta, so use an independent symbol for the bound substitution.
    bb=sp.Symbol('b_free')
    comb_b=(4*kap*kap+2*kap-1)*bb+(4*kap+3)*be+(kap+1)*de-(kap+4)*rr
    zero('first numerator lower with independent b',comb_b.subs(bb,rr+de)-lower)
    # Section 4: full linear-first-point parameterization, not old U scope.
    k,a,b,c,G,Q,C,chi,aj,bk=sp.symbols('k a b c G Q C chi a_j b_k')
    d0=a+k*b; ai0=d0+b;bi0=d0+c
    rhoj=G+(k+1)*Q; rhok=(k+1)*C+k*bk+chi; S0=G+k*Q
    I0,J0,K0=cross(ai0,bi0,rhoj,rhok,aj,bk)
    m0=-d0*I0+S0*J0+C*K0
    E=aj+G; BB=k*b+c; Du=Q*chi-E*(C+bk)
    Mb=C*(Q*k*(k+1)+aj*(k+1)+G*(2*k+1))+bk*(Q*k*k+aj*k+2*G*k)+chi*G
    Mc=C*(Q*(k+1)+G)+bk*(Q*k+G)
    zero('linear Du identity',m0-I0+(a+k+1)*Du-(b-1)*Mb-(c-1)*Mc)
    zero('linear derivative Phi',sp.diff(m0-J0,a)+Du+rhok+bk)
    zero('linear D packet',BB*I0+E*J0-(k+1)*m0-chi*K0)
    zero('linear intrinsic packet',m0+Q*J0-b*I0-(C+bk)*K0)
    # Static all-parameter nonnegative polynomial certificate for i-fit.
    f,r,de,be,g,u,al,w,v,eps=sp.symbols('f r delta beta g u alpha w theta eps')
    Pstar=sp.expand((m0-J0).subs({a:f*(k*b+c)+r,Q:f*(aj+G)+v,C:al+f*chi+w},simultaneous=True)
                   .subs({b:r+de,c:r+be,G:g+u}).subs(chi,bk+al+1+eps))
    variables=[f,r,de,be,g,u,al,w,v,eps,k,aj,bk]
    shifted=sp.expand(Pstar.subs({v:v+1 for v in [f,de,be,g,al,v,k,aj,bk]},simultaneous=True))
    poly=sp.Poly(shifted,*variables)
    expected={'variables':[str(x) for x in variables],
              'interpretation':'f,delta,beta,g,alpha,theta,k,a_j,b_k are shifted down by one; r,u,w,eps are unchanged.',
              'terms':[{'exponents':list(mon),'coefficient':int(co)} for mon,co in poly.terms()]}
    certpath=ROOT/'I_FIT_POSITIVE_COEFFICIENTS.json'
    if write_certificate:
        certpath.write_text(json.dumps(expected,ensure_ascii=False,indent=2)+'\n')
    data=json.loads(certpath.read_text())
    if data!=expected:raise RuntimeError('Static polynomial certificate differs from expanded expression')
    if not all(row['coefficient']>=0 for row in data['terms']):raise RuntimeError('Negative coefficient')
    constant=int(poly.coeff_monomial(1))
    if constant<=0:raise RuntimeError('No positive constant')
    reconstructed=sum(sp.Integer(t['coefficient'])*sp.prod(x**e for x,e in zip(variables,t['exponents'])) for t in data['terms'])
    zero('715-monomial exact static positivity certificate',shifted-reconstructed)
    # Final source certificate and complementary packet, in original notation.
    dd,rr,de,be,g,u,al,f,theta,w,k,chi,aj,bk=sp.symbols('d r delta beta g u alpha f theta w k chi a_j b_k')
    bb=rr+de;cc=rr+be;GG=g+u;EE=aj+GG;RR=aj+g;TT=bk+al;BB=k*bb+cc
    QQ=f*EE+theta;CC=al+f*chi+w
    ai2=dd+bb;bi2=dd+cc;rhoj2=GG+(k+1)*QQ;rhok2=(k+1)*CC+k*bk+chi
    II,JJ,KK=cross(ai2,bi2,rhoj2,rhok2,aj,bk)
    SS=GG+k*QQ;mm=-dd*II+SS*JJ+CC*KK
    P2=dd+rr+de+be
    FF=(P2-1)*II+(RR-1)*JJ+(TT-1)*KK-mm
    fc=(f+1)*(k+1)*mm+(dd+be-1-(f+1)*BB)*II+(theta-u-1)*JJ+(chi-w-1)*KK
    zero('D repeated packet final F row',FF-fc)
    Mdiamond=1+f*(k+1);Bdiamond=bb+f*BB;Kdiamond=TT+w
    zero('complementary nonnegative packet',Mdiamond*mm+theta*JJ-Bdiamond*II-Kdiamond*KK)
    qAk=(ai2-1)*II-JJ+(TT-1)*KK
    lower=Mdiamond*mm+(dd-f*BB-1)*II+(theta-1)*JJ
    zero('same PF gap reduced-depth return',qAk+(w+1)*KK-lower)
    zero('Du Euclidean form',QQ*chi-EE*(CC+bk)-(theta*chi-EE*(TT+w)))
    # Qk cone coordinate conversion. No v_K=1 is assumed.
    ell,rK,vK,bK,aK=sp.symbols('ell r_K v_K b_K a_K')
    pK=k*vK+rK;LK=vK*(k+1)+rK+ell
    qki=LK*dd-pK*ai2-vK*bi2-aK
    zero('Qk i residual reparameterized',qki-(ell*dd-vK*BB-rK*bb-aK))
    qkj=LK*SS-(pK+1)*rhoj2+vK*aj+bK
    desired=(vK*EE+(ell-1)*GG+bK)-(rK+1-k*(ell-1))*QQ
    zero('Qk j residual reparameterized',qkj-desired)
    qkk=LK*CC-vK*rhok2+pK*bk-al
    zero('Qk k residual reparameterized',qkk-(rK*(CC+bk)+ell*CC-vK*chi-al))
    # A checked packet insertion into a separately given actual FK.
    LL,AA,BBk=sp.symbols('L_k A_k B_k')
    fkval=(LL-1)*mm+(AA+be)*II+(BBk+RR)*JJ-KK
    fnew=(LL-1-Mdiamond)*mm+(AA+be+Bdiamond)*II+(BBk+RR-theta)*JJ+(Kdiamond-1)*KK
    zero('same FK complementary packet insertion',fkval-fnew)
    result={'status':'PASS','identity_count':len(checks),'checks':checks,
            'positive_polynomial':{'monomial_count':len(data['terms']),'constant_term':constant,
                                   'sha256':hashlib.sha256(certpath.read_bytes()).hexdigest()},
            'limitations':['Not an independent audit of inherited hypotheses.',
                           'Not a proof-assistant formalization of ceilings, inequalities, or scope.',
                           'No finite numerical search is used as a proof.',
                           'Mathematical closure is proved in the maintained Markdown; these checks alone do not establish it.']}
    (ROOT/'verification_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':'PASS','identities':len(checks),'positive_monomials':len(data['terms']),'constant':constant}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--write-certificate',action='store_true')
    args=p.parse_args();main(args.write_certificate)
