#!/usr/bin/env python3
"""P21: exact symbolic identities and static all-parameter positivity certificate.

This is not a proof-assistant formalization and does not audit inherited P21
classification theorems. No finite search over semigroup parameters is used as
proof. Normal execution checks, rather than creates, the coefficient table.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sympy as s

HERE = Path(__file__).resolve().parent
CHECKS: list[dict[str, str]] = []


def zero(name: str, expression: s.Expr) -> None:
    residual = s.expand(expression)
    if residual != 0:
        raise RuntimeError(f'{name}: nonzero residual {s.factor(residual)}')
    CHECKS.append({'name': name, 'status': 'PASS'})


def main(write_certificate: bool = False) -> None:
    p,q,a,b,r,de,be,aj,g,al,bk,P,E,th,ch,H = s.symbols(
        'p q s t r delta beta a_j g alpha b_k P E theta chi H')
    # Source matrix [[p,q],[s,t]]. All four entries are positive integers.
    det = p*b-q*a
    L=p+q; M=a+b
    A=p*(r+de)+q*(r+be)
    B=a*(r+de)+b*(r+be)
    R=aj+g; T=bk+al
    D=th*ch-E*H
    I0=E*A+th*B; J0=ch*A+H*B
    M0=L*E+M*th; K0=L*ch+M*H
    ai=P-be; bi=P-de
    rj=M0-aj; rk=K0-bk
    II=rj*rk-aj*bk
    JJ=ai*rk+bi*bk
    KK=bi*rj+ai*aj
    mh=I0*rk-aj*J0-D*bi
    zero('source determinant',A*M-B*L-det*(de-be))
    zero('two-packet elimination determinant',I0*K0-M0*J0+D*(A*M-B*L))
    zero('canonical Rj cross-product',rj*JJ-ai*II-bk*KK)
    zero('canonical Rk cross-product',rk*KK-bi*II-aj*JJ)
    zero('canonical Ri cross-product',(ai+bi)*II-(rj-aj)*JJ-(rk-bk)*KK)
    zero('scaled m formula modulo det=1',
         I0*II-D*KK-M0*mh-aj*D*(det-1)*(de-be))
    zero('m-minus-k strict derivative',s.diff(mh-KK,P)+D+M0)
    # The defining packets themselves, modulo the single matrix determinant.
    zero('D packet modulo det=1',B*II+E*JJ-M*mh-ch*KK
         -(be-de)*(det-1)*(E*rk-aj*ch))
    # A direct check avoiding any implicit division: follows from the other
    # elimination and determinant identities.
    zero('P packet modulo det=1',A*II+H*KK-L*mh-th*JJ
         -(de-be)*(det-1)*(th*rk-aj*H))

    nu,h,z,x,w = s.symbols('nu h z x w')
    Z=B+nu*A; N=M+nu*L
    srcj=E-nu*th; srck=nu*H-ch
    zero('one-column combined i source',Z-(B+nu*A))
    zero('one-column combined m output',N-(M+nu*L))
    # Candidate F equality is valid whenever the two original packets hold.
    ni,nj,nk,m = s.symbols('n_i n_j n_k m')
    eqD=B*ni+E*nj-M*m-ch*nk
    eqP=A*ni+H*nk-L*m-th*nj
    zero('combined packet as exact sum',
         Z*ni+srcj*nj+srck*nk-N*m-eqD-nu*eqP)
    W=(P-1)*ni+(R-1)*nj+(T-1)*nk
    final=(N-1)*m+(P-1-Z)*ni+(R-1-srcj)*nj+(T-1-srck)*nk
    zero('SAME W final certificate',(W-m)-final-eqD-nu*eqP)

    # Failure descent: quotient e, positive remainders rho and kappa.
    e,rho,kappa=s.symbols('e rho kappa')
    pp=b+e*q; qq=a+e*p; aa=q; bb=p
    LL=pp+qq; MM=aa+bb
    AA=pp*(r+be)+qq*(r+de)
    BB=aa*(r+be)+bb*(r+de)
    zero('descent source matrix determinant',pp*bb-qq*aa-det)
    zero('descent new L',LL-(M+e*L))
    zero('descent new M',MM-L)
    zero('descent new A',AA-(B+e*A))
    zero('descent new B',BB-A)
    zero('descent determinant invariant',
         (kappa*th-H*rho)-D.subs({E:e*th+rho,ch:e*H+kappa},simultaneous=True))
    zero('descent canonical new rho_j',
         LL*H+MM*kappa-bk-rk.subs(ch,e*H+kappa))
    zero('descent canonical new rho_k',
         LL*th+MM*rho-aj-rj.subs(E,e*th+rho))
    zero('strict descending measure',
         (e*th+rho+e*H+kappa)-(H+th)-((e-1)*(H+th)+rho+kappa))
    zero('new D packet is old P',BB*ni+H*nk-MM*m-th*nj-eqP)
    zero('new P packet is old D plus e old P',
         AA*ni+rho*nj-LL*m-kappa*nk
         -(eqD+e*eqP).subs({E:e*th+rho,ch:e*H+kappa},simultaneous=True))
    zero('same W under color exchange',
         W-((P-1)*ni+(T-1)*nk+(R-1)*nj))

    # Initial embedding of the latest residual into the abstract theorem.
    f,k,u=s.symbols('f k u')
    initial={p:f*k+1,q:f,a:k,b:1}
    zero('initial matrix determinant',det.subs(initial)-1)
    zero('initial L',L.subs(initial)-(1+f*(k+1)))
    zero('initial M',M.subs(initial)-(k+1))
    BB0=k*(r+de)+(r+be)
    zero('initial B',B.subs(initial)-BB0)
    zero('initial A',A.subs(initial)-((r+de)+f*BB0))
    Q=f*(R+u)+th
    C=al+f*ch+w
    zero('initial canonical rho_j',
         rj.subs(initial).subs(E,R+u)-((k+1)*Q+g+u))
    zero('initial canonical rho_k',
         rk.subs(initial).subs(H,T+w)-((k+1)*C+k*bk+ch))

    # Terminal threshold positivity. Here P is set to Z only to evaluate a
    # polynomial. This need not describe an actual semigroup.
    terminal_sub={E:nu*(h+z)+R-h, th:h+z,
                  H:T+w, ch:nu*(T+w)-T+1+x}
    phi=s.expand((mh-KK).subs(P,Z).subs(terminal_sub,simultaneous=True))
    zero('terminal j coefficient',srcj.subs(terminal_sub,simultaneous=True)-(R-h))
    zero('terminal k coefficient',srck.subs(terminal_sub,simultaneous=True)-(T-1-x))
    # L>M and det=1 imply p>=s+1 and q>=t. The positivity identity actually
    # holds without imposing det=1 after the following substitution.
    p0,q0,s0,t0,r0,d0,b0,aj0,g0,al0,bk0,nu0,h0,z0,x0,w0=s.symbols(
        'p0 q0 s0 t0 r0 delta0 beta0 aj0 g0 alpha0 bk0 nu0 h0 z0 x0 w0')
    variables=[p0,q0,s0,t0,r0,d0,b0,aj0,g0,al0,bk0,nu0,h0,z0,x0,w0]
    subs={p:s0+2+p0,q:t0+1+q0,a:s0+1,b:t0+1,
          r:r0,de:d0+1,be:b0+1,aj:aj0+1,g:g0+1,
          al:al0+1,bk:bk0+1,nu:nu0+2,h:h0+1,z:z0,x:x0,w:w0}
    polynomial=s.Poly(s.expand(phi.subs(subs,simultaneous=True)),*variables)
    table={
        'definition':'hat_m - K at P=B+nu*A, with terminal substitutions; see proof.',
        'variables':[str(v) for v in variables],
        'substitutions':{str(a):str(b) for a,b in subs.items()},
        'terms':[{'exponents':list(monomial),'coefficient':int(coefficient)}
                 for monomial,coefficient in polynomial.terms()]}
    certpath=HERE/'TERMINAL_POSITIVITY_COEFFICIENTS.json'
    if write_certificate:
        certpath.write_text(json.dumps(table,ensure_ascii=False,indent=2)+'\n')
    stored=json.loads(certpath.read_text())
    if stored != table:
        raise RuntimeError('Static coefficient table differs from the defining polynomial')
    if any(row['coefficient']<0 for row in stored['terms']):
        raise RuntimeError('Negative coefficient in terminal certificate')
    constant=int(polynomial.coeff_monomial(1))
    if constant<=0:
        raise RuntimeError('Terminal polynomial lacks a positive constant')
    reconstruction=s.Poly.from_dict({tuple(row['exponents']):s.Integer(row['coefficient'])
                                      for row in stored['terms']},*variables)
    if reconstruction != polynomial:
        raise RuntimeError('Static coefficient reconstruction failed')
    CHECKS.append({'name':'static terminal all-parameter polynomial certificate','status':'PASS'})
    result={'status':'PASS','identity_count':len(CHECKS),'checks':CHECKS,
            'terminal_positive_polynomial':{
                'monomial_count':len(stored['terms']),
                'constant_term':constant,
                'minimum_coefficient':min(row['coefficient'] for row in stored['terms']),
                'total_degree':polynomial.total_degree(),
                'sha256':hashlib.sha256(certpath.read_bytes()).hexdigest()},
            'limitations':[
                'Exact symbolic checks, not a proof-assistant formalization.',
                'Ceiling/floor case logic and well-founded descent are proved in the Markdown, not by these checks.',
                'No independent audit of inherited P21 reductions or global classifications.',
                'No finite parameter search is used as a proof.']}
    (HERE/'verification_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':'PASS','identities':len(CHECKS),
                      'positive_monomials':len(stored['terms']),'constant':constant},ensure_ascii=False))

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--write-certificate',action='store_true')
    args=parser.parse_args()
    main(args.write_certificate)
