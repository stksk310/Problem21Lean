# P21 publication supplement

This is the reader-facing reproducibility supplement for **The type of four-generated numerical semigroups with canonical reduction**.

## Included

- complete D-linear and Euclidean static coefficient tables;
- unchanged verifier scripts with their exact companion tables;
- expected output from a fresh run;
- Python/SymPy environment note;
- SHA-256 checksums;
- exact manuscript-to-certificate map.

## Excluded deliberately

Internal blind-audit reports, historical proof-search logs, AI/translation provenance, obsolete verification editions, and unrelated project archives are not part of this publication supplement.

## Reproducibility

From the supplement root:

```bash
python3 verification_scripts/LINEAR/verify_D_linear.py
python3 verification_scripts/EUCLIDEAN/verify_euclidean_closure.py
```

Expected results are `28/28`, 715 monomials, constant 35 for the D-linear check and `35/35`, 3,234 monomials, constant 63 for the Euclidean check. No finite scan of numerical semigroups is used as a proof, and no proof-assistant formal verification is claimed.

## Archival plan

Freeze the exact public release, archive it with a stable versioned URL, and deposit that release in a DOI-bearing service such as Zenodo if appropriate. Until an archive is created, use the explicit placeholder:

`[SUPPLEMENT DOI TO BE INSERTED AFTER ARCHIVE]`
