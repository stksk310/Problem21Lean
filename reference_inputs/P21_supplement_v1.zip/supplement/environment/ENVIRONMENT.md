# Verification environment

Fresh regression for this submission package was run on 8 September 2026 with:

- Python 3.13.5
- SymPy 1.14.0

The verifier scripts themselves are unchanged from the frozen verification edition. Exact output JSON and stdout are stored under `expected_outputs/`.
